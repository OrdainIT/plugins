// 1.0 - Document Ready
(function ($) {
  "use strict";
    $(document).ready(function () {
      
  });
})(jQuery);
