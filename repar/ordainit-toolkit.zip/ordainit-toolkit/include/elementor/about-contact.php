<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_About_Contact extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-about-contact';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD About Contact', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

              // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'od_about_contact_content',
			[
				'label' => __( 'About Contact Content', 'ordainit-toolkit' ),
			]
		);

        $this->add_control(
			'od_about_contact_switcher',
			[
				'label' => esc_html__( 'Icon Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->add_control(
			'od_about_contact_title_content',
			[
				'label' => __( 'Title', 'ordainit-toolkit' ),
				'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Call Us','ordainit-toolkit'),
                'label_block' => true,
			]
		);

        
		$this->add_control(
			'od_about_contact_title_phone',
			[
				'label' => __( 'Phone', 'ordainit-toolkit' ),
				'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '+91236548798','ordainit-toolkit'),
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_about_contact_title_img',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-03/about/icon.png',
				],
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
			]
		);

	


	

		$this->end_controls_section();

		$this->start_controls_section(
			'od_about_contact_content_style',
                [
                    'label' => __( 'Content Style', 'ordainit-toolkit' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
            );
        
        $this->add_control(
			'od_about_contact_content_title_color',
			[
				'label' => esc_html__( 'Title Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-tel-text span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_contact_content_title_typography',
				'selector' => '{{WRAPPER}} .it-about-2-tel-text span',
			]
		);

        $this->add_responsive_control(
            'od_about_contact_content_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-tel-text span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_contact_content_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-tel-text span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

         $this->add_control(
			'od_about_contact_content_phone_color',
			[
				'label' => esc_html__( 'Phone Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-tel-text a' => 'color: {{VALUE}}',
				],
			]
		);
     

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_contact_content_phone_typography',
				'selector' => '{{WRAPPER}} .it-about-2-tel-text a',
			]
		);

        $this->add_responsive_control(
            'od_about_contact_content_phone_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-tel-text a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_contact_content_phone_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-tel-text a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		

		$this->end_controls_section();

        $this->start_controls_section(
			'od_about_contact_icon_style',
                [
                    'label' => __( 'Icon Style', 'ordainit-toolkit' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
            );


        $this->add_control(
			'od_about_contact_icon_color',
			[
				'label' => esc_html__( 'Icon  Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-tel-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);

        
        $this->add_control(
			'od_about_contact_icon_border_color',
			[
				'label' => esc_html__( 'Border Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-tel-icon span' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();

	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_about_contact_switcher = $settings['od_about_contact_switcher'];
        $od_title_content = $settings['od_about_contact_title_content'];
        $od_title_phone = $settings['od_about_contact_title_phone'];
        $od_about_contact_title_img = $settings['od_about_contact_title_img'];

		?>
         <?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

            <div class="it-about-2-tel-box d-flex align-items-center">
                 <?php if(!empty($od_about_contact_switcher)):?>
                <div class="it-about-2-tel-icon">
                    <img src="<?php echo esc_url($od_about_contact_title_img['url'], 'ordainit-toolkit');?>" alt="">
                </div>
                <?php endif;?>
                <div class="it-about-2-tel-text">
                    <span><?php echo esc_html($od_title_content, 'ordainit-toolkit');?></span>
                    <a class="border-line-black" href="tel:<?php echo esc_attr($od_title_phone, 'ordainit-toolkit');?>"><?php echo esc_html($od_title_phone, 'ordainit-toolkit');?></a>
                </div>
            </div>




         <?php else : ?>
        <div class="it-about-2-tel-box d-flex align-items-center">
            <?php if(!empty($od_about_contact_switcher)):?>
            <div class="it-about-2-tel-icon">
                <span>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.3952 13.1277C17.1707 13.1277 15.9684 12.9362 14.8291 12.5597C14.2708 12.3693 13.5845 12.544 13.2438 12.8939L10.995 14.5915C8.38703 13.1994 6.78057 11.5934 5.40745 9.00505L7.0551 6.81484C7.48318 6.38734 7.63672 5.76286 7.45276 5.17693C7.07464 4.03161 6.88255 2.8299 6.88255 1.6049C6.8826 0.719948 6.16266 0 5.27776 0H1.60484C0.719948 0 0 0.719948 0 1.60484C0 11.7481 8.25198 20 18.3952 20C19.2801 20 20.0001 19.2801 20.0001 18.3952V14.7325C20 13.8477 19.2801 13.1277 18.3952 13.1277Z" fill="#0A0909"></path>
                    </svg>
                </span>
            </div>
            <?php endif;?>
            <div class="it-about-2-tel-text">
                <span><?php echo esc_html($od_title_content, 'ordainit-toolkit');?></span>
                <a class="border-line-black" href="tel:<?php echo esc_attr($od_title_phone, 'ordainit-toolkit');?>"><?php echo esc_html($od_title_phone, 'ordainit-toolkit');?></a>
            </div>
        </div>

        <?php endif;?>


        <?php
	}

	
}

$widgets_manager->register( new Od_About_Contact() );
