<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Full_Funfact extends Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'od-full-funfact';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Full Funfact', 'ordainit-toolkit');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'od-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'od_full_funfact_content1',
            [
                'label' => __('Funfact Content One', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_full_funfact_title1',
            [
                'label' => esc_html__('Title', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Total products', OD),
            ]
        );

        // od full funfact number1

        $this->add_control(
            'od_full_funfact_number1',
            [
                'label' => esc_html__('Number', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('835', OD),
            ]
        );

        // od full faunfact prefix1

        $this->add_control(
            'od_full_funfact_prefix1',
            [
                'label' => esc_html__('Prefix', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+', OD),
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'od_full_funfact_content2',
            [
                'label' => __('Funfact Content Two', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_full_funfact_title2',
            [
                'label' => esc_html__('Title', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('project completed', OD),
            ]
        );

        // od full funfact number1

        $this->add_control(
            'od_full_funfact_number2',
            [
                'label' => esc_html__('Number', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('6246', OD),
            ]
        );

        // od full faunfact prefix1

        $this->add_control(
            'od_full_funfact_prefix2',
            [
                'label' => esc_html__('Prefix', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+', OD),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'od_full_funfact_content3',
            [
                'label' => __('Funfact Content Three', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_full_funfact_title3',
            [
                'label' => esc_html__('Title', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Happy Customers', OD),
            ]
        );

        // od full funfact number1

        $this->add_control(
            'od_full_funfact_number3',
            [
                'label' => esc_html__('Number', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('2000', OD),
            ]
        );

        // od full faunfact prefix1

        $this->add_control(
            'od_full_funfact_prefix3',
            [
                'label' => esc_html__('Prefix', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+', OD),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'od_full_funfact_content4',
            [
                'label' => __('Funfact Content Four', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_full_funfact_title4',
            [
                'label' => esc_html__('Title', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Team Members', OD),
            ]
        );

        // od full funfact number1

        $this->add_control(
            'od_full_funfact_number4',
            [
                'label' => esc_html__('Number', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('60', OD),
            ]
        );

        // od full faunfact prefix1

        $this->add_control(
            'od_full_funfact_prefix4',
            [
                'label' => esc_html__('Prefix', OD),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+', OD),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'od_full_funfact_shap_image_area',
            [
                'label' => __('Shap Image', 'ordainit-toolkit'),
                
            ]
        );


        $this->add_control(
            'shape_image_for_funfact_shap',
            [
                'label' => esc_html__('Choose Image', OD),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
  


        $this->end_controls_section();



        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_transform',
            [
                'label' => __('Text Transform', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('None', 'ordainit-toolkit'),
                    'uppercase' => __('UPPERCASE', 'ordainit-toolkit'),
                    'lowercase' => __('lowercase', 'ordainit-toolkit'),
                    'capitalize' => __('Capitalize', 'ordainit-toolkit'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget ouodut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $od_full_funfact_title1 = $settings['od_full_funfact_title1'];
        $od_full_funfact_number1 = $settings['od_full_funfact_number1'];
        $od_full_funfact_prefix1 = $settings['od_full_funfact_prefix1'];

        $od_full_funfact_title2 = $settings['od_full_funfact_title2'];
        $od_full_funfact_number2 = $settings['od_full_funfact_number2'];
        $od_full_funfact_prefix2 = $settings['od_full_funfact_prefix2'];

        $od_full_funfact_title3 = $settings['od_full_funfact_title3'];
        $od_full_funfact_number3 = $settings['od_full_funfact_number3'];
        $od_full_funfact_prefix3 = $settings['od_full_funfact_prefix3'];

        $od_full_funfact_title4 = $settings['od_full_funfact_title4'];
        $od_full_funfact_number4 = $settings['od_full_funfact_number4'];
        $od_full_funfact_prefix4 = $settings['od_full_funfact_prefix4'];

        $od_full_funfact_shap_image = $settings['shape_image_for_funfact_shap'];

?>



        <!-- funfact-area-start -->
        <div class="it-funfact-2-area orange-bg">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="it-funfact-2-wrap flex-wrap d-md-flex justify-content-center text-center justify-content-sm-between">
                            <div class="it-funfact-item p-relative">
                                <i><b class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($od_full_funfact_number1, OD); ?>"></b><?php echo esc_html($od_full_funfact_prefix1, OD); ?></i>
                                <span><?php echo esc_html($od_full_funfact_title1, OD); ?></span>
                                <img class="it-funfact-2-shape d-none d-xl-block" src="<?php echo esc_url($od_full_funfact_shap_image['url'], OD); ?>" alt="">
                            </div>
                            <div class="it-funfact-item p-relative">
                                <i><b class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($od_full_funfact_number2, OD); ?>"></b><?php echo esc_html($od_full_funfact_prefix2, OD); ?></i>
                                <span><?php echo esc_html($od_full_funfact_title2, OD); ?></span>
                                <img class="it-funfact-2-shape d-none d-xl-block" src="<?php echo esc_url($od_full_funfact_shap_image['url'], OD); ?>" alt="">
                            </div>
                            <div class="it-funfact-item p-relative">
                                <i><b class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($od_full_funfact_number3, OD); ?>"></b><?php echo esc_html($od_full_funfact_prefix3, OD); ?></i>
                                <span><?php echo esc_html($od_full_funfact_title3, OD); ?></span>
                                <img class="it-funfact-2-shape d-none d-xl-block" src="<?php echo esc_url($od_full_funfact_shap_image['url'], OD); ?>" alt="">
                            </div>
                            <div class="it-funfact-item">
                                <i><b class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($od_full_funfact_number4, OD); ?>"></b><?php echo esc_html($od_full_funfact_prefix4, OD); ?></i>
                                <span><?php echo esc_html($od_full_funfact_title4, OD); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- funfact-area-end -->





        <script>
            "use strict";
            jQuery(document).ready(function($) {
                ////////////////////////////////////////////////////
                // 12. Counter Js
                if ($(".purecounter").length) {
                    new PureCounter({
                        filesizing: true,
                        selector: ".filesizecount",
                        pulse: 2,
                    });
                    new PureCounter();
                }


            });
        </script>
<?php
    }
}

$widgets_manager->register(new Od_Full_Funfact());
