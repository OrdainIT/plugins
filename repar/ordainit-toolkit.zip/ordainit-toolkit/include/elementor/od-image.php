<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Image extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-image';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Image', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
              // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Default Image', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Animated Image', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Animated Rptated', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();



		$this->start_controls_section(
			'od_image_section_area',
			[
				'label' => __( 'Image', 'ordainit-toolkit' ),
			]
		);

		$this->add_control(
			'od_default_image',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


        

        $this->add_group_control(
			\Elementor\Group_Control_Image_Size::get_type(),
			[
				'name' => 'od_default_image_size', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				
				'include' => [],
				'default' => 'full',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'ordainit-toolkit' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'ordainit-toolkit' ),
					'uppercase' => __( 'UPPERCASE', 'ordainit-toolkit' ),
					'lowercase' => __( 'lowercase', 'ordainit-toolkit' ),
					'capitalize' => __( 'Capitalize', 'ordainit-toolkit' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_default_image = $settings['od_default_image'];
?>
 <?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

    <div class="od-animation-image">
        <img src="<?php echo esc_url($od_default_image['url'], 'ordainit-toolkit');?>" alt="">
    </div>
 <?php elseif ( $settings['od_design_style']  == 'layout-3' ): ?>
<div class="p-relative">
	<div class="od-rotated-image">
			<img src="<?php echo esc_url($od_default_image['url'], 'ordainit-toolkit');?>" alt="">
	</div>
</div>
 <?php else: ?>


<div class="shine-hover">
    <div class="shine">
        <img  src="<?php echo esc_url($od_default_image['url'], 'ordainit-toolkit');?>" alt="" size=""> 
    </div>
</div>

<?php endif;?>

<style>

.od-animation-image {
    animation: itswing 0.9s forwards infinite alternate;
}
.od-rotated-image img {
    animation: rotate 15s linear infinite;;
}
</style>



<?php
	}

	
}

$widgets_manager->register( new Od_Image() );