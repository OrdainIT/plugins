<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Testimonial extends Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'od-testimonial';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('OD Testimonial', 'ordainit-toolkit');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'od-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
                    'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
                    'layout-5' => esc_html__('Layout 5', 'ordainit-toolkit'),
                    'layout-6' => esc_html__('Layout 6', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // od_section_title
        $this->start_controls_section(
            'od__testimonial_section_bg',
            [
                'label' => esc_html__('Background', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_bg',
            [
                'label' => esc_html__('Background Shap', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );



        $this->add_control(
            'od_testimonial_shap',
            [
                'label' => esc_html__('Background Shap', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/testimonial-shape-1.png',
                ],
            ]
        );


        $this->end_controls_section();

        // Section Settings
        $this->start_controls_section(
            'od_section_settings',
            [
                'label' => esc_html__('Settings', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ],
            ]
        );

        $this->add_control(
            'od_section_title_show',
            [
                'label' => esc_html__('Section Title & Content', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_section_subtitle_icon_show',
            [
                'label' => esc_html__('Subtitle Icon Show/Hide', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_section_slider_arrow_icon_show',
            [
                'label' => esc_html__('Arrow Icon Show/Hide', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_section_slider_auto_play_switcher',
            [
                'label' => esc_html__('Autoplay On/Off', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'ordainit-toolkit'),
                'label_off' => esc_html__('Off', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );



        $this->end_controls_section();



        // od_section_title
        $this->start_controls_section(
            'od_section_title',
            [
                'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ],
            ]
        );



        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc('basic'),
                'type' => Controls_Manager::TEXT,
                'default' => od_kses('Testimonial', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc('intermediate'),
                'type' => Controls_Manager::TEXT,
                'default' => od_kses('We’re Proud of recent same Success Work', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        // od_btn_button_group
        $this->start_controls_section(
            'od_btn_button_group',
            [
                'label' => esc_html__('Button', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3']
                ],
            ]
        );

        $this->add_control(
            'od_btn_button_show',
            [
                'label' => esc_html__('Show Button', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_button_icon',
            [
                'label' => esc_html__('Icon Show/Hide', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('All Review', 'ordainit-toolkit'),
                'title' => esc_html__('Enter button text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'od_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'od_btn_link',
            [
                'label' => esc_html__('Button link', 'ordainit-toolkit'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htods://your-link.com', 'ordainit-toolkit'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'od_btn_link_type' => '1',
                    'od_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => od_get_all_pages(),
                'condition' => [
                    'od_btn_link_type' => '2',
                    'od_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();



        // Testimonail Control
        $this->start_controls_section(
            'od_testimonial_content_area',
            [
                'label' => __('Testimonial', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ],
            ]
        );



        $this->add_control(
            'od_testimonial_content_sliders',
            [
                'label' => esc_html__('Testimonial List', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'od_testimonial_content_slider_title_extra',
                        'label' => esc_html__('Title', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Best Bicycle Repairs Services', 'ordainit-toolkit'),
                        'description' => esc_html__('Only for Layout 4', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_testimonial_content_slider_title',
                        'label' => esc_html__('Name', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Kathryn Murphy', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_testimonial_content_slider_subtitle',
                        'label' => esc_html__('Description', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Marketing Coordinator', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_testimonial_content_slider_description',
                        'label' => esc_html__('Description', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__('Descriptions', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_testimonial_content_slider_img',
                        'label' => esc_html__('Image', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/testimonial/avatar-2.png',
                        ],
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_testimonial_content_slider_rating',
                        'label' => esc_html__('Border Style', 'ordainit-toolkit'),
                        'description' => esc_html__('Only for Layout 4', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '4',
                        'options' => [
                            '1' => esc_html__('1 Star', 'ordainit-toolkit'),
                            '2' => esc_html__('2 Star', 'ordainit-toolkit'),
                            '3' => esc_html__('3 Star', 'ordainit-toolkit'),
                            '4' => esc_html__('4 Star', 'ordainit-toolkit'),
                            '5' => esc_html__('5 Star', 'ordainit-toolkit'),
                        ],
                    ],
                ],
                'default' => [
                    [
                        'od_testimonial_content_slider_title' => esc_html__('Kathryn Murphy', 'ordainit-toolkit'),
                    ],
                    [
                        'od_testimonial_content_slider_title' => esc_html__('Esther Howard', 'ordainit-toolkit'),
                    ],
                ],
                'title_field' => '{{{ od_testimonial_content_slider_title }}}',
            ]
        );


        $this->end_controls_section();

        // Testimonail Control
        $this->start_controls_section(
            'od_testimonial_content_area_6',
            [
                'label' => __('Testimonial', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-6']
                ],
            ]
        );


        $this->add_control(
            'od_testimonial_content_area_6_title',
            [
                'label' => esc_html__('Name', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Esther Howard', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_testimonial_content_area_6_designation',
            [
                'label' => esc_html__('Designation', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Marketing Coordinato', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_testimonial_content_area_6_description',
            [
                'label' => esc_html__('Description', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => od_kses('Descriptions', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_testimonial_content_area_6_imge',
            [
                'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/testimonial/avatar-1.png',
                ],
            ]
        );
        $this->add_control(
            'od_testimonial_content_area_6_shap',
            [
                'label' => esc_html__('Choose Shap', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'od_testimonial_main_area',
            [
                'label' => __('Main Area Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'od_testimonial_main_area_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-area.theme-bg' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-2.it-testimonial-bg' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-area.it-testimonial-style-2.it-testimonial-style-4.orange-bg' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-item' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'od_testimonial_main_area_slider_bg_color',
            [
                'label' => esc_html__('Slider Content BG', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-item' => 'background-color: {{VALUE}}',
                ],
            ]
        );



        $this->add_responsive_control(
            'od_testimonial_main_area_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-area.theme-bg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2.it-testimonial-bg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-area.it-testimonial-style-2.it-testimonial-style-4.orange-bg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_main_area_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-area.theme-bg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2.it-testimonial-bg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-area.it-testimonial-style-2.it-testimonial-style-4.orange-bg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        $this->end_controls_section();


        $this->start_controls_section(
            'od_testimonial_title_content_area',
            [
                'label' => __('Content Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        //Sub title
        $this->add_control(
            'od_testimonial_content_subtitle_color',
            [
                'label' => esc_html__('Sub Title Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle-2 span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle.yellow-subtitle' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle.yellow-subtitle span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle.theme-subtitle' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle.theme-subtitle span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-info span' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_content_subtitle_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2',
                    '{{WRAPPER}} .it-section-subtitle.yellow-subtitle',
                    '{{WRAPPER}} .it-section-subtitle.theme-subtitle',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-info span',
                ],
            ]
        );



        $this->add_responsive_control(
            'od_testimonial_content_subtitle_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-section-subtitle.yellow-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-section-subtitle.theme-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_content_subtitle_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-section-subtitle.yellow-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-section-subtitle.theme-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-info span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title Style
        $this->add_control(
            'od_testimonial_content_title_color',
            [
                'label' => esc_html__('Title Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
                    
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_content_title_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-section-title',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-title',
                ],
            ]
        );



        $this->add_responsive_control(
            'od_testimonial_content_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_content_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        $this->end_controls_section();


        $this->start_controls_section(
            'od_testimonial_button_area',
            [
                'label' => __('Button Style ', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3']
                ],
            ]
        );

        $this->start_controls_tabs(
            'od_testimonial_button_area_tabs'
        );

        $this->start_controls_tab(
            'od_testimonial_button_area_noraml_tab',
            [
                'label' => esc_html__('Normal', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_testimonial_button_text_noraml_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-btn.black-bg i svg' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_button_text_noraml_bgcolor',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_testimonial_button_text_noraml_border',
                'selector' => '{{WRAPPER}} .it-btn.black-bg',
            ]
        );






        $this->end_controls_tab();


        $this->start_controls_tab(
            'od_testimonial_button_area_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_testimonial_button_text_hover_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-btn.black-bg:hover i svg' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_button_text_hover_bgcolor',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_testimonial_button_text_hover_border',
                'selector' => '{{WRAPPER}} .it-btn.black-bg:hover',
            ]
        );



        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Add border radius control
        $this->add_control(
            'od_testimonial_button_area_border_radius',
            [
                'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_button_text_typography',
                'selector' => '{{WRAPPER}} .it-btn.black-bg',
            ]
        );

        $this->add_responsive_control(
            'od_testimonial_button_text_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_button_text_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn.black-bg' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );





        $this->end_controls_section();

        $this->start_controls_section(
            'od_testimonial_sldier_area',
            [
                'label' => __('Slider  Style', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']
                ],
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        );
        // Arrow Style

        $this->add_control(
            'od_testimonial_sldier_area_arrow_extra_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'od_testimonial_sldier_area_title__extra_color',
            [
                'label' => esc_html__('Title Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-4 .it-testimonial-title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-2 .it-testimonial-author-title' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_title__extra_typography',
                'selector' => '{{WRAPPER}} .it-testimonial-author-title',
            ]
        );

        $this->add_responsive_control(
            'od_testimonial_sldier_area_title__extra_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-4 .it-testimonial-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_sldier_area_title__extra_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-4 .it-testimonial-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        // Star Style

        $this->add_control(
            'od_testimonial_sldier_area_star',
            [
                'label' => esc_html__('Star', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'od_testimonial_sldier_area_title___active_star_color',
            [
                'label' => esc_html__('Active Star Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-4 .it-testimonial-ratting i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} span.it-testimonial-quote-2 svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_title__deactive_star_color',
            [
                'label' => esc_html__('Active Star Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-style-4 .it-testimonial-ratting i.grey' => 'color: {{VALUE}}',
                ],
            ]
        );




        // Title
        $this->add_control(
            'od_testimonial_sldier_area_title',
            [
                'label' => esc_html__('Name', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_title_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_title_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-title',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-title',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_testimonial_sldier_area_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_sldier_area_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Sub Title

        $this->add_control(
            'od_testimonial_sldier_area_subtitle',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]

        );

        $this->add_control(
            'od_testimonial_sldier_area_subtitle_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-info span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-info span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_subtitle_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-info span',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-info span',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_testimonial_sldier_area_subtitle_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_sldier_area_subtitle_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-author-info span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-author-info span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        // Description Style
        $this->add_control(
            'od_testimonial_sldier_area_description',
            [
                'label' => esc_html__('Description', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'od_testimonial_sldier_area_description_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-text P' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_description_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-text p',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-text P',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_testimonial_sldier_area_description_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-text P' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_testimonial_sldier_area_description_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-testimonial-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-testimonial-style-5 .it-testimonial-text P' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        // Arrow Style

        $this->add_control(
            'od_testimonial_sldier_area_arrow',
            [
                'label' => esc_html__('Arrow', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );


        $this->start_controls_tabs(
            'od_testimonial_sldier_area_arrow_tabs',
        );

        $this->start_controls_tab(
            'od_testimonial_sldier_area_arrow_normal_tab',
            [
                'label' => esc_html__('Normal', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_arrow_normal_icon_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.testimonial-style button span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_arrow_normal_icon_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.testimonial-style button span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_arrow_normnal_icon_border',
                'selector' => '{{WRAPPER}} .it-arrow-box.testimonial-style button span',
            ]
        );







        $this->end_controls_tab();

        $this->start_controls_tab(
            'od_testimonial_sldier_area_arrow_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_arrow_hover_icon_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.testimonial-style button:hover span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_testimonial_sldier_area_arrow_hover_icon_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.testimonial-style button:hover span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_testimonial_sldier_area_arrow_hover_icon_border',
                'selector' => '{{WRAPPER}} .it-arrow-box.testimonial-style button:hover span',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Add border radius control
        $this->add_control(
            'od_testimonial_sldier_area_arrow_border_radius',
            [
                'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.testimonial-style button span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );








        $this->end_controls_section();
    }

    /**
     * Render the widget ouodut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $od_testimonial_bg = $settings['od_testimonial_bg'];
        $od_testimonial_shap = $settings['od_testimonial_shap'];

        $od_sub_title = $settings['od_sub_title'];
        $od_title = $settings['od_title'];

        $od_testimonial_content_sliders = $settings['od_testimonial_content_sliders'];

        $od_section_title_show = $settings['od_section_title_show'];
        $od_section_subtitle_icon_show = $settings['od_section_subtitle_icon_show'];
        $od_section_slider_arrow_icon_show = $settings['od_section_slider_arrow_icon_show'];
        $od_section_slider_auto_play_switcher = $settings['od_section_slider_auto_play_switcher'];

        $od_btn_button_icon = $settings['od_btn_button_icon'];
        $od_btn_text = $settings['od_btn_text'];





?>

        <?php if ($settings['od_design_style']  == 'layout-2'): ?>

            <!-- testimonial-area-start -->
            <div class="it-testimonial-area it-testimonial-style-2 it-testimonial-bg grey-bg-2 fix z-index-1 p-relative pt-120 pb-40" style="background-image: url(<?php echo esc_url($od_testimonial_bg['url'], 'ordainit-toolkit'); ?>);">
                <div class="it-testimonial-shape-2">
                    <img src="<?php echo esc_url($od_testimonial_shap['url'], 'ordainit-toolkit'); ?>" alt="">
                </div>
                <div class="container">
                    <div class="it-testimonial-title-box mb-70">
                        <div class="row align-items-end">
                            <div class="col-xl-5 col-lg-6">
                                <?php if (!empty($od_section_title_show)): ?>
                                    <div class="it-testimonial-title-box">
                                        <span class="it-section-subtitle yellow-subtitle mb-15">
                                            <?php if (!empty($od_section_subtitle_icon_show)): ?>
                                                <span>
                                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>
                                            <?php echo od_kses($od_sub_title, 'ordainit-toolkit'); ?></span>
                                        <h3 class="it-section-title"> <?php echo od_kses($od_title, 'ordainit-toolkit'); ?></h3>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-xl-7 col-lg-6">
                                <?php if (!empty($od_section_slider_arrow_icon_show)): ?>
                                    <div class="it-arrow-box testimonial-style text-lg-end">
                                        <button class="slider-prev">
                                            <span>
                                                <svg width="24" height="12" viewBox="0 0 24 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0.469669 6.53033C0.176777 6.23744 0.176777 5.76256 0.469669 5.46967L5.24264 0.696699C5.53553 0.403806 6.01041 0.403806 6.3033 0.696699C6.59619 0.989593 6.59619 1.46447 6.3033 1.75736L2.06066 6L6.3033 10.2426C6.59619 10.5355 6.59619 11.0104 6.3033 11.3033C6.01041 11.5962 5.53553 11.5962 5.24264 11.3033L0.469669 6.53033ZM24 6.75H1V5.25H24V6.75Z" fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                        <button class="slider-next">
                                            <span>
                                                <svg width="24" height="12" viewBox="0 0 24 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M23.5303 6.53033C23.8232 6.23744 23.8232 5.76256 23.5303 5.46967L18.7574 0.696699C18.4645 0.403806 17.9896 0.403806 17.6967 0.696699C17.4038 0.989593 17.4038 1.46447 17.6967 1.75736L21.9393 6L17.6967 10.2426C17.4038 10.5355 17.4038 11.0104 17.6967 11.3033C17.9896 11.5962 18.4645 11.5962 18.7574 11.3033L23.5303 6.53033ZM0 6.75H23V5.25H0V6.75Z" fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="it-testimonial-slider-wrapper p-relative">
                                <div class="swiper-container it-testimonial-active-2">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($od_testimonial_content_sliders as $single_testi_item2):
                                            $single_testi_img2 = $single_testi_item2['od_testimonial_content_slider_img'];
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-testimonial-item z-index-1 p-relative">
                                                    <div class="it-testimonial-text mb-35">
                                                        <p class="mb-0"><?php echo od_kses($single_testi_item2['od_testimonial_content_slider_description'], 'ordainit-toolkit'); ?></p>
                                                    </div>
                                                    <div class="it-testimonial-author-wrap d-flex align-items-center">
                                                        <div class="it-testimonial-author-thumb">
                                                            <img src="<?php echo esc_url($single_testi_img2['url'], 'ordainit-toolkit'); ?>" alt="">
                                                        </div>
                                                        <div class="it-testimonial-author-info text-start">
                                                            <h5 class="it-testimonial-author-title"><?php echo od_kses($single_testi_item2['od_testimonial_content_slider_title'], 'ordainit-toolkit'); ?></h5>
                                                            <span><?php echo od_kses($single_testi_item2['od_testimonial_content_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                        </div>
                                                    </div>
                                                    <span class="it-testimonial-quote">
                                                        <img src="<?php echo ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/shape/testi-shape-1.png'; ?>" alt="">
                                                    </span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- testimonial-area-end -->

        <?php elseif ($settings['od_design_style']  == 'layout-3'): ?>



            <!-- testimonial-area-start -->
            <div class="it-testimonial-area it-testimonial-style-2 it-testimonial-style-3 orange-bg fix z-index-1 p-relative pt-120" style="background-image: url(<?php echo esc_url($od_testimonial_bg['url'], 'ordainit-toolkit'); ?>);">
                <div class="container">
                    <div class="it-testimonial-title-box mb-70">
                        <?php if (!empty($od_section_title_show)): ?>
                            <div class="row">
                                <div class="col-12">
                                    <div class="it-testimonial-title-box text-center">
                                        <span class="it-section-subtitle-2 mb-15">
                                            <span>
                                                <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                    <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                </svg>
                                            </span>
                                            <?php echo od_kses($od_sub_title, 'ordainit-toolkit'); ?>
                                            <span>
                                                <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                    <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                </svg>
                                            </span></span>
                                        <h3 class="it-section-title"> <?php echo od_kses($od_title, 'ordainit-toolkit'); ?></h3>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="it-testimonial-slider-wrapper p-relative p-relative">
                                <?php if (!empty($od_section_slider_arrow_icon_show)): ?>
                                    <div class="it-arrow-box d-none d-xxl-block testimonial-style text-lg-end">
                                        <button class="slider-prev">
                                            <span>
                                                <svg width="24" height="12" viewBox="0 0 24 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0.469669 6.53033C0.176777 6.23744 0.176777 5.76256 0.469669 5.46967L5.24264 0.696699C5.53553 0.403806 6.01041 0.403806 6.3033 0.696699C6.59619 0.989593 6.59619 1.46447 6.3033 1.75736L2.06066 6L6.3033 10.2426C6.59619 10.5355 6.59619 11.0104 6.3033 11.3033C6.01041 11.5962 5.53553 11.5962 5.24264 11.3033L0.469669 6.53033ZM24 6.75H1V5.25H24V6.75Z" fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                        <button class="slider-next">
                                            <span>
                                                <svg width="24" height="12" viewBox="0 0 24 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M23.5303 6.53033C23.8232 6.23744 23.8232 5.76256 23.5303 5.46967L18.7574 0.696699C18.4645 0.403806 17.9896 0.403806 17.6967 0.696699C17.4038 0.989593 17.4038 1.46447 17.6967 1.75736L21.9393 6L17.6967 10.2426C17.4038 10.5355 17.4038 11.0104 17.6967 11.3033C17.9896 11.5962 18.4645 11.5962 18.7574 11.3033L23.5303 6.53033ZM0 6.75H23V5.25H0V6.75Z" fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <div class="swiper-container it-testimonial-active-3">
                                    <div class="swiper-wrapper">

                                        <?php foreach ($od_testimonial_content_sliders as $single_testi_item3):
                                            $single_testi_img3 = $single_testi_item3['od_testimonial_content_slider_img'];
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-testimonial-item z-index-1 p-relative">
                                                    <div class="it-testimonial-text mb-35">
                                                        <p class="mb-0"><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_description'], 'ordainit-toolkit'); ?></p>
                                                    </div>
                                                    <div class="it-testimonial-author-wrap d-flex align-items-center">
                                                        <div class="it-testimonial-author-thumb">
                                                            <img src="<?php echo esc_url($single_testi_img3['url'], 'ordainit-toolkit'); ?>" alt="">
                                                        </div>
                                                        <div class="it-testimonial-author-info text-start">
                                                            <h5 class="it-testimonial-author-title"><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_title'], 'ordainit-toolkit'); ?></h5>
                                                            <span><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- testimonial-area-end -->

        <?php elseif ($settings['od_design_style']  == 'layout-4'): ?>


            <!-- testimonial-area-start -->
            <div class="it-testimonial-area it-testimonial-style-2 it-testimonial-style-4 orange-bg fix z-index-1 p-relative mt-120 pt-120 pb-120" style="background-image: url(<?php echo esc_url($od_testimonial_bg['url'], 'ordainit-toolkit'); ?>);">
                <div class="container">
                    <?php if (!empty($od_section_title_show)): ?>
                        <div class="it-testimonial-title-box mb-70">
                            <div class="row">
                                <div class="col-12">
                                    <div class="it-testimonial-title-box text-center">
                                        <span class="it-section-subtitle theme-subtitle mb-15">
                                            <?php if (!empty($od_section_subtitle_icon_show)): ?>
                                                <span>
                                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>
                                            <?php echo od_kses($od_sub_title, 'ordainit-toolkit'); ?>
                                            <?php if (!empty($od_section_subtitle_icon_show)): ?>
                                                <span>
                                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>
                                        </span>
                                        <h3 class="it-section-title theme-title"> <?php echo od_kses($od_title, 'ordainit-toolkit'); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="it-testimonial-slider-wrapper p-relative p-relative">
                                <div class="swiper-container it-testimonial-active-4">
                                    <div class="swiper-wrapper">

                                        <?php foreach ($od_testimonial_content_sliders as $single_testi_item3):
                                            $single_url_img3 = $single_testi_item3['od_testimonial_content_slider_img'];
                                            $ratingvalue = $single_testi_item3['od_testimonial_content_slider_rating']; // Get the rating value
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-testimonial-item z-index-1 p-relative">
                                                    <div class="it-testimonial-top d-flex justify-content-between align-items-center">
                                                        <h5 class="it-testimonial-title"><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_title_extra'], 'ordainit-toolkit'); ?></h5>
                                                        <div class="it-testimonial-ratting">
                                                            <?php
                                                            // Loop to display filled and gray stars based on $ratingvalue
                                                            for ($i = 1; $i <= 5; $i++) {
                                                                if ($i <= $ratingvalue) {
                                                                    echo '<i class="fa-solid fa-star"></i>'; // Filled star
                                                                } else {
                                                                    echo '<i class="fa-solid fa-star grey"></i>'; // Gray star
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="it-testimonial-text mb-25">
                                                        <p class="mb-0"><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_description'], 'ordainit-toolkit'); ?></p>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <div class="it-testimonial-author-wrap d-flex align-items-center">
                                                            <div class="it-testimonial-author-thumb">
                                                                <img src="<?php echo esc_url($single_url_img3['url'], 'ordainit-toolkit'); ?>" alt="">
                                                            </div>
                                                            <div class="it-testimonial-author-info text-start">
                                                                <h5 class="it-testimonial-author-title"><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_title'], 'ordainit-toolkit'); ?></h5>
                                                                <span><?php echo od_kses($single_testi_item3['od_testimonial_content_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                            </div>
                                                        </div>
                                                        <span class="it-testimonial-quote-2">
                                                            <svg width="71" height="50" viewBox="0 0 71 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M13.229 32.6606C11.6699 36.582 9.21313 40.4562 5.92947 44.1888C4.89005 45.3699 4.74831 47.0707 5.59872 48.3936C6.26024 49.4331 7.34682 50 8.52799 50C8.85874 50 9.18951 49.9765 9.52026 49.8583C16.4654 47.8267 32.6947 40.6216 33.1436 17.518C33.3088 8.61208 26.7889 0.958155 18.3081 0.0840931C13.607 -0.388396 8.92968 1.14702 5.45698 4.26532C1.98443 7.40727 0 11.8957 0 16.5731C0 24.3688 5.52792 31.1959 13.229 32.6606Z" fill="#FF8A71" />
                                                                <path d="M56.0111 0.0840931C51.3336 -0.388396 46.6562 1.14702 43.1837 4.26532C39.711 7.40727 37.7266 11.8957 37.7266 16.5731C37.7266 24.3688 43.2545 31.1959 50.9557 32.6606C49.3965 36.582 46.9397 40.4562 43.656 44.1887C42.6166 45.3699 42.4749 47.0707 43.3254 48.3936C43.9868 49.433 45.0735 50 46.2547 50C46.5853 50 46.9161 49.9765 47.2468 49.8582C54.1921 47.8267 70.4213 40.6216 70.8701 17.5179V17.1873C70.8701 8.42304 64.421 0.958155 56.0111 0.0840931Z" fill="#FF8A71" />
                                                            </svg>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- testimonial-area-end -->

        <?php elseif ($settings['od_design_style']  == 'layout-5'): ?>
            <div class="it-testimonial-style-7  it-testimonial-style-6  ">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="it-testimonial-slider-wrapper p-relative">
                                <div class="swiper-container it-testimonial-active">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($od_testimonial_content_sliders as $single_testi_item4):
                                            $single_testi_img4 = $single_testi_item4['od_testimonial_content_slider_img'];
                                            $ratingvalue = $single_testi_item4['od_testimonial_content_slider_rating']; // Get the rating value
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-testimonial-item z-index-1 p-relative">
                                                    <div class="it-testimonial-top mb-35 d-flex justify-content-between align-items-center">
                                                        <span class="it-testimonial-quote">
                                                            <svg width="45" height="33" viewBox="0 0 45 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M26.7363 32.6458H43.6816C44.4098 32.6458 45 32.0556 45 31.3274V14.382C45 13.6539 44.4098 13.0637 43.6816 13.0637H36.5275V1.67294C36.5275 0.945093 35.9373 0.35458 35.2091 0.35458H30.9725C30.405 0.35458 29.9014 0.717815 29.7222 1.25614L25.4859 13.9652C25.4409 14.0995 25.4179 14.2402 25.4179 14.382V31.3274C25.4179 32.0556 26.0081 32.6458 26.7363 32.6458Z" fill="currentcolor" />
                                                                <path d="M1.31832 32.6458H18.2637C18.9919 32.6458 19.582 32.0556 19.582 31.3274V14.382C19.582 13.6539 18.9919 13.0637 18.2637 13.0637H11.1092V1.67294C11.1092 0.945093 10.519 0.35458 9.79082 0.35458H5.55457C4.98706 0.35458 4.48341 0.717815 4.30385 1.25614L0.0675964 13.9652C0.0229645 14.0995 -3.8147e-05 14.2402 -3.8147e-05 14.382V31.3274C-3.8147e-05 32.0556 0.590132 32.6458 1.31832 32.6458Z" fill="currentcolor" />
                                                            </svg>
                                                        </span>
                                                        <div class="it-testimonial-ratting">
                                                            <?php
                                                            // Loop to display filled and gray stars based on $ratingvalue
                                                            for ($i = 1; $i <= 5; $i++) {
                                                                if ($i <= $ratingvalue) {
                                                                    echo '<i class="fa-solid fa-star"></i>'; // Filled star
                                                                } else {
                                                                    echo '<i class="fa-solid fa-star grey"></i>'; // Gray star
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="it-testimonial-text mb-25">
                                                        <p class="mb-0"><?php echo od_kses($single_testi_item4['od_testimonial_content_slider_description'], 'ordainit-toolkit'); ?></p>
                                                    </div>
                                                    <div class="it-testimonial-author-wrap d-flex align-items-center">
                                                        <div class="it-testimonial-author-thumb">
                                                            <img src="<?php echo esc_url($single_testi_img4['url'], 'ordainit-toolkit'); ?>" alt="">
                                                        </div>
                                                        <div class="it-testimonial-author-info text-start">
                                                            <h5 class="it-testimonial-author-title"><?php echo od_kses($single_testi_item4['od_testimonial_content_slider_title'], 'ordainit-toolkit'); ?></h5>
                                                            <span><?php echo od_kses($single_testi_item4['od_testimonial_content_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="it-arrow-box testimonial-style-2 d-none d-md-block">
                                    <button class="slider-prev">
                                        <span>
                                            <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M0.292892 8.70711C-0.0976315 8.31658 -0.0976315 7.68342 0.292892 7.29289L6.65685 0.928932C7.04738 0.538408 7.68054 0.538408 8.07107 0.928932C8.46159 1.31946 8.46159 1.95262 8.07107 2.34315L2.41421 8L8.07107 13.6569C8.46159 14.0474 8.46159 14.6805 8.07107 15.0711C7.68054 15.4616 7.04738 15.4616 6.65685 15.0711L0.292892 8.70711ZM21 9H1V7H21V9Z" fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                    <button class="slider-next">
                                        <span>
                                            <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M20.7071 8.70711C21.0976 8.31658 21.0976 7.68342 20.7071 7.29289L14.3431 0.928932C13.9526 0.538408 13.3195 0.538408 12.9289 0.928932C12.5384 1.31946 12.5384 1.95262 12.9289 2.34315L18.5858 8L12.9289 13.6569C12.5384 14.0474 12.5384 14.6805 12.9289 15.0711C13.3195 15.4616 13.9526 15.4616 14.3431 15.0711L20.7071 8.70711ZM0 9H20V7H0V9Z" fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        <?php elseif ($settings['od_design_style']  == 'layout-6'):
            $od_testimonial_content_area_6_title = $settings['od_testimonial_content_area_6_title'];
            $od_testimonial_content_area_6_designation = $settings['od_testimonial_content_area_6_designation'];
            $od_testimonial_content_area_6_description = $settings['od_testimonial_content_area_6_description'];
            $od_testimonial_content_area_6_imge = $settings['od_testimonial_content_area_6_imge'];
            $od_testimonial_content_area_6_shap = $settings['od_testimonial_content_area_6_shap'];
        ?>
            <div class="it-testimonial-style-2">
                <div class="it-testimonial-item z-index-1 p-relative">
                    <div class="it-testimonial-text mb-35">
                        <p class="mb-0"><?php echo  od_kses($od_testimonial_content_area_6_description, 'ordainit-toolkit'); ?></p>
                    </div>
                    <div class="it-testimonial-author-wrap d-flex align-items-center">
                        <div class="it-testimonial-author-thumb">
                            <img src="<?php echo  esc_url($od_testimonial_content_area_6_imge['url'], 'ordainit-toolkit'); ?>" alt="">
                        </div>
                        <div class="it-testimonial-author-info text-start">
                            <h5 class="it-testimonial-author-title"><?php echo esc_html($od_testimonial_content_area_6_title, 'ordainit-toolkit'); ?></h5>
                            <span><?php echo esc_html($od_testimonial_content_area_6_designation, 'ordainit-toolkit'); ?></span>
                        </div>
                    </div>
                    <span class="it-testimonial-quote">
                        <img src="<?php echo esc_url($od_testimonial_content_area_6_shap['url']);?>" alt="">
                    </span>
                </div>
            </div>
        <?php else:


            // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn black-bg');
            } else {
                if (! empty($settings['od_btn_link']['url'])) {
                    $this->add_link_attributes('od-button-arg', $settings['od_btn_link']);
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn black-bg');
                }
            }




        ?>
            <div class="it-testimonial-style-6 testi_style_one ">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="it-testimonial-slider-wrapper p-relative">
                                <div class="swiper-container it-testimonial-active">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($od_testimonial_content_sliders as $single_testi_item1):
                                            $single_item_img_url1 = $single_testi_item1['od_testimonial_content_slider_img'];
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-testimonial-item z-index-1 p-relative">
                                                    <div class="it-testimonial-top mb-35 d-flex justify-content-between align-items-center">
                                                        <span class="it-testimonial-quote">
                                                            <svg width="45" height="33" viewBox="0 0 45 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M26.7363 32.6458H43.6816C44.4098 32.6458 45 32.0556 45 31.3274V14.382C45 13.6539 44.4098 13.0637 43.6816 13.0637H36.5275V1.67294C36.5275 0.945093 35.9373 0.35458 35.2091 0.35458H30.9725C30.405 0.35458 29.9014 0.717815 29.7222 1.25614L25.4859 13.9652C25.4409 14.0995 25.4179 14.2402 25.4179 14.382V31.3274C25.4179 32.0556 26.0081 32.6458 26.7363 32.6458Z" fill="currentcolor" />
                                                                <path d="M1.31832 32.6458H18.2637C18.9919 32.6458 19.582 32.0556 19.582 31.3274V14.382C19.582 13.6539 18.9919 13.0637 18.2637 13.0637H11.1092V1.67294C11.1092 0.945093 10.519 0.35458 9.79082 0.35458H5.55457C4.98706 0.35458 4.48341 0.717815 4.30385 1.25614L0.0675964 13.9652C0.0229645 14.0995 -3.8147e-05 14.2402 -3.8147e-05 14.382V31.3274C-3.8147e-05 32.0556 0.590132 32.6458 1.31832 32.6458Z" fill="currentcolor" />
                                                            </svg>
                                                        </span>
                                                        <div class="it-testimonial-ratting">
                                                            <i class="fa-solid fa-star"></i>
                                                            <i class="fa-solid fa-star"></i>
                                                            <i class="fa-solid fa-star"></i>
                                                            <i class="fa-solid fa-star"></i>
                                                            <i class="fa-solid fa-star grey"></i>
                                                        </div>
                                                    </div>
                                                    <div class="it-testimonial-text mb-25">
                                                        <p class="mb-0"><?php echo od_kses($single_testi_item1['od_testimonial_content_slider_description'], 'ordainit-toolkit'); ?></p>
                                                    </div>
                                                    <div class="it-testimonial-author-wrap d-flex align-items-center">
                                                        <div class="it-testimonial-author-thumb">
                                                            <img src="<?php echo esc_url($single_item_img_url1['url'], 'ordainit-toolkit'); ?>" alt="">
                                                        </div>
                                                        <div class="it-testimonial-author-info text-start">
                                                            <h5 class="it-testimonial-author-title"><?php echo od_kses($single_testi_item1['od_testimonial_content_slider_title'], 'ordainit-toolkit'); ?></h5>
                                                            <span><?php echo od_kses($single_testi_item1['od_testimonial_content_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="it-arrow-box testimonial-style-2 d-none d-md-block">
                                    <button class="slider-prev testi_prev">
                                        <span>
                                            <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M0.292892 8.70711C-0.0976315 8.31658 -0.0976315 7.68342 0.292892 7.29289L6.65685 0.928932C7.04738 0.538408 7.68054 0.538408 8.07107 0.928932C8.46159 1.31946 8.46159 1.95262 8.07107 2.34315L2.41421 8L8.07107 13.6569C8.46159 14.0474 8.46159 14.6805 8.07107 15.0711C7.68054 15.4616 7.04738 15.4616 6.65685 15.0711L0.292892 8.70711ZM21 9H1V7H21V9Z" fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                    <button class="slider-next testi_next">
                                        <span>
                                            <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M20.7071 8.70711C21.0976 8.31658 21.0976 7.68342 20.7071 7.29289L14.3431 0.928932C13.9526 0.538408 13.3195 0.538408 12.9289 0.928932C12.5384 1.31946 12.5384 1.95262 12.9289 2.34315L18.5858 8L12.9289 13.6569C12.5384 14.0474 12.5384 14.6805 12.9289 15.0711C13.3195 15.4616 13.9526 15.4616 14.3431 15.0711L20.7071 8.70711ZM0 9H20V7H0V9Z" fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        <?php endif; ?>
        <script>
            "use strict";
            jQuery(document).ready(function($) {

                ////////////////////////////////////////////////////
                //  Swiper Js
                const testimonialswiper = new Swiper(".it-testimonial-active", {
                    speed: 1500,
                    loop: true,
                    slidesPerView: 2,
                    spaceBetween: 35,
                    autoplay: <?php echo ($od_section_slider_auto_play_switcher === 'yes') ? 'true' : 'false'; ?>,
                    breakpoints: {
                        '1400': {
                            slidesPerView: 3,
                        },
                        '1200': {
                            slidesPerView: 3,
                        },
                        '992': {
                            slidesPerView: 2,
                        },
                        '768': {
                            slidesPerView: 2,
                        },
                        '576': {
                            slidesPerView: 1,
                        },
                        '0': {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: " .testi_prev",
                        nextEl: " .testi_next",
                    },
                });


                ////////////////////////////////////////////////////
                //  Swiper Js
                const testimonial2swiper = new Swiper(".it-testimonial-active-2", {
                    speed: 1500,
                    loop: true,
                    slidesPerView: 2,
                    spaceBetween: 35,
                    autoplay: <?php echo ($od_section_slider_auto_play_switcher === 'yes') ? 'true' : 'false'; ?>,
                    breakpoints: {
                        1400: {
                            slidesPerView: 2,
                        },
                        1200: {
                            slidesPerView: 2,
                        },
                        992: {
                            slidesPerView: 2,
                        },
                        768: {
                            slidesPerView: 1,
                        },
                        576: {
                            slidesPerView: 1,
                        },
                        0: {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: ".slider-prev",
                        nextEl: ".slider-next",
                    },
                });

                ////////////////////////////////////////////////////
                //  Swiper Js
                const testimonial3swiper = new Swiper(".it-testimonial-active-3", {
                    // Optional parameters
                    speed: 1500,
                    loop: true,
                    slidesPerView: 3,
                    spaceBetween: 35,
                    autoplay: <?php echo ($od_section_slider_auto_play_switcher === 'yes') ? 'true' : 'false'; ?>,
                    breakpoints: {
                        1400: {
                            slidesPerView: 3,
                        },
                        1200: {
                            slidesPerView: 3,
                        },
                        992: {
                            slidesPerView: 2,
                        },
                        768: {
                            slidesPerView: 1,
                        },
                        576: {
                            slidesPerView: 1,
                        },
                        0: {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: ".slider-prev",
                        nextEl: ".slider-next",
                    },
                });


                ////////////////////////////////////////////////////
                //  Swiper Js
                const testimonia4swiper = new Swiper(".it-testimonial-active-4", {
                    // Optional parameters
                    speed: 1500,
                    loop: true,
                    slidesPerView: 2,
                    spaceBetween: 35,
                    autoplay: <?php echo ($od_section_slider_auto_play_switcher === 'yes') ? 'true' : 'false'; ?>,
                    breakpoints: {
                        1400: {
                            slidesPerView: 2,
                        },
                        1200: {
                            slidesPerView: 2,
                        },
                        992: {
                            slidesPerView: 2,
                        },
                        768: {
                            slidesPerView: 1,
                        },
                        576: {
                            slidesPerView: 1,
                        },
                        0: {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: ".slider-prev",
                        nextEl: ".slider-next",
                    },
                });




            });
        </script>






<?php
    }
}

$widgets_manager->register(new Od_Testimonial());
