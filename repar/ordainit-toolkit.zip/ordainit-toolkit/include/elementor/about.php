<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_About extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

              // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
                    'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
                    'layout-5' => esc_html__('Layout 5', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // od_section_title
        $this->start_controls_section(
            'od_section_title',
            [
                'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
            ]
        );

       

        $this->add_control(
            'od_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'ordainit-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
			'od_about_subtitle_icon_switcher',
			[
				'label' => esc_html__( 'Sub Title Icon Hide/Show', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('More About Us', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('General Auto repair and carThis maintenance About', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'secondary_sub_title',
            [
                'label' => esc_html__('Secondary Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Skills', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-10']
                ],

            ]
        );
         $this->add_control(
            'secondary_sub_title2',
            [
                'label' => esc_html__('Secondary 2 Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('From Any Where', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-10']
                ],
            ]
        );
       

        $this->add_control(
            'od_desctiption',
            [
                'label' => esc_html__('Description', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('section description here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type section description here', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_desctiption2',
            [
                'label' => esc_html__('Description 2', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('section description here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type section description here', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-20']
                ],
            ]
        );


 
        $this->end_controls_section();

           // Features group
        $this->start_controls_section(
            'od_about_feature_list_section',
            [
                'label' => esc_html__('Featured Items', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => [ 'layout-1']
                ],
            ]
        );

        
        $this->add_control(
			'od_about_feature_switcher1',
			[
				'label' => esc_html__( 'Featured Hide/Show', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        
        $this->add_control(
			'od_about_feature_repeater_area',
			[
				'label' => esc_html__( 'Feature Lists', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'od_about_feature_title_1',
						'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => od_kses( 'Award Winding Company' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_about_feature_description_1',
						'label' => esc_html__( 'Content', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => od_kses( 'List Content' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_about_feature_image_1',
						'label' => esc_html__( 'Icon', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
					]
				],
				'default' => [
					[
						'od_about_feature_title_1' => esc_html__( 'Award Winding Company', 'textdomain' ),
					],
					[
						'od_about_feature_title_1' => esc_html__( 'Award Winding Company', 'textdomain' ),
					],
				],
				'title_field' => '{{{ od_about_feature_title_1 }}}',
			]
		);
       




         $this->end_controls_section();

             // Features group
        $this->start_controls_section(
            'od_about_list_section_2',
            [
                'label' => esc_html__('List Items', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-2']
                ],
            ]
        );

        $this->add_control(
            'od_about_list_area_21',
            [
                'label' => esc_html__( 'List Item 1', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'od_list_2_title1',
                        'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( '24/7 call Services Availble' , 'ordainit-toolkit' ),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'od_list_2_title1' => esc_html__( '24/7 call Services Availble', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_list_2_title1' => esc_html__( 'Instant Operation & Appointment', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_list_2_title1' => esc_html__( 'From Scientific Journal', 'ordainit-toolkit' ),
                    ],
                ],
                'title_field' => '{{{ od_list_2_title1 }}}',
            ]
        );
        $this->add_control(
            'od_about_list_area_22',
            [
                'label' => esc_html__( 'List Item 2', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'od_list_2_title2',
                        'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'How to improve business' , 'ordainit-toolkit' ),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'od_list_2_title2' => esc_html__( 'How to improve business', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_list_2_title2' => esc_html__( 'Medicine & Instrument', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_list_2_title2' => esc_html__( '100% Expert Doctors', 'ordainit-toolkit' ),
                    ],
                ],
                'title_field' => '{{{ od_list_2_title2 }}}',
            ]
        );




        $this->end_controls_section();



    


        // Features group
        $this->start_controls_section(
            'od_about_feature',
            [
                'label' => esc_html__('List Items', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-4']
                ],
            ]
        );

        $this->add_control(
            'od_about_feature_switcher',
            [
                'label' => esc_html__( 'Show/Hide', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );


        $repeater = new \Elementor\Repeater();


        $repeater->add_control(
            'od_about_mission_title', [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Online Counseling', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        ); 
        $repeater->add_control(
            'od_about_mission_icon_class', [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('flaticon-counseling', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );     
        $this->add_control(
            'od_features_list',
            [
                'label' => esc_html__('List Item', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'od_about_mission_title' => esc_html__('Online Counseling', 'ordainit-toolkit'),
                        'od_about_mission_icon_class' => esc_html__('flaticon-counseling', 'ordainit-toolkit'),
                    ],   
                    [
                        'od_about_mission_title' => esc_html__('Group Therapy', 'ordainit-toolkit'),
                        'od_about_mission_icon_class' => esc_html__('flaticon-artificial-intelligence', 'ordainit-toolkit'),
                    ],
                ],
                'title_field' => '{{{ od_about_mission_title }}}',
            ]
        );

      


        $this->end_controls_section();



         // Feature Item for About 3
        $this->start_controls_section(
            'od_feature_about_3_group',
            [
                'label' => esc_html__('Features Items', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
            ]
        );
        $this->add_control(
            'od_about_3_feature_swticher',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_about_4_feature_list',
            [
                'label' => esc_html__( 'Feature List', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'od_feature_title',
                        'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Qualified Doctors' , 'ordainit-toolkit' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_feature_desc',
                        'label' => esc_html__( 'Descriptions', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__( 'Duis aute irure reprehenderit in voluptate velit.' , 'ordainit-toolkit' ),
                        'show_label' => false,
                    ],
                    [
                        'name' => 'od_feature_icon_class',
                        'label' => esc_html__( 'Icon Class', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'flaticon-doctor' , 'ordainit-toolkit' ),
                        'label_block' => true,
                    ]
                ],
                'default' => [
                    [
                        'od_feature_title' => esc_html__( 'Qualified Doctors', 'ordainit-toolkit' ),
                        'od_feature_desc' => esc_html__( 'Duis aute irure reprehenderit in voluptate velit.', 'ordainit-toolkit' ),
                        'od_feature_icon_class' => esc_html__( 'flaticon-doctor', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_feature_title' => esc_html__( 'Eye Examination', 'ordainit-toolkit' ),
                        'od_feature_desc' => esc_html__( 'Duis aute irure reprehenderit in voluptate velit.', 'ordainit-toolkit' ),
                        'od_feature_icon_class' => esc_html__( 'flaticon-eye-1', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_feature_title' => esc_html__( 'Contact Lenses', 'ordainit-toolkit' ),
                        'od_feature_desc' => esc_html__( 'Duis aute irure reprehenderit in voluptate velit.', 'ordainit-toolkit' ),
                        'od_feature_icon_class' => esc_html__( 'flaticon-contact', 'ordainit-toolkit' ),
                    ],
                    [
                        'od_feature_title' => esc_html__( 'Eye Correction', 'ordainit-toolkit' ),
                        'od_feature_desc' => esc_html__( 'Duis aute irure reprehenderit in voluptate velit.', 'ordainit-toolkit' ),
                        'od_feature_icon_class' => esc_html__( 'flaticon-eye-surgery', 'ordainit-toolkit' ),
                    ],
                ],
                'title_field' => '{{{ od_feature_title }}}',
            ]
        );


        $this->end_controls_section();


        // od_btn_button_group
        $this->start_controls_section(
            'od_btn_button_group',
            [
                'label' => esc_html__('Button', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3', 'layout-4', 'layout-5'],
                ],

            ]
        );

        $this->add_control(
            'od_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'ordainit-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
			'od_about_button_icon_switcher',
			[
				'label' => esc_html__( 'Icon Hide/Show', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
            'od_btn_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Discover More', 'ordainit-toolkit'),
                'title' => esc_html__('Enter button text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'od_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'od_btn_link',
            [
                'label' => esc_html__('Button link', 'ordainit-toolkit'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htods://your-link.com', 'ordainit-toolkit'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'od_btn_link_type' => '1',
                    'od_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => od_get_all_pages(),
                'condition' => [
                    'od_btn_link_type' => '2',
                    'od_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

            // About Contact
        $this->start_controls_section(
            'od_about_contact_area',
            [
                'label' => esc_html__('About Contact', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => [ 'layout-2', 'layout-3', 'layout-4']
                ],
            ]
        );

        $this->add_control(
            'about_contact_text',
            [
                'label' => esc_html__( 'Text', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => esc_html__( 'Emergency', 'ordainit-toolkit' ),
                'placeholder' => esc_html__( 'Type Here', 'ordainit-toolkit' ),
            ]
        ); $this->add_control(
            'about_contact_phone',
            [
                'label' => esc_html__( 'Phone Number', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__( '(+99)012356987', 'ordainit-toolkit' ),
                'placeholder' => esc_html__( 'Type Here', 'ordainit-toolkit' ),
            ]
        );

        $this->end_controls_section();

            // About Contact
        $this->start_controls_section(
            'od_about_author_info',
            [
                'label' => esc_html__('About Author', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => [ 'layout-2']
                ],
            ]
        );

        $this->add_control(
            'about_author_name',
            [
                'label' => esc_html__( 'Author Name', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__( 'Jane Cooper', 'ordainit-toolkit' ),
                'placeholder' => esc_html__( 'Type Here', 'ordainit-toolkit' ),
            ]
        ); 
        $this->add_control(
            'about_author_designation',
            [
                'label' => esc_html__( 'Designation', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__( 'co founder', 'ordainit-toolkit' ),
                'placeholder' => esc_html__( 'Type Here', 'ordainit-toolkit' ),
            ]
        );
       $this->add_control(
            'about_author_image',
            [
                'label' => esc_html__( 'Choose Image', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/avatar.png',
                ],
            ]
        );

        $this->end_controls_section();




            // Features group
        $this->start_controls_section(
            'od_about_video_button_area',
            [
                'label' => esc_html__('Video Button', 'ordainit-toolkit'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-7']
                ],
            ]
        );

        $this->add_control(
            'od_video_about_bg',
            [
                'label' => esc_html__( 'Choose Image', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/thumb-sm.png',
                ],
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label' => esc_html__( 'URL', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'ordainit-toolkit' ),
                'placeholder' => esc_html__( 'URL Here', 'ordainit-toolkit' ),
            ]
        );

        $this->end_controls_section();


 

    


        // _od_image
		$this->start_controls_section(
            'od_image',
            [
                'label' => esc_html__('Thumbnail', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'about_image11',
            [
                'label' => esc_html__( 'Choose Image', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/about/about-1.jpg',
                ],
                'condition' => [
                    'od_design_style' => ['layout-1','layout-2', 'layout-3', 'layout-4', 'layout-5'],
                ],
            ]
        );
        $this->add_control(
            'about_image12',
            [
                'label' => esc_html__( 'Choose Image 2', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/about/about-2.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-1','layout-2', 'layout-4', 'layout-5'],
                ],
            ]
        );
        $this->add_control(
            'about_image13',
            [
                'label' => esc_html__( 'Choose Image 3', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/about-shape-1.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-1','layout-2'],
                ],
            ]
        );
        $this->add_control(
            'about_popup_video_url',
            [
                'label' => esc_html__( 'URL', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'textdomain' ),
                'placeholder' => esc_html__( 'Type URL Here', 'ordainit-toolkit' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );
        $this->add_control(
            'about_image14',
            [
                'label' => esc_html__( 'Choose Image 4', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/about-shape-3.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );
        $this->add_control(
            'about_image15',
            [
                'label' => esc_html__( 'Choose Image 5', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/about-1-5.jpg',
                ],
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );
        $this->add_control(
            'about_imageshap',
            [
                'label' => esc_html__( 'Shap', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/shape-1-1.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-2',  'layout-4', 'layout-5'],
                ],
            ]
        );
        $this->add_control(
            'about_imageshap2',
            [
                'label' => esc_html__( 'Shap 2', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/shape-4-1.png',
                ],
                'condition' => [
                    'od_design_style' => [ 'layout-4'],
                ],
            ]
        );

        $this->end_controls_section();

          // _Section Experience
        $this->start_controls_section(
            '_section_experience_info',
            [
                'label' => __('Experience Info', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
            ]
        );
        $this->add_control(
        'experienced_area_switcher',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
         $this->add_control(
            'exp_nums',
            [
                'label' => __('Number', 'ordainit-toolkit'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('8+', 'ordainit-toolkit'),
                'placeholder' => __('Type number Here', 'ordainit-toolkit'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
           $this->add_control(
            'exp_titles',
                [
                    'label' => __('Title', 'ordainit-toolkit'),
                    'label_block' => true,
                    'type' => Controls_Manager::TEXT,
                    'default' => __('years of experience', 'ordainit-toolkit'),
                    'placeholder' => __('Type your text', 'ordainit-toolkit'),
                    'dynamic' => [
                        'active' => true,
                    ]
                ]
            );

        $this->end_controls_section();


      



		
        // Sub title Area Style

        $this->start_controls_section(
            'od_about_subtitle_style_section',
            [
                'label' => __( 'Sub Title Style', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_about_sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_sub_title_typography',
				'selector' => '{{WRAPPER}} .it-section-subtitle',
			]
		);

        $this->add_responsive_control(
            'od_about_sub_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_sub_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

    
       

        $this->end_controls_section();

        // Title Area Style

        $this->start_controls_section(
            'od_about_title_style_section',
            [
                'label' => __( 'Title Style', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

         $this->add_control(
			'od_about_title_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title',
			]
		);

        $this->add_responsive_control(
            'od_about_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
       

        $this->end_controls_section();

        // Description Area Style

        $this->start_controls_section(
            'od_about_description_style_section',
            [
                'label' => __( 'Description Style', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

             $this->add_control(
			'od_about_description_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-text p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_description_typography',
				'selector' => '{{WRAPPER}} .it-about-text p',
			]
		);

        $this->add_responsive_control(
            'od_about_description_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_description_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
       

        $this->end_controls_section();


        // Feature Area Style

        $this->start_controls_section(
            'od_about_featured_style_section',
            [
                'label' => __( 'Feature Style', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_about_feature_title_color',
			[
				'label' => esc_html__( 'Title Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-award-box h5' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_feature_title_typography',
				'selector' => '{{WRAPPER}} .it-about-award-box h5',
			]
		);

        $this->add_responsive_control(
            'od_about_feature_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-award-box h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_feature_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-award-box h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
         $this->add_control(
			'od_about_feature_description_color',
			[
				'label' => esc_html__( 'Description Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-award-box p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_feature_description_typography',
				'selector' => '{{WRAPPER}} .it-about-award-box p',
			]
		);

        $this->add_responsive_control(
            'od_about_feature_description_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-award-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_feature_description_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-award-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
       

        $this->end_controls_section();

        // button Area Style

        $this->start_controls_section(
            'od_about_button_style_section',
            [
                'label' => __( 'Button Style', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'od_about_button_style_tabs'
        );

        $this->start_controls_tab(
            'od_about_button_normal_style_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_about_button_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn svg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_button_normal_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'background-color: {{VALUE}}',
				],
			]
		);



         $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_about_button_normal_border_color',
				'selector' => '{{WRAPPER}} .it-btn',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'od_about_button_hover_style_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );


        $this->add_control(
			'od_about_button_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn:hover svg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_button_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        

         $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_about_button_hover_border_color',
				'selector' => '{{WRAPPER}} .it-btn:hover',
			]
		);

        

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_button__typography',
				'selector' => '{{WRAPPER}} .it-btn',
			]
		);

         
        $this->add_responsive_control(
            'od_about_button_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        
        $this->add_responsive_control(
            'od_about_button_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        
        // Add border radius control
		$this->add_control(
			'od_about_button__border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
    
       

        $this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
        $settings = $this->get_settings_for_display();


        $od_section_title_show = $settings['od_section_title_show'];
        $od_sub_title = $settings['od_sub_title'];
        $od_title = $settings['od_title'];
        $secondary_sub_title = $settings['secondary_sub_title'];
        $secondary_sub_title2 = $settings['secondary_sub_title2'];
        $od_desctiption = $settings['od_desctiption'];
        $about_image11 = $settings['about_image11'];
        $about_image12 = $settings['about_image12'];
        $about_image13 = $settings['about_image13'];
        $experienced_area_switcher = $settings['experienced_area_switcher'];
        $exp_nums = $settings['exp_nums'];
        $exp_titles = $settings['exp_titles'];
        $od_features_list = $settings['od_features_list'];
        $video_url = $settings['video_url'];
        $od_video_about_bg = $settings['od_video_about_bg'];
        $od_desctiption2 = $settings['od_desctiption2'];

        $about_contact_text = $settings['about_contact_text'];
        $about_contact_phone = $settings['about_contact_phone'];
        $od_about_list_area_21 = $settings['od_about_list_area_21'];
        $od_about_list_area_22 = $settings['od_about_list_area_22'];
        $about_author_name = $settings['about_author_name'];
        $about_author_designation = $settings['about_author_designation'];
        $about_author_image = $settings['about_author_image'];
        $about_image14 = $settings['about_image14'];
        $about_image15 = $settings['about_image15'];
        $about_imageshap = $settings['about_imageshap'];
        $od_btn_text = $settings['od_btn_text'];



        $od_about_button_icon_switcher = $settings['od_about_button_icon_switcher'];
        $od_about_feature_switcher1 = $settings['od_about_feature_switcher1'];
        $od_about_subtitle_icon_switcher = $settings['od_about_subtitle_icon_switcher'];

        ?>


        <?php if ( $settings['od_design_style']  == 'layout-2' ):



    

                     // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn-white sky-bg');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn-white sky-bg');
                }
            }

        ?>

             <!-- about-area-start -->
      <div class="it-about-area p-relative fix z-index pt-120 pb-120">
         <div class="it-about-shape-2">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/about/shape-1-2.png" alt="">
         </div>
         <div class="it-about-shape-3 d-none d-xxl-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/choose/shape-1-2.png" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center justify-content-center">
               <div class="col-xl-5 col-lg-6 col-md-10 wow itfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="it-about-left">
                     <div class="it-about-thumb-wrap p-relative d-flex justify-content-between align-items-center">
                        <div class="it-about-thumb thumb-1">
                           <img src="<?php echo esc_url($about_image11['url'], 'ordainit-toolkit');?>" alt="">
                        </div>
                        <div class="it-about-thumb-box">
                           <div class="it-about-thumb thumb-2">
                              <img src="<?php echo esc_url($about_image12['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                           <div class="it-about-thumb thumb-3">
                              <img src="<?php echo esc_url($about_image13['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                        </div>
                        <div class="it-about-thumb-box m-0">
                           <div class="it-about-thumb thumb-4">
                              <img src="<?php echo esc_url($about_image14['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                           <div class="it-about-thumb thumb-5">
                              <img src="<?php echo esc_url($about_image15['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                        </div>
                        <div class="it-about-shape-1">
                           <img src="<?php echo esc_url($about_imageshap['url'], 'ordainit-toolkit');?>" alt="">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-6 wow itfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="it-about-right">
                     <div class="it-about-title-box mb-20">
                        <span class="it-section-subtitle"><?php echo esc_html($od_sub_title, 'ordainit-toolkit');?></span>
                        <h3 class="it-section-title"><?php echo od_kses($od_title, 'ordainit-toolkit');?></h3>
                     </div>
                     <div class="it-about-text mb-30">
                      <?php echo od_kses($od_desctiption, 'ordainit-toolkit');?>
                     </div>
                     <div class="it-about-list-wrap mb-45">
                        <div class="row">
                           <div class="col-lg-6 col-md-6">
                              <div class="it-about-list style-1">
                                 <ul>
                                    <?php foreach($od_about_list_area_21 as $single_item21):?>
                                        <li><i class="flaticon-check-mark"></i><?php echo esc_html($single_item21['od_list_2_title1'], 'ordainit-toolkit');?></li>
                                    <?php endforeach;?>
                                 </ul>
                              </div>
                           </div>
                           <div class="col-lg-6 col-md-6">
                              <div class="it-about-list style-2">
                                 <ul>
                                    <?php foreach($od_about_list_area_22 as $single_item22):?>
                                        <li><i class="flaticon-check-mark"></i><?php echo esc_html($single_item22['od_list_2_title2'], 'ordainit-toolkit');?></li>
                                    <?php endforeach;?>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="it-about-bottom flex-wrap d-sm-flex align-items-center">
                        <?php if(!empty($about_author_name)):?>
                        <div class="it-about-author-info d-flex align-items-center">
                           <div class="it-about-author-thumb">
                              <img src="<?php echo esc_url($about_author_image['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                           <div class="it-about-author-text">
                              <h5><?php echo esc_html($about_author_name, 'ordainit-toolkit');?></h5>
                              <span><?php echo esc_html($about_author_designation, 'ordainit-toolkit');?></span>
                           </div>
                        </div>
                    <?php endif;?>
                        <?php if(!empty($about_contact_phone)):?>
                        <div class="it-about-tel-box d-flex align-items-center">
                           <div class="it-about-tel-icon">
                              <span><i class="flaticon-phone-call"></i></span>
                           </div>
                           <div class="it-about-tel-text">
                              <span><?php echo esc_html($about_contact_text, 'ordainit-toolkit');?></span>
                              <a href="tel:<?php echo esc_attr($about_contact_phone, 'ordainit-toolkit');?>"><?php echo esc_html($about_contact_phone, 'ordainit-toolkit');?></a>
                           </div>
                        </div>
                    <?php endif;?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->

      
  



        <?php elseif ( $settings['od_design_style']  == 'layout-3' ):
            $od_about_4_feature_list = $settings['od_about_4_feature_list'];
            $od_btn_text = $settings['od_btn_text'];
            $od_btn_button_show = $settings['od_btn_button_show'];
                  // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme tertiary-bg');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme tertiary-bg');
                }
            }

        ?>


         <!-- about-area-start -->
      <div class="it-about-3-area p-relative pt-120 pb-120">
         <div class="it-about-3-shape-1 d-none d-lg-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/about/shape-2-1.png" alt="">
         </div>   
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 order-1 order-lg-0 wow itfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="it-about-3-left p-relative">
                    <?php if(!empty($experienced_area_switcher)):?>
                     <div class="it-about-3-experience d-none d-md-flex align-items-center">
                        <h6><?php echo esc_html($exp_nums, 'ordainit-toolkit');?></h6>
                        <span><?php echo od_kses($exp_titles, 'ordainit-toolkit');?></span>
                     </div>
                 <?php endif;?>
                     <div class="it-about-3-contact d-none d-md-block text-center">
                        <?php if(!empty($about_contact_text)):?>   
                        <?php echo od_kses($about_contact_text, 'ordainit-toolkit');?>
                        <div class="it-about-3-ratting">
                           <i class="flaticon-star"></i>
                           <i class="flaticon-star"></i>
                           <i class="flaticon-star"></i>
                           <i class="flaticon-star"></i>
                           <i class="flaticon-star"></i>
                        </div>
                    <?php endif;?>
                    <?php if(!empty($about_contact_phone)):?>   
                        <a href="tel:<?php echo esc_attr($about_contact_phone, 'ordainit-toolkit');?>"><i class="flaticon-phone-call"></i><span class="hover-anim white"><?php echo esc_html($about_contact_phone, 'ordainit-toolkit');?></span></a>
                    <?php endif;?>
                     </div>
                     <div class="it-about-3-thumb">
                        <img src="<?php echo esc_url($about_image11['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 order-0 order-lg-1 wow itfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="it-about-3-right">
                     <div class="it-about-3-title-box mb-20">
                        <span class="it-section-subtitle tertiary"><?php echo esc_html($od_sub_title, 'ordainit-toolkit');?></span>
                        <h3 class="it-section-title"><?php echo od_kses($od_title, 'ordainit-toolkit');?></h3>
                     </div>
                     <div class="it-about-3-text mb-30">
                        <p><?php echo od_kses($od_desctiption, 'ordainit-toolkit');?></p>
                     </div>
                     <div class="row">
                        <?php foreach($od_about_4_feature_list as $single_item_feature):?>
                        <div class="col-md-6 col-sm-6 mb-20">
                           <div class="it-choose-staff style-1 d-flex align-items-center">
                              <div class="it-choose-staff-icon">
                                 <span><i class="<?php echo esc_attr($single_item_feature['od_feature_icon_class'], 'ordainit-toolkit');?>"></i></span>
                              </div>
                              <div class="it-choose-staff-text">
                                 <h6 class="it-choose-staff-title"><?php echo esc_html($single_item_feature['od_feature_title'], 'ordainit-toolkit');?></h6>
                                 <p class="mb-0"><?php echo od_kses($single_item_feature['od_feature_desc'], 'ordainit-toolkit');?></p>
                              </div>
                           </div>
                        </div>
                    <?php endforeach;?>

                     </div>
                    <div class="it-about-3-button mt-30">
                       <a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
                          <span class="btn-wrap">
                             <span class="text-one">
                               <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                             </span>
                             <span class="text-two">
                                <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                             </span>
                          </span>
                       </a>
                    </div> 
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->  









        <?php elseif ( $settings['od_design_style']  == 'layout-4' ):

            $od_features_list = $settings['od_features_list'];
            $about_imageshap2 = $settings['about_imageshap2'];
            $od_btn_text = $settings['od_btn_text'];
            $od_about_feature_switcher = $settings['od_about_feature_switcher'];



                  // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme grey-bg mr-55');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme grey-bg mr-55');
                }
            }
          
         
        ?>


           <!-- about-area-start -->
      <div class="it-about-2-area it-about-style-2 p-relative pt-120 pb-120">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 order-1 order-lg-0 wow itfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="it-about-4-left p-relative">
                     <div class="it-about-4-thumb-1">
                        <img src="<?php echo esc_url($about_image11['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                     <div class="it-about-4-thumb-2">
                        <img src="<?php echo esc_url($about_image12['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                     <div class="it-about-4-shape-1 d-none d-lg-block">
                        <img src="<?php echo esc_url($about_imageshap['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                     <div class="it-about-4-shape-2 d-none d-lg-block">
                        <img src="<?php echo esc_url($about_imageshap2['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 order-0 order-lg-1 wow itfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="it-about-2-right">
                     <div class="it-about-2-content">
                        <div class="it-about-2-title-box mb-20">
                           <span class="it-section-subtitle green"><?php echo esc_html($od_sub_title, 'medito');?></span>
                           <h3 class="it-section-title"><?php echo od_kses($od_title, 'medito');?></h3>
                        </div>

                        <?php echo od_kses($od_desctiption, 'medito');?>
                     <?php if(!empty($od_about_feature_switcher)):?>
                        <div class="row">
                            <?php $i=0; foreach ($od_features_list as $single_feature_item): $i++?>
                           <div class="col-lg-6 col-md-6 col-6">
                              <div class="it-about-2-icon-box style-<?php echo esc_attr($i, 'ordainit-toolkit');?>">
                                 <span><i class="<?php echo esc_attr($single_feature_item['od_about_mission_icon_class'], 'ordainit-toolkit');?>"></i></span>
                                 <h5><?php echo esc_attr($single_feature_item['od_about_mission_title'], 'ordainit-toolkit');?></h5>
                              </div>
                           </div>
                       <?php endforeach;?>
                        </div>
                    <?php endif;?>
                        <div class="it-about-2-tel-wrap mt-30 flex-wrap d-sm-flex align-items-center">
                           <a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
                              <span class="btn-wrap">
                                 <span class="text-one">
                                    <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                                 </span>
                                 <span class="text-two">
                                    <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                                 </span>
                              </span>
                           </a>
                           <?php if(!empty($about_contact_phone)):?>
                           <div class="it-about-2-tel-box d-flex align-items-center">
                              <div class="it-about-2-tel-icon">
                                 <span><i class="flaticon-message"></i></span>
                              </div>
                              <div class="it-about-2-tel-text">
                                 <span><?php echo esc_html($about_contact_text, 'ordainit-toolkit');?></span>
                                 <a class="hover-anim" href="tel:<?php echo esc_attr($about_contact_phone, 'ordainit-toolkit');?>"><?php echo esc_html($about_contact_phone, 'ordainit-toolkit');?></a>
                              </div>
                           </div>
                       <?php endif;?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->











        <?php elseif ( $settings['od_design_style']  == 'layout-5' ):
            $od_btn_text = $settings['od_btn_text'];
            $od_features_list_5 = $settings['od_features_list_5'];
                  // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme red-bg mr-35');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn-theme red-bg mr-35');
                }
            }
          

        ?>


      <!-- about-area-start -->
      <div class="it-about-5-area fix pt-120 pb-150">
         <div class="container container-1520 ">
            <div class="row align-items-center">
               <div class="col-xl-5 col-lg-5 order-1 order-lg-0">
                  <div class="it-about-5-thumb">
                     <img src="<?php echo esc_url($about_image11['url'], 'ordainit-toolkit');?>" alt="">
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 order-0 order-lg-1">
                  <div class="it-about-5-right p-relative">
                     <div class="it-about-5-shape-1 d-none d-lg-block">
                        <img src="<?php echo esc_url($about_imageshap['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                     <div class="it-about-2-title-box mb-30">
                        <span class="it-section-subtitle red-border"><?php echo esc_html($od_sub_title, 'ordainit-toolkit');?></span>
                        <h3 class="it-section-title d-block"><?php echo od_kses($od_title, 'ordainit-toolkit');?>
                        </h3>
                     </div>
                     <div class="row align-items-center align-items-xl-end">
                        <div class="col-xl-7 col-lg-7 col-md-7">
                           <div class="it-about-5-content">
                            <?php echo od_kses($od_desctiption, 'ordainit-toolkit');?>
                              <div class="it-about-5-client-wrap d-flex align-items-center">

                                <?php $i=0; foreach($od_features_list_5 as $single_feature_list): $i++;?>

                                 <div class="it-about-5-client-item style-<?php echo esc_attr($i, 'ordainit-toolkit');?>">
                                    <span><?php echo esc_html('0'.$i.'.');?> <?php echo esc_html($single_feature_list['od_about_mission_title1']);?></span>
                                    <i><b  class="purecounter" data-purecounter-duration="1"
                                       data-purecounter-end="<?php echo esc_html($single_feature_list['od_about_mission_number']);?>"></b><?php echo esc_html($single_feature_list['od_about_mission_symbol']);?></i>
                                 </div>

                                <?php endforeach;?>

                              </div>
                              <div class="it-slider-button mt-35">
                                 <a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
                                    <span class="btn-wrap">
                                       <span class="text-one">
                                         <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                                          <i>
                                             <svg width="34" height="12" viewBox="0 0 34 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M32.4512 6.67971H0.683183C0.305297 6.67971 0 6.37442 0 5.99653C0 5.61865 0.305297 5.31335 0.683183 5.31335H30.8009L26.6548 1.16728C26.3879 0.900413 26.3879 0.46702 26.6548 0.200151C26.9217 -0.0667171 27.3551 -0.0667171 27.6219 0.200151L32.9358 5.51403C33.1322 5.71045 33.1899 6.00294 33.0831 6.25913C32.9764 6.51319 32.7266 6.67971 32.4512 6.67971Z"
                                                   fill="currentcolor" />
                                                <path
                                                   d="M27.1309 12C26.9558 12 26.7808 11.9338 26.6484 11.7993C26.3815 11.5325 26.3815 11.0991 26.6484 10.8322L31.9687 5.51192C32.2355 5.24505 32.6689 5.24505 32.9358 5.51192C33.2027 5.77879 33.2027 6.21218 32.9358 6.47905L27.6155 11.7993C27.481 11.9338 27.306 12 27.1309 12Z"
                                                   fill="currentcolor" />
                                             </svg>
                                          </i>
                                       </span>
                                       <span class="text-two">
                                          <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                                          <i>
                                             <svg width="34" height="12" viewBox="0 0 34 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M32.4512 6.67971H0.683183C0.305297 6.67971 0 6.37442 0 5.99653C0 5.61865 0.305297 5.31335 0.683183 5.31335H30.8009L26.6548 1.16728C26.3879 0.900413 26.3879 0.46702 26.6548 0.200151C26.9217 -0.0667171 27.3551 -0.0667171 27.6219 0.200151L32.9358 5.51403C33.1322 5.71045 33.1899 6.00294 33.0831 6.25913C32.9764 6.51319 32.7266 6.67971 32.4512 6.67971Z"
                                                   fill="currentcolor" />
                                                <path
                                                   d="M27.1309 12C26.9558 12 26.7808 11.9338 26.6484 11.7993C26.3815 11.5325 26.3815 11.0991 26.6484 10.8322L31.9687 5.51192C32.2355 5.24505 32.6689 5.24505 32.9358 5.51192C33.2027 5.77879 33.2027 6.21218 32.9358 6.47905L27.6155 11.7993C27.481 11.9338 27.306 12 27.1309 12Z"
                                                   fill="currentcolor" />
                                             </svg>
                                          </i>
                                       </span>
                                    </span>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-xl-5 col-lg-5 col-md-5">
                           <div class="it-about-5-thumb-sm text-end">
                              <img src="<?php echo esc_url($about_image12['url'], 'ordainit-toolkit');?>" alt="">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->





     
        
      


        <?php else:

          
            $od_about_feature_repeater_area = $settings['od_about_feature_repeater_area'];

                     // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn');
                }
            }

      

        ?>

        <!-- about-area-start -->
      <div class="it-about-area z-index-1 p-relative fix pt-120 pb-120">
         <div class="it-about-shape-1  d-none d-xl-block">
            <img src="<?php echo esc_url($about_image13['url'], 'ordainit-toolkit');?>" alt="">
         </div>
         <div class="it-about-big-thumb d-none d-xxl-block">
            <img src="<?php echo esc_url($about_image12['url'], 'ordainit-toolkit');?>" alt="">
            <div class="it-about-shape-3">
               <img src="<?php echo esc_url($about_image14['url'], 'ordainit-toolkit');?>" alt="">
            </div>
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-4 col-lg-6 order-1 order-lg-0">
                  <div class="it-about-main-thumb shine-hover shine text-center text-lg-start p-relative">
                     <img src="<?php echo esc_url($about_image11['url'], 'ordainit-toolkit');?>" alt="">
                  </div>
               </div>
               <div class="col-xl-8 col-lg-6 order-0 order-lg-1">
                  <div class="it-about-left">
                     <div class="it-about-title-box mb-30">
                        <span class="it-section-subtitle mb-15">
                        <?php if(!empty($od_about_subtitle_icon_switcher)):?>
                           <span>
                              <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                 <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                              </svg>
                           </span>
                        <?php endif;?>
                           <?php echo od_kses($od_sub_title, 'ordainit-toolkit');?></span>
                        <h3 class="it-section-title pb-5"><?php echo od_kses($od_title, 'ordainit-toolkit');?></h3>
                     </div>
                     <div class="it-about-content">
                        <div class="it-about-text mb-35">
                           <p><?php echo od_kses($od_desctiption, 'ordainit-toolkit');?></p>
                        </div>
                        <?php if(!empty($od_about_feature_switcher1)):?>
                        <div class="row">
                            <?php foreach($od_about_feature_repeater_area as $single_item_feature):
                                $od_about_img_url1 = $single_item_feature['od_about_feature_image_1'];
                            
                            ?>
                           <div class="col-xl-5 col-lg-6 col-md-6 col-sm-6">
                              <div class="it-about-award-box">
                                 <span>
                                    <img src="<?php echo esc_url($od_about_img_url1['url'], 'ordainit-toolkit');?>" alt="">
                                 </span>
                                 <h5><?php echo od_kses($single_item_feature['od_about_feature_title_1'], 'ordainit-toolkit');?></h5>
                                 <p><?php echo od_kses($single_item_feature['od_about_feature_description_1'], 'ordainit-toolkit');?></p>
                              </div>
                           </div>
                           <?php endforeach;?>
                        </div>
                    <?php endif;?>
                        <div class="it-about-btn mt-40">
                           <a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
                              <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                              <?php if(!empty($od_about_button_icon_switcher)):?>
                              <i>
                                 <svg width="25" height="14" viewBox="0 0 25 14" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z"
                                       fill="currentcolor" />
                                 </svg>
                              </i>
                              <?php endif;?>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->
           



        <?php endif; ?>



        <?php

		
}
}

$widgets_manager->register( new OD_About() );