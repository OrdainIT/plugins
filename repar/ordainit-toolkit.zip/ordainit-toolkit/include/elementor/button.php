<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Button extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-button';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Od Button', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {


		// layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Style 1', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
		


        // od_btn_button_group
        $this->start_controls_section(
            'od_btn_button_group',
            [
                'label' => esc_html__('Button', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_btn_button_show_icon',
            [
                'label' => esc_html__( 'Icon Show/Hide', 'ordainit-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'ordainit-toolkit'),
                'title' => esc_html__('Enter button text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_btn_link',
            [
                'label' => esc_html__('Button link', 'ordainit-toolkit'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htods://your-link.com', 'ordainit-toolkit'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'od_btn_link_type' => '1',
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => od_get_all_pages(),
                'condition' => [
                    'od_btn_link_type' => '2',
                ]
            ]
        );




		// $service_cats = get_terms('project-categories', array('order' => 'DESC'));
		// $cat_array = array( '' => 'Select One' );
		// foreach($service_cats as $cat) {
		//     $cat_array[$cat->slug] = $cat->name;
		// }

		/**
		 * Get Post Categories
		 */
		// function od_get_categories($taxonomy)
		// {
		//     $terms = get_terms(array(
		//         'taxonomy' => $taxonomy,
		//         'hide_empty' => true,
		//     ));
		//     $options = array();
		//     if (!empty($terms) && !is_wp_error($terms)) {
		//         foreach ($terms as $term) {
		//             $options[$term->slug] = $term->name;
		//         }
		//     }
		//     return $options;
		// }


        // $this->add_control(
        //     'category',
        //     [
        //         'label' => esc_html__('Include Categories', 'ordainit-toolkit'),
        //         'description' => esc_html__('Select a category to include or leave blank for all.', 'ordainit-toolkit'),
        //         'type' => Controls_Manager::SELECT2,
        //         'multiple' => true,
        //         'options' => od_get_categories('project-categories'),
        //         'label_block' => true,
        //     ]
        // );

		$this->end_controls_section();

		$this->start_controls_section(
			'od_button_section_style',
			[
				'label' => __( 'Button Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_button_style_tabs'
		);

		$this->start_controls_tab(
			'od_button__normal_style_tab',
			[
				'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
			]
		);

		$this->add_control(
			'od_button_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn svg' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_button_bg_color',
			[
				'label' => esc_html__( 'background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_button_normal_border',
				'selector' => '{{WRAPPER}} .it-btn',
			]
		);

	
		





		$this->end_controls_tab();

			$this->start_controls_tab(
			'od_button_hover_style_tab',
			[
				'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
			]
		);

		$this->add_control(
			'od_button_hover_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn:hover svg' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_button_bg_hover_color',
			[
				'label' => esc_html__( 'background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_button_hover_border',
				'selector' => '{{WRAPPER}} .it-btn:hover',
			]
		);



		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
            'od_button_normal_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		// Add border radius control
		$this->add_control(
			'od_button_normal_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .it-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);



		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_button_typography',
				'selector' => '{{WRAPPER}} .it-btn',
			]
		);

	
		

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_btn_button_show_icon = $settings['od_btn_button_show_icon'];
        $od_btn_text = $settings['od_btn_text'];

	    // Link
	    if ('2' == $settings['od_btn_link_type']) {
	        $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
	        $this->add_render_attribute('od-button-arg', 'target', '_self');
	        $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
	        $this->add_render_attribute('od-button-arg', 'class', 'it-btn');
	    } else {
	        if ( ! empty( $settings['od_btn_link']['url'] ) ) {
	            $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
	            $this->add_render_attribute('od-button-arg', 'class', 'it-btn');
	        }
	    }

	    // Link
	    if ('2' == $settings['od_btn_link_type']) {
	        $this->add_render_attribute('od-button-arg1', 'href', get_permalink($settings['od_btn_page_link']));
	        $this->add_render_attribute('od-button-arg1', 'target', '_self');
	        $this->add_render_attribute('od-button-arg1', 'rel', 'nofollow');
	        $this->add_render_attribute('od-button-arg1', 'class', 'it-btn-theme grey-bg');
	    } else {
	        if ( ! empty( $settings['od_btn_link']['url'] ) ) {
	            $this->add_link_attributes( 'od-button-arg1', $settings['od_btn_link'] );
	            $this->add_render_attribute('od-button-arg1', 'class', 'it-btn-theme grey-bg');
	        }
	    }  
	    // Link
	    if ('2' == $settings['od_btn_link_type']) {
	        $this->add_render_attribute('od-button-arg2', 'href', get_permalink($settings['od_btn_page_link']));
	        $this->add_render_attribute('od-button-arg2', 'target', '_self');
	        $this->add_render_attribute('od-button-arg2', 'rel', 'nofollow');
	        $this->add_render_attribute('od-button-arg2', 'class', 'it-btn-theme red-bg mr-35');
	    } else {
	        if ( ! empty( $settings['od_btn_link']['url'] ) ) {
	            $this->add_link_attributes( 'od-button-arg2', $settings['od_btn_link'] );
	            $this->add_render_attribute('od-button-arg2', 'class', 'it-btn-theme red-bg mr-35');
	        }
	    }


		

		?>

	

	
		<a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
				<?php echo esc_html($od_btn_text, 'mcssa');?>
		<?php if(!empty($od_btn_button_show_icon)): ?>
			<i>
			<svg width="25" height="14" viewBox="0 0 25 14" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z" fill="currentcolor"></path>
			</svg>
			</i>
		<?php endif;?>
		</a>

	


		<?php
	}

	
}

$widgets_manager->register( new Od_Button() );
