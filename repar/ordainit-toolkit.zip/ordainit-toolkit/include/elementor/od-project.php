<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Project extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-proejct';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('OD project', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{

		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
					'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_project_content_area',
			[
				'label' => __('Project Content', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_project_content_title',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('GAFERACER 650XS', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_project_content_subtitle',
			[
				'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
				],
				'default' => od_kses('GAFERACER 650XS', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_project_content_image',
			[
				'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . '/assets/dummy/home-02/work/work-3.jpg',
				],
			]
		);



		$this->add_control(
			'od_project_content_url',
			[
				'label' => esc_html__('URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
			]
		);


		$this->end_controls_section();



		$this->start_controls_section(
			'od_project_content_area_style',
			[
				'label' => __('Content Area Style', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-1'],
				],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_project_content_area_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-content-box' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'od_project_content_area_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-work-2-content-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'od_project_content_area_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-work-2-content-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_project_content_area_border',
				'selector' => '{{WRAPPER}} .it-work-2-content-box',
			]
		);

		// Add border radius control
		$this->add_control(
			'od_project_content_area_border_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-work-2-content-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();


		// Title

		$this->start_controls_section(
			'od_project_content_area_title_style',
			[
				'label' => __('Title Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'od_project_content_area_title_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-portfolio-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_project_content_area_title__bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-2'],
				],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-portfolio-title' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_project_content_area_title_typography',
				'selector' => '{{WRAPPER}} .it-work-2-title',
				'selector' => '{{WRAPPER}} .it-portfolio-title',
			]
		);


		$this->end_controls_section();

		// Sub Title

		$this->start_controls_section(
			'od_project_content_area_subtitle_style',
			[
				'label' => __('Sub Title Style', 'ordainit-toolkit'),
				'description' => esc_html__('This Style Tab Only for Layout 1 & Layout 2', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'od_project_content_area_subtitle_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-content-box span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-portfolio-content span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_project_content_area_subtitle__bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-2'],
				],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-portfolio-content span' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_project_content_area_subtitle_typography',
				'selector' => '{{WRAPPER}} .it-work-2-content-box span',
			]
		);


		$this->end_controls_section();

		// Arrow Title

		$this->start_controls_section(
			'od_project_content_area_arrow_style',
			[
				'label' => __('Arrow Style', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-1', 'layout-3'],
				],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_project_content_area_arrow_style_tabs'
		);
		// Normal
		$this->start_controls_tab(
			'od_project_content_area_arrow_style_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_project_content_area_arrow_style_normal_color',
			[
				'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-arrow a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_project_content_area_arrow_style_normal__bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-arrow a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_project_content_area_arrow_style_normal__border',
				'selector' => '{{WRAPPER}} .it-work-2-arrow a',
			]
		);

		$this->end_controls_tab();

		// Hover
		$this->start_controls_tab(
			'od_project_content_area_arrow_style_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_project_content_area_arrow_style_hover_color',
			[
				'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-arrow a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_project_content_area_arrow_style_hover__bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-2-arrow a::after' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_project_content_area_arrow_style_hover__border',
				'selector' => '{{WRAPPER}} .it-work-2-arrow a:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		// Add border radius control
		$this->add_control(
			'od_project_content_area_arrow_style_border_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-work-2-arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();

		$od_project_content_title = $settings['od_project_content_title'];
		$od_project_content_subtitle = $settings['od_project_content_subtitle'];
		$od_project_content_image = $settings['od_project_content_image'];
		$od_project_content_url = $settings['od_project_content_url'];
?>

		<?php if ($settings['od_design_style']  == 'layout-2'): ?>
			<div class="it-portfolio-item fix p-relative">
				<a class="it-portfolio-arrow" href="<?php echo esc_url($od_project_content_url, 'ordainit-toolkit'); ?>">
					<svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M17.7071 8.70711C18.0976 8.31658 18.0976 7.68342 17.7071 7.29289L11.3431 0.928932C10.9526 0.538408 10.3195 0.538408 9.92893 0.928932C9.53841 1.31946 9.53841 1.95262 9.92893 2.34315L15.5858 8L9.92893 13.6569C9.53841 14.0474 9.53841 14.6805 9.92893 15.0711C10.3195 15.4616 10.9526 15.4616 11.3431 15.0711L17.7071 8.70711ZM0 9H17V7H0V9Z" fill="currentcolor"></path>
					</svg>
				</a>
				<div class="it-portfolio-thumb">
					<img src="<?php echo esc_url($od_project_content_image['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<div class="it-portfolio-content">
					<span><?php echo od_kses($od_project_content_subtitle, 'ordainit-toolkit'); ?></span>
					<h4 class="it-portfolio-title"><a class="border-line-black" href="<?php echo esc_url($od_project_content_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_project_content_title, 'ordainit-toolkit'); ?></a></h4>
				</div>
			</div>

		<?php elseif ($settings['od_design_style']  == 'layout-3'): ?>
			<div class="it-work-2-style-2 ">
				<div class="it-work-2-item p-relative">
					<div class="it-work-2-thumb">
						<img src="<?php echo esc_url($od_project_content_image['url'], 'ordainit-toolkit'); ?>" alt="">
					</div>
					<div class="it-work-2-content-box">
						<div class="flex-wrap d-sm-flex d-lg-flex align-items-center justify-content-between">
							<div class="it-work-2-content">
								<h4 class="it-work-2-title"><a class="border-line-white" href="<?php echo esc_url($od_project_content_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_project_content_title, 'ordainit-toolkit'); ?></a></h4>
								<span><?php echo od_kses($od_project_content_subtitle, 'ordainit-toolkit'); ?></span>
							</div>
							<div class="it-work-2-arrow">
								<a href="project-details.html">
									<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M13.9991 2.04344C14.023 1.49167 13.5952 1.02493 13.0434 1.00094L4.05193 0.61001C3.50017 0.58602 3.03343 1.01386 3.00944 1.56563C2.98545 2.11739 3.41329 2.58413 3.96506 2.60812L11.9575 2.95562L11.61 10.9481C11.586 11.4998 12.0139 11.9666 12.5656 11.9906C13.1174 12.0146 13.5841 11.5867 13.6081 11.0349L13.9991 2.04344ZM1.67572 13.7372L13.6757 2.73715L12.3243 1.26285L0.324275 12.2628L1.67572 13.7372Z" fill="currentcolor"></path>
									</svg>
								</a>
							</div>
						</div>
					</div>
				</div>

			</div>
		<?php else: ?>

			<div class="it-work-2-item p-relative">
				<div class="it-work-2-thumb">
					<img src="<?php echo esc_url($od_project_content_image['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<div class="it-work-2-content-box">
					<div class="flex-wrap d-sm-flex d-lg-flex align-items-center justify-content-between">
						<div class="it-work-2-content">
							<span><?php echo od_kses($od_project_content_subtitle, 'ordainit-toolkit'); ?></span>
							<h4 class="it-work-2-title"><a class="border-line-black" href="<?php echo esc_url($od_project_content_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_project_content_title, 'ordainit-toolkit'); ?></a></h4>
						</div>
						<div class="it-work-2-arrow">
							<a href="<?php echo esc_url($od_project_content_url, 'ordainit-toolkit'); ?>">
								<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M13.9991 2.04344C14.023 1.49167 13.5952 1.02493 13.0434 1.00094L4.05193 0.61001C3.50017 0.58602 3.03343 1.01386 3.00944 1.56563C2.98545 2.11739 3.41329 2.58413 3.96506 2.60812L11.9575 2.95562L11.61 10.9481C11.586 11.4998 12.0139 11.9666 12.5656 11.9906C13.1174 12.0146 13.5841 11.5867 13.6081 11.0349L13.9991 2.04344ZM1.67572 13.7372L13.6757 2.73715L12.3243 1.26285L0.324275 12.2628L1.67572 13.7372Z" fill="currentcolor"></path>
								</svg>
							</a>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>




		<script>
			"use strict";
			jQuery(document).ready(function($) {



			});
		</script>
<?php
	}
}

$widgets_manager->register(new Od_Project());
