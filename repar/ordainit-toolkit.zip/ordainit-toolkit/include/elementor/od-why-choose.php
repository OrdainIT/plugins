<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Why_Choose extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-why-choose';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Why Choose', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'od_why_choose_area_title_content',
			[
				'label' => __( 'Title & Content', 'ordainit-toolkit' ),
			]
		);

        $this->add_control(
			'od_why_choose_area_title',
			[
				'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses( 'Bicycle with confidence <br> After our expert repairs', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);

        $this->add_control(
			'od_why_choose_area_subtitle_icon_swithcer',
			[
				'label' => esc_html__( 'Sub Title icon Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        
        $this->add_control(
			'od_why_choose_area_subtitle__swithcer',
			[
				'label' => esc_html__( 'Sub Title Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'od_why_choose_area_subtitle',
			[
				'label' => esc_html__( 'Sub Title', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses( ' Why Choose Us', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);

        $this->add_control(
			'od_why_choose_area_description__swithcer',
			[
				'label' => esc_html__( 'Description Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'od_why_choose_area_description',
			[
				'label' => esc_html__( 'Description', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses( 'Description', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'od_why_choose_are_thumnail_content',
			[
				'label' => __( 'Thumbnail & Shap', 'ordainit-toolkit' ),
			]
		);

        $this->add_control(
			'od_why_choose_are_thumnail_image',
			[
				'label' => esc_html__( 'Thumbnail Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-04/choose/choose.jpg',
				],
			]
		);

        $this->add_control(
			'od_why_choose_are_thumnail_shap',
			[
				'label' => esc_html__( 'Shap Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-04/shape/choose.png',
				],
			]
		);

        $this->add_control(
			'od_why_choose_are_thumnail_shap2',
			[
				'label' => esc_html__( 'Shap Image 2', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-04/shape/choose-2.png',
				],
			]
		);





		$this->end_controls_section();

		$this->start_controls_section(
			'od_why_choose_are_list_content',
			[
				'label' => __( 'List Items', 'ordainit-toolkit' ),
			]
		);


        $this->add_control(
			'od_why_choose_area_list_bg_image',
			[
				'label' => esc_html__( 'Background Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-04/shape/choose-bg.png',
				],
			]
		);

        $this->add_control(
			'od_why_choose_list_items',
			[
				'label' => esc_html__( 'List Itmes', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'od_why_choose_list_title',
						'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => od_kses( '24/7 Work Process' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_why_choose_list_number',
						'label' => esc_html__( 'Number', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '01' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_why_choose_list_description',
						'label' => esc_html__( 'Description', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => od_kses( 'Lorem ipsum dolor sit amet, <br> consectetur adipiscing elit, sed <br> do eiusmod tempor incididunt.' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_why_choose_list_title' => esc_html__( '24/7 Work Process', 'ordainit-toolkit' ),
					],
					[
						'od_why_choose_list_title' => esc_html__( 'Expert Team Members', 'ordainit-toolkit' ),
					],
					[
						'od_why_choose_list_title' => esc_html__( 'Quality Time Delivery', 'ordainit-toolkit' ),
					],
				],
				'title_field' => '{{{ od_why_choose_list_title }}}',
			]
		);




		$this->end_controls_section();



         // Title & Content Style

		$this->start_controls_section(
			'od_why_choose_title_&_content_area',
			[
				'label' => __( 'Title & Content Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Sub Title

        $this->add_control(
			'od_why_choose_sub_title_style',
			[
				'label' => esc_html__( 'Sub Title Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_sub_title_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle.theme-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle.theme-subtitle span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_sub_title_style_typography',
				'selector' => '{{WRAPPER}} .it-section-subtitle.theme-subtitle',
			]
		);

        //  Title

        $this->add_control(
			'od_why_choose_title_style',
			[
				'label' => esc_html__( 'Title Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_title_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_title_style_typography',
				'selector' => '{{WRAPPER}} .it-section-title',
			]
		);
        //  Description

        $this->add_control(
			'od_why_choose_description_style',
			[
				'label' => esc_html__( 'Description Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_description_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-left p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_description_style_typography',
				'selector' => '{{WRAPPER}} .it-choose-left p',
			]
		);






	

		$this->end_controls_section();

        // List Item Style

		$this->start_controls_section(
			'od_why_choose_list_content_area',
			[
				'label' => __( 'List Item Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


          //  Item area

        $this->add_control(
			'od_why_choose_list_item_area_style',
			[
				'label' => esc_html__( 'Item Area Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_list_item_area_style_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-item-box' => 'background-color: {{VALUE}}',
				],
			]
		);


        //  Item area

        $this->add_control(
			'od_why_choose_list_item_number_style',
			[
				'label' => esc_html__( 'Item Number Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_list_item_number_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-icon' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_why_choose_list_item_number_style_hover_color',
			[
				'label' => esc_html__( 'Hover Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-item:hover .it-choose-icon' => 'color: {{VALUE}}',
				],
			]
		);


        
        $this->add_control(
			'od_why_choose_list_item_number_style_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-icon' => 'background-color: {{VALUE}}',
				],
			]
		);
        
        $this->add_control(
			'od_why_choose_list_item_number_style_hover_bg_color',
			[
				'label' => esc_html__( 'Hover Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-item:hover .it-choose-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

        	$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_list_item_number_style_typography',
				'selector' => '{{WRAPPER}} .it-choose-icon',
			]
		);


          // Item Title area

        $this->add_control(
			'od_why_choose_list_item_title_style_heading',
			[
				'label' => esc_html__( 'Item Title Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_list_item_area_style_title_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-content h5' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_list_item_area_style_title_typography',
				'selector' => '{{WRAPPER}} .it-choose-content h5',
			]
		);
          // Item Description area

        $this->add_control(
			'od_why_choose_list_item_description_style_heading',
			[
				'label' => esc_html__( 'Item Description Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_why_choose_list_item_area_style_description_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_list_item_area_style_description_typography',
				'selector' => '{{WRAPPER}} .it-choose-style-2 .it-choose-content p',
			]
		);





	

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $od_why_choose_area_title = $settings['od_why_choose_area_title'];
        $od_why_choose_area_subtitle_icon_swithcer = $settings['od_why_choose_area_subtitle_icon_swithcer'];
        $od_why_choose_area_subtitle__swithcer = $settings['od_why_choose_area_subtitle__swithcer'];
        $od_why_choose_area_subtitle = $settings['od_why_choose_area_subtitle'];
        $od_why_choose_area_description__swithcer = $settings['od_why_choose_area_description__swithcer'];
        $od_why_choose_area_description = $settings['od_why_choose_area_description'];
        $od_why_choose_are_thumnail_image = $settings['od_why_choose_are_thumnail_image'];
        $od_why_choose_area_list_bg_image = $settings['od_why_choose_area_list_bg_image'];
        $od_why_choose_are_thumnail_shap = $settings['od_why_choose_are_thumnail_shap'];
        $od_why_choose_are_thumnail_shap2 = $settings['od_why_choose_are_thumnail_shap2'];
        $od_why_choose_list_items = $settings['od_why_choose_list_items'];
?>


      <!-- choose-area-start -->
      <div class="it-choose-area it-choose-style-2 p-relative pt-170">
         <div class="it-choose-shape-3">
            <img src="<?php echo esc_url($od_why_choose_are_thumnail_shap['url'], 'ordainit-toolkit');?>" alt="">
         </div>
         <div class="it-choose-shape-2">
            <img src="<?php echo esc_url($od_why_choose_are_thumnail_shap2['url'], 'ordainit-toolkit');?>" alt="">
         </div>
         <div class="container">            
            <div class="p-relative">   
               <div class="row align-items-center align-items-xl-start">
                  <div class="col-xl-6 col-lg-6">
                     <div class="it-choose-left">
                        <div class="it-choose-title-box mb-25">
                            <?php if(!empty($od_why_choose_area_subtitle__swithcer)):?>
                            <span class="it-section-subtitle theme-subtitle mb-15">
                                <?php if(!empty($od_why_choose_area_subtitle_icon_swithcer)):?>
                                <span>
                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                    </svg>
                                </span>
                            
                                <?php endif;?>
                                    <?php echo od_kses($od_why_choose_area_subtitle, 'ordainit-toolkit');?>
                            </span>
                            <?php endif;?>
                           <h3 class="it-section-title"><?php echo od_kses($od_why_choose_area_title, 'ordainit-toolkit');?></h3>                       
                        </div>
                        <?php if(!empty($od_why_choose_area_description__swithcer)):?>
                        <p><?php echo od_kses($od_why_choose_area_description, 'ordainit-toolkit');?></p>          
                        <?php endif;?>                
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="it-choose-thumb zoom-effect w-100">
                        <img src="<?php echo esc_url($od_why_choose_are_thumnail_image['url'], 'ordainit-toolkit');?>" alt="">
                     </div>
                  </div>
               </div>  
               <div class="row">
                  <div class="col-12">
                     <div class="it-choose-item-box d-flex justify-content-between align-items-center" style="background-image: url(<?php echo esc_url($od_why_choose_area_list_bg_image['url'], 'ordainit-toolkit');?>);" >
                        <?php foreach($od_why_choose_list_items as $item):?>
                        <div class="it-choose-item">
                           <span class="it-choose-icon mb-20"><?php echo esc_html($item['od_why_choose_list_number']);?></span>
                           <div class="it-choose-content">
                              <h5><?php echo  od_kses($item['od_why_choose_list_title']);?></h5>
                              <p class=""><?php echo  od_kses($item['od_why_choose_list_description']);?></p>
                           </div>
                        </div>
                        <?php endforeach;?>
                     </div>  
                    
                  </div>   
               </div> 
            </div>         
         </div>
      </div>
      <!-- choose-area-end -->





<script>
    "use strict";
    jQuery(document).ready(function($) {

 

    });
</script>
<?php
	}

	
}

$widgets_manager->register( new Od_Why_Choose() );