<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Funfact extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-funfact';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Funfact', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
        
              // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'od_funfact_area_content',
			[
				'label' => __( 'Content', 'ordainit-toolkit' ),
			]
		);

		$this->add_control(
			'od_funfact_counter_title',
			[
				'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Car Repair Solutions', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
		$this->add_control(
			'od_funfact_counter_number',
			[
				'label' => esc_html__( 'Number', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '123', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
		$this->add_control(
			'od_funfact_counter_symbol',
			[
				'label' => esc_html__( 'Number', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '+', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
           $this->add_control(
			'od_funfact_counter_img_icon_switcher',
			[
				'label' => esc_html__( 'Icon Show/Show', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_funfact_counter_img_icon',
			[
				'label' => esc_html__( 'Icon Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $this->add_control(
			'od_funfact_counter_shap_switcher',
			[
				'label' => esc_html__( 'Shap Show/Show', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
                'label_block' => true,
			]
		);

        $this->add_control(
			'od_funfact_counter_img_shap',
			[
				'label' => esc_html__( 'Shap Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL .'assets/dummy/home-01/shape/funfact-shape-1.png',
				],
			]
		);

         




		$this->end_controls_section();

		$this->start_controls_section(
			'od_funfact_title_section_style',
			[
				'label' => __( 'Title', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_responsive_control(
            'od_funfact_align',
            [
                'label' => esc_html__('Alignment', 'ordainit-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
			'od_funfact_counter_title_color',
			[
				'label' => esc_html__( 'Title Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-item span' => 'color: {{VALUE}}',
				],
			]
		);
       $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_funfact_counter_title_typography',
				'selector' => '{{WRAPPER}} .it-funfact-item span',
			]
		);

              $this->add_responsive_control(
            'od_funfact_counter_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-funfact-item span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_funfact_counter_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-funfact-item span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


		$this->end_controls_section();

        $this->start_controls_section(
			'od_funfact_counter_section_style',
			[
				'label' => __( 'Counter Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'od_funfact_counter_color',
			[
				'label' => esc_html__( 'Counter Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-item i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_funfact_counter_typography',
				'selector' => '{{WRAPPER}} .it-funfact-item i',
			]
		);

        $this->add_responsive_control(
            'od_funfact_counter_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-funfact-item i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_funfact_counter_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-funfact-item i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
          $this->add_render_attribute('od_funfact_align', 'class', 'it-funfact-item p-relative');
        $od_funfact_counter_title = $settings['od_funfact_counter_title'];
        $od_funfact_counter_number = $settings['od_funfact_counter_number'];
        $od_funfact_counter_symbol = $settings['od_funfact_counter_symbol'];
        $od_funfact_counter_img_icon = $settings['od_funfact_counter_img_icon'];
        $od_funfact_counter_img_icon_switcher = $settings['od_funfact_counter_img_icon_switcher'];
        $od_funfact_counter_shap_switcher = $settings['od_funfact_counter_shap_switcher'];
        $od_funfact_counter_img_shap = $settings['od_funfact_counter_img_shap'];

      

?>

<div <?php echo $this->get_render_attribute_string( 'od_funfact_align' );?> >
    <?php if(!empty($od_funfact_counter_shap_switcher)):?>
    <div class="it-funfact-shape-2">
        <img src="<?php echo esc_url($od_funfact_counter_img_shap['url'], 'ordainit-toolkit');?>" alt="">
    </div>
    <?php endif;?>
    <?php if(!empty($od_funfact_counter_img_icon_switcher)):?>
    <span class="it-funfact-icon">
       <img src="<?php echo esc_url($od_funfact_counter_img_icon['url'], 'ordainit-toolkit');?>" height="58px" width="58px" alt="">
    </span>
     <?php endif;?>
    <i><b class="purecounter" data-purecounter-duration="0" data-purecounter-end="<?php echo esc_attr($od_funfact_counter_number, 'ordainit-toolkit');?>"><?php echo esc_html($od_funfact_counter_number, 'ordainit-toolkit');?></b><?php echo esc_html($od_funfact_counter_symbol, 'ordainit-toolkit');?></i>
    <span><?php echo esc_html($od_funfact_counter_title, 'ordainit-toolkit');?></span>
</div>




<style>
    .elementor-widget-container .it-funfact-shape-2{
        z-index: 1;
    }
</style>


<?php
	}

	
}

$widgets_manager->register( new Od_Funfact() );