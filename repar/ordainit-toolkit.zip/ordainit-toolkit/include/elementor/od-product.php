<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Product extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-product';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('OD Product', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{

		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_section_content',
			[
				'label' => __('Product Query', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'prodcut_per_page',
			[
				'label' => __('Product Per Page', 'ordainit-toolkit'),
				'type' => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);

		$this->add_control(
			'product_column',
			[
				'label' => __('Product Columns', 'ordainit-toolkit'),
				'type' => Controls_Manager::NUMBER,
				'default' => 2,
			]
		);


		$post_type = 'products';
		$taxonomy = 'product_cat';

		$this->add_control(
			'categories',
			[
				'label' => esc_html__('Include Categories', 'ordainit-toolkit'),
				'description' => esc_html__('Select a category to include or leave blank for all.', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => od_get_categories($taxonomy),
				'label_block' => true,
			]
		);







		$this->end_controls_section();

		$this->start_controls_section(
			'od_product_column_area',
			[
				'label' => __('Product Column', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => 'layout-2',
				],
			]
		);


		// text control

		$this->add_control(
			'od_product_column_col_xl',
			[
				'label' => __('Row Col XL', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => __('3', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_product_column_col_lg',
			[
				'label' => __('Row Col LG', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => __('2', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_product_column_col_md',
			[
				'label' => __('Row Col MD', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => __('1', 'ordainit-toolkit'),
			]
		);





		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __('Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __('Text Transform', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __('None', 'ordainit-toolkit'),
					'uppercase' => __('UPPERCASE', 'ordainit-toolkit'),
					'lowercase' => __('lowercase', 'ordainit-toolkit'),
					'capitalize' => __('Capitalize', 'ordainit-toolkit'),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();

		// Get settings
		$prodcut_per_page = !empty($settings['prodcut_per_page']) ? intval($settings['prodcut_per_page']) : -1; // Default to -1 for all products
		$product_column = !empty($settings['product_column']) ? intval($settings['product_column']) : 4; // Default to 4 columns
		$categories = !empty($settings['categories']) ? $settings['categories'] : array(); // Assume this is an array of selected category slugs
		$od_design_style = $settings['od_design_style'];
		global $od_design_style_global;
		$od_design_style_global = $od_design_style;


		$widget_id = !empty($this->get_id()) ? 'elementor-widget-' . esc_attr($this->get_id()) : '';
?>


		<?php if ($od_design_style == 'layout-1'): ?>
			<div class="od-product-widget <?php echo $widget_id; ?>">
				<?php

				echo do_shortcode("[products limit='$prodcut_per_page' columns='$product_column' category='" . implode(',', $categories) . "']");
				?>
			</div>

		<?php else:

			$od_product_column_col_xl = $settings['od_product_column_col_xl'];
			$od_product_column_col_lg = $settings['od_product_column_col_lg'];
			$od_product_column_col_md = $settings['od_product_column_col_md'];

		?>

			<div class="od-product-widget it-product-style-2 woocommerce <?php echo $widget_id; ?>">
				<div class="container">
					<div class="row row-cols-xl-<?php echo esc_attr($od_product_column_col_xl); ?> row-cols-lg-<?php echo esc_attr($od_product_column_col_lg); ?> row-cols-md-<?php echo esc_attr($od_product_column_col_md); ?> row-cols-1">
						<?php
						$args = array(
							'post_type' => 'product',
							'posts_per_page' => $prodcut_per_page, // Number of products to display
							'orderby' => 'date',
							'order' => 'DESC',
						);

						$query = new \WP_Query($args);


						if ($query->have_posts()) :
							while ($query->have_posts()) : $query->the_post();
								global $product;

								$product_id = $product->get_id();

						?>
								<div class="col">
									<div class="it-product-item d-flex align-items-center p-relative mb-35 prodcut-style-2">

										<?php if ($product->is_on_sale()) : ?>
											<div class="it-product-badge theme">
												<span>
													<?php
													// Check if the product is a simple product
													if ($product->is_type('simple')) {
														$regular_price = floatval($product->get_regular_price());
														$sale_price = floatval($product->get_sale_price());

														if ($regular_price > $sale_price && $sale_price > 0) {
															$percentage = round((($regular_price - $sale_price) / $regular_price) * 100);
															echo esc_html($percentage . '%');
														}
													}
													// Check if the product is a variable product
													elseif ($product->is_type('variable')) {
														$variations = $product->get_children();
														$min_percentage = null; // Initialize a variable to track the minimum percentage

														foreach ($variations as $variation_id) {
															// Ensure the variation ID corresponds to a valid WC_Product_Variation
															$variation = wc_get_product($variation_id);

															// Check if it's a valid variation product
															if ($variation && $variation instanceof WC_Product_Variation) {
																$regular_price = floatval($variation->get_regular_price());
																$sale_price = floatval($variation->get_sale_price());

																// Check if sale price is valid
																if ($regular_price > $sale_price && $sale_price > 0) {
																	$percentage = round((($regular_price - $sale_price) / $regular_price) * 100);

																	// Store the minimum percentage if it's the first valid percentage
																	if (is_null($min_percentage) || $percentage < $min_percentage) {
																		$min_percentage = $percentage;
																	}
																}
															}
														}

														// Display the minimum percentage discount found for variable products
														if (!is_null($min_percentage)) {
															echo esc_html($min_percentage . '%');
														}
													}
													?>
												</span>
											</div>
										<?php endif; ?>



										<div class="it-product-thumb-box">
											<div class="it-product-thumb fix p-relative">
												<?php
												// Display the product thumbnail
												echo woocommerce_get_product_thumbnail();
												?>
												<div class="it-product-action-2 it-shop-action-blackStyle">
													<div class="it-product-action-item-2">
														<button type="button" class="it-product-action-btn-2 it-product-quick-view-btn" data-bs-toggle="modal" data-bs-target="#producQuickViewModal<?php echo esc_attr($product_id, 'repar'); ?>">
															<svg width="18" height="15" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path fill-rule="evenodd" clip-rule="evenodd" d="M8.99948 5.06828C7.80247 5.06828 6.82956 6.04044 6.82956 7.23542C6.82956 8.42951 7.80247 9.40077 8.99948 9.40077C10.1965 9.40077 11.1703 8.42951 11.1703 7.23542C11.1703 6.04044 10.1965 5.06828 8.99948 5.06828ZM8.99942 10.7482C7.0581 10.7482 5.47949 9.17221 5.47949 7.23508C5.47949 5.29705 7.0581 3.72021 8.99942 3.72021C10.9407 3.72021 12.5202 5.29705 12.5202 7.23508C12.5202 9.17221 10.9407 10.7482 8.99942 10.7482Z" fill="currentColor"></path>
																<path fill-rule="evenodd" clip-rule="evenodd" d="M1.41273 7.2346C3.08674 10.9265 5.90646 13.1215 8.99978 13.1224C12.0931 13.1215 14.9128 10.9265 16.5868 7.2346C14.9128 3.54363 12.0931 1.34863 8.99978 1.34773C5.90736 1.34863 3.08674 3.54363 1.41273 7.2346ZM9.00164 14.4703H8.99804H8.99714C5.27471 14.4676 1.93209 11.8629 0.0546754 7.50073C-0.0182251 7.33091 -0.0182251 7.13864 0.0546754 6.96883C1.93209 2.60759 5.27561 0.00288103 8.99714 0.000185582C8.99894 -0.000712902 8.99894 -0.000712902 8.99984 0.000185582C9.00164 -0.000712902 9.00164 -0.000712902 9.00254 0.000185582C12.725 0.00288103 16.0676 2.60759 17.945 6.96883C18.0188 7.13864 18.0188 7.33091 17.945 7.50073C16.0685 11.8629 12.725 14.4676 9.00254 14.4703H9.00164Z" fill="currentColor"></path>
															</svg>
															<span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Quick View', 'repar'); ?></span>
														</button>
														<button type="button" class="it-product-action-btn-2 it-product-add-to-wishlist-btn it-shop-add-to-wishlist-btn">
															<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path fill-rule="evenodd" clip-rule="evenodd" d="M1.60355 7.98635C2.83622 11.8048 7.7062 14.8923 9.0004 15.6565C10.299 14.8844 15.2042 11.7628 16.3973 7.98985C17.1806 5.55102 16.4535 2.46177 13.5644 1.53473C12.1647 1.08741 10.532 1.35966 9.40484 2.22804C9.16921 2.40837 8.84214 2.41187 8.60476 2.23329C7.41078 1.33952 5.85105 1.07778 4.42936 1.53473C1.54465 2.4609 0.820172 5.55014 1.60355 7.98635ZM9.00138 17.0711C8.89236 17.0711 8.78421 17.0448 8.68574 16.9914C8.41055 16.8417 1.92808 13.2841 0.348132 8.3872C0.347252 8.3872 0.347252 8.38633 0.347252 8.38633C-0.644504 5.30321 0.459792 1.42874 4.02502 0.284605C5.69904 -0.254635 7.52342 -0.0174044 8.99874 0.909632C10.4283 0.00973263 12.3275 -0.238878 13.9681 0.284605C17.5368 1.43049 18.6446 5.30408 17.6538 8.38633C16.1248 13.2272 9.59485 16.8382 9.3179 16.9896C9.21943 17.0439 9.1104 17.0711 9.00138 17.0711Z" fill="currentColor"></path>
																<path fill-rule="evenodd" clip-rule="evenodd" d="M14.203 6.67473C13.8627 6.67473 13.5743 6.41474 13.5462 6.07159C13.4882 5.35202 13.0046 4.7445 12.3162 4.52302C11.9689 4.41097 11.779 4.04068 11.8906 3.69666C12.0041 3.35175 12.3724 3.16442 12.7206 3.27297C13.919 3.65901 14.7586 4.71561 14.8615 5.96479C14.8905 6.32632 14.6206 6.64322 14.2575 6.6721C14.239 6.67385 14.2214 6.67473 14.203 6.67473Z" fill="currentColor"></path>
															</svg>
															<span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Wishlist', 'repar'); ?> </span>
														</button>
														<button type="button" class="it-product-action-btn-2 it-product-add-to-compare-btn it-shop-add-to-compare-btn">
															<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path d="M11.4144 6.16828L14 3.58412L11.4144 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
																<path d="M1.48883 3.58374L14 3.58374" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
																<path d="M4.07446 8.32153L1.48884 10.9057L4.07446 13.4898" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
																<path d="M14 10.9058H1.48883" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
															</svg>
															<span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Compare', 'repar'); ?> </span>
														</button>
													</div>
												</div>
											</div>
										</div>
										<div class="it-product-content">
											<div class="mb-25">
												<h3 class="it-product-title">
													<a href="<?php the_permalink(); ?>" class="border-line-black"><?php the_title(); ?></a>
												</h3>
												<div class="it-product-price">
													<span class="it-product-ammount">
														<?php
														if ($product->is_type('variable')) {
															// Get the minimum and maximum price for the variable product
															$min_price = $product->get_variation_price('min', true);
															$max_price = $product->get_variation_price('max', true);

															// Display the price range
															echo '<p class="price">' . wc_price($min_price) . ' - ' . wc_price($max_price) . '</p>';
														} else {
															// Display the regular price for simple products
															woocommerce_template_single_price();
														}
														?>
													</span>
													<span class="it-product-rating">
														<?php echo woocommerce_template_loop_rating(); ?>
													</span>
												</div>
											</div>
											<div class="it-product-btn text-center">
												<?php echo woocommerce_template_loop_add_to_cart(); ?>
											</div>
										</div>
									</div>

								</div>

								<?php get_template_part('woocommerce/components/modal-product'); ?>

						<?php endwhile;
							wp_reset_postdata();
						else :
							echo '<p>No products found</p>';
						endif; ?>
					</div>
				</div>
			</div>

		<?php endif; ?>





<?php

	}
}

$widgets_manager->register(new Od_Product());
