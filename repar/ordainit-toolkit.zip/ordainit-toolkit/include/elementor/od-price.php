<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use \Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_Price extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'od-price';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'OD Price', 'ordainit-toolkit' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'od-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'ordainit-toolkit' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'ordainit-toolkit' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {


       
        
        
          // od_section_title
        $this->start_controls_section(
            'od_pricing_heading',
            [
                'label' => esc_html__('Heading', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'hightlights_button',
            [
                'label' => esc_html__( 'High Light Box', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'price_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Basic Plan', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        ); 
        $this->add_control(
            'price_prcing',
            [
                'label' => esc_html__('Price', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => od_kses('$982.00', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Your Price', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
			'price_prcing_image',
			[
				'label' => esc_html__( 'Choose Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-03/price/price-1.jpg',
				],
			]
		);   

        
  

        

        $this->end_controls_section();

         // od_btn_button_group
        $this->start_controls_section(
            'od_btn_button_group',
            [
                'label' => esc_html__('Button', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'ordainit-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_button_show_icon',
            [
                'label' => esc_html__( 'Show Button Icon', 'ordainit-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Select Plan', 'ordainit-toolkit'),
                'title' => esc_html__('Enter button text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'od_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'od_btn_link',
            [
                'label' => esc_html__('Button link', 'ordainit-toolkit'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htods://your-link.com', 'ordainit-toolkit'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'od_btn_link_type' => '1',
                    'od_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => od_get_all_pages(),
                'condition' => [
                    'od_btn_link_type' => '2',
                    'od_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();
          // od_btn_button_group
        $this->start_controls_section(
            'pricing_repeater_list_seciton',
            [
                'label' => esc_html__('List Item', 'ordainit-toolkit'),
            ]
        );

       
        $this->add_control(
            'pricing_repeater_list',
            [
                'label' => esc_html__( 'List Item', 'ordainit-toolkit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'list_title',
                        'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Rims & Tire Change' , 'ordainit-toolkit' ),
                        'label_block' => true,
                    ],
                    [   
                        'name' => 'actvie_list',
                        'label' => esc_html__( 'Active List', 'ordainit-toolkit' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => esc_html__( 'active', 'ordainit-toolkit' ),
                        'label_off' => esc_html__( 'Inactive', 'ordainit-toolkit' ),
                        'return_value' => 'yes',
                        'default' => 'yes',
                    ],
                ],
                'default' => [
                    [
                        'list_title' => esc_html__( 'Rims & Tire Change', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Interior Cleaning', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Wipe all Surfaces', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Leather Clean & Dry', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Light Carpet Clean', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Rims & Tire Change', 'ordainit-toolkit' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Interior Cleaning', 'ordainit-toolkit' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );


        $this->end_controls_section();



        $this->start_controls_section(
			'od_price_bg_area',
			[
				'label' => __( 'Price Box', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_price_bg_area_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_price_bg_area_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_price_bg_area_normal_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Active

        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__( 'Active', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_price_bg_area_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

         $this->add_responsive_control(
            'od_price_bg_area_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-price-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_price_bg_area_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-price-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_price_bg_area_border',
				'selector' => '{{WRAPPER}} .it-price-item',
			]
		);

        	// Add border radius control
		$this->add_control(
			'od_price_bg_area_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
                    '{{WRAPPER}} .it-price-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();


        $this->start_controls_section(
			'od_price_bg_area_heading',
			[
				'label' => __( 'Heading Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_price_bg_area_heading_tabs'
        );

        // Normal
        $this->start_controls_tab(
            'od_price_bg_area_heading_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_price_bg_area_heading_normal_title',
			[
				'label' => esc_html__( 'Normal Title Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_price_bg_area_heading_normal_title_color',
			[
				'label' => esc_html__( 'Normal Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-title' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_bg_area_heading_normal_title_bg_color',
			[
				'label' => esc_html__( 'Normal Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-title' => 'background-color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_price_bg_area_heading_normal_title_bg_typography',
				'selector' => '{{WRAPPER}} .it-price-title',
			]
		);


        $this->add_control(
			'od_price_bg_area_heading_normal_title_price',
			[
				'label' => esc_html__( 'Normal Price Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_price_bg_area_heading_normal_title_price_color',
			[
				'label' => esc_html__( 'Normal Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-value' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_price_bg_area_heading_normal_title_price_typography',
				'selector' => '{{WRAPPER}} .it-price-value',
			]
		);





        $this->end_controls_tab();

        // Active
        $this->start_controls_tab(
            'od_price_bg_area_heading_active_tab',
            [
                'label' => esc_html__( 'Active', 'textdomain' ),
            ]
        );


        $this->add_control(
			'od_price_bg_area_heading_active_title',
			[
				'label' => esc_html__( 'Active Title Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_price_bg_area_heading_active_title_color',
			[
				'label' => esc_html__( 'Active Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-title' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_bg_area_heading_active_title_bg_color',
			[
				'label' => esc_html__( 'Active Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-title' => 'background-color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_price_bg_area_heading_active_title_bg_typography',
				'selector' => '{{WRAPPER}} .it-price-item.active .it-price-title',
			]
		);


        $this->add_control(
			'od_price_bg_area_heading_active_title_price',
			[
				'label' => esc_html__( 'Active Price Style', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_price_bg_area_heading_active_title_price_color',
			[
				'label' => esc_html__( 'Active Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-value' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_price_bg_area_heading_active_title_price_typography',
				'selector' => '{{WRAPPER}} .it-price-item.active .it-price-value',
			]
		);



        $this->end_controls_tab();

        $this->end_controls_tabs();



        $this->end_controls_section();



        $this->start_controls_section(
			'od_price_button_area_style',
			[
				'label' => __( 'Button Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


        $this->start_controls_tabs(
            'od_price_button_area_style_tabs'
        );

        // Normal
        $this->start_controls_tab(
            'od_price_button_area_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_price_button_area_style_normal_color',
			[
				'label' => esc_html__( 'Normal Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn.orange-bg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.orange-bg svg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_style_normal_bg_color',
			[
				'label' => esc_html__( 'Normal Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn.orange-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

             
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_price_button_area_style_normal_border',
				'selector' => '{{WRAPPER}} .it-btn.orange-bg',
			]
		);

        $this->end_controls_tab();

        // Active
        $this->start_controls_tab(
            'od_price_button_area_style_active_tab',
            [
                'label' => esc_html__( 'Active', 'ordainit-toolkit' ),
            ]
        );

        
        $this->add_control(
			'od_price_button_area_style_active_color',
			[
				'label' => esc_html__( 'Active Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-btn.orange-bg ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-price-item.active .it-btn.orange-bg svg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_style_active_bg_color',
			[
				'label' => esc_html__( 'Active Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-btn.orange-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_price_button_area_style_active_border',
				'selector' => '{{WRAPPER}} .it-price-item.active .it-btn.orange-bg',
			]
		);

        $this->end_controls_tab();

          // Active
        $this->start_controls_tab(
            'od_price_button_area_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );


        $this->add_control(
			'od_price_button_area_style_hover_color',
			[
				'label' => esc_html__( 'Hover Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn.orange-bg:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.orange-bg:hover svg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_style_hover_bg_color',
			[
				'label' => esc_html__( 'Hover Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn.orange-bg:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_price_button_area_style_hover_border',
				'selector' => '{{WRAPPER}} .it-btn.orange-bg:hover',
			]
		);


        $this->end_controls_tab();

        $this->end_controls_tabs();

          // Add border radius control
		$this->add_control(
			'od_price_button_area_style__border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
                    '{{WRAPPER}} .it-btn.orange-bg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);



        $this->end_controls_section();


        $this->start_controls_section(
			'od_price_button_area_list_style',
			[
				'label' => __( 'List Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        

        $this->start_controls_tabs(
            'od_price_button_area_list_style_tabs'
        );


        // Normal

        $this->start_controls_tab(
            'od_price_button_area_list_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_price_button_area_list_style_normal_color',
			[
				'label' => esc_html__( 'Normal Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-list ul li' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_list_style_normal_icon_active_color',
			[
				'label' => esc_html__( 'Normal Active Icon Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-list ul li i' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_list_style_normal_icon_inactive_color',
			[
				'label' => esc_html__( 'Normal Inactive Icon Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-list ul li.inactive i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Active

        $this->start_controls_tab(
            'od_price_button_area_list_style_active_tab',
            [
                'label' => esc_html__( 'Active', 'ordainit-toolkit' ),
            ]
        );


        $this->add_control(
			'od_price_button_area_list_style_active_color',
			[
				'label' => esc_html__( 'active Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-list ul li' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_list_style_active_icon_active_color',
			[
				'label' => esc_html__( 'Active Active Icon Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-list ul li i' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_price_button_area_list_style_active_icon_inactive_color',
			[
				'label' => esc_html__( 'Normal Inactive Icon Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-price-item.active .it-price-list ul li.inactive i' => 'color: {{VALUE}}',
				],
			]
		);




        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_price_button_area_list_style_typography',
				'selector' => '{{WRAPPER}} .it-price-list ul li',
			]
		);

        $this->end_controls_section();


      

        

        

    }

   


    /**
     * Render the widget ouodut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $hightlights_button = $settings['hightlights_button'];
        $price_title = $settings['price_title'];
        $price_prcing = $settings['price_prcing'];
        $price_prcing_image = $settings['price_prcing_image'];
        $pricing_repeater_list = $settings['pricing_repeater_list'];
        $od_btn_text = $settings['od_btn_text'];
        $od_btn_button_show = $settings['od_btn_button_show'];
        $od_btn_button_show_icon = $settings['od_btn_button_show_icon'];

         // Link
            if ('2' == $settings['od_btn_link_type']) {
                $this->add_render_attribute('od-button-arg', 'href', get_permalink($settings['od_btn_page_link']));
                $this->add_render_attribute('od-button-arg', 'target', '_self');
                $this->add_render_attribute('od-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('od-button-arg', 'class', 'it-btn orange-bg');
            } else {
                if ( ! empty( $settings['od_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'od-button-arg', $settings['od_btn_link'] );
                    $this->add_render_attribute('od-button-arg', 'class', 'it-btn orange-bg');
                }
            }

           

            $this->add_render_attribute('title_args', 'class', 'it-price-title');
            
            if($hightlights_button =='yes'){
                $active_class = "active ";
                
            }else{
                $active_class = "";
                
            }

            

        ?>

        <div class="it-price-item <?php echo esc_attr($active_class, 'ordainit-toolkit');?> ">
            <div class="it-price-head text-center mb-40">
            <span class="it-price-title mb-30"><?php echo esc_html($price_title, 'ordainit-toolkit');?></span>
            <span class="it-price-value"><?php echo od_kses($price_prcing, 'ordainit-toolkit');?></span>                        
            </div>
            <div class="it-price-thumb mb-55 text-center">
            <img src="<?php echo esc_url($price_prcing_image['url'], 'ordainit-toolkit');?>" alt="">                     
            </div>
            <div class="it-price-body mb-45">
            <div class="it-price-list">
                <ul>
                    
                <?php foreach($pricing_repeater_list as $single_item):
                        $active_list_item = $single_item['actvie_list'];

                         if($active_list_item =='yes'){
                            $inactive_class = "";
                            
                        }else{
                            $inactive_class = "inactive";
                            
                        }


                    ?>
                    <li class="<?php echo esc_attr($inactive_class, 'ordainit-toolkit'); ?>">
                        <?php if ($inactive_class) : ?>
                            <i class="fa-light fa-circle-xmark"></i>
                        <?php else : ?>
                            <i class="flaticon-check-mark"></i>
                        <?php endif; ?>
                        <?php echo esc_html($single_item['list_title'], 'ordainit-toolkit'); ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            </div>
            <div class="it-price-button">
            <a <?php echo $this->get_render_attribute_string( 'od-button-arg' ); ?>>
                 <?php echo esc_html($od_btn_text, 'ordainit-toolkit');?>
                 <?php if(!empty($od_btn_button_show_icon)):?>
                <svg width="25" height="14" viewBox="0 0 25 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M24.6364 7.6364C24.9879 7.28492 24.9879 6.71508 24.6364 6.3636L18.9088 0.636039C18.5574 0.284567 17.9875 0.284567 17.636 0.636039C17.2846 0.987511 17.2846 1.55736 17.636 1.90883L22.7272 7L17.636 12.0912C17.2846 12.4426 17.2846 13.0125 17.636 13.364C17.9875 13.7154 18.5574 13.7154 18.9088 13.364L24.6364 7.6364ZM0 7.9H24V6.1H0V7.9Z" fill="currentcolor"></path>
                </svg>
                <?php endif;?>
            </a>
            </div>
        </div>




        <?php
    }

}

$widgets_manager->register( new OD_Price() );