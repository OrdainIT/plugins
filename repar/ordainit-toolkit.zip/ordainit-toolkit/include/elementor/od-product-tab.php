<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_prduct_tab extends Widget_Base
{

   /**
    * Retrieve the widget name.
    *
    * @since 1.0.0
    *
    * @access public
    *
    * @return string Widget name.
    */
   public function get_name()
   {
      return 'od-product-tab';
   }

   /**
    * Retrieve the widget title.
    *
    * @since 1.0.0
    *
    * @access public
    *
    * @return string Widget title.
    */
   public function get_title()
   {
      return __('OD Product Tab', 'ordainit-toolkit');
   }

   /**
    * Retrieve the widget icon.
    *
    * @since 1.0.0
    *
    * @access public
    *
    * @return string Widget icon.
    */
   public function get_icon()
   {
      return 'od-icon';
   }

   /**
    * Retrieve the list of categories the widget belongs to.
    *
    * Used to determine where to display the widget in the editor.
    *
    * Note that currently Elementor supports only one category.
    * When multiple categories passed, Elementor uses the first one.
    *
    * @since 1.0.0
    *
    * @access public
    *
    * @return array Widget categories.
    */
   public function get_categories()
   {
      return ['ordainit-toolkit'];
   }

   /**
    * Retrieve the list of scripts the widget depended on.
    *
    * Used to set scripts dependencies required to run the widget.
    *
    * @since 1.0.0
    *
    * @access public
    *
    * @return array Widget scripts dependencies.
    */
   public function get_script_depends()
   {
      return ['ordainit-toolkit'];
   }

   protected function get_product_categories()
   {
      // Check if WooCommerce is active
      if (! class_exists('WooCommerce')) {
         return [];
      }

      // Get product IDs to filter categories associated only with products
      $product_ids = get_posts([
         'post_type'   => 'product',
         'numberposts' => -1,
         'fields'      => 'ids',
      ]);

      // Retrieve terms from the 'product_cat' taxonomy, associated with products only
      $terms = get_terms([
         'taxonomy'   => 'product_cat',
         'hide_empty' => false,
         'object_ids' => $product_ids,  // Filter to terms associated with products
      ]);

      // Check if terms were retrieved successfully
      if (is_wp_error($terms) || empty($terms)) {
         return [];
      }

      // Create options array with term IDs as keys and term names as values
      $options = [];
      foreach ($terms as $term) {
         $options[$term->term_id] = $term->name;
      }

      return $options;
   }




   /**
    * Register the widget controls.
    *
    * Adds different input fields to allow the user to change and customize the widget settings.
    *
    * @since 1.0.0
    *
    * @access protected
    */
   protected function register_controls()
   {
      $this->start_controls_section(
         'od_product_tab_title_section',
         [
            'label' => __('Title & Content', 'ordainit-toolkit'),
         ]
      );

      $this->add_control(
         'od_sub_title_icon_switcher',
         [
            'label' => esc_html__('Show/Hide Icon', 'ordainit-toolkit'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__('Show', 'ordainit-toolkit'),
            'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
            'return_value' => 'yes',
            'default' => 'yes',
         ]
      );

      $this->add_control(
         'od_sub_title',
         [
            'label' => __('Sub Title', 'ordainit-toolkit'),
            'type' => Controls_Manager::TEXT,
            'default' => od_kses(' Featured Products', 'ordainit-toolkit'),
            'labe_block' => true,
         ]
      );
      $this->add_control(
         'od_title',
         [
            'label' => __('Title', 'ordainit-toolkit'),
            'type' => Controls_Manager::TEXT,
            'default' => od_kses(' Auto Parts For <br> all model', 'ordainit-toolkit'),
            'labe_block' => true,
         ]
      );

      $this->end_controls_section();

      $this->start_controls_section(
         'od_product_tab_product_area',
         [
            'label' => __('Tab Product', 'ordainit-toolkit'),
         ]
      );


      $this->add_control(
         'od_product_tab_product_lists',
         [
            'label' => esc_html__('Product Tab List', 'ordainit-toolkit'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => [
               [
                  'name' => 'product_tab_list_name',
                  'label' => esc_html__('Tab Name', 'ordainit-toolkit'),
                  'type' => \Elementor\Controls_Manager::TEXT,
                  'default' => esc_html__('Name', 'ordainit-toolkit'),
                  'label_block' => true,
               ],
               [
                  'name' => 'product_tab_list_number',
                  'label' => esc_html__('product Number', 'ordainit-toolkit'),
                  'type' => \Elementor\Controls_Manager::TEXT,
                  'default' => esc_html__('4', 'ordainit-toolkit'),
                  'label_block' => true,
               ],
               [
                  'name' => 'product_tab_list_category',
                  'label' => esc_html__('Product Category', 'ordainit-toolkit'),
                  'type' => \Elementor\Controls_Manager::SELECT2, // Corrected to uppercase
                  'multiple' => true,
                  'options' => $this->get_product_categories(), // Fetches the categories as options
                  'label_block' => true,
               ],

            ],
            'default' => [
               [
                  'product_tab_list_name' => esc_html__('Title #1', 'textdomain'),
               ],
               [
                  'product_tab_list_name' => esc_html__('Title #1', 'textdomain'),
               ],
            ],
            'title_field' => '{{{ product_tab_list_name }}}',
         ]
      );



      $this->end_controls_section();


      $this->start_controls_section(
         'section_style',
         [
            'label' => __('Style', 'ordainit-toolkit'),
            'tab' => Controls_Manager::TAB_STYLE,
         ]
      );



      $this->add_control(
         'text_transform',
         [
            'label' => __('Text Transform', 'ordainit-toolkit'),
            'type' => Controls_Manager::SELECT,
            'default' => '',
            'options' => [
               '' => __('None', 'ordainit-toolkit'),
               'uppercase' => __('UPPERCASE', 'ordainit-toolkit'),
               'lowercase' => __('lowercase', 'ordainit-toolkit'),
               'capitalize' => __('Capitalize', 'ordainit-toolkit'),
            ],
            'selectors' => [
               '{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
            ],
         ]
      );

      $this->end_controls_section();
   }

   /**
    * Render the widget ouodut on the frontend.
    *
    * Written in PHP and used to generate the final HTML.
    *
    * @since 1.0.0
    *
    * @access protected
    */
   protected function render()
   {
      $settings = $this->get_settings_for_display();
      $od_sub_title = $settings['od_sub_title'];
      $od_title = $settings['od_title'];
      $od_sub_title_icon_switcher = $settings['od_sub_title_icon_switcher'];
      $od_product_tab_product_lists = $settings['od_product_tab_product_lists'];
?>





      <!-- product-area-start -->
      <div class="it-product-area woocommerce pt-120 pb-90 od-widget-product-tab">
         <div class="container">
            <div class="it-product-title-wrap mb-65">
               <div class="row align-items-end">
                  <div class="col-xl-6 col-lg-5">
                     <div class="it-blog-title-box">
                        <span class="it-section-subtitle orange-2-subtitle mb-15">
                           <?php if (!empty($od_sub_title_icon_switcher)): ?>
                              <span>
                                 <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                    <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                 </svg>
                              </span>
                           <?php endif; ?>
                           <?php echo od_kses($od_sub_title, 'ordainit-tookit'); ?></span>
                        <h3 class="it-section-title theme-title"><?php echo od_kses($od_title, 'od_title-tookit'); ?></h3>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-7">
                     <div class="it-product-tab">
                        <ul class="nav nav-tab justify-content-lg-end" id="myTab" role="tablist">
                           <?php
                           $i = 0;
                           foreach ($od_product_tab_product_lists as $single_tab_product_list):
                              $i++;
                           ?>
                              <li class="nav-item" role="presentation">
                                 <button class="nav-link <?php echo ($i === 1) ? 'active' : ''; ?> " id="home-tab<?php echo esc_attr($i, 'ordainit-toolkit'); ?>" data-bs-toggle="tab" data-bs-target="#home_tab<?php echo esc_attr($i, 'ordainit-toolkit'); ?>"
                                    type="button" role="tab" aria-controls="home_tab" aria-selected="<?php if ($i == 1) {
                                                                                                         echo "true";
                                                                                                      } else {
                                                                                                         echo "false";
                                                                                                      } ?>"><?php echo esc_html($single_tab_product_list['product_tab_list_name'], 'ordainit-tookit'); ?></button>
                              </li>
                           <?php endforeach; ?>




                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="it-product-tab-wrap">
               <div class="tab-content" id="myTabContent">

                  <?php
                  $i = 0;
                  foreach ($od_product_tab_product_lists as $single_tab_product_list):
                     $i++;
                  ?>
                     <div class="tab-pane fade <?php echo ($i === 1) ? 'show  active' : ''; ?>  " id="home_tab<?php echo esc_attr($i, 'ordainit-toolkit'); ?>" role="tabpanel" aria-labelledby="home-tab<?php echo esc_attr($i, 'ordainit-toolkit'); ?>">
                        <div class="row">
                           <?php

                           // Query for products
                           $args = [
                              'post_type' => 'product', // Custom post type for products
                              'posts_per_page' => $single_tab_product_list['product_tab_list_number'], // Number of products to display
                              'tax_query' => [], // Initialize tax_query as empty
                           ];

                           // Check if categories are selected
                           if (!empty($single_tab_product_list['product_tab_list_category'])) {
                              // If categories are selected, filter by category
                              $args['tax_query'] = [
                                 [
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'term_id',
                                    'terms'    => (array) $single_tab_product_list['product_tab_list_category'], // Use the selected categories as an array
                                    'operator' => 'IN', // Ensure it matches any of the selected categories
                                 ],
                              ];
                           } else {
                              // If no categories are selected, show random products
                              $args['orderby'] = 'rand'; // Order by random
                           }
                           $product_query = new \WP_Query($args);
                           global $product;

                           if ($product_query->have_posts()) :
                              while ($product_query->have_posts()) : $product_query->the_post();
                                 $product_id = get_the_ID();
                           ?>

                                 <?php get_template_part('woocommerce/components/modal-product'); // Adjust the path as necessary
                                 ?>

                                 <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-30">
                                    <div class="it-product-item p-relative">

                                       <?php
                                       // Always check if WooCommerce is active
                                       if (function_exists('wc_get_product')) {
                                          // Get the product object properly
                                          global $post;
                                          $product = wc_get_product($post->ID);

                                          // Only proceed if we have a valid product object
                                          if ($product && $product->is_on_sale()) : ?>
                                             <div class="it-product-badge theme">
                                                <span>
                                                   <?php
                                                   // For simple products
                                                   if ($product->is_type('simple')) {
                                                      $regular_price = (float) $product->get_regular_price();
                                                      $sale_price = (float) $product->get_sale_price();

                                                      if ($regular_price > 0 && $sale_price > 0 && $regular_price > $sale_price) {
                                                         $percentage = round((($regular_price - $sale_price) / $regular_price) * 100);
                                                         echo esc_html($percentage . '%');
                                                      }
                                                   }
                                                   // For variable products
                                                   elseif ($product->is_type('variable')) {
                                                      $percentages = array();
                                                      $variation_prices = $product->get_variation_prices();

                                                      foreach ($variation_prices['regular_price'] as $key => $regular_price) {
                                                         $sale_price = $variation_prices['sale_price'][$key];
                                                         if ($sale_price < $regular_price) {
                                                            $percentages[] = round((($regular_price - $sale_price) / $regular_price) * 100);
                                                         }
                                                      }

                                                      if (!empty($percentages)) {
                                                         $min_percentage = min($percentages);
                                                         echo esc_html($min_percentage . '%');
                                                      }
                                                   }
                                                   ?>
                                                </span>
                                             </div>
                                       <?php endif;
                                       } ?>


                                       <div class="it-product-thumb-box">
                                          <?php if (has_post_thumbnail()) : ?>
                                             <div class="it-product-thumb fix p-relative">
                                                <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                                                <div class="it-product-action-2 it-shop-action-blackStyle">
                                                   <div class="it-product-action-item-2">
                                                      <button type="button"
                                                         class="it-product-action-btn-2 it-product-quick-view-btn"
                                                         data-bs-toggle="modal" data-bs-target="#producQuickViewModal<?php echo esc_attr($product_id, 'ordainit-toolkit'); ?>">
                                                         <svg width="18" height="15" viewBox="0 0 18 15" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                               d="M8.99948 5.06828C7.80247 5.06828 6.82956 6.04044 6.82956 7.23542C6.82956 8.42951 7.80247 9.40077 8.99948 9.40077C10.1965 9.40077 11.1703 8.42951 11.1703 7.23542C11.1703 6.04044 10.1965 5.06828 8.99948 5.06828ZM8.99942 10.7482C7.0581 10.7482 5.47949 9.17221 5.47949 7.23508C5.47949 5.29705 7.0581 3.72021 8.99942 3.72021C10.9407 3.72021 12.5202 5.29705 12.5202 7.23508C12.5202 9.17221 10.9407 10.7482 8.99942 10.7482Z"
                                                               fill="currentColor"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                               d="M1.41273 7.2346C3.08674 10.9265 5.90646 13.1215 8.99978 13.1224C12.0931 13.1215 14.9128 10.9265 16.5868 7.2346C14.9128 3.54363 12.0931 1.34863 8.99978 1.34773C5.90736 1.34863 3.08674 3.54363 1.41273 7.2346ZM9.00164 14.4703H8.99804H8.99714C5.27471 14.4676 1.93209 11.8629 0.0546754 7.50073C-0.0182251 7.33091 -0.0182251 7.13864 0.0546754 6.96883C1.93209 2.60759 5.27561 0.00288103 8.99714 0.000185582C8.99894 -0.000712902 8.99894 -0.000712902 8.99984 0.000185582C9.00164 -0.000712902 9.00164 -0.000712902 9.00254 0.000185582C12.725 0.00288103 16.0676 2.60759 17.945 6.96883C18.0188 7.13864 18.0188 7.33091 17.945 7.50073C16.0685 11.8629 12.725 14.4676 9.00254 14.4703H9.00164Z"
                                                               fill="currentColor"></path>
                                                         </svg>
                                                         <span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Quick View', 'ordainit-toolkit'); ?></span>
                                                      </button>
                                                      <button type="button"
                                                         class="it-product-action-btn-2 it-product-add-to-wishlist-btn it-shop-add-to-wishlist-btn">
                                                         <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                               d="M1.60355 7.98635C2.83622 11.8048 7.7062 14.8923 9.0004 15.6565C10.299 14.8844 15.2042 11.7628 16.3973 7.98985C17.1806 5.55102 16.4535 2.46177 13.5644 1.53473C12.1647 1.08741 10.532 1.35966 9.40484 2.22804C9.16921 2.40837 8.84214 2.41187 8.60476 2.23329C7.41078 1.33952 5.85105 1.07778 4.42936 1.53473C1.54465 2.4609 0.820172 5.55014 1.60355 7.98635ZM9.00138 17.0711C8.89236 17.0711 8.78421 17.0448 8.68574 16.9914C8.41055 16.8417 1.92808 13.2841 0.348132 8.3872C0.347252 8.3872 0.347252 8.38633 0.347252 8.38633C-0.644504 5.30321 0.459792 1.42874 4.02502 0.284605C5.69904 -0.254635 7.52342 -0.0174044 8.99874 0.909632C10.4283 0.00973263 12.3275 -0.238878 13.9681 0.284605C17.5368 1.43049 18.6446 5.30408 17.6538 8.38633C16.1248 13.2272 9.59485 16.8382 9.3179 16.9896C9.21943 17.0439 9.1104 17.0711 9.00138 17.0711Z"
                                                               fill="currentColor"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                               d="M14.203 6.67473C13.8627 6.67473 13.5743 6.41474 13.5462 6.07159C13.4882 5.35202 13.0046 4.7445 12.3162 4.52302C11.9689 4.41097 11.779 4.04068 11.8906 3.69666C12.0041 3.35175 12.3724 3.16442 12.7206 3.27297C13.919 3.65901 14.7586 4.71561 14.8615 5.96479C14.8905 6.32632 14.6206 6.64322 14.2575 6.6721C14.239 6.67385 14.2214 6.67473 14.203 6.67473Z"
                                                               fill="currentColor"></path>
                                                         </svg>
                                                         <span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Add To
                                                Wishlist', 'ordainit-toolkit'); ?></span>
                                                      </button>
                                                      <button type="button"
                                                         class="it-product-action-btn-2 it-product-add-to-compare-btn it-shop-add-to-compare-btn">
                                                         <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M11.4144 6.16828L14 3.58412L11.4144 1" stroke="currentColor"
                                                               stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                                            </path>
                                                            <path d="M1.48883 3.58374L14 3.58374" stroke="currentColor"
                                                               stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                                            </path>
                                                            <path d="M4.07446 8.32153L1.48884 10.9057L4.07446 13.4898"
                                                               stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                               stroke-linejoin="round"></path>
                                                            <path d="M14 10.9058H1.48883" stroke="currentColor" stroke-width="1.5"
                                                               stroke-linecap="round" stroke-linejoin="round"></path>
                                                         </svg>
                                                         <span class="it-product-tooltip it-product-tooltip-right"><?php echo esc_html__('Add To
                                                Compare', 'ordainit-toolkit'); ?></span>
                                                      </button>
                                                   </div>
                                                </div>
                                             </div>
                                          <?php endif; ?>
                                       </div>
                                       <div class="it-product-content">
                                          <div class="mb-25">
                                             <h3 class="it-product-title">
                                                <a href="<?php the_permalink(); ?>" class="border-line-black"><?php the_title(); ?></a>
                                             </h3>
                                             <div class="it-product-price d-flex justify-content-between align-items-center">
                                                <span class="it-product-ammount">
                                                   <?php
                                                   global $product;
                                                   if ($product->is_type('variable')) {
                                                      // Get the minimum and maximum price for the variable product
                                                      $min_price = $product->get_variation_price('min', true);
                                                      $max_price = $product->get_variation_price('max', true);

                                                      // Display the price range
                                                      echo '<p class="price">' . wc_price($min_price) . ' - ' . wc_price($max_price) . '</p>';
                                                   } else {
                                                      // Display the regular price for simple products
                                                      woocommerce_template_single_price();
                                                   }
                                                   ?>
                                                </span>
                                                <span class="it-product-rating">
                                                   <?php
                                                   global $product;
                                                   if ($product->get_average_rating() > 0) {
                                                      echo wc_get_rating_html($product->get_average_rating()); // Display star rating
                                                   }
                                                   ?>
                                                </span>
                                             </div>
                                          </div>
                                          <div class="it-product-btn text-center">
                                             <a class="it-btn orange-2-btn" href="<?php echo esc_url(get_permalink()); ?>">
                                                <span class="btn-wrap">Add To Cart</span>
                                             </a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                           <?php
                              endwhile;
                              wp_reset_postdata(); // Reset post data
                           else :
                              echo '<p>No products found</p>';
                           endif;
                           ?>
                        </div>
                     </div>
                  <?php endforeach; ?>


               </div>
            </div>
         </div>
      </div>
      <!-- product-area-end -->





      <script>
         "use strict";
         jQuery(document).ready(function($) {



         });
      </script>
<?php
   }
}

$widgets_manager->register(new Od_prduct_tab());
