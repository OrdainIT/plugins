<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Icon_box extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-icon-box';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('OD Icon Box', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{

		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
					'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_iconbox_content',
			[
				'label' => __('Iconbox Content', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-1']
				],
			],
		);

		$this->add_control(
			'od_iconbox_icon_switcher',
			[
				'label' => esc_html__('Icon Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_icon',
			[
				'label' => esc_html__('Icon', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa-solid fa-circle-check',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'od_iconbox_title_switcher',
			[
				'label' => esc_html__('Title Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_title',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('Title', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_iconbox_description_switcher',
			[
				'label' => esc_html__('Description Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_description',
			[
				'label' => esc_html__('Description', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses('Description', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_iconbox_bg',
			[
				'label' => esc_html__('Background Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);



		$this->end_controls_section();


		$this->start_controls_section(
			'od_iconbox_content2',
			[
				'label' => __('Iconbox Content', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			],
		);

		$this->add_control(
			'od_iconbox_title_switcher2',
			[
				'label' => esc_html__('Title Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_title2',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('Title', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_iconbox_description_switcher2',
			[
				'label' => esc_html__('Description Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_description2',
			[
				'label' => esc_html__('Description', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses('Description', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_iconbox_box_img_switcher',
			[
				'label' => esc_html__('Box Image Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'od_iconbox_bg2',
			[
				'label' => esc_html__('Box Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->add_control(
			'od_iconbox_icon_img_switcher',
			[
				'label' => esc_html__('Icon Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_iconbox_icon_img',
			[
				'label' => esc_html__('Icon', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa-sharp fa-regular fa-arrow-right',
				],
			]
		);


		$this->add_control(
			'od_iconbox_icon_url',
			[
				'label' => esc_html__('URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
				'label_block' => true,
			]
		);





		$this->end_controls_section();

		// icon box Style 3 Content
		$this->start_controls_section(
			'od_iconbox_content3',
			[
				'label' => __('Iconbox Content', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-3']
				],
			],
		);


		$this->add_control(
			'od_iconbox_title3',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('Service Kits', 'ordainit-toolkit'),
				'label_block' => true,
			]
		);

		$this->add_control(
			'od_iconbox_title_icon_select3',
			[
				'label' => esc_html__('Select Icon', 'ordainit-toolkit'),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'flaticon-wrench',
				'options' => [
					'flaticon-wrench' => esc_html__('Icon Wrench', 'ordainit-toolkit'),
					'flaticon-brake-disc'  => esc_html__('Icon Brake disck', 'ordainit-toolkit'),
					'flaticon-damper' => esc_html__('Icon Damper', 'ordainit-toolkit'),
					'flaticon-engine' => esc_html__('Icon Engine', 'ordainit-toolkit'),
					'flaticon-oil' => esc_html__('Icon Oil', 'ordainit-toolkit'),
					'flaticon-tire' => esc_html__('Icon Tire', 'ordainit-toolkit'),
					'flaticon-steering-wheel' => esc_html__('Icon Wheel', 'ordainit-toolkit'),
					'flaticon-car-light' => esc_html__('Icon Cart Light', 'ordainit-toolkit'),
					'flaticon-drivetrain' => esc_html__('Icon Drivetrain', 'ordainit-toolkit'),
					'flaticon-vacuum' => esc_html__('Icon Vacum', 'ordainit-toolkit'),
				],
			]
		);


		$this->add_control(
			'od_iconbox3_url',
			[
				'label' => esc_html__('URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('#', 'ordainit-toolkit'),
				'label_block' => true,
			]
		);

		// icon box bg image

		$this->add_control(
			'od_iconbox_bg3',
			[
				'label' => esc_html__('Background Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);




		$this->end_controls_section();

		$this->start_controls_section(
			'od_icon_box_main_area',
			[
				'label' => __('Main Area Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'od_align',
			[
				'label' => esc_html__('Alignment', 'ordainit-toolkit'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'ordainit-toolkit'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'ordainit-toolkit'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', 'ordainit-toolkit'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => false,
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};'
				]
			]
		);

		$this->start_controls_tabs(
			'od_icon_box_main_area_tabs'
		);

		$this->start_controls_tab(
			'od_icon_box_main_area_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_main_area_bg_normal_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-process-item.style-1' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-part-item' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_icon_box_main_area_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_icon_box_main_area_bg_hover_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-process-item.style-1:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-part-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();


		$this->end_controls_tabs();

		$this->add_responsive_control(
			'od_icon_box_main_area_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-item.style-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-part-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_icon_box_main_area_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-item.style-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-part-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_icon_box_main_area_border',
				'selector' => '{{WRAPPER}} .it-feature-item, {{WRAPPER}} .it-process-item.style-1, {{WRAPPER}}  .it-part-item',

			]
		);

		$this->add_control(
			'od_icon_box_main_area_border_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-item.style-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-part-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Box Image Style For Style 2
		$this->start_controls_section(
			'od_icon_box_image_area',
			[
				'label' => __('Box Image Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-2'],
				],
			]
		);


		$this->add_control(
			'od_icon_box_image_area_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-process-icon' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->add_responsive_control(
			'od_icon_box_image_area_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-process-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_icon_box_image_area_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-process-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_icon_box_image_area_border',
				'selector' => '{{WRAPPER}} .it-process-icon-box',
			]
		);

		$this->add_control(
			'od_icon_box_image_area_borer_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-process-icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);






		$this->end_controls_section();

		// Icon Style

		$this->start_controls_section(
			'od_icon_box_icon',
			[
				'label' => __('Icon Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_icon_box_icon_tabs'
		);

		$this->start_controls_tab(
			'od_icon_box_icon_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_icon_normal_color',
			[
				'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-title i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-arrow a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-part-item span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_icon_box_icon_normal_bg_color',
			[
				'label' => esc_html__('Backgournd Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'od_design_style' => 'layout-2',
				],
				'selectors' => [
					'{{WRAPPER}} .it-process-arrow a' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-process-item.style-1::after' => 'background-color: {{VALUE}}',
				],
			]
		);



		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_icon_box_icon_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_icon_hover_color',
			[
				'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-title i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-arrow:hover a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-part-item:hover span' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'od_icon_box_icon_hover_bg_color',
			[
				'label' => esc_html__('Backgournd Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'od_design_style' => 'layout-2',
				],
				'selectors' => [
					'{{WRAPPER}} .it-process-arrow:hover a' => 'background-color: {{VALUE}}',
				],
			]
		);



		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->add_responsive_control(
			'od_icon_box_icon_hover_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-title i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_icon_box_icon_hover_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-title i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		// title Style

		$this->start_controls_section(
			'od_icon_box_title',
			[
				'label' => __('Title Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);



		$this->start_controls_tabs(
			'od_icon_box_title_tabs'
		);

		// Normal
		$this->start_controls_tab(
			'od_icon_box_title_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_title_normal_title_color',
			[
				'label' => esc_html__('Title Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-part-title' => 'color: {{VALUE}}',
				],
			]
		);





		$this->end_controls_tab();
		// Hover
		$this->start_controls_tab(
			'od_icon_box_title_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_title_hover_title_color',
			[
				'label' => esc_html__('Title Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-part-item:hover .it-part-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();




		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_icon_box_title_normal_title_typography',
				'selectors' => [
					'{{WRAPPER}} .it-feature-title',
					'{{WRAPPER}} .it-process-title',
					'{{WRAPPER}} .it-part-title',
				],
			]
		);

		$this->add_responsive_control(
			'od_icon_box_title_normal_title_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-title i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-part-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_icon_box_title_normal_title_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-part-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

		// Description Style

		$this->start_controls_section(
			'od_icon_box_description',
			[
				'label' => __('Description Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_icon_box_description_tabs'
		);
		// Normal
		$this->start_controls_tab(
			'od_icon_box_description_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_description_normal__color',
			[
				'label' => esc_html__('Description Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-item p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();
		// Hover
		$this->start_controls_tab(
			'od_icon_box_description_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_icon_box_description_hover__color',
			[
				'label' => esc_html__('Description Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-process-item p:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();



		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_icon_box_description_typography',
				'selectors' => [
					'{{WRAPPER}} .it-feature-item p',
					'{{WRAPPER}} .it-process-item p',
				],
			]
		);

		$this->add_responsive_control(
			'od_icon_box_description_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_icon_box_description_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-feature-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-process-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$od_iconbox_icon_switcher = $settings['od_iconbox_icon_switcher'];
		$od_iconbox_icon = $settings['od_iconbox_icon'];
		$od_iconbox_title_switcher = $settings['od_iconbox_title_switcher'];
		$od_iconbox_title = $settings['od_iconbox_title'];
		$od_iconbox_description_switcher = $settings['od_iconbox_description_switcher'];
		$od_iconbox_description = $settings['od_iconbox_description'];
		$od_iconbox_bg = $settings['od_iconbox_bg'];


?>
		<?php if ($settings['od_design_style']  == 'layout-2'):
			$this->add_render_attribute('od_align', 'class', 'it-process-item style-1');
			$od_iconbox_title_switcher2 = $settings['od_iconbox_title_switcher2'];
			$od_iconbox_title2 = $settings['od_iconbox_title2'];
			$od_iconbox_description_switcher2 = $settings['od_iconbox_description_switcher2'];
			$od_iconbox_description2 = $settings['od_iconbox_description2'];
			$od_iconbox_icon_img = $settings['od_iconbox_icon_img'];
			$od_iconbox_icon_url = $settings['od_iconbox_icon_url'];
			$od_iconbox_bg2 = $settings['od_iconbox_bg2'];
			$od_iconbox_box_img_switcher = $settings['od_iconbox_box_img_switcher'];
			$od_iconbox_icon_img_switcher = $settings['od_iconbox_icon_img_switcher'];
		?>

			<div <?php echo $this->get_render_attribute_string('od_align'); ?>>
				<?php if (!empty($od_iconbox_icon_img_switcher)): ?>
					<div class="it-process-arrow d-none d-xl-block">
						<a href="<?php echo esc_url($od_iconbox_icon_url, 'ordainit-toolkit'); ?>">
							<i class="<?php echo esc_attr($od_iconbox_icon_img['value'], 'ordainit-toolkit'); ?>"></i>
						</a>
					</div>
				<?php endif; ?>
				<?php if (!empty($od_iconbox_box_img_switcher)): ?>
					<div class="it-process-icon-box mb-25">
						<span class="it-process-icon">
							<img src="<?php echo esc_url($od_iconbox_bg2['url'], 'ordainit-toolkit'); ?>" alt="">
						</span>
					</div>
				<?php endif; ?>
				<?php if (!empty($od_iconbox_title_switcher2)): ?>
					<h4 class="it-process-title mb-20"><a class="border-line-black" href="#"><?php echo od_kses($od_iconbox_title2, 'ordainit-toolkit'); ?></a></h4>
				<?php endif; ?>
				<?php if (!empty($od_iconbox_description_switcher2)): ?>
					<p><?php echo od_kses($od_iconbox_description2, 'ordainit-toolkit'); ?></p>
				<?php endif; ?>
			</div>

		<?php elseif ($settings['od_design_style']  == 'layout-3'):
			$this->add_render_attribute('od_align', 'class', 'it-part-item');
			$od_iconbox_title3 = $settings['od_iconbox_title3'];
			$od_iconbox_title_icon_select3 = $settings['od_iconbox_title_icon_select3'];
			$od_iconbox3_url = $settings['od_iconbox3_url'];
			$od_iconbox_bg3 = $settings['od_iconbox_bg3'];
		?>

			
			<div <?php echo $this->get_render_attribute_string('od_align'); ?> style="background-image:url(<?php echo esc_url($od_iconbox_bg3['url'], 'ordainit-toolit'); ?>);">
				<span>
					<i class="<?php echo esc_attr($od_iconbox_title_icon_select3, 'ordainit-toolit'); ?>"></i>
				</span>
				<h6 class="it-part-title"><a href="<?php echo esc_url($od_iconbox3_url, 'ordainit-toolit'); ?>" class="border-line-white"><?php echo od_kses($od_iconbox_title3, 'ordainit-toolit'); ?></a>
				</h6>
			</div>

		<?php else:

			$this->add_render_attribute('od_align', 'class', 'it-feature-item z-index-1 p-relative');

		?>
			<div <?php echo $this->get_render_attribute_string('od_align'); ?>>
				<div class="it-feature-shape-1">
					<img src="<?php echo esc_url($od_iconbox_bg['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<?php if (!empty($od_iconbox_title_switcher)): ?>
					<h4 class="it-feature-title">
						<?php if (!empty($od_iconbox_icon_switcher)): ?>
							<i class="<?php echo esc_attr($od_iconbox_icon['value'], 'ordainit-toolkit'); ?>"></i>
						<?php endif; ?>
						<?php echo od_kses($od_iconbox_title, 'ordainit-toolkit'); ?>
					</h4>
				<?php endif; ?>
				<?php if (!empty($od_iconbox_description_switcher)): ?>
					<p> <?php echo od_kses($od_iconbox_description, 'ordainit-toolkit'); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

<?php
	}
}

$widgets_manager->register(new Od_Icon_box());
