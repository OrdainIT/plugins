<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Team extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-team';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Team', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
        	         // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'od_team_content',
			[
				'label' => __( 'Team Content', 'ordainit-toolkit' ),
			]
		);

		$this->add_control(
			'od_team_name',
			[
				'label' => esc_html__( 'Name', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Esther Howard', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
		$this->add_control(
			'od_team_designation',
			[
				'label' => esc_html__( 'Designation', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Esther Howard', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_team_img',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/team/team-1.jpg',
				],
			]
		);
		$this->add_control(
			'od_team_url',
			[
				'label' => esc_html__( 'Designation', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_team_social_area',
			[
				'label' => esc_html__( 'Team Social', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_team_social_lists_swticher',
			[
				'label' => esc_html__( 'Social Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'od_team_social_lists',
			[
				'label' => esc_html__( 'Social List', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'fields' => [
					[
						'name' => 'od_team_social_name',
						'label' => esc_html__( 'Social Name', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => od_kses( '- Facebook' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_team_social_url',
						'label' => esc_html__( 'Social URL', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_team_social_name' => od_kses( '- Facebook', 'ordainit-toolkit' ),
					],
					[
						'od_team_social_name' => od_kses( '- Twitter', 'ordainit-toolkit' ),
					],
					[
						'od_team_social_name' => od_kses( '- LinkedIn', 'ordainit-toolkit' ),
					],
					[
						'od_team_social_name' => od_kses( '- Youtube', 'ordainit-toolkit' ),
					],
					[
						'od_team_social_name' => od_kses( '- Instagram', 'ordainit-toolkit' ),
					],
					[
						'od_team_social_name' => od_kses( '- Wahtsapp', 'ordainit-toolkit' ),
					],
				],
				'title_field' => '{{{ od_team_social_name }}}',
			]
		);


        $this->add_control(
			'od_team_social_lists2',
			[
				'label' => esc_html__( 'Social List', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'fields' => [
					[
						'name' => 'od_team_social_icon',
						'label' => esc_html__( 'Social Icon', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fa-brands fa-facebook',
                            'library' => 'fa-brands',
                        ],
						'label_block' => true,
					],
					[
						'name' => 'od_team_social_url2',
						'label' => esc_html__( 'Social URL', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
				],
				'title_field' =>esc_html__('Social Icon'), 'ordainit-toolkit',
			]
		);

	


		

		$this->end_controls_section();

        // Od Team Style

		$this->start_controls_section(
			'od_team_title_style',
			[
				'label' => __( 'Title Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_team_title_style_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_team_title_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );
        $this->add_control(
			'od_team_title_style_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-title' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_team_title_style_normal_bg_color',
			[
				'label' => esc_html__( 'Title Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-title' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-content' => 'background-color: {{VALUE}}',
				],
			]
		);
        

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_team_title_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

          $this->add_control(
			'od_team_title_style_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-title:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_team_title_style_hover_bg_color',
			[
				'label' => esc_html__( 'Title Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-title:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-content:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-content:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_title_style_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-team-title',
                    '{{WRAPPER}} .it-team-2-title',
                    '{{WRAPPER}} .it-team-3-title',
                ],
			]
		);

	

		$this->end_controls_section();

        // Sub Title

		$this->start_controls_section(
			'od_team_sub_style',
			[
				'label' => __( 'Sub Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);



        
        $this->start_controls_tabs(
            'od_team_subtitle_style_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_team_subtitle_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );
        $this->add_control(
			'od_team_subtitle_style_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-content > span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-content span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-content span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_team_title_substyle_normal_bg_color',
			[
				'label' => esc_html__( 'Title Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-content > span' => 'background-color: {{VALUE}}',
				],
			]
		);
        

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_team_subtitle_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

          $this->add_control(
			'od_team_subtitle_style_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-content:hover > span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-content span:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-content span:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_team_subtitle_style_hover_bg_color',
			[
				'label' => esc_html__( 'Title Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-content:hover > span' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_subtitle_style_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-team-content > span',
                    '{{WRAPPER}} .it-team-2-content span',
                    '{{WRAPPER}} .it-team-3-content span',
                ],
			]
		);


	

		$this->end_controls_section();
        // Socail Style

		$this->start_controls_section(
			'od_team_social_style',
			[
				'label' => __( 'Social Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'od_team_social_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-social-box a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-social-box a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-social a' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_team_social_style3_hover_color',
			[
				'label' => esc_html__( 'Hover Text Color', 'ordainit-toolkit' ),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social a:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_team_social_style_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-social-box' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-social-box' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-2-item:hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-social a' => 'background-color: {{VALUE}}',
				],
			]
		);


           $this->add_control(
			'od_team_social_style3_hover__bg_color',
			[
				'label' => esc_html__( 'Hover Background Color', 'ordainit-toolkit' ),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);



	

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_team_name = $settings['od_team_name'];
        $od_team_img = $settings['od_team_img'];
        $od_team_url = $settings['od_team_url'];
        $od_team_designation = $settings['od_team_designation'];
        $od_team_social_lists = $settings['od_team_social_lists'];
        $od_team_social_lists2 = $settings['od_team_social_lists2'];
        $od_team_social_lists_swticher = $settings['od_team_social_lists_swticher'];
?>


 <?php if ( $settings['od_design_style']  == 'layout-2' ):?>
<div class="it-team-2-item p-relative fix">
        <div class="it-team-2-thumb">
        <img src="<?php echo esc_url($od_team_img['url'], 'ordainit-toolkit');?>" alt="">
        </div>
        <div class="it-team-2-content d-flex align-items-center justify-content-between p-relative z-index-1">
        <div>
            <h4 class="it-team-2-title"><a class="border-line-black" href="<?php echo esc_url($od_team_url, 'ordainit-toolkit');?>"><?php echo od_kses($od_team_name, 'ordainit-toolkit');?></a></h4>
            <span><?php echo od_kses($od_team_designation, 'ordainit-toolkit');?> </span>
        </div>
        <span class="it-team-2-pluse">
            <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.5 -0.000976562C7.85011 -0.000976562 0 7.84914 0 17.499C0 27.1489 7.85011 34.999 17.5 34.999C27.1499 34.999 35 27.1489 35 17.499C35 7.84914 27.1499 -0.000976562 17.5 -0.000976562ZM25.1562 18.9573H18.9582V25.1553C18.9582 25.9604 18.3051 26.6135 17.5 26.6135C16.6949 26.6135 16.0418 25.9604 16.0418 25.1553V18.9573H9.84375C9.03866 18.9573 8.38551 18.3041 8.38551 17.499C8.38551 16.6939 9.03866 16.0408 9.84375 16.0408H16.0418V9.84277C16.0418 9.03768 16.6949 8.38453 17.5 8.38453C18.3051 8.38453 18.9582 9.03768 18.9582 9.84277V16.0408H25.1562C25.9613 16.0408 26.6145 16.6939 26.6145 17.499C26.6145 18.3041 25.9613 18.9573 25.1562 18.9573Z" fill="currentcolor"></path>
            </svg>
        </span>
            <?php if(!empty($od_team_social_lists_swticher)):?>
            <div class="it-team-2-social-box">
                <?php foreach($od_team_social_lists2 as $social_list2):
                $social_list_icon_value = $social_list2['od_team_social_icon'];
                    
                ?>
                <a href="<?php echo esc_url($social_list2['od_team_social_url2'], 'ordainit-toolkit');?>"><i class="<?php echo esc_attr($social_list_icon_value['value'], 'ordainit-toolkit');?>"></i></a>
                <?php endforeach; ?>
                
            </div>
            <?php endif;?>
        </div>
    </div>
 <?php elseif ( $settings['od_design_style']  == 'layout-3' ):?>
    <div class="it-team-3-item">
        <div class="it-team-3-thumb p-relative">
        <img src="<?php echo esc_url($od_team_img['url'], 'ordainit-toolkit');?>" alt="">
            <?php if(!empty($od_team_social_lists_swticher)):?>
            <div class="it-team-3-social">
                
                <?php foreach($od_team_social_lists2 as $social_list3):
                $social_list_icon_value2 = $social_list3['od_team_social_icon'];
                ?>
                <a href="<?php echo esc_url($social_list3['od_team_social_url2']);?>"><i class="<?php echo esc_attr($social_list_icon_value2['value'], 'ordainit-toolkit');?>"></i></a>
                <?php endforeach; ?>

            </div>
            <?php endif;?>
        </div>
        <div class="it-team-3-content">
        <h4 class="it-team-3-title"><a class="border-line-black" href="<?php echo esc_url($od_team_url, 'ordainit-toolkit');?>"><?php echo od_kses($od_team_name, 'ordainit-toolkit');?></a></h4>
        <span><?php echo od_kses($od_team_designation, 'ordainit-toolkit');?></span>
        </div>
    </div>
 <?php elseif ( $settings['od_design_style']  == 'layout-4' ):?>
<?php else:?>
<div class="it-team-item fix">
    <div class="it-team-thumb">
    <img src="<?php echo esc_url($od_team_img['url'], 'ordainit-toolkit');?>" alt="">
    </div>
    <div class="it-team-content p-relative z-index-1">
        <h4 class="it-team-title"><a class="border-line-white" href="<?php echo esc_url($od_team_url, 'ordainit-toolkit');?>"><?php echo od_kses($od_team_name, 'ordainit-toolkit');?></a></h4>
        <span><?php echo od_kses($od_team_designation, 'ordainit-toolkit');?></span>
        <?php if(!empty($od_team_social_lists_swticher)):?>
        <div class="it-team-social-box">
            <?php foreach($od_team_social_lists as $single_social_item):?>
            <a href="<?php echo esc_url($single_social_item['od_team_social_url'], 'ordainit-toolkit');?>"><span class="border-line-white"><?php echo od_kses($single_social_item['od_team_social_name'], 'ordainit-toolkit');?></span></a>
            <?php endforeach;?>
        </div>
        <?php endif;?>
    </div>
</div>
<?php endif;?>


<script>
    "use strict";
    jQuery(document).ready(function($) {

 

    });
</script>
<?php
	}

	
}

$widgets_manager->register( new Od_Team() );