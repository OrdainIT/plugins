<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Service extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-service';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('OD Service', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{


		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
					'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
					'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_service_content_area',
			[
				'label' => __('Service Content', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_service_title_switcher',
			[
				'label' => esc_html__('Title Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_service_title',
			[
				'label' => __('Title', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => od_kses('Our Service', 'ordainit-toolkit'),
				'label_block' => true,

			],
		);

		$this->add_control(
			'od_service_description_switcher',
			[
				'label' => esc_html__('Description Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->add_control(
			'od_service_description',
			[
				'label' => __('Description', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => od_kses('Description', 'ordainit-toolkit'),
				'label_block' => true,

			],
		);
		$this->add_control(
			'od_service_img_switcher',
			[
				'label' => esc_html__('Image Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_service_img',
			[
				'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'od_service_icon_switcher',
			[
				'label' => esc_html__('Icon Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'od_design_style' => ['layout-2', 'layout-4'],
				],
			]

		);
		$this->add_control(
			'od_service_icon',
			[
				'label' => esc_html__('Choose Icon', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'od_design_style' => ['layout-2'],
				],
			]
		);

		$this->add_control(
			'od_service_icon_class_4',
			[
				'label' => __('Icon Class', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => od_kses('flaticon-wrench', 'ordainit-toolkit'),
				'label_block' => true,
				'condition' => [
					'od_design_style' => ['layout-4'],
				],

			],
		);
		$this->add_control(
			'od_service_button_switcher',
			[
				'label' => esc_html__('Button Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_service_button_icon_switcher',
			[
				'label' => esc_html__('Button icon Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_service_button_text',
			[
				'label' => __('Button Text', 'ordainit-toolkit'),
				'default' => esc_html__('only for style 1 4', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Details', 'ordainit-toolkit'),
				'label_block' => true,

			],
		);
		$this->add_control(
			'od_service_button_url',
			[
				'label' => __('URL', 'ordainit-toolkit'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
				'label_block' => true,

			],
		);
		$this->end_controls_section();


		// Service Style

		// Service Style

		$this->start_controls_section(
			'od_service_2_icon_style',
			[
				'label' => __('icon', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-2', 'layout-4'],
				],
			]
		);

		$this->add_control(
			'od_service_2_icon_style_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-2-icon' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-4-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_service_2_icon_style_color',
			[
				'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
				'descriptions' => esc_html__('Only for Style 4', ''),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-4-icon' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_section();


		$this->start_controls_section(
			'od_service_area_style',
			[
				'label' => __('Service Area Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-1', 'layout-3'],
				],
			]
		);


		$this->start_controls_tabs(
			'od_service_area_normal_tabs'
		);

		$this->start_controls_tab(
			'od_service_area_normal_style',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_area_normal_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item' => 'background-color: {{VALUE}}',
				],
			]
		);







		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_service_area_hover_style',
			[
				'label' => esc_html__('Hover', 'textdomain'),
			]
		);

		$this->add_control(
			'od_service_area_hover_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'od_service_area_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_service_area_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_service_area_border',
				'selector' => '{{WRAPPER}} .it-service-item, {{WRAPPER}} .it-service-3-item',
			]
		);

		// Add border radius control
		$this->add_control(
			'od_service_area_border_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-service-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'custom_box_shadow',
			[
				'label' => esc_html__('Box Shadow', 'textdomain'),
				'type' => \Elementor\Controls_Manager::BOX_SHADOW,
				'selectors' => [
					'{{WRAPPER}} .it-service-item' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}};',
					'{{WRAPPER}} .it-service-3-item' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}};',
				],
			]
		);






		$this->end_controls_section();

		$this->start_controls_section(
			'od_service_title_style',
			[
				'label' => __('Title Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs(
			'od_service_title_style_tabs'
		);

		$this->start_controls_tab(
			'od_service_title_normal_style',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_title_normal_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-2-title' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_service_title_hover_style',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_title_hover_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item:hover .it-service-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-2-title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item .border-line-black' => 'background-image: linear-gradient({{VALUE}}, {{VALUE}}), linear-gradient({{VALUE}}, {{VALUE}})',
				],
			]
		);





		$this->end_controls_tab();


		$this->end_controls_tabs();


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_title_normal_typography',
				'selectors' => [
					'{{WRAPPER}} .it-service-title',
					'{{WRAPPER}} .it-service-2-title',
				],
			]
		);

		$this->add_responsive_control(
			'od_service_title_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-2-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_service_title_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-2-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);





		$this->end_controls_section();

		$this->start_controls_section(
			'od_service_description_style',
			[
				'label' => __('Description Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs(
			'od_service_description_style_tabs'
		);

		$this->start_controls_tab(
			'od_service_description_normal_style',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_description_normal_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-2-content p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-4-item p' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_service_description_hover_style',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_description_hover_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item:hover p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-2-content:hover p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-item:hover p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-4-item:hover  p' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_tab();


		$this->end_controls_tabs();


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_description__typography',
				'selectors' => [
					'{{WRAPPER}} .it-service-item p',
					'{{WRAPPER}} .it-service-2-content p',
					'{{WRAPPER}} .it-service-3-item p',
					'{{WRAPPER}} .it-service-4-item p',
				],
			]
		);

		$this->add_responsive_control(
			'od_service_description_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-2-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-4-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_service_description_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-service-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-2-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-4-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_service_button_style',
			[
				'label' => __('Button Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-1',  'layout-3',  'layout-4'],
				],
			]
		);

		$this->start_controls_tabs(
			'od_service_button_style_tabs'
		);

		$this->start_controls_tab(
			'od_service_button_normal_style',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_button_normal_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn-grey-sm' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-arrow a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_service_button_normal_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-btn-grey-sm' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn-grey-sm i' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_service_button_hover_style',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_service_button_hover_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item:hover .it-btn-grey-sm' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-arrow a:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-arrow a::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-btn-grey-sm.theme-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_service_button_hover_color',
			[
				'label' => esc_html__('Text Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-item:hover .it-btn-grey-sm' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-item:hover .it-btn-grey-sm i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-service-3-arrow a:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn-grey-sm.theme-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn-grey-sm.theme-btn:hover i' => 'color: {{VALUE}}',
				],
			]
		);




		$this->end_controls_tab();


		$this->end_controls_tabs();


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_button__typography',
				'selectors' => [
					'{{WRAPPER}} .it-btn-grey-sm',
				],
			]
		);

		$this->add_responsive_control(
			'od_service_button_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-btn-grey-sm' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-arrow a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_service_button_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-btn-grey-sm' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-service-3-arrow a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);





		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$od_service_title_switcher = $settings['od_service_title_switcher'];
		$od_service_title = $settings['od_service_title'];
		$od_service_description_switcher = $settings['od_service_description_switcher'];
		$od_service_description = $settings['od_service_description'];
		$od_service_button_switcher = $settings['od_service_button_switcher'];
		$od_service_button_icon_switcher = $settings['od_service_button_icon_switcher'];
		$od_service_button_text = $settings['od_service_button_text'];
		$od_service_button_url = $settings['od_service_button_url'];
		$od_service_img = $settings['od_service_img'];
		$od_service_icon_switcher = $settings['od_service_icon_switcher'];
		$od_service_icon = $settings['od_service_icon'];
		$od_service_img_switcher = $settings['od_service_img_switcher'];

?>

		<?php if ($settings['od_design_style']  == 'layout-2'): ?>
			<div class=" style-2 it-service-2-item fix p-relative">
				<?php if (!empty($od_service_img_switcher)): ?>
					<div class="it-service-2-thumb">
						<img src="<?php echo esc_url($od_service_img['url'], 'ordainit-toolkit'); ?>" alt="">
					</div>
				<?php endif; ?>
				<div class="it-service-2-content white-bg">
					<?php if (!empty($od_service_icon_switcher)): ?>
						<span class="it-service-2-icon">
							<img src="<?php echo esc_url($od_service_icon['url'], 'ordainit-toolkit'); ?>" alt="">
						</span>
					<?php endif; ?>
					<?php if (!empty($od_service_title_switcher)): ?>
						<h4 class="it-service-2-title"><a class="border-line-black" href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_service_title, 'ordainit-toolkit'); ?></a></h4>
					<?php endif; ?>
					<?php if (!empty($od_service_description_switcher)): ?>
						<p><?php echo od_kses($od_service_description, 'ordainit-toolkit'); ?></p>
					<?php endif; ?>
				</div>
			</div>

		<?php elseif ($settings['od_design_style']  == 'layout-3'): ?>

			<div class="it-service-3-item text-center">
				<?php if (!empty($od_service_img_switcher)): ?>
					<div class="it-service-3-thumb">
						<img src="<?php echo esc_url($od_service_img['url'], 'ordainit-toolkit'); ?>" alt="">
					</div>
				<?php endif; ?>
				<?php if (!empty($od_service_title_switcher)): ?>
					<h4 class="it-service-title"><a class="border-line-black" href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_service_title, 'ordainit-toolkit'); ?></a></h4>
				<?php endif; ?>

				<?php if (!empty($od_service_description_switcher)): ?>
					<p class="mb-45"><?php echo od_kses($od_service_description, 'ordainit-toolkit'); ?></p>
				<?php endif; ?>
				<?php if (!empty($od_service_button_switcher)): ?>
					<div class="it-service-3-arrow">
						<a href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>">
							<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M14.4258 10.9899L23.0101 10.9899L23.0101 19.5741" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
								<path d="M10.9902 23.0106L22.8908 11.11" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
							</svg>
						</a>
					</div>
				<?php endif; ?>
			</div>

		<?php elseif ($settings['od_design_style']  == 'layout-4'):
			$od_service_icon_class_4 = $settings['od_service_icon_class_4'];
		?>
			<div class="it-service-4-item text-center">
				<?php if (!empty($od_service_img_switcher)): ?>
					<div class="it-service-4-thumb">
						<img src="<?php echo esc_url($od_service_img['url'], 'ordainit-toolkit'); ?>" alt="">
					</div>
				<?php endif; ?>
				<div class="it-service-4-content p-relative">
					<?php if (!empty($od_service_icon_switcher)): ?>
						<span class="it-service-4-icon">
							<i class="<?php echo esc_attr($od_service_icon_class_4, 'ordainit-toolkit'); ?>"></i>
						</span>
					<?php endif; ?>
					<?php if (!empty($od_service_title_switcher)): ?>
						<h4 class="it-service-title"><a class="border-line-black" href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_service_title, 'ordainit-toolkit'); ?></a></h4>
					<?php endif; ?>
					<?php if (!empty($od_service_description_switcher)): ?>
						<p class="mb-25"><?php echo od_kses($od_service_description, 'ordainit-toolkit'); ?></p>
					<?php endif; ?>
					<?php if (!empty($od_service_button_switcher)): ?>
						<a href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>" class="it-btn-grey-sm theme-btn">
							<?php echo esc_html($od_service_button_text, 'ordainit-toolkit'); ?>
							<?php if (!empty($od_service_button_icon_switcher)): ?>
								<i>
									<svg width="21" height="12" viewBox="0 0 21 12" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z" fill="currentcolor"></path>
									</svg>
								</i>
							<?php endif; ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
		<?php else: ?>

			<div class="it-service-item text-center">
				<?php if (!empty($od_service_img_switcher)): ?>
					<span class="it-service-icon mb-30">
						<img src="<?php echo esc_url($od_service_img['url'], 'ordainit-toolkit'); ?>" alt="">
					</span>
				<?php endif; ?>
				<?php if (!empty($od_service_title_switcher)): ?>
					<h4 class="it-service-title"><a class="border-line-white" href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>"><?php echo od_kses($od_service_title, 'ordainit-toolkit'); ?></a></h4>
				<?php endif; ?>
				<?php if (!empty($od_service_description_switcher)): ?>
					<p class="mb-35"><?php echo od_kses($od_service_description, 'ordainit-toolkit'); ?></p>
				<?php endif; ?>
				<?php if (!empty($od_service_button_switcher)): ?>
					<div class="it-service-btn">
						<a href="<?php echo esc_url($od_service_button_url, 'ordainit-toolkit'); ?>" class="it-btn-grey-sm">
							<?php echo esc_html($od_service_button_text, 'ordainit-toolkit'); ?>
							<?php if (!empty($od_service_button_icon_switcher)): ?>
								<i>
									<svg width="21" height="12" viewBox="0 0 21 12" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z" fill="currentcolor"></path>
									</svg>
								</i>
							<?php endif; ?>
						</a>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>



		<style>
			span.it-service-icon img {
				max-height: 150px;
				max-width: 150px;
			}

			.style-2 span.it-service-2-icon img {
				height: 25px;
				width: 25px;
				object-fit: cover;
			}
		</style>



<?php
	}
}

$widgets_manager->register(new Od_Service());
