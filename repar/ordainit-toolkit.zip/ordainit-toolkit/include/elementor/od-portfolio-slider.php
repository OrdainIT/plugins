<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Portfolio_Slider extends Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'od-portfolio-slider';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('OD Portfolio Slider', 'ordainit-toolkit');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'od-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();



        // od_section_title
        $this->start_controls_section(
            'od_section_settings',
            [
                'label' => esc_html__('Settings', 'ordainit-toolkit'),
            ]
        );





        $this->add_control(
            'od_section_slider_arrow_icon_show',
            [
                'label' => esc_html__('Arrow Icon Show/Hide', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_section_slider_auto_play_switcher',
            [
                'label' => esc_html__('Autoplay On/Off', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'ordainit-toolkit'),
                'label_off' => esc_html__('Off', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );



        $this->end_controls_section();




        $this->start_controls_section(
            'od_portfolio_slider_area',
            [
                'label' => __('Slider Area', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_portfolio_slider_items',
            [
                'label' => esc_html__('Slider List', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'od_portolio_slider_title',
                        'label' => esc_html__('Title', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Engine Repaired', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_portolio_slider_subtitle',
                        'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Car Repaired', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_portolio_slider_image',
                        'label' => esc_html__('Slider Image', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/portfolio/portfolio-2.jpg',
                        ],
                        'label_block' => true,
                    ],
                    [
                        'name' => 'od_portolio_slider_url',
                        'label' => esc_html__('URL', 'ordainit-toolkit'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('#', 'ordainit-toolkit'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'od_portolio_slider_title' => esc_html__('Engine Repaired', 'ordainit-toolkit'),
                    ],
                    [
                        'od_portolio_slider_title' => esc_html__('Engine Repaired', 'ordainit-toolkit'),
                    ],
                    [
                        'od_portolio_slider_title' => esc_html__('Engine Repaired', 'ordainit-toolkit'),
                    ],
                    [
                        'od_portolio_slider_title' => esc_html__('Engine Repaired', 'ordainit-toolkit'),
                    ],
                ],
                'title_field' => '{{{ od_portolio_slider_title }}}',
            ]
        );







        $this->end_controls_section();

        $this->start_controls_section(
            'od_porfolio_slider_area',
            [
                'label' => __('Main Area', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'od_portoflio_slider_area_bg_color',
            [
                'label' => esc_html__('Background Overlay', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-overley::after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_portoflio_slider_area_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-area.it-portfolio-overley' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_portoflio_slider_area_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-area.it-portfolio-overley' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'od_porfolio_slider_section_title_content',
            [
                'label' => __('Title & Content Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'od_porfolio_slider_section_subtitle_color',
            [
                'label' => esc_html__('Subtitle Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle-2 span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_porfolio_slider_section_subtitle_typography',
                'selector' => '{{WRAPPER}} .it-section-subtitle-2',
            ]
        );

        $this->add_responsive_control(
            'od_porfolio_slider_section_subtitle_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_porfolio_slider_section_subtitle_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title

        $this->add_control(
            'od_porfolio_slider_section_title_color',
            [
                'label' => esc_html__('Title Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_porfolio_slider_section_title_typography',
                'selector' => '{{WRAPPER}} .it-section-title',
            ]
        );

        $this->add_responsive_control(
            'od_porfolio_slider_section_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_porfolio_slider_section_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        $this->end_controls_section();

        $this->start_controls_section(
            'od_porfolio_content_slider_content',
            [
                'label' => __('Slider Content Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Sub Title Style

        $this->add_control(
            'od_porfolio_slider_content_subtitle_bg_color',
            [
                'label' => esc_html__('Subtitle Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-content span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_porfolio_slider_content_subtitle_color',
            [
                'label' => esc_html__('Subtitle Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-content span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_porfolio_slider_subtitle_typography',
                'selector' => '{{WRAPPER}} .it-portfolio-content span',
            ]
        );

        $this->add_responsive_control(
            'od_porfolio_slider_content_subtitle_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-content span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_porfolio_slider__content_subtitle_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-content span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        // Title Style



        $this->add_control(
            'od_porfolio_slider_title_content_color',
            [
                'label' => esc_html__('Title Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_porfolio_slider_title_content_typography',
                'selector' => '{{WRAPPER}} .it-portfolio-title',
            ]
        );

        $this->add_responsive_control(
            'od_porfolio_slider_title_content_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_porfolio_slider_title_content_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-portfolio-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'od_porfolio_slider_heading_separator',
            [
                'label' => esc_html__('Arrow Style', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs(
            'od_porfolio_slider_arrow_tabs'
        );
        //Normal Tab
        $this->start_controls_tab(
            'od_porfolio_slider_arrow_noraml_tab',
            [
                'label' => esc_html__('Normal', 'textdomain'),
            ]
        );

        $this->add_control(
            'od_porfolio_slider_arrow_normal_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_porfolio_slider_normal_arrow_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span' => 'color: {{VALUE}}',
                ],
            ]
        );





        $this->end_controls_tab();
        //Normal Tab
        $this->start_controls_tab(
            'od_porfolio_slider_arrow_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_porfolio_slider_arrow_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_porfolio_slider_hover_arrow_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span:hover' => 'color: {{VALUE}}',
                ],
            ]
        );



        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'od_porfolio_slider_arrow_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_porfolio_slider_arrow_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box button span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );




        $this->end_controls_section();
    }

    /**
     * Render the widget ouodut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $od_section_slider_auto_play_switcher = $settings['od_section_slider_auto_play_switcher'];

        $od_portfolio_slider_items = $settings['od_portfolio_slider_items'];


?>

        <?php if ($settings['od_design_style']  == 'layout-2'): ?>
        <?php else: ?>
            <div class="portolio_slider_widget">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="it-portfolio-slider-wrapper">
                                <div class="swiper-container it-portfolio-active p-relative">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($od_portfolio_slider_items as $single_portfolio_slider_item):
                                            $portfolio_img_url_1 = $single_portfolio_slider_item['od_portolio_slider_image'];
                                        ?>
                                            <div class="swiper-slide">
                                                <div class="it-portfolio-item fix p-relative">
                                                    <a class="it-portfolio-arrow" href="<?php echo esc_url($single_portfolio_slider_item['od_portolio_slider_url'], 'ordainit-toolkit'); ?>">
                                                        <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M17.7071 8.70711C18.0976 8.31658 18.0976 7.68342 17.7071 7.29289L11.3431 0.928932C10.9526 0.538408 10.3195 0.538408 9.92893 0.928932C9.53841 1.31946 9.53841 1.95262 9.92893 2.34315L15.5858 8L9.92893 13.6569C9.53841 14.0474 9.53841 14.6805 9.92893 15.0711C10.3195 15.4616 10.9526 15.4616 11.3431 15.0711L17.7071 8.70711ZM0 9H17V7H0V9Z" fill="currentcolor" />
                                                        </svg>
                                                    </a>
                                                    <div class="it-portfolio-thumb">
                                                        <img src="<?php echo esc_url($portfolio_img_url_1['url'], 'ordainit-toolkit'); ?>" alt="">
                                                    </div>
                                                    <div class="it-portfolio-content">
                                                        <span><?php echo od_kses($single_portfolio_slider_item['od_portolio_slider_subtitle'], 'ordainit-toolkit'); ?></span>
                                                        <h4 class="it-portfolio-title"><a class="border-line-black"
                                                                href="<?php echo esc_url($single_portfolio_slider_item['od_portolio_slider_url'], 'ordainit-toolkit'); ?>"><?php echo od_kses($single_portfolio_slider_item['od_portolio_slider_title'], 'ordainit-toolkit'); ?></a></h4>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="it-arrow-box text-center mt-80">
                                    <button class="slider-prev">
                                        <span>
                                            <svg width="10" height="17" viewBox="0 0 10 17" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.22722 17C9.42485 17 9.62267 16.9245 9.77354 16.7736C10.0755 16.4716 10.0755 15.9827 9.77354 15.681L2.59258 8.49999L9.77354 1.31902C10.0755 1.01708 10.0755 0.528136 9.77354 0.226385C9.4716 -0.0753652 8.98266 -0.0755583 8.6809 0.226385L0.95362 7.95367C0.651677 8.25561 0.651677 8.74456 0.95362 9.04631L8.6809 16.7736C8.83178 16.9245 9.0296 17 9.22722 17Z"
                                                    fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                    <button class="slider-next">
                                        <span>
                                            <svg width="10" height="17" viewBox="0 0 10 17" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M0.772776 17C0.575151 17 0.377333 16.9245 0.226458 16.7736C-0.0754859 16.4716 -0.0754859 15.9827 0.226458 15.681L7.40742 8.49999L0.226458 1.31902C-0.0754859 1.01708 -0.0754859 0.528136 0.226458 0.226385C0.528401 -0.0753652 1.01734 -0.0755583 1.3191 0.226385L9.04638 7.95367C9.34832 8.25561 9.34832 8.74456 9.04638 9.04631L1.3191 16.7736C1.16822 16.9245 0.970402 17 0.772776 17Z"
                                                    fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>




        <?php endif; ?>

        <script>
            "use strict";
            jQuery(document).ready(function($) {

                ////////////////////////////////////////////////////
                //  Swiper Js
                const portfolioswiper = new Swiper('.it-portfolio-active', {
                    speed: 1500,
                    loop: true,
                    slidesPerView: 3,
                    spaceBetween: 35,
                    autoplay: <?php echo ($od_section_slider_auto_play_switcher === 'yes') ? 'true' : 'false'; ?>,
                    breakpoints: {
                        '1400': {
                            slidesPerView: 4,
                        },
                        '1200': {
                            slidesPerView: 3,
                        },
                        '992': {
                            slidesPerView: 3,
                        },
                        '768': {
                            slidesPerView: 2,
                        },
                        '576': {
                            slidesPerView: 1,
                        },
                        '0': {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: '.slider-prev',
                        nextEl: '.slider-next',
                    },

                });

          







            });
        </script>

<?php
    }
}

$widgets_manager->register(new Od_Portfolio_Slider());
