<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_beforeafter extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-before-after';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Before After', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'od_bforeafter_content',
			[
				'label' => __( 'Before After Content', 'ordainit-toolkit' ),
			]
		);

		

	    $this->add_control(
			'od_before_image',
			[
				'label' => esc_html__( 'Before Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL .'assets/dummy/home-01/before-after/after.png',
				],
			]
		);

	    $this->add_control(
			'od_after_image',
			[
				'label' => esc_html__( 'After Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL .'assets/dummy/home-01/before-after/before.png',
				],
			]
		);

		

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'ordainit-toolkit' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'ordainit-toolkit' ),
					'uppercase' => __( 'UPPERCASE', 'ordainit-toolkit' ),
					'lowercase' => __( 'lowercase', 'ordainit-toolkit' ),
					'capitalize' => __( 'Capitalize', 'ordainit-toolkit' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_before_image = $settings['od_before_image'];
        $od_after_image = $settings['od_after_image'];

?>

<div class="beforeAfter z-index-10 p-relative">
    <img src="<?php echo esc_url($od_after_image['url'], 'ordainit-toolkit');?>" alt="">                   
    <img src="<?php echo esc_url($od_before_image['url'], 'ordainit-toolkit');?>" alt="">
</div>

<script>
    "use strict";
    jQuery(document).ready(function($) {

          // before-after
  if ($(".beforeAfter").length > 0) {
    $(".beforeAfter").beforeAfter({
      movable: true,
      clickMove: true,
      position: 50,
      separatorColor: "#fafafa",
      bulletColor: "#fafafa",
      onMoveStart: function (e) {
        console.log(event.target);
      },
      onMoving: function () {
        console.log(event.target);
      },
      onMoveEnd: function () {
        console.log(event.target);
      },
    });
  }
 

    });
</script>
<?php
	}

	
}

$widgets_manager->register( new Od_beforeafter() );