<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_Main_Slider extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('Main Slider', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{


		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
					'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
					'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();
		// title & Content
		$this->start_controls_section(
			'od_section_title_content',
			[
				'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);

		$this->add_control(
			'od_title',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses('Premier Motorcycle Repair Services Mcssa', 'ordainit-toolkit'),
				'label' 		=> true,
			]
		);
		$this->add_control(
			'od_title_img',
			[
				'label' => esc_html__('Title Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/slider/tumb-sm.jpg',
				],
				'label' 		=> true,
			]
		);
		$this->add_control(
			'od_descriptions',
			[
				'label' => esc_html__('Description', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses('Suspendisse ultrice gravida dictum fusce placerat ultricies integer <i>quis auctor elit sed vulputate mi sit.</i> Auctor eu augue ut lectus arcu bibendum at varius vel.', 'ordainit-toolkit'),
				'label' 		=> true,
			]
		);
		$this->add_control(
			'od_button_text',
			[
				'label' => esc_html__('Button Text', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Discover more', 'ordainit-toolkit'),
				'label' 		=> true,
			]
		);
		$this->add_control(
			'od_button_url',
			[
				'label' => esc_html__('Button URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
				'label' 		=> true,
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'od_main_slider_settings',
			[
				'label' => esc_html__('Settings', 'ordainit-toolkit'),
				'description' => esc_html__('Control all the style settings from Style tab', 'ordainit-toolkit'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'od_slider_button_switcher',
			[
				'label' => esc_html__('Button Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_slider_video_switcher',
			[
				'label' => esc_html__('Video Button Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',

				'condition' => [
					'od_design_style' => ['layout-1', 'layout-4']
				],
			]
		);
		$this->add_control(
			'od_slider_auto_switcher',
			[
				'label' => esc_html__('Slider AutoPlay On/Off', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('On', 'ordainit-toolkit'),
				'label_off' => esc_html__('Off', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_slider_social_switcher',
			[
				'label' => esc_html__('Social On/Off', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('On', 'ordainit-toolkit'),
				'label_off' => esc_html__('Off', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);
		$this->add_control(
			'od_slider_arrow_switcher',
			[
				'label' => esc_html__('Slider Arrow Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'od_slider_cusomer_switcher',
			[
				'label' => esc_html__('Cusomer Area Show/Hide', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__('Show', 'ordainit-toolkit'),
				'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);

		$this->end_controls_section();






		$this->start_controls_section(
			'od_main_slider',
			[
				'label' => esc_html__('Main Slider', 'ordainit-toolkit'),
				'description' => esc_html__('Control all the style settings from Style tab', 'ordainit-toolkit'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'od_slider_list2',
			[
				'label' => esc_html__('Slider List', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'condition' => [
					'od_design_style' => ['layout-2']
				],
				'fields' => [

					[
						'name' => 'od_slider_title2',
						'label' => esc_html__('Slider Title', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('Slider Image', 'mcssa'),
						'label_block' => true,
					],
					[
						'name' => 'slider_2_img',
						'label' => esc_html__('Slider Image', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/slider/slider-2.jpg',
						],
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_slider_title2' => esc_html__('Slider Image', 'ordainit-toolkit'),
					],
					[
						'od_slider_title2' => esc_html__('Slider Image', 'ordainit-toolkit'),
					],
					[
						'od_slider_title2' => esc_html__('Slider Image', 'ordainit-toolkit'),
					],
				],
				'title_field' => '{{{ od_slider_title2 }}}',
			]
		);

		$this->add_control(
			'od_slider_list_area',
			[
				'label' => esc_html__('Slider List', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'condition' => [
					'od_design_style' => ['layout-1', 'layout-3', 'layout-4']
				],
				'fields' => [
					[
						'name' => 'od_slider_img',
						'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/slider/slider-1.jpg',
						],
					],

					[
						'name' => 'od_slider_title',
						'label' => esc_html__('Title', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => od_kses('If your car hurts <br> bring it to <span>Mcssa</span>', 'ordainit-toolkit'),
						'label_block' => true,
					],
					[
						'name' => 'od_slider_description',
						'label' => esc_html__('Descriptions', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => od_kses('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut <br> labore et dolore magna aliqua. Ut enim ad inim veniam, quis nostrud exercitation', 'ordainit-toolkit'),
						'show_label' => false,
					],
					[
						'name' => 'od_slider_button_text',
						'label' => esc_html__('Button Text', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('Discover More', 'ordainit-toolkit'),
						'label_block' => true,
					],
					[
						'name' => 'od_slider_button_url',
						'label' => esc_html__('Button URL', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('#', 'ordainit-toolkit'),
						'label_block' => true,
					],
					[
						'name' => 'od_slider_video_url',
						'label' => esc_html__('Video URL', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('https://www.youtube.com/watch?v=r0O6hv8sApY', 'ordainit-toolkit'),
						'label_block' => true,
					],
					[
						'name' => 'od_slider_video_text',
						'label' => esc_html__('Video Text', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => od_kses('watch our video <br> how its works', 'ordainit-toolkit'),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_slider_title' => od_kses('If your car hurts <br> bring it to <span>Mcssa</span>', 'ordainit-toolkit'),
					],
					[
						'od_slider_title' => od_kses('If your car hurts <br> bring it to <span>Mcssa</span>', 'ordainit-toolkit'),
					],
					[
						'od_slider_title' => od_kses('If your car hurts <br> bring it to <span>Mcssa</span>', 'ordainit-toolkit'),
					],
				],
				'title_field' => '{{{ od_slider_title }}}',
			]
		);





		$this->end_controls_section();

		$this->start_controls_section(
			'od_slider_happy_customer',
			[
				'label' => esc_html__('Happy Customer', 'ordainit-toolkit'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);

		$this->add_control(
			'od_happy_customer_title',
			[
				'label' => esc_html__('Title', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('Happy Customer', 'ordainit-toolkit'),
				'label'	=> true,
			]
		);
		$this->add_control(
			'od_happy_customer_imge',
			[
				'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/slider/customer.png',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_slider_2_shap_area',
			[
				'label' => esc_html__('Shap', 'ordainit-toolkit'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'od_design_style' => ['layout-2', 'layout-4']
				],
			]
		);

		$this->add_control(
			'od_slider2_shap_1',
			[
				'label' => esc_html__('Shap 1', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/shape/slider-shape.png',
				],
				'description' => esc_html__('This Image Section For Only Style Layout 2', ''),
			]
		);
		$this->add_control(
			'od_slider2_shap_2',
			[
				'label' => esc_html__('Shap 2', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/shape/slider-shape-2.png',
				],
			]
		);
		$this->add_control(
			'od_slider2_shap_3',
			[
				'label' => esc_html__('Animation Image ', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/shape/cycle.png',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'od_slider_2_social_area',
			[
				'label' => esc_html__('Social', 'ordainit-toolkit'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);

		$this->add_control(
			'social_list_area',
			[
				'label' => esc_html__('Social List', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'od_social_list_title',
						'label' => esc_html__('Title', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('Facebook', 'ordainit-toolkit'),
						'label_block' => true,
					],
					[
						'name' => 'od_social_list_url',
						'label' => esc_html__('URL', 'ordainit-toolkit'),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('Facebook', 'ordainit-toolkit'),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_social_list_title' => esc_html__('Facebook', 'ordainit-toolkit'),
					],
					[
						'od_social_list_title' => esc_html__('Twitter', 'ordainit-toolkit'),
					],
					[
						'od_social_list_title' => esc_html__('Linkedin', 'ordainit-toolkit'),
					],
					[
						'od_social_list_title' => esc_html__('Instagram', 'ordainit-toolkit'),
					],
				],
				'title_field' => '{{{ od_social_list_title }}}',
			]
		);


		$this->end_controls_section();


		// Style
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __('Title Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_slider_title_color',
			[
				'label' => esc_html__('Title Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_slider_stitle_color',
			[
				'label' => esc_html__('Secound Title Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-title span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_title_typography',
				'selector' => '{{WRAPPER}} .it-slider-title, {{WRAPPER}} .it-hero-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_style',
			[
				'label' => __('Description Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_slider_description_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-text p i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_description_typography',
				'selector' => '{{WRAPPER}} .it-slider-text p, {{WRAPPER}} .it-hero-text p',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => __('Button Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);

		// normal

		$this->start_controls_tab(
			'od_button_style_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_slider_button_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-button .it-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-button .it-btn svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.yellow-bg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.yellow-bg i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.yellow-bg svg' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'od_slider_button_bgcolor',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-button .it-btn' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-btn.yellow-bg' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .it-slider-button .it-btn, {{WRAPPER}}  .it-btn.yellow-bg',
			]
		);



		$this->end_controls_tab();



		// hover

		$this->start_controls_tab(
			'od_button_style_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_slider_button_hover_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-button .it-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .it-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-button .it-btn:hover svg' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .it-btn:hover svg' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'od_slider_button_hover_bgcolor',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .it-slider-button .it-btn:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}}   .it-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_hover',
				'selector' => '{{WRAPPER}} .it-slider-button .it-btn:hover',
				'selector' => '{{WRAPPER}}  .it-btn:hover',
			]
		);





		$this->end_controls_tab();
		// end tab

		$this->end_controls_tabs();
		// end tabs
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_button_typography',
				'selector' => '{{WRAPPER}} .it-btn',
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'od_slider_section_arrow_style',
			[
				'label' => __('Arrow Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_slider_arrow_style_tabs'
		);

		$this->start_controls_tab(
			'od_slider_arrow_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_slider_arrow_normal_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-arrow-box.slider-arrow button span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-area .slider-arrow button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-area .slider-arrow button.active' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-style-2 .slider-arrow button span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_slider_arrow_normal_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-arrow-box.slider-arrow button span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-area .slider-arrow button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-style-2 .slider-arrow button span' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'os_slider_normal_arrow',
				'selector' => '{{WRAPPER}} .it-arrow-box.slider-arrow button span, {{WRAPPER}} .it-hero-area .slider-arrow button',
			]
		);





		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_slider_arrow_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_slider_arrow_hover_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-hero-area .slider-arrow button:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-arrow-box.slider-arrow button:hover span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-style-2 .slider-arrow button:hover span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_slider_arrow_hover_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-arrow-box.slider-arrow button:hover span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-area .slider-arrow button:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-slider-style-2 .slider-arrow button:hover span' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'os_slider_hover_arrow',
				'selector' => '{{WRAPPER}} .it-arrow-box.slider-arrow button span, {{WRAPPER}} .it-hero-area .slider-arrow button:hover',
			]
		);




		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();



		$this->start_controls_section(
			'section_video_style',
			[
				'label' => __('Video Button Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-1']
				],
			]
		);

		$this->add_control(
			'od_slider_video_text_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-video a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_video_button_typography',
				'selector' => '{{WRAPPER}} .it-slider-video a',
			]
		);

		$this->add_control(
			'od_slider_video_animation_color',
			[
				'label' => esc_html__('Animation & Icon color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-slider-video a i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'od_slider_section_cusomter_style',
			[
				'label' => __('Customer Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);


		$this->add_control(
			'od_slider_customer_text_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-hero-customer span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_customer_typography',
				'selector' => '{{WRAPPER}} .it-hero-customer span',
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'od_slider_section_social_style',
			[
				'label' => __('Soocial Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => ['layout-2']
				],
			]
		);

		$this->start_controls_tabs(
			'od_slider_social_style_tabs'
		);

		$this->start_controls_tab(
			'od_social_normal_tab',
			[
				'label' => esc_html__('Normal', 'ordainit-toolkit'),
			]
		);


		$this->add_control(
			'od_slider_social_text_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-hero-social a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-hero-social a:not(:last-child)::after' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'od_social_hover_tab',
			[
				'label' => esc_html__('Hover', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_slider_social_text_hover_color',
			[
				'label' => esc_html__('Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-hero-social a:hover' => 'color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_slider_social_typography',
				'selector' => '{{WRAPPER}} .it-hero-social a',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();

		$od_design_style = $settings['od_design_style'];
		$od_slider_button_switcher = $settings['od_slider_button_switcher'];
		$od_slider_video_switcher = $settings['od_slider_video_switcher'];
		$od_slider_auto_switcher = $settings['od_slider_auto_switcher'];
		$od_slider_arrow_switcher = $settings['od_slider_arrow_switcher'];
		$od_slider_list_area = $settings['od_slider_list_area'];

?>
		<?php if ($od_design_style  == 'layout-2'):

			$od_title = $settings['od_title'];
			$od_title_img = $settings['od_title_img'];
			$od_descriptions = $settings['od_descriptions'];
			$od_button_text = $settings['od_button_text'];
			$od_button_text = $settings['od_button_text'];
			$od_button_url = $settings['od_button_url'];
			$od_slider_list2 = $settings['od_slider_list2'];
			$od_happy_customer_title = $settings['od_happy_customer_title'];
			$od_happy_customer_imge = $settings['od_happy_customer_imge'];
			$od_slider2_shap_1 = $settings['od_slider2_shap_1'];
			$od_slider2_shap_2 = $settings['od_slider2_shap_2'];
			$od_slider2_shap_3 = $settings['od_slider2_shap_3'];
			$od_slider_social_switcher = $settings['od_slider_social_switcher'];
			$social_list_area = $settings['social_list_area'];
			$od_slider_cusomer_switcher = $settings['od_slider_cusomer_switcher'];

		?>
			<!-- hero-area-start -->
			<div class="it-hero-area it-slider-2-area  p-relative grey-bg-2 z-index-1">
				<?php if (!empty($od_slider_arrow_switcher)): ?>
					<div class="slider-arrow d-none d-xxl-block">
						<button class="slider-prev">
							<span>
								<svg width="25" height="16" viewBox="0 0 25 16" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M0.292892 8.70711C-0.0976315 8.31658 -0.0976315 7.68342 0.292892 7.29289L6.65685 0.928932C7.04738 0.538408 7.68054 0.538408 8.07107 0.928932C8.46159 1.31946 8.46159 1.95262 8.07107 2.34315L2.41421 8L8.07107 13.6569C8.46159 14.0474 8.46159 14.6805 8.07107 15.0711C7.68054 15.4616 7.04738 15.4616 6.65685 15.0711L0.292892 8.70711ZM25 9H1V7H25V9Z" fill="currentcolor" />
								</svg>
							</span>
						</button>
						<button class="slider-next active">
							<span>
								<svg width="25" height="16" viewBox="0 0 25 16" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M24.7071 8.70711C25.0976 8.31658 25.0976 7.68342 24.7071 7.29289L18.3431 0.928932C17.9526 0.538408 17.3195 0.538408 16.9289 0.928932C16.5384 1.31946 16.5384 1.95262 16.9289 2.34315L22.5858 8L16.9289 13.6569C16.5384 14.0474 16.5384 14.6805 16.9289 15.0711C17.3195 15.4616 17.9526 15.4616 18.3431 15.0711L24.7071 8.70711ZM0 9H24V7H0V9Z" fill="currentcolor" />
								</svg>
							</span>
						</button>
					</div>
				<?php endif; ?>
				<?php if (!empty($od_slider_social_switcher)): ?>
					<div class="it-hero-social d-none d-xxl-block">
						<?php foreach ($social_list_area as $single_social_item): ?>
							<a href="<?php echo esc_html($single_social_item['od_social_list_url'], 'mcssa'); ?>"><?php echo esc_html($single_social_item['od_social_list_title'], 'mcssa'); ?></a>
						<?php endforeach; ?>

					</div>
				<?php endif; ?>
				<div class="it-hero-shape-1">
					<img src="<?php echo esc_url($od_slider2_shap_1['url'], 'mcssa'); ?>" alt="">
				</div>
				<div class="it-hero-shape-2">
					<img src="<?php echo esc_url($od_slider2_shap_2['url'], 'mcssa'); ?>" alt="">
				</div>
				<div class="it-slider-cycle-wrap">
					<img class="movingX1 it-slider-cycle" src="<?php echo esc_url($od_slider2_shap_3['url'], 'mcssa'); ?>" alt="">
				</div>
				<div class="container">
					<div class="row">
						<div class="col-xl-6 col-lg-6">
							<div class="it-hero-content">
								<h2 class="it-hero-title mb-20  wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
									<?php echo esc_html($od_title, 'mcssa'); ?>
									<img src="<?php echo esc_url($od_title_img['url'], 'mcssa'); ?>" alt="">
								</h2>
								<div class="it-hero-text  wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".5s">
									<p class="mb-35"><?php echo od_kses($od_descriptions, 'mcssa'); ?> </p>
								</div>
								<?php if (!empty($od_slider_button_switcher)): ?>
									<div class="it-slider-2-button  wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
										<a href="<?php echo esc_url($od_button_url, 'mcssa'); ?>" class="it-btn yellow-bg">
											<?php echo esc_html($od_button_text, 'mcssa'); ?>
											<i>
												<svg width="25" height="14" viewBox="0 0 25 14" fill="none"
													xmlns="http://www.w3.org/2000/svg">
													<path
														d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z"
														fill="currentcolor" />
												</svg>
											</i>
										</a>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<?php if (!empty($od_slider_cusomer_switcher)): ?>
					<div class="it-slider-2-customer it-hero-customer d-none d-xl-block">
						<span><?php echo esc_html($od_happy_customer_title, 'mcssa'); ?></span>
						<img src="<?php echo esc_url($od_happy_customer_imge['url'], 'mcssa'); ?>" alt="">
					</div>
				<?php endif; ?>
				<div class="it-hero-thumb-wrap">
					<div class="swiper-container it-slider-active">
						<div class="swiper-wrapper">
							<?php foreach ($od_slider_list2 as $single_item2):
								$img_url = $single_item2['slider_2_img'];
							?>
								<div class="swiper-slide">
									<div class="it-hero-thumb">
										<img src="<?php echo esc_url($img_url['url'], 'mcssa'); ?>" alt="">
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
			<!-- hero-area-end -->
		<?php elseif ($od_design_style  == 'layout-3'): ?>
			<!-- slider-area-start -->
			<div class="it-slider-area it-slider-style-2 z-index-2">
				<div class="it-slider-wrapper p-relative fix">
					<?php if (!empty($od_slider_arrow_switcher)): ?>
						<div class="slider-arrow d-none d-xl-block">
							<button class="slider-prev">
								<span>
									<i class="fa-regular fa-arrow-right"></i>
								</span>
							</button>
							<button class="slider-next">
								<span>
									<i class="fa-regular fa-arrow-left"></i>
								</span>
							</button>
						</div>
					<?php endif; ?>
					<div class="swiper-container it-slider-active">
						<div class="swiper-wrapper">
							<?php foreach ($od_slider_list_area as $single_item3):
								$img_url3 = $single_item3['od_slider_img'];
							?>
								<div class="swiper-slide">
									<div class="it-slider-height it-slider-overley z-index-1 p-relative">
										<div class="it-slider-bg" style="background-image: url(<?php echo esc_url($img_url3['url'], 'mcssa'); ?>);"></div>
										<div class="container">
											<div class="row">
												<div class="col-12">
													<div class="it-slider-content text-center">
														<h2 class="it-slider-title mb-25"><?php echo od_kses($single_item3['od_slider_title'], 'mcssa'); ?></h2>
														<div class="it-slider-text">
															<p class="mb-35"><?php echo od_kses($single_item3['od_slider_description'], 'mcssa'); ?></p>
															<?php if (!empty($od_slider_button_switcher)): ?>
																<div class="it-slider-button">
																	<a href="<?php echo esc_url($single_item3['od_slider_button_url'], 'mcssa'); ?>" class="it-btn orange-bg">
																		<?php echo esc_html($single_item3['od_slider_button_text'], 'mcssa'); ?>
																		<i>
																			<svg width="25" height="14" viewBox="0 0 25 14" fill="none"
																				xmlns="http://www.w3.org/2000/svg">
																				<path
																					d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z"
																					fill="currentcolor" />
																			</svg>
																		</i>
																	</a>
																</div>
															<?php endif; ?>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
			<!-- slider-area-end -->
		<?php elseif ($od_design_style  == 'layout-4'):

			$od_slider2_shap_2 = $settings['od_slider2_shap_2'];
			$od_slider2_shap_3 = $settings['od_slider2_shap_3'];
		?>

			<!-- slider-area-start -->
			<div class="it-slider-area p-relative it-slider-style-2 it-slider-style-3 it-slider-style-4">
				<div class="it-slider-shape-4">
					<img src="<?php echo esc_url($od_slider2_shap_2['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<div class="it-slider-cycle-wrap">
					<img class="movingX1 it-slider-cycle" src="<?php echo esc_url($od_slider2_shap_3['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<div class="it-slider-wrapper p-relative fix">
					<?php if (!empty($od_slider_arrow_switcher)): ?>
						<div class="it-arrow-box slider-arrow d-none d-lg-block">
							<button class="slider-prev">
								<span>
									<i class="flaticon-chevron"></i>
								</span>
							</button>
							<button class="slider-next">
								<span>
									<i class="flaticon-left-chevron"></i>
								</span>
							</button>
						</div>
					<?php endif; ?>
					<div class="swiper-container it-slider-active">
						<div class="swiper-wrapper">

							<?php foreach ($od_slider_list_area as $single_item4):
								$img_url4 = $single_item4['od_slider_img'];
							?>
								<div class="swiper-slide">
									<div class="it-slider-overley z-index-1 p-relative">
										<div class="it-slider-bg" style="background-image: url(<?php echo esc_url($img_url4['url'], 'mcssa'); ?>);"></div>
										<div class="container">
											<div class="row">
												<div class="col-xl-8 col-lg-10">
													<div class="it-slider-content">
														<h2 class="it-slider-title mb-25"><?php echo od_kses($single_item4['od_slider_title'], 'mcssa'); ?></h2>
														<div class="it-slider-text">
															<p class="mb-35"><?php echo od_kses($single_item4['od_slider_description'], 'mcssa'); ?></p>
															<div class="it-slider-button flex-nowrap d-sm-flex align-items-center">
																<?php if (!empty($od_slider_button_switcher)): ?>
																	<a href="<?php echo esc_url($single_item4['od_slider_button_url'], 'mcssa'); ?>" class="it-btn theme-btn mr-30">
																		<?php echo esc_html($single_item4['od_slider_button_text'], 'mcssa'); ?>
																		<i>
																			<svg width="25" height="14" viewBox="0 0 25 14" fill="none"
																				xmlns="http://www.w3.org/2000/svg">
																				<path
																					d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z"
																					fill="currentcolor" />
																			</svg>
																		</i>
																	</a>
																<?php endif; ?>
																<?php if (!empty($od_slider_video_switcher)): ?>
																	<div class="it-slider-video">
																		<a href="<?php echo esc_url($single_item4['od_slider_video_url'], 'mcssa'); ?>" class="popup-video">
																			<i>
																				<svg width="10" height="12" viewBox="0 0 10 12" fill="none"
																					xmlns="http://www.w3.org/2000/svg">
																					<path d="M10 6.2265L0 0.452994L0 12L10 6.2265Z"
																						fill="currentcolor" />
																				</svg>
																			</i>
																			<span>
																				<?php echo od_kses($single_item4['od_slider_video_text'], 'mcssa'); ?>
																			</span>
																		</a>
																	</div>
																<?php endif; ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>

						</div>
					</div>
				</div>
			</div>
			<!-- slider-area-end -->


		<?php else:
		?>
			<!-- slider-area-start -->
			<div class="it-slider-area">
				<div class="it-slider-wrapper p-relative fix">
					<?php if (!empty($od_slider_arrow_switcher)): ?>
						<div class="it-arrow-box slider-arrow d-none d-lg-block">
							<button class="slider-prev">
								<span>
									<i class="flaticon-chevron"></i>
								</span>
							</button>
							<button class="slider-next">
								<span>
									<i class="flaticon-left-chevron"></i>
								</span>
							</button>
						</div>
					<?php endif; ?>
					<div class="swiper-container it-slider-active">
						<div class="swiper-wrapper">
							<?php foreach ($od_slider_list_area as $single_slider_item):
								$slider_url = $single_slider_item['od_slider_img'];
							?>
								<div class="swiper-slide">
									<div class="it-slider-height it-slider-overley z-index-1 p-relative">
										<div class="it-slider-bg" style="background-image:url(<?php echo esc_url($slider_url['url'], 'mcssa'); ?>);"></div>
										<div class="it-slider-shape-1">
											<img src="<?php echo esc_url(ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/slider-1.png'); ?>" alt="">
										</div>
										<div class="it-slider-shape-2">
											<img src="<?php echo esc_url(ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/slider-2.png'); ?>" alt="">
										</div>
										<div class="it-slider-shape-3">
											<img src="<?php echo esc_url(ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-01/shape/slider-3.png'); ?>" alt="">
										</div>
										<div class="container">
											<div class="row">
												<div class="col-xl-8 col-lg-8">
													<div class="it-slider-content">
														<h2 class="it-slider-title mb-25"><?php echo od_kses($single_slider_item['od_slider_title'], 'mcssa'); ?></h2>
														<div class="it-slider-text">
															<p class="mb-35"><?php echo od_kses($single_slider_item['od_slider_description'], 'mcssa'); ?> </p>
															<div class="it-slider-button flex-nowrap d-sm-flex align-items-center">
																<?php if (!empty($od_slider_button_switcher)): ?>
																	<a href=" <?php echo esc_url($single_slider_item['od_slider_button_url'], 'mcssa'); ?>" class="it-btn mr-30">
																		<?php echo esc_html($single_slider_item['od_slider_button_text'], 'mcssa'); ?>
																		<i>
																			<svg width="25" height="14" viewBox="0 0 25 14" fill="none"
																				xmlns="http://www.w3.org/2000/svg">
																				<path
																					d="M24.6364 7.63627C24.9879 7.2848 24.9879 6.71495 24.6364 6.36348L18.9088 0.635917C18.5574 0.284445 17.9875 0.284445 17.636 0.635917C17.2846 0.987389 17.2846 1.55724 17.636 1.90871L22.7272 6.99988L17.636 12.091C17.2846 12.4425 17.2846 13.0124 17.636 13.3638C17.9875 13.7153 18.5574 13.7153 18.9088 13.3638L24.6364 7.63627ZM0 7.89988H24V6.09988H0V7.89988Z"
																					fill="currentcolor" />
																			</svg>
																		</i>
																	</a>
																<?php endif; ?>
																<?php if (!empty($od_slider_video_switcher)): ?>
																	<div class="it-slider-video">
																		<a href="<?php echo esc_url($single_slider_item['od_slider_video_url'], 'mcssa'); ?>" class="popup-video">
																			<i>
																				<svg width="10" height="12" viewBox="0 0 10 12" fill="none"
																					xmlns="http://www.w3.org/2000/svg">
																					<path d="M10 6.2265L0 0.452994L0 12L10 6.2265Z"
																						fill="currentcolor" />
																				</svg>
																			</i>
																			<span>
																				<?php echo od_kses($single_slider_item['od_slider_video_text'], 'mcssa'); ?>
																			</span>
																		</a>
																	</div>
																<?php endif; ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
			<!-- slider-area-end -->

		<?php endif; ?>


		<script>
			"use strict";
			jQuery(document).ready(function($) {

				////////////////////////////////////////////////////

				////////////////////////////////////////////////////
				//  Swiper Js
				const sliderswiper = new Swiper('.it-slider-active', {
					speed: 2000,
					slidesPerView: 1,
					loop: true,
					autoplay: <?php echo ($od_slider_auto_switcher === 'yes') ? 'true' : 'false'; ?>,
					effect: 'fade',
					breakpoints: {
						'1400': {
							slidesPerView: 1,
						},
						'1200': {
							slidesPerView: 1,
						},
						'992': {
							slidesPerView: 1,
						},
						'768': {
							slidesPerView: 1,
						},
						'576': {
							slidesPerView: 1,
						},
						'0': {
							slidesPerView: 1,
						},
					},
					navigation: {
						prevEl: '.slider-prev',
						nextEl: '.slider-next',
					},
				});






			});
		</script>

<?php

	}
}


$widgets_manager->register(new OD_Main_Slider());
