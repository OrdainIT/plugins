<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Card extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-card';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Card', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
                 // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


		$this->start_controls_section(
			'od_card_content_section',
			[
				'label' => __( 'Cart Content', 'ordainit-toolkit' ),
			]
		);


        $this->add_control(
			'od_card_title',
			[
				'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses( 'GET A QUOTE', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_card_description',
			[
				'label' => esc_html__( 'Description', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses( 'adipiscing elit, sed do eiusmod', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);
        $this->add_control(
			'od_card_number',
			[
				'label' => esc_html__( 'Number', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => od_kses( '01', 'ordainit-toolkit' ),
                'label_block' => true,
			]
		);


	

		$this->end_controls_section();

        // Card Area Style

		$this->start_controls_section(
			'od_cart_area_style',
			[
				'label' => __( 'Card Area Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style'=> 'layout-1',
                ],
			]
		);


        $this->start_controls_tabs(
            'od_cart_area_style_tabs'
        );


        // Normal

        $this->start_controls_tab(
            'od_cart_area_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_style_normal_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-work-number span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-work-content::after' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_cart_area_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_style_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item:hover .it-work-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-work-item:hover .it-work-number span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-work-item:hover .it-work-content::after' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

		

		$this->end_controls_section();

        // Title Style

		$this->start_controls_section(
			'od_cart_area_title_style',
			[
				'label' => __( 'Title Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);



        $this->start_controls_tabs(
            'od_cart_area_title_style_tabs'
        );


        // Normal

        $this->start_controls_tab(
            'od_cart_area_title_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_title_style_normal_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-work-number span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-content h5' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_cart_area_title_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_title_style_hover_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item:hover .it-work-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-work-item:hover .it-work-number span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-content h5:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cart_area_title_style_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-work-item .it-work-title',
                    '{{WRAPPER}} .it-work-number span',
                    '{{WRAPPER}} .it-choose-content h5',
                ],
			]
		);

		

		$this->end_controls_section();

        // Description Style
		$this->start_controls_section(
			'od_cart_area_icon_style',
			[
				'label' => __( 'Number Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style'=> 'layout-2',
                ],
			]
		);


        $this->start_controls_tabs(
            'od_cart_area_icon_style_tabs'
        );
        // Normal
        $this->start_controls_tab(
            'od_cart_area_icon_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );

        $this->add_control(
			'od_cart_area_icon_style_normal_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-icon' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cart_area_icon_style_normal__bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-icon' => 'background-color: {{VALUE}}',
				],
			]
		);


        $this->end_controls_tab();
        // Hover
        $this->start_controls_tab(
            'od_cart_area_icon_style_hover_tab',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );


         $this->add_control(
			'od_cart_area_icon_style_hover_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-item:hover .it-choose-icon' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cart_area_icon_style_hover__bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-item:hover .it-choose-icon' => 'background-color: {{VALUE}}',
				],
			]
		);




        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cart_area_icon_style_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-choose-icon',
                ],
			]
		);



        $this->end_controls_section();

        // Description Style
		$this->start_controls_section(
			'od_cart_area_description_style',
			[
				'label' => __( 'Description Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


        $this->start_controls_tabs(
            'od_cart_area_description_style_tabs'
        );


        // Normal

        $this->start_controls_tab(
            'od_cart_area_description_style_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_description_style_normal_color',
			[
				'label' => esc_html__( 'Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-content p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_cart_area_description_style_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_cart_area_description_style_hover_color',
			[
				'label' => esc_html__( 'Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item:hover .it-work-content p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-content p:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cart_area_description_style_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-work-content p',
                    '{{WRAPPER}} .it-choose-content p',
                ],
			]
		);

		

		$this->end_controls_section();
		// Description Style
		$this->start_controls_section(
			'od_cart_area_border_style',
			[
				'label' => __('Before After Color', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'od_design_style' => 'layout-1',
				],
			]
		);

		// before color

		$this->add_control(
			'od_cart_area_border__before_color',
			[
				'label' => esc_html__('Before Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-number:before' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_cart_area_border__after_color',
			[
				'label' => esc_html__('After Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-number:after' => 'border-color: {{VALUE}}',
				],
			]
		);



		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_card_title = $settings['od_card_title'];
        $od_card_number = $settings['od_card_number'];
        $od_card_description = $settings['od_card_description'];

?>

 <?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

    <div class="it-choose-item d-flex align-items-start">
        <?php if(!empty($od_card_number)): ?>
        <span class="it-choose-icon"><?php echo esc_html($od_card_number, 'ordainit-toolkit');?></span>
        <?php endif;?>
        <div class="it-choose-content">
        <h5><?php echo od_kses($od_card_title, 'ordainit-toolkit');?></h5>
        <p><?php echo od_kses($od_card_description, 'ordainit-toolkit');?></p>
        </div>
    </div>


<?php else: ?>


<div class="it-work-item">
    <div class="it-work-item-box d-flex justify-content-between align-items-center">
        <div class="it-work-number d-none d-xl-block">
            <span><?php echo esc_html($od_card_number, 'ordainit-toolkit');?></span>
        </div>
        <div class="it-work-content">
            <h4 class="it-work-title"><?php echo od_kses($od_card_title, 'ordainit-toolkit');?></h4>
            <p class="mb-0"><?php echo od_kses($od_card_description, 'ordainit-toolkit');?>
            </p>
        </div>
    </div>
</div>
<?php endif;?>

<?php
	}

	
}

$widgets_manager->register( new Od_Card() );