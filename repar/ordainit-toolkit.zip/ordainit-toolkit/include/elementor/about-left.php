<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class About_Left extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-about-left';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD About Left', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

               // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
                    'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
                    'layout-5' => esc_html__('Layout 5', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


		$this->start_controls_section(
			'od_about_left_thumbnail_area',
			[
				'label' => __( 'Thumbnail', 'ordainit-toolkit' ),
			]
		);

        $this->add_control(
			'od_about_left_image1',
			[
				'label' => esc_html__( 'Image 1', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/about/thumb-1.jpg',
				],
			]
		);
        $this->add_control(
			'od_about_left_image2',
			[
				'label' => esc_html__( 'Image 2', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/about/thumb-3.jpg',
				],
			]
		);
        $this->add_control(
			'od_about_left_image3',
			[
				'label' => esc_html__( 'Image 3', 'ordainit-toolkit' ),
				'description' => esc_html__( 'This Control Only For Style 1','ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/about/thumb-2.jpg',
				],
			]
		);

		



		$this->end_controls_section();

		$this->start_controls_section(
			'od_about_left_experience',
			[
				'label' => __( 'Experience', 'ordainit-toolkit' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2']
                ],
			]
		);

        $this->add_control(
			'od_about_left_experience_switcher',
			[
				'label' => esc_html__( 'Show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);



        $this->add_control(
			'od_about_left_experience_content',
			[
				'label' => esc_html__( 'Content', 'ordainit-toolki' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => od_kses( '<h6>16+</h6><span>Years <br>Experience</span>', 'ordainit-toolki' ),
			]
		);

		
        $this->add_control(
			'od_about_left_experience_counter',
			[
				'label' => esc_html__( 'Counter Number', 'ordainit-toolki' ),
				'description' => esc_html__( 'This Control Only For Style 2','ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'rows' => 10,
				'default' => od_kses( '25', 'ordainit-toolki' ),
			]
		);
		
        $this->add_control(
			'od_about_left_experience_stymbol',
			[
				'label' => esc_html__( 'Symbol', 'ordainit-toolki' ),
				'description' => esc_html__( 'This Control Only For Style 2','ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'rows' => 10,
				'default' => od_kses( '+', 'ordainit-toolki' ),
			]
		);

         $this->add_control(
			'od_about_left_experience_bg',
			[
				'label' => esc_html__( 'Background Image', 'ordainit-toolkit' ),
				'description' => esc_html__( 'This Control Only For Style 1','ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/shape/about.png',
				],
			]
		);



		



		$this->end_controls_section();

        $this->start_controls_section(
			'od_about_left_section_style_area',
			[
				'label' => __( 'Experience Area', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_about_left_section_area_bg',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-experience' => 'background-color: {{VALUE}}',
				],
			]
		);
       $this->add_responsive_control(
            'od_about_left_section_area_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
       $this->add_responsive_control(
            'od_about_left_section_area_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

		$this->start_controls_section(
			'od_about_left_section_title_style_area',
			[
				'label' => __( 'Experience Title Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
			'od_about_left_experience_title',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-experience h6' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-2-experience h6.text-white' => 'color: {{VALUE}}',
				],
			]
		);
          $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_left_experience_title_typography',
				'selector' => '{{WRAPPER}} .it-about-2-experience h6',
			]
		);

        $this->add_responsive_control(
            'od_about_left_experience_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_left_experience_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience h6' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
			'od_about_left_section_style_description_area',
			[
				'label' => __( 'Experience Description Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
			'od_about_left_experience_description',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-experience span' => 'color: {{VALUE}}',
				],
			]
		);
          $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_left_experience_description_typography',
				'selector' => '{{WRAPPER}} .it-about-2-experience span',
			]
		);

        $this->add_responsive_control(
            'od_about_left_experience_description_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_about_left_experience_description_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-experience span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_about_left_image1 = $settings['od_about_left_image1'];
        $od_about_left_image2 = $settings['od_about_left_image2'];
        $od_about_left_image3 = $settings['od_about_left_image3'];
        $od_about_left_experience_content = $settings['od_about_left_experience_content'];
        $od_about_left_experience_bg = $settings['od_about_left_experience_bg'];
        $od_about_left_experience_switcher = $settings['od_about_left_experience_switcher'];
        $od_about_left_experience_counter = $settings['od_about_left_experience_counter'];
        $od_about_left_experience_stymbol = $settings['od_about_left_experience_stymbol'];

    ?>

	<?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

	<div class="it-about-3-area">
			<div class="it-about-2-left p-relative">
			<?php if(!empty($od_about_left_experience_switcher)):?>
			<div class="it-about-2-experience d-none d-xl-flex fix">
				<div>
					<h6 class=""><i class="purecounter" data-purecounter-duration="0" data-purecounter-end="<?php echo esc_attr($od_about_left_experience_counter, 'ordainit-toolkit');?>"><?php echo esc_html($od_about_left_experience_counter, 'ordainit-toolkit');?></i><?php echo esc_html($od_about_left_experience_stymbol, 'ordainit-toolkit');?></h6>
					<span class="d-block">
						<?php echo od_kses($od_about_left_experience_content, 'ordainit-toolkit');?>
					</span>
					<span>
						<svg width="49" height="10" viewBox="0 0 49 10" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M1.92496 8.0511C4.77728 8.17092 6.32125 6.5524 7.54907 5.2665C8.65506 4.11386 9.52997 3.20518 11.2162 3.27129C12.9024 3.3374 13.7021 4.31165 14.7095 5.55007C15.8375 6.93293 17.2388 8.66398 20.0911 8.78381C22.9434 8.90364 24.4758 7.28458 25.7152 5.99921C26.8212 4.84657 27.6845 3.93737 29.3823 4.004C31.0685 4.07011 31.8682 5.04436 32.8756 6.28278C34.0037 7.66564 35.4049 9.3967 38.2572 9.51652C41.1095 9.63635 42.6419 8.01729 43.8813 6.73193C44.9873 5.57929 45.8507 4.67008 47.5484 4.73672C48.2642 4.76969 48.8571 4.20679 48.8896 3.50233C48.9115 2.77425 48.3603 2.18178 47.656 2.14933C44.8037 2.02951 43.2713 3.64856 42.0319 4.93393C40.9259 6.08657 40.0626 6.99578 38.3648 6.92914C36.6786 6.86303 35.8789 5.88878 34.8715 4.65036C33.7435 3.2675 32.3422 1.53645 29.4899 1.41662C26.6376 1.29679 25.1052 2.91585 23.8658 4.20122C22.7598 5.35385 21.8965 6.26306 20.1987 6.19643C18.5125 6.13032 17.7128 5.15607 16.7054 3.91764C15.5773 2.53479 14.1761 0.803732 11.3238 0.683906C8.47148 0.56408 6.92751 2.1826 5.69968 3.4685C4.5937 4.62114 3.73033 5.53035 2.03259 5.46371C1.31569 5.45383 0.723355 6.00519 0.690902 6.70965C0.657918 7.42565 1.22068 8.01865 1.92496 8.0511Z" fill="white"></path>
						</svg>
					</span>
				</div>
			</div>
			<?php endif;?>
			<div class="it-about-2-thumb-box">
			<div class="it-about-2-thumb shine-hover thumb-style-1">
				<div class="shine">  
					<img src="<?php echo esc_url($od_about_left_image1['url'], 'ordainit-toolkit');?>" alt="">
				</div>
			</div>
			</div>
			<div class="it-about-2-thumb shine-hover thumb-style-2">
			<div class="shine">  
				<img src="<?php echo esc_url($od_about_left_image2['url'], 'ordainit-toolkit');?>" alt="">
			</div>
			</div>
		</div>
	</div>
		


	<?php else:?>

    <div class="it-about-2-left p-relative">
        <?php if(!empty($od_about_left_experience_switcher)): ?>
        <div class="it-about-2-experience d-none d-md-block fix">
            <?php echo od_kses($od_about_left_experience_content, 'ordainit-toolkit');?>
            <div class="it-about-2-experience-shape">
            <img src="<?php echo esc_url($od_about_left_experience_bg['url'], 'ordainit-toolkit');?>" alt="">
            </div>
        </div>
        <?php endif; ?>
        <div class="it-about-2-thumb-box">
            <div class="it-about-2-thumb shine-hover thumb-style-1 d-block">
            <div class="shine d-inline-block">
                <img src="<?php echo esc_url($od_about_left_image1['url'], 'ordainit-toolkit');?>" alt="">
            </div>
            </div>
            <div class="it-about-2-thumb shine-hover thumb-style-3">
            <div class="shine d-inline-block">
                <img src="<?php echo esc_url($od_about_left_image2['url'], 'ordainit-toolkit');?>" alt="">
            </div>
            </div>
        </div>
        <div class="it-about-2-thumb shine-hover thumb-style-2">
            <div class="shine d-inline-block">
            <img src="<?php echo esc_url($od_about_left_image3['url'], 'ordainit-toolkit');?>" alt="">
            </div>
        </div>
    </div>

	<?php endif;?>

    


    <?php



		
	}

	
}

$widgets_manager->register( new About_Left() );