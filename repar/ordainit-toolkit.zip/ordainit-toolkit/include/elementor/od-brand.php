<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Brand extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'od-brand';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('OD Brand', 'ordainit-toolkit');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends()
	{
		return ['ordainit-toolkit'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls()
	{
		// layout Panel
		$this->start_controls_section(
			'od_layout',
			[
				'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
			]
		);
		$this->add_control(
			'od_design_style',
			[
				'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
					'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
					'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
				],
				'default' => 'layout-1',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'od_brand_content_section',
			[
				'label' => __('Brand Gallery', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-1', 'layout-2'],
				],
			]
		);



		$this->add_control(
			'od_brand_gallery_image',
			[
				'label' => esc_html__('Add Slider Images', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]

		);




		$this->add_control(
			'brand_slider_star_image',
			[
				'label' => esc_html__('Choose Star Image', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-1'],
				],
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-03/brand/star.png',
				],
			]
		);






		$this->end_controls_section();

		$this->start_controls_section(
			'od_brand_content_section3',
			[
				'label' => __('Brand Content', 'ordainit-toolkit'),
				'condition' => [
					'od_design_style' => ['layout-3'],
				],
			]
		);

		$this->add_control(
			'od_brand_content3_bgimage',
			[
				'label' => esc_html__('Background Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-04/shape/cta-shape.png',
				],
			]
		);


		$this->add_control(
			'od_brand_content3_image',
			[
				'label' => esc_html__('Choose Image', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/logo/logo-white-2.png',
				],
			]
		);

		$this->add_control(
			'od_brand_content3_heading',
			[
				'label' => esc_html__('Social Area', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'od_brand_social_title',
			[
				'label' => esc_html__('Follow Text', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => od_kses('Foillow US :', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_brand_social_facebook',
			[
				'label' => esc_html__('Facebook URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_brand_social_pinterest',
			[
				'label' => esc_html__('Pinterest URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
			]
		);

		$this->add_control(
			'od_brand_social_skype',
			[
				'label' => esc_html__('Skype URL', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'ordainit-toolkit'),
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'od_brand_content_style',
			[
				'label' => __('Brand Style', 'ordainit-toolkit'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'od_brand_content_bg_color',
			[
				'label' => esc_html__('Background Color', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-brand-wrap' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .swiper-container.it-brand-active-2' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-cta-wrap' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'od_brand_content_margin',
			[
				'label' => esc_html__('Margin', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-brand-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-container.it-brand-active-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-cta-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'od_brand_content_padding',
			[
				'label' => esc_html__('Padding', 'ordainit-toolkit'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .it-brand-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-container.it-brand-active-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-cta-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_brand_content_border',
				'selector' => '{{WRAPPER}} .it-brand-wrap, {{WRAPPER}} .swiper-container.it-brand-active-2, {{WRAPPER}} .it-cta-wrap',
			]
		);

		$this->add_control(
			'od_brand_content_border_radius',
			[
				'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .it-brand-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-container.it-brand-active-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .it-cta-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$od_brand_gallery_image = $settings['od_brand_gallery_image'];
		$brand_slider_star_image = $settings['brand_slider_star_image'];
?>
		<?php if ($settings['od_design_style']  == 'layout-2'): ?>
			<div class="swiper-container it-brand-active-2">
				<div class="swiper-wrapper slider-transtion d-flex align-items-center">
					<?php foreach ($od_brand_gallery_image as $single_brand_image): ?>
						<div class="swiper-slide">
							<div class="it-brand-item text-center text-xxl-start">
								<img src="<?php echo esc_url($single_brand_image['url'], 'ordainit-toolkit'); ?>" alt="">
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>


		<?php elseif ($settings['od_design_style']  == 'layout-3'):
			$od_brand_content3_bgimage = $settings['od_brand_content3_bgimage'];
			$od_brand_content3_image = $settings['od_brand_content3_image'];
			$od_brand_social_title = $settings['od_brand_social_title'];
			$od_brand_social_facebook = $settings['od_brand_social_facebook'];
			$od_brand_social_pinterest = $settings['od_brand_social_pinterest'];
			$od_brand_social_skype = $settings['od_brand_social_skype'];
		?>

			<div class="it-cta-wrap flex-wrap text-center d-sm-flex justify-content-between align-items-center orange-bg z-index-2" style="background-image: url(<?php echo esc_url($od_brand_content3_bgimage['url'], 'ordainit-toolkit'); ?>);">
				<div class="it-cta-logo">
					<img src="<?php echo esc_url($od_brand_content3_image['url'], 'ordainit-toolkit'); ?>" alt="">
				</div>
				<div class="it-cta-social">
					<span><?php echo esc_html($od_brand_social_title, 'ordainit-toolkit'); ?></span>
					<?php if (!empty($od_brand_social_facebook)): ?>
						<a href="<?php echo esc_url($od_brand_social_facebook, 'ordainit-toolkit'); ?>">
							<i class="fa-brands fa-facebook"></i>
						</a>
					<?php endif; ?>
					<?php if (!empty($od_brand_social_pinterest)): ?>
						<a href="<?php echo esc_url($od_brand_social_pinterest, 'ordainit-toolkit'); ?>">
							<i class="fa-brands fa-pinterest"></i>
						</a>
					<?php endif; ?>
					<?php if (!empty($od_brand_social_skype)): ?>
						<a href="<?php echo esc_url($od_brand_social_skype, 'ordainit-toolkit'); ?>">
							<i class="fa-brands fa-skype"></i>

						</a>
					<?php endif; ?>
				</div>
			</div>
		<?php else: ?>
			<div class="it-brand-wrap">
				<div class="swiper-container it-brand-active">
					<div class="swiper-wrapper">
						<?php foreach ($od_brand_gallery_image as $single_brand_image): ?>
							<div class="swiper-slide">
								<div class="it-brand-item text-center text-xxl-start">
									<img src="<?php echo esc_url($single_brand_image['url'], 'ordainit-toolkit'); ?>" alt="">
									<span class="it-brand-star d-none d-xxl-inline-block"><img src="<?php echo esc_url($brand_slider_star_image['url'], 'ordainit-toolkit'); ?>"
											alt=""></span>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
		<script>
			"use strict";
			jQuery(document).ready(function($) {

				////////////////////////////////////////////////////
				//  Swiper Js
				const brandswiper = new Swiper(".it-brand-active", {
					// Optional parameters
					speed: 1500,
					loop: true,
					slidesPerView: 4,
					spaceBetween: 0,
					autoplay: true,
					breakpoints: {
						1400: {
							slidesPerView: 4,
						},
						1200: {
							slidesPerView: 4,
						},
						992: {
							slidesPerView: 3,
						},
						768: {
							slidesPerView: 2,
						},
						576: {
							slidesPerView: 2,
						},
						0: {
							slidesPerView: 1,
						},
					},
				});


				////////////////////////////////////////////////////
				// 13. Swiper Js
				var it_brand = new Swiper(".it-brand-active-2", {
					loop: true,
					freemode: true,
					slidesPerView: 'auto',
					spaceBetween: 100,
					centeredSlides: true,
					allowTouchMove: false,
					speed: 2500,
					autoplay: {
						delay: 1,
						disableOnInteraction: true,
					},
				});






			});
		</script>
<?php
	}
}

$widgets_manager->register(new Od_Brand());
