<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Popup_Video extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-popup-video';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Popup Video', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        
              // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('layout 2', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
		$this->start_controls_section(
			'od_popup_video_area',
			[
				'label' => __( 'Popup Video Content', 'ordainit-toolkit' ),
			]
		);


        $this->add_control(
			'od_popup_video_image',
			[
				'label' => esc_html__( 'Choose Image', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  ORDAINIT_TOOLKIT_ADDONS_URL . 'assets/dummy/home-02/about/video.jpg',
				],
			]
		);

        $this->add_control(
			'od_popup_video_url',
			[
				'label' => esc_html__( 'Video URL', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'ordainit-toolkit' ),
                'label_block' =>true,
			]
		);



		


	

		$this->end_controls_section();

		$this->start_controls_section(
			'od_popup_video_section_style',
			[
				'label' => __( 'Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


         $this->add_control(
			'od_popup_video_icon_color',
			[
				'label' => esc_html__( 'Icon  Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-video-btn svg' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-2-video-btn svg path' => 'fill: {{VALUE}}',
				],
			]
		);

         $this->add_control(
			'od_popup_video_bg_color',
			[
				'label' => esc_html__( 'Icon Bg Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-video-btn' => 'background-color: {{VALUE}}',
				],
			]
		);

	

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $od_popup_video_image =$settings['od_popup_video_image'];
        $od_popup_video_url =$settings['od_popup_video_url'];

		?>
 <?php if ( $settings['od_design_style']  == 'layout-2' ): ?>
        <div class="style-2 it-about-4-thumb-wrap">
            <div class="it-about-4-thumb shine-hover p-relative">
                <div class="shine zoom-effect">
                    <img src="<?php echo esc_url($od_popup_video_image['url'], 'ordainit-toolkit');?>" alt="">
                </div>
                <a class="it-about-2-video-btn popup-video" href="<?php echo esc_url($od_popup_video_url, 'ordainit-toolkit');?>">
                        <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                        </svg>
                </a>                    
            </div>
        </div>

<?php else: ?>

        <div class="it-about-2-video-thumb p-relative ">
            <img src="<?php echo esc_url($od_popup_video_image['url'], 'ordainit-toolkit');?>" alt="">
            <a class="it-about-2-video-btn popup-video" href="<?php echo esc_url($od_popup_video_url, 'ordainit-toolkit');?>">
                <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="#0A0909"></path>
                </svg>
            </a>
            </div>
        <?php endif;?>
<style>
    .style-2  .it-about-2-video-btn {
    height: 77px;
    width: 77px;
    line-height: 75px;
    background-color: var(--it-common-white);
    animation: ripple-white 1s linear infinite;
}
 .style-2  .it-about-2-video-btn svg {
    width: 18px;
    height: 16px;
    color: var(--it-theme-2);
}
</style>

<?php
	}
	
}

$widgets_manager->register( new Od_Popup_Video() );