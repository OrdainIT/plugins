<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Utils;
use \Elementor\Control_Media;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_Heading extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-heading';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Title Box', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {


        // od_section_title
        $this->start_controls_section(
            'od_section_title',
            [
                'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
			'od_heading_sub_title_switcher',
			[
				'label' => esc_html__( 'show/Hide', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

         $this->add_control(
			'od_heading_sub_title_icon_switcher',
			[
				'label' => esc_html__( 'Left Icon show/Hide', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        
         $this->add_control(
			'od_heading_sub_title_icon2_switcher',
			[
				'label' => esc_html__( 'Right Icon show/Hide', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('OD Sub Title', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        
        $this->add_control(
			'od_heading_title_switcher',
			[
				'label' => esc_html__( 'show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
            'od_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('OD Title Here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        
        $this->add_control(
			'od_heading_description_switcher',
			[
				'label' => esc_html__( 'show/Hide', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ordainit-toolkit' ),
				'label_off' => esc_html__( 'Hide', 'ordainit-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
            'od_desctiption',
            [
                'label' => esc_html__('Description', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('OD section description here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type section description here', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'ordainit-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'ordainit-toolkit'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'od_align',
            [
                'label' => esc_html__('Alignment', 'ordainit-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ordainit-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};'
                ]
            ]
        );
        $this->end_controls_section();

       
        // TAB_STYLE
        $this->start_controls_section(
            'od_heading_subtitle_section_style',
            [
                'label' => __( 'Sub title', 'ordainit-toolkit' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'od_heading_subtitle_tabs_area'
        );

        $this->start_controls_tab(
            'od_heading_subtitle_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_heading_subtitle_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle span' => 'color: {{VALUE}}',
				],
			]
		);





        $this->end_controls_tab();

        

        $this->start_controls_tab(
            'od_heading_subtitle_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

         $this->add_control(
			'od_heading_subtitle_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle:hover span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();


        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_heading_subtitle_typography',
				'selector' => '{{WRAPPER}} .it-section-subtitle, {{WRAPPER}} .it-section-subtitle span',
			]
		);

        $this->add_responsive_control(
            'od_heading_subtitle_margin_style',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        
        $this->add_responsive_control(
            'od_heading_subtitle_padding_style',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

         // style tab here
        $this->start_controls_section(
            'od_heading_title_section_style',
            [
                'label' => __( 'Title Style', 'ordainit-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'od_heading_title__style_tabs'
        );

        $this->start_controls_tab(
            'od_heading_title_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_heading_title_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
				],
			]
		);

        
        $this->add_control(
			'od_heading_stitle_normal_color',
			[
				'label' => esc_html__( 'Secoundary Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title span' => 'color: {{VALUE}}',
				],
			]
		);



        $this->end_controls_tab();

        
        $this->start_controls_tab(
            'od_heading_title_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

           $this->add_control(
			'od_heading_title_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title:hover' => 'color: {{VALUE}}',
				],
			]
		);

        
        $this->add_control(
			'od_heading_stitle_hover_color',
			[
				'label' => esc_html__( 'Secoundary Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title:hover span' => 'color: {{VALUE}}',
				],
			]
		);




        $this->end_controls_tab();

        

        $this->end_controls_tabs();

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_heading_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title',
			]
		);

        $this->add_responsive_control(
            'od_heading_title_margin_style',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_heading_title_padding_style',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();


          // style tab here
        $this->start_controls_section(
            'od_heading_descriptions_section_style',
            [
                'label' => __( 'Descriptions Style', 'ordainit-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

         $this->start_controls_tabs(
            'od_heading_descriptions__style_tabs'
        );

        $this->start_controls_tab(
            'od_heading_description_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'ordainit-toolkit' ),
            ]
        );

        $this->add_control(
			'od_heading_description_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-title-box p' => 'color: {{VALUE}}',
				],
			]
		);

        
      



        $this->end_controls_tab();

        
        $this->start_controls_tab(
            'od_heading_description_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'ordainit-toolkit' ),
            ]
        );

           $this->add_control(
			'od_heading_decription_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-service-title-box p:hover' => 'color: {{VALUE}}',
				],
			]
		);

      




        $this->end_controls_tab();

        

        $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_heading_description_typography',
				'selector' => '{{WRAPPER}} .it-service-title-box p',
			]
		);

        $this->add_responsive_control(
            'od_heading_description_margin_style',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-service-title-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

          $this->add_responsive_control(
            'od_heading_description_padding_style',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-service-title-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


         $this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute('title_args', 'class', 'it-section-title mb-20');
        $this->add_render_attribute('od_align', 'class', 'it-service-title-box d-inline-block');
        $od_heading_descriptions = $settings['od_desctiption'];
        $od_heading_sub_title_switcher = $settings['od_heading_sub_title_switcher'];
        $od_heading_title_switcher = $settings['od_heading_title_switcher'];
        $od_heading_description_switcher = $settings['od_heading_description_switcher'];
        $od_heading_sub_title_icon_switcher = $settings['od_heading_sub_title_icon_switcher'];
        $od_heading_sub_title_icon2_switcher = $settings['od_heading_sub_title_icon2_switcher'];

       

		?>
        <div <?php echo $this->get_render_attribute_string( 'od_align' );?> >
            <?php if(!empty($od_heading_sub_title_switcher)):?>
            <span class="it-section-subtitle mb-15">
                <?php if(!empty($od_heading_sub_title_icon_switcher)):?>
                <span>
                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor"></path>
                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor"></path>
                    </svg>
                </span>
                <?php endif;?>
                <?php echo od_kses( $settings['od_sub_title'] ); ?>
                <?php if(!empty($od_heading_sub_title_icon2_switcher)):?>
                <span>
                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor"></path>
                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor"></path>
                    </svg>
                </span>
                <?php endif;?>
            </span>
            <?php endif;?>
              <?php
            if ( !empty($od_heading_title_switcher) ) :
                printf(
                    '<%1$s %2$s>%3$s</%1$s>',
                    esc_attr( $settings['od_title_tag'] ), // Use esc_attr to escape the tag attribute.
                    $this->get_render_attribute_string( 'title_args' ),
                    od_kses( $settings['od_title'] ),
                );
            endif;
            ?>
            <?php if(!empty($od_heading_description_switcher)):?>
            <p><?php echo od_kses($od_heading_descriptions, 'ordainit-toolkit');?></p>
            <?php endif;?>
        </div>
       


        <?php
 
	}
}

$widgets_manager->register( new Od_Heading() );