<?php

namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_Blog_Post extends Widget_Base
{

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'od-blog-post';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('OD Blog Post', 'ordainit-toolkit');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'od-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends()
    {
        return ['ordainit-toolkit'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {


        // od_section_title
        $this->start_controls_section(
            'od_section_title',
            [
                'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );

        $this->add_control(
            'od_section_title_show',
            [
                'label' => esc_html__('Section Title & Content', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'od_section_sub_title_icon_switcher',
            [
                'label' => esc_html__('Sub Title Icon Show/Hide', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc('basic'),
                'type' => Controls_Manager::TEXT,
                'default' => od_kses('BLOG POST', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc('intermediate'),
                'type' => Controls_Manager::TEXT,
                'default' => od_kses('Our Blog', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_description',
            [
                'label' => esc_html__('Description', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc('intermediate'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Description here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type section description here', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-4', 'layout-5']
                ],
            ]
        );

        $this->add_control(
            'od_blog_post_shap',
            [
                'label' => esc_html__('Shap Image', 'textdomain'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => ORDAINIT_TOOLKIT_ADDONS_URL . '/assets/dummy/home-01/shape/blog.png',
                ],
            ]
        );




        $this->end_controls_section();

        // od_btn_button_group
        $this->start_controls_section(
            'od_blog_post_settings',
            [
                'label' => esc_html__('Settings', 'ordainit-toolkit'),


            ]
        );

        $this->add_control(
            'od_blog_post_arrow_switcher',
            [
                'label' => esc_html__('Arrow Show/Hide', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'description' => esc_html__('This Switcher For Only Layout 1', 'ordainit-toolkit'),
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'od_blog_post_button_switcher',
            [
                'label' => esc_html__('Blog Button Show/Hide', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'od_blog_post_button_icon_switcher',
            [
                'label' => esc_html__('Blog Button Icon Show/Hide', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'od_blog_post_meta_switcher',
            [
                'label' => esc_html__('Post Meta Show/Hide', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_blog_button_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type your title here', 'ordainit-toolkit'),
            ]
        );



        $this->end_controls_section();

        // od_btn_button_group
        $this->start_controls_section(
            'od_btn_button_group',
            [
                'label' => esc_html__('Button', 'ordainit-toolkit'),

                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-5']
                ],
            ]
        );

        $this->add_control(
            'od_btn_button_show',
            [
                'label' => esc_html__('Show Button', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_btn_text',
            [
                'label' => esc_html__('Button Text', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('All Blog Post', 'ordainit-toolkit'),
                'title' => esc_html__('Enter button text', 'ordainit-toolkit'),
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'od_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'od_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'od_btn_link',
            [
                'label' => esc_html__('Button link', 'ordainit-toolkit'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htods://your-link.com', 'ordainit-toolkit'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'od_btn_link_type' => '1',
                    'od_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'od_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => od_get_all_pages(),
                'condition' => [
                    'od_btn_link_type' => '2',
                    'od_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

        // Blog Query
        $this->start_controls_section(
            'od_post_query',
            [
                'label' => esc_html__('Blog Query', 'ordainit-toolkit'),
            ]
        );

        $post_type = 'post';
        $taxonomy = 'category';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'ordainit-toolkit'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'ordainit-toolkit'),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'ordainit-toolkit'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => od_get_categories($taxonomy),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_category',
            [
                'label' => esc_html__('Exclude Categories', 'ordainit-toolkit'),
                'description' => esc_html__('Select a category to exclude', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => od_get_categories($taxonomy),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post__not_in',
            [
                'label' => esc_html__('Exclude Item', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => od_get_all_types_post($post_type),
                'multiple' => true,
                'label_block' => true
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => esc_html__('Offset', 'ordainit-toolkit'),
                'type' => Controls_Manager::NUMBER,
                'default' => '0',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
                    'ID' => 'Post ID',
                    'author' => 'Post Author',
                    'title' => 'Title',
                    'date' => 'Date',
                    'modified' => 'Last Modified Date',
                    'parent' => 'Parent Id',
                    'rand' => 'Random',
                    'comment_count' => 'Comment Count',
                    'menu_order' => 'Menu Order',
                ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc'     => esc_html__('Ascending', 'ordainit-toolkit'),
                    'desc'     => esc_html__('Descending', 'ordainit-toolkit')
                ],
                'default' => 'desc',

            ]
        );
        $this->add_control(
            'ignore_sticky_posts',
            [
                'label' => esc_html__('Ignore Sticky Posts', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'ordainit-toolkit'),
                'label_off' => esc_html__('No', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_blog_title_word',
            [
                'label' => esc_html__('Title Word Count', 'ordainit-toolkit'),
                'description' => esc_html__('Set how many word you want to displa!', 'ordainit-toolkit'),
                'type' => Controls_Manager::NUMBER,
                'default' => '6',
            ]
        );

        $this->add_control(
            'od_post_content',
            [
                'label' => __('Content', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'ordainit-toolkit'),
                'label_off' => __('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'od_post_content_limit',
            [
                'label' => __('Content Limit', 'ordainit-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '14',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'od_post_content' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();


        // layout Panel
        $this->start_controls_section(
            'od_post_',
            [
                'label' => esc_html__('Blog - Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),
                    'layout-2' => esc_html__('Layout 2', 'ordainit-toolkit'),
                    'layout-3' => esc_html__('Layout 3', 'ordainit-toolkit'),
                    'layout-4' => esc_html__('Layout 4', 'ordainit-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'od-post-thumb',
            ]
        );
        $this->add_control(
            'od_post__pagination',
            [
                'label' => esc_html__('Pagination', 'ordainit-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'ordainit-toolkit'),
                'label_off' => esc_html__('Hide', 'ordainit-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => array(
                    'od_design_style' => 'layout-1',
                ),
            ]
        );
        $this->end_controls_section();






        // style control

        $this->start_controls_section(
            'od_blog_post_area_bg',
            [
                'label' => __('Blog Area', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );

        $this->add_control(
            'od_blog_post_area_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-bg' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-area' => 'background-color: {{VALUE}}',
                ],
            ]
        );




        $this->end_controls_section();


        $this->start_controls_section(
            'od_blog_post_sub_title_area',
            [
                'label' => __('Sub Title', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );


        $this->add_control(
            'od_blog_post_sub_title_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-section-subtitle span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_blog_post_sub_title_typography',
                'selector' => '{{WRAPPER}} .it-section-subtitle',
            ]
        );






        $this->end_controls_section();

        // Title Style

        $this->start_controls_section(
            'od_blog_post_title_area',
            [
                'label' => __('Title Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );



        $this->add_control(
            'od_blog_post_title_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-section-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_blog_post_title_typography',
                'selector' => '{{WRAPPER}} .it-section-title',
            ]
        );







        $this->end_controls_section();


        // Arrow Style

        $this->start_controls_section(
            'od_blog_post_arrow_area',
            [
                'label' => __('Arrow Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );


        $this->start_controls_tabs(
            'od_blog_post_arrow_style_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_blog_post_arrow_style_normal_tab',
            [
                'label' => esc_html__('Normal', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_blog_post_arrow_style_normal_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.blog-style button span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'od_blog_post_arrow_style_normal_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.blog-style button span' => 'background-color: {{VALUE}}',
                ],
            ]
        );



        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_blog_post_arrow_style_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_blog_post_arrow_style_hover_color',
            [
                'label' => esc_html__('Icon Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.blog-style button:hover span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'od_blog_post_arrow_style_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-arrow-box.blog-style button:hover span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();






        $this->end_controls_section();

        // Post Bg Style

        $this->start_controls_section(
            'od_blog_post_bg_style_area',
            [
                'label' => __('Post Background Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
            ]
        );


        $this->start_controls_tabs(
            'od_blog_post_bg_style_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_blog_post_bg_style_normal_tab',
            [
                'label' => esc_html__('Normal', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_blog_post_bg_style_normal_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-2-item' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_blog_post_bg_style_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );

        $this->add_control(
            'od_blog_post_bg_style_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-2-item:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();



        $this->end_controls_tabs();


        $this->add_responsive_control(
            'od_blog_post_bg_style_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-blog-2-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_blog_post_bg_style_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-blog-2-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();


        // Post Style

        $this->start_controls_section(
            'od_blog_post_style_area',
            [
                'label' => __('Post Style', 'ordainit-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'od_blog_post_style_title_area',
            [
                'label' => esc_html__('Title Style', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'od_blog_post_style_title_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_blog_post_style_title_typography',
                'selector' => '{{WRAPPER}} .it-blog-title',
            ]
        );



        $this->add_control(
            'od_blog_post_style_meta_area',
            [
                'label' => esc_html__('Meta Style', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'od_blog_post_style_meta_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-meta span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-2-meta span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_blog_post_style_meta_hover_color',
            [
                'label' => esc_html__('Hover Text Color', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-2-item:hover .it-blog-2-meta span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-2-item:hover .it-blog-2-meta span i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'od_blog_post_style_meta_typography',
                'selectors' => [
                    '{{WRAPPER}} .it-blog-meta span',
                    '{{WRAPPER}} it-blog-2-meta span',
                ],
            ]
        );


        $this->add_control(
            'od_blog_post_style_button_area',
            [
                'label' => esc_html__('Button Style', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs(
            'od_blog_post_style_button_area_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_blog_post_style_button_area_normal_tab',
            [
                'label' => esc_html__('Normal', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_blog_post_style_button_normal_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-2-meta span i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_blog_post_style_button_normal_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_blog_post_style_button_normal_border',
                'selector' => '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm, {{WRAPPER}} .it-blog-2-item:hover .it-btn-grey-sm.orange-btn',
            ]
        );

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_blog_post_style_button_area_hover_tab',
            [
                'label' => esc_html__('Hover', 'ordainit-toolkit'),
            ]
        );


        $this->add_control(
            'od_blog_post_style_button_hover_color',
            [
                'label' => esc_html__('Text Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm:hover i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-2-item:hover .it-btn-grey-sm.orange-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'od_blog_post_style_button_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm:hover' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .it-blog-2-item:hover .it-btn-grey-sm.orange-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'od_blog_post_style_button_hover_border',
                'selector' => '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm:hover, {{WRAPPER}} .it-blog-2-item:hover .it-btn-grey-sm.orange-btn:hover',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();



        $this->add_responsive_control(
            'od_blog_post_style_button_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'od_blog_post_style_button_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );





        // Add border radius control
        $this->add_control(
            'od_blog_post_style_button_border_radius',
            [
                'label' => esc_html__('Border Radius', 'ordainit-toolkit'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .it-blog-item a.it-btn-grey-sm' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .it-btn-grey-sm.orange-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );







        $this->end_controls_section();
    }

    /**
     * Render the widget ouodut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $od_sub_title = $settings['od_sub_title'];
        $od_title = $settings['od_title'];
        $od_section_title_show = $settings['od_section_title_show'];
        $od_btn_text = $settings['od_btn_text'];
        $od_description = $settings['od_description'];
        $od_section_sub_title_icon_switcher = $settings['od_section_sub_title_icon_switcher'];
        $od_blog_post_button_switcher = $settings['od_blog_post_button_switcher'];
        $od_blog_button_text = $settings['od_blog_button_text'];
        $od_blog_post_meta_switcher = $settings['od_blog_post_meta_switcher'];
        $od_blog_post_arrow_switcher = $settings['od_blog_post_arrow_switcher'];
        $od_blog_post_button_icon_switcher = $settings['od_blog_post_button_icon_switcher'];
        $od_blog_post_shap = $settings['od_blog_post_shap'];


        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } else if (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }


        // include_categories
        $category_list = '';
        if (!empty($settings['category'])) {
            $category_list = implode(", ", $settings['category']);
        }
        $category_list_value = explode(" ", $category_list);



        // exclude_categories
        $exclude_categories = '';
        if (!empty($settings['exclude_category'])) {
            $exclude_categories = implode(", ", $settings['exclude_category']);
        }
        $exclude_category_list_value = explode(" ", $exclude_categories);

        $post__not_in = '';
        if (!empty($settings['post__not_in'])) {
            $post__not_in = $settings['post__not_in'];
            $args['post__not_in'] = $post__not_in;
        }

        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';
        $offset_value = (!empty($settings['offset'])) ? $settings['offset'] : '0';


        // number
        $off = (!empty($offset_value)) ? $offset_value : 0;
        $offset = $off + (($paged - 1) * $posts_per_page);
        $p_ids = array();

        // build up the array
        if (!empty($settings['post__not_in'])) {
            foreach ($settings['post__not_in'] as $p_idsn) {
                $p_ids[] = $p_idsn;
            }
        }






        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'offset' => $offset,
            'paged' => $paged,
            'post__not_in' => $p_ids,
        );


        // exclude_categories
        if (!empty($settings['exclude_category'])) {

            // Exclude the correct cats from tax_query
            $args['tax_query'] = array(
                array(
                    'taxonomy'    => 'category',
                    'field'         => 'slug',
                    'terms'        => $exclude_category_list_value,
                    'operator'    => 'NOT IN'
                )
            );

            // Include the correct cats in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query']['relation'] = 'AND';
                $args['tax_query'][] = array(
                    'taxonomy'    => 'category',
                    'field'        => 'slug',
                    'terms'        => $category_list_value,
                    'operator'    => 'IN'
                );
            }
        } else {
            // Include the cats from $cat_slugs in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query'][] = [
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $category_list_value,
                ];
            }
        }




        // The Query
        $query = new \WP_Query($args);





?>



        <?php if ($settings['od_design_style']  == 'layout-2'): ?>



            <div class="it-blog-area it-blog-syle-2 p-relative z-index-1">
                <div class="container">
                    <div class="row">

                        <?php

                        $i = -1;

                        if ($query->have_posts()) : ?>
                            <?php while ($query->have_posts()) :
                                $i++;

                                $query->the_post();
                                $_post_thumbnail = get_field('post_single_thumbnail');
                                global $post;
                            ?>

                                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s" data-wow-delay="<?php echo esc_attr(.3 + $i * .2); ?>s">
                                    <div class="it-blog-item">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <div class="it-blog-thumb shine-hover fix">
                                                <div class="shine">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php if (!empty($_post_thumbnail)): ?>
                                                            <img src="<?php echo esc_url($_post_thumbnail['url']); ?>" alt="">
                                                        <?php else: ?>
                                                            <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="it-blog-content">
                                            <?php if (!empty($od_blog_post_meta_switcher)): ?>
                                                <div class="it-blog-meta">
                                                    <span><?php echo esc_html__('BY', 'ordainit-toolkit'); ?> <?php echo get_the_author(); ?></span>
                                                    <span><?php echo comments_number(); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <h4 class="it-blog-title"><a class="border-line-black" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                            <?php if (!empty($od_blog_post_button_switcher)): ?>
                                                <a href="<?php the_permalink(); ?>" class="it-btn-grey-sm yellow-btn">
                                                    <?php echo esc_html($od_blog_button_text, 'ordainit-toolkit'); ?>
                                                    <?php if (!empty($od_blog_post_button_icon_switcher)): ?>
                                                        <i>
                                                            <svg width="21" height="12" viewBox="0 0 21 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z" fill="currentcolor"></path>
                                                            </svg>
                                                        </i>
                                                    <?php endif; ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>


                            <?php endwhile;
                            wp_reset_query(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>





        <?php elseif ($settings['od_design_style']  == 'layout-3'): ?>


            <!-- blog-area-start -->
            <div class="it-blog-3-area">
                <div class="container">
                    <div class="row">


                        <?php $x = -1;
                        if ($query->have_posts()) : ?>
                            <?php $i = 0;
                            while ($query->have_posts()) :
                                $i++;
                                $x++;
                                $query->the_post();
                                $_post_thumbnail = get_field('post_single_thumbnail');
                                global $post;
                            ?>
                                <div class="col-lg-6 mb-30 wow itfadeUp" data-wow-duration=".9s" data-wow-delay="<?php echo esc_attr(.3 + $x * .2); ?>s">


                                    <?php if ($i === 1 || $i === 4): ?>
                                        <div class="it-blog-2-item d-flex justify-content-between align-items-center">
                                            <div class="it-blog-2-content">
                                                <?php if (!empty($od_blog_post_meta_switcher)): ?>
                                                    <div class="it-blog-2-meta mb-15">
                                                        <span><i class="fa-light fa-calendar-days"></i> <?php echo get_the_date(); ?></span>
                                                        <span><i class="fa-light fa-messages"></i><?php echo comments_number(); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <h4 class="it-blog-title"><a class="border-line-white" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                <?php if (!empty($od_blog_post_button_switcher)): ?>
                                                    <a href="<?php the_permalink(); ?>" class="it-btn-grey-sm orange-btn">
                                                        <?php echo esc_html($od_blog_button_text, 'ordainit-toolkit'); ?>
                                                        <?php if (!empty($od_blog_post_button_icon_switcher)): ?>
                                                            <i>
                                                                <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </i>
                                                        <?php endif; ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                            <?php if (has_post_thumbnail()) : ?>
                                                <div class="it-blog-2-thumb">
                                                    <?php if (!empty($_post_thumbnail)): ?>
                                                        <img src="<?php echo esc_url($_post_thumbnail['url']); ?>" alt="">
                                                    <?php else: ?>
                                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php else : ?>

                                        <div class="it-blog-2-item d-flex justify-content-between align-items-center style-2">

                                            <?php if (has_post_thumbnail()) : ?>
                                                <div class="it-blog-2-thumb">
                                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                </div>
                                            <?php endif; ?>
                                            <div class="it-blog-2-content">
                                                <?php if (!empty($od_blog_post_meta_switcher)): ?>
                                                    <div class="it-blog-2-meta mb-15">
                                                        <span><i class="fa-light fa-calendar-days"></i> <?php echo get_the_date(); ?></span>
                                                        <span><i class="fa-light fa-messages"></i><?php echo comments_number(); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <h4 class="it-blog-title"><a class="border-line-white" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                <?php if (!empty($od_blog_post_button_switcher)): ?>
                                                    <a href="<?php the_permalink(); ?>" class="it-btn-grey-sm orange-btn">
                                                        <?php echo esc_html($od_blog_button_text, 'ordainit-toolkit'); ?>
                                                        <?php if (!empty($od_blog_post_button_icon_switcher)): ?>
                                                            <i>
                                                                <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </i>
                                                        <?php endif; ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>




                                </div>

                            <?php endwhile;
                            wp_reset_query(); ?>
                        <?php endif; ?>

                    </div>
                </div>


            </div>
            <!-- blog-area-end -->






        <?php elseif ($settings['od_design_style']  == 'layout-4'): ?>



            <!-- blog-area-start -->
            <div class="it-blog-area it-blog-bg p-relative z-index-1 pt-120 pb-120">
                <div class="it-blog-shape-1">
                    <img src="<?php echo esc_url($od_blog_post_shap['url'], 'ordainit-toolkit'); ?>" alt="">
                </div>
                <div class="container">
                    <div class="it-blog-title-wrap mb-65">
                        <div class="row align-items-end">
                            <div class="col-xl-6 col-lg-7 col-md-8">
                                <?php if (!empty($od_section_title_show)): ?>
                                    <div class="it-blog-title-box">
                                        <span class="it-section-subtitle theme-subtitle mb-15">
                                            <?php if (!empty($od_section_sub_title_icon_switcher)): ?>
                                                <span>
                                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>
                                            <?php echo od_kses($od_sub_title, 'ordainit-toolkit'); ?></span>
                                        <h3 class="it-section-title theme-title"><?php echo od_kses($od_title, 'ordainit-toolkit'); ?></h3>
                                    </div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($od_blog_post_arrow_switcher)): ?>
                            <div class="col-xl-6 col-lg-5 col-md-4">
                                <div class="it-arrow-box blog-style theme-style text-md-end">
                                    <button class="slider-prev">
                                        <span>
                                            <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M0.469669 6.53033C0.176777 6.23744 0.176777 5.76256 0.469669 5.46967L5.24264 0.696699C5.53553 0.403806 6.01041 0.403806 6.3033 0.696699C6.59619 0.989593 6.59619 1.46447 6.3033 1.75736L2.06066 6L6.3033 10.2426C6.59619 10.5355 6.59619 11.0104 6.3033 11.3033C6.01041 11.5962 5.53553 11.5962 5.24264 11.3033L0.469669 6.53033ZM21 6.75H1V5.25H21V6.75Z"
                                                    fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                    <button class="slider-next">
                                        <span>
                                            <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                    fill="currentcolor" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="it-blog-slider-wrapper">
                                <div class="swiper-container it-blog-active">
                                    <div class="swiper-wrapper">


                                        <?php if ($query->have_posts()) : ?>
                                            <?php while ($query->have_posts()) :
                                                $query->the_post();

                                                $_post_thumbnail = get_field('post_single_thumbnail');
                                                global $post;
                                            ?>
                                                <div class="swiper-slide">
                                                    <div class="it-blog-item">
                                                        <?php if (has_post_thumbnail()) : ?>
                                                            <div class="it-blog-thumb fix">
                                                                <a href="<?php the_permalink(); ?>">
                                                                    <?php if (!empty($_post_thumbnail)): ?>
                                                                        <img src="<?php echo esc_url($_post_thumbnail['url']); ?>" alt="">
                                                                    <?php else: ?>
                                                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                                    <?php endif; ?>
                                                                </a>
                                                            </div>
                                                        <?php endif; ?>

                                                        <div class="it-blog-content">
                                                            <?php if (!empty($od_blog_post_meta_switcher)): ?>
                                                                <div class="it-blog-meta">
                                                                    <span><?php echo esc_html__('BY', 'ordainit-toolkit'); ?> <?php echo get_the_author(); ?></span>
                                                                    <span><?php echo comments_number(); ?></span>
                                                                </div>
                                                            <?php endif; ?>
                                                            <h4 class="it-blog-title"><a class="border-line-black" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <?php if (!empty($od_blog_post_button_switcher)): ?>
                                                                <a href="<?php the_permalink(); ?>" class="it-btn-grey-sm theme-btn">
                                                                    <?php echo esc_html($od_blog_button_text, 'ordainit-toolkit'); ?>
                                                                    <?php if (!empty($od_blog_post_button_icon_switcher)): ?>
                                                                        <i>
                                                                            <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                <path
                                                                                    d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                                                    fill="currentcolor" />
                                                                            </svg>
                                                                        </i>
                                                                    <?php endif; ?>
                                                                </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile;
                                            wp_reset_query(); ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- blog-area-end -->

        <?php else:

        ?>


            <!-- blog-area-start -->
            <div class="it-blog-area p-relative z-index-1 pt-120 pb-120">
                <div class="it-blog-shape-1">
                    <img src="<?php echo esc_url($od_blog_post_shap['url'], 'ordainit-toolkit'); ?>" alt="">
                </div>
                <div class="container">
                    <div class="it-blog-title-wrap mb-65">
                        <div class="row align-items-end">
                            <div class="col-xl-6 col-lg-7 col-md-8">
                                <?php if (!empty($od_section_title_show)): ?>
                                    <div class="it-blog-title-box">
                                        <span class="it-section-subtitle mb-15">
                                            <?php if (!empty($od_section_sub_title_icon_switcher)): ?>
                                                <span>
                                                    <svg width="19" height="13" viewBox="0 0 19 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M19 6.10701L9.5 -0.000128746L9.5 12.2142L19 6.10701Z" fill="currentcolor" />
                                                        <path d="M9.5 6.10701L0 -0.000128746L0 12.2142L9.5 6.10701Z" fill="currentcolor" />
                                                    </svg>
                                                </span>
                                            <?php endif; ?>
                                            <?php echo od_kses($od_sub_title, 'ordainit-toolkit'); ?></span>
                                        <h3 class="it-section-title"><?php echo od_kses($od_title, 'ordainit-toolkit'); ?></h3>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($od_blog_post_arrow_switcher)): ?>
                                <div class="col-xl-6 col-lg-5 col-md-4">
                                    <div class="it-arrow-box blog-style text-md-end">
                                        <button class="slider-prev">
                                            <span>
                                                <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M0.469669 6.53033C0.176777 6.23744 0.176777 5.76256 0.469669 5.46967L5.24264 0.696699C5.53553 0.403806 6.01041 0.403806 6.3033 0.696699C6.59619 0.989593 6.59619 1.46447 6.3033 1.75736L2.06066 6L6.3033 10.2426C6.59619 10.5355 6.59619 11.0104 6.3033 11.3033C6.01041 11.5962 5.53553 11.5962 5.24264 11.3033L0.469669 6.53033ZM21 6.75H1V5.25H21V6.75Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                        <button class="slider-next">
                                            <span>
                                                <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="it-blog-slider-wrapper">
                                <div class="swiper-container it-blog-active">
                                    <div class="swiper-wrapper">

                                        <?php if ($query->have_posts()) : ?>
                                            <?php while ($query->have_posts()) :
                                                $query->the_post();
                                                global $post;
                                                $_post_thumbnail = get_field('post_single_thumbnail');
                                                $categories = get_the_category($post->ID);
                                            ?>
                                                <div class="swiper-slide">
                                                    <div class="it-blog-item">
                                                        <?php if (has_post_thumbnail()) : ?>
                                                            <div class="it-blog-thumb fix">
                                                                <a href="<?php the_permalink(); ?>">
                                                                    <?php if (!empty($_post_thumbnail)): ?>
                                                                        <img src="<?php echo esc_url($_post_thumbnail['url']); ?>" alt="">
                                                                    <?php else: ?>
                                                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="">
                                                                    <?php endif; ?>
                                                                </a>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="it-blog-content">
                                                            <?php if (!empty($od_blog_post_meta_switcher)): ?>
                                                                <div class="it-blog-meta">
                                                                    <span><?php echo esc_html__('BY', 'ordainit-toolkit'); ?> <?php echo get_the_author(); ?></span>
                                                                    <span><?php echo comments_number(); ?></span>
                                                                </div>
                                                            <?php endif; ?>
                                                            <h4 class="it-blog-title"><a class="border-line-black" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <?php if (!empty($od_blog_post_button_switcher)): ?>
                                                                <a href="<?php the_permalink(); ?>" class="it-btn-grey-sm">
                                                                    <?php echo esc_html($od_blog_button_text, 'ordainit-toolkit'); ?>
                                                                    <?php if (!empty($od_blog_post_button_icon_switcher)): ?>
                                                                        <i>
                                                                            <svg width="21" height="12" viewBox="0 0 21 12" fill="none"
                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                <path
                                                                                    d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z"
                                                                                    fill="currentcolor" />
                                                                            </svg>
                                                                        </i>
                                                                    <?php endif; ?>
                                                                </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>


                                            <?php endwhile;
                                            wp_reset_query(); ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- blog-area-end -->








        <?php endif; ?>


        <script>
            "use strict";
            jQuery(document).ready(function($) {

                ////////////////////////////////////////////////////
                //  Swiper Js
                const blogswiper = new Swiper(".it-blog-active", {
                    // Optional parameters
                    speed: 1500,
                    loop: true,
                    slidesPerView: 3,
                    spaceBetween: 30,
                    autoplay: true,
                    breakpoints: {
                        1400: {
                            slidesPerView: 3,
                        },
                        1200: {
                            slidesPerView: 3,
                        },
                        992: {
                            slidesPerView: 3,
                        },
                        768: {
                            slidesPerView: 2,
                        },
                        576: {
                            slidesPerView: 1,
                        },
                        0: {
                            slidesPerView: 1,
                        },
                    },
                    navigation: {
                        prevEl: ".slider-prev",
                        nextEl: ".slider-next",
                    },
                });




            });
        </script>

<?php
    }
}

$widgets_manager->register(new OD_Blog_Post());
