<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_FAQ extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD Faq', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {


		 // layout Panel
        $this->start_controls_section(
            'od_layout',
            [
                'label' => esc_html__('Design Layout', 'ordainit-toolkit'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'ordainit-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'ordainit-toolkit'),

                ],
                'default' => 'layout-1',
            ]
        );


        $this->end_controls_section();


		 // od_section_title
        $this->start_controls_section(
            'od_section_title',
            [
                'label' => esc_html__('Title & Content', 'ordainit-toolkit'),
                'condition' => [
                    'od_design_style' => ['layout-3'  ],
                ],
            ]
        );

        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sub Title', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_title',
            [
                'label' => esc_html__('Title', 'ordainit-toolkit'),
                'description' => od_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title Here', 'ordainit-toolkit'),
                'placeholder' => esc_html__('Type Heading Text', 'ordainit-toolkit'),
                'label_block' => true,
            ]
        );

      

        $this->end_controls_section();

		$this->start_controls_section(
            '_accordions_area',
            [
                'label' => esc_html__( 'Accordion', 'ordainit-toolkit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

			$this->add_control(
			'_accordion_list_section',
			[
				'label' => esc_html__( 'Accordion List', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'accordion_title',
						'label' => esc_html__( 'Title', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'What services does the clinic offer' , 'textdomain' ),
						'label_block' => true,
					],
					[
						'name' => 'accordion_description',
						'label' => esc_html__( 'Content', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur elit, sed doeiusmod tempor
                                       incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                       nostrud exercitation.' , 'ordainit-toolkit' ),
					],

				],
				'default' => [
					[
						'accordion_title' => esc_html__( 'What services does the clinic offer?', 'ordainit-toolkit' ),
					],
					[
						'accordion_title' => esc_html__( ' How do I schedule an appointment?', 'ordainit-toolkit' ),
					],
					[
						'accordion_title' => esc_html__( 'How long is the average wait time for appointments?', 'ordainit-toolkit' ),
					],
				],
				'title_field' => '{{{ accordion_title }}}',
			]
		);

       $this->end_controls_section();

       

      


		$this->start_controls_section(
			'od_faq_area_style',
			[
				'label' => __( 'Faq Area Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_faq_area_style_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-items' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
		// Faq Title
		$this->start_controls_section(
			'od_faq_area_title_style',
			[
				'label' => __( 'Faq Title Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_faq_area_title_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-buttons' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_area_title_style_typography',
				'selector' => '{{WRAPPER}} .it-custom-accordion .accordion-buttons',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'od_faq_area_title_style_border',
				'selector' => '{{WRAPPER}} .it-custom-accordion .accordion-buttons',
			]
		);

		$this->end_controls_section();

			// Faq Description
		$this->start_controls_section(
			'od_faq_area_description_style',
			[
				'label' => __( 'Faq Description Style', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'od_faq_area_description_style_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-body p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_area_description_style_typography',
				'selector' => '{{WRAPPER}} .it-custom-accordion .accordion-body p',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$accordian_items = $settings['_accordion_list_section'];

		?>


		<?php if ( $settings['od_design_style']  == 'layout-2' ):?>

                

         <?php elseif ( $settings['od_design_style']  == 'layout-3' ):?>

  



        <?php else: ?>	
			<div class="it-faq-wrap mb-30">
				<div class="it-custom-accordion">
				<div class="accordion" id="accordionExample">
					<?php 
						$i=0;
						foreach($accordian_items as $single_item):
						$i++;
					?>

					<div class="accordion-items">
						<h2 class="accordion-header" id="headingOne">
							<button class="accordion-buttons <?php echo ($i === 1) ? '' : 'collapsed'; ?> " type="button" data-bs-toggle="collapse"
							data-bs-target="#collapse" aria-expanded="<?php if($i==1){ echo "true";}else{ echo "false";}?>" aria-controls="collapse<?php echo esc_attr($i, 'ordainit-toolkit');?>">
							<?php echo esc_html($single_item['accordion_title']);?>
							</button>
						</h2>
						<div id="collapse" class="accordion-collapse collapse  <?php if($i==1){echo "show";}else{echo "";}?>"
							aria-labelledby="headingOne" data-bs-parent="#accordionExample">
							<div class="accordion-body d-flex align-items-center">
							<p class="mb-0"><?php echo od_kses($single_item['accordion_description']);?>.</p>
						
							</div>
						</div>
					</div>

					
                   <?php endforeach;?>
				</div>
				</div>
			</div>

     


		
     

      <?php endif;?>
<script>
    "use strict";
    jQuery(document).ready(function($) {
 // Generate unique ID for accordion container and items
  $(".accordion").each(function (index) {
    var accordionID = "accordionExample-" + index; // Create unique ID for each accordion container
    $(this).attr("id", accordionID); // Set unique ID for accordion container

    // Update each accordion item inside the container
    $(this)
      .find(".accordion-items")
      .each(function (itemIndex) {
        var itemID = accordionID + "-item-" + itemIndex;
        $(this)
          .find(".accordion-header")
          .attr("id", "heading-" + itemID);
        $(this)
          .find(".accordion-buttons")
          .attr("data-bs-target", "#collapse-" + itemID)
          .attr("aria-controls", "collapse-" + itemID);
        $(this)
          .find(".accordion-collapse")
          .attr("id", "collapse-" + itemID)
          .attr("data-bs-parent", "#" + accordionID);
      });
  });

  // Generate unique ID for Tab Products Widgets
  $(".nav-tab").each(function (index) {
    var tabID = "tab-" + index; // Create unique ID for each tab
    $(this).attr("id", tabID + "-tab"); // Set unique ID for tab buttons

    // Update corresponding tab content
    var tabContentID = "tab-content-" + index;
    $(this).attr("data-bs-target", "#" + tabContentID);
    $("#" + tabContentID).attr("id", tabID); // Ensure the tab content matches the tab
  });

  // Loop through each tab-nav list
  $(".nav-tab").each(function (index) {
    var uniqueTabId = "tab-" + index; // Create unique ID for each nav-tab
    $(this).attr("id", uniqueTabId + "-myTab"); // Assign unique ID to each nav-tab

    // Update each tab-content accordingly
    var tabContentId = uniqueTabId + "-myTabContent";
    $("#" + uniqueTabId + "-myTabContent").attr("id", tabContentId); // Ensure tab content gets updated
  });
 

    });
</script>


		<?php
	}

}

$widgets_manager->register( new OD_FAQ() );