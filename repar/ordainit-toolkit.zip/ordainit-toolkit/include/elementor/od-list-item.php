<?php
namespace ordainit_toolkit\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Od_List_Item extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'od-list-item';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'OD List Item', 'ordainit-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'od-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'ordainit-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'od_list_item_area',
			[
				'label' => __( 'List Item', 'ordainit-toolkit' ),
			]
		);

        $this->add_control(
			'od_list_items',
			[
				'label' => esc_html__( 'List item', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'od_list_item_title',
						'label' => esc_html__( 'Title', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Duis aute irure dolor in reprehenderit in voluptate velit' , 'ordainit-toolkit' ),
						'label_block' => true,
					],
					[
						'name' => 'od_list_item_icon',
						'label' => esc_html__( 'Icon', 'ordainit-toolkit' ),
						'type' => \Elementor\Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'flaticon-check',
                            'library' => '',
                        ],
						'label_block' => true,
					],
				],
				'default' => [
					[
						'od_list_item_title' => esc_html__( 'Duis aute irure dolor in reprehenderit in voluptate velit', 'ordainit-toolkit' ),
					],
					[
						'od_list_item_title' => esc_html__( 'Duis aute irure dolor in reprehenderit in voluptate velit', 'ordainit-toolkit' ),
					],
					[
						'od_list_item_title' => esc_html__( 'Duis aute irure dolor in reprehenderit in voluptate velit', 'ordainit-toolkit' ),
					],
				],
				'title_field' => '{{{ od_list_item_title }}}',
			]
		);

	

	



		$this->end_controls_section();



		$this->start_controls_section(
			'od_list_item_title_area',
			[
				'label' => __( 'List Item', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

	         $this->add_control(
			'od_list_item_title_color',
			[
				'label' => esc_html__( 'Text Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-list ul li span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_list_item_title_typography',
				'selector' => '{{WRAPPER}} .it-about-2-list ul li span',
			]
		);

        $this->add_responsive_control(
            'od_list_item_title_margin',
            [
                'label' => esc_html__('Margin', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-list ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'od_list_item_title_padding',
            [
                'label' => esc_html__('Padding', 'ordainit-toolkit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .it-about-2-list ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();

        
		$this->start_controls_section(
			'od_list_item_icon_area',
			[
				'label' => __( 'Icon', 'ordainit-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_control(
			'od_list_item_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'ordainit-toolkit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-2-list ul li span i' => 'color: {{VALUE}}',
				],
			]
		);

		// Icon font size

		$this->add_responsive_control(
			'od_list_item_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'ordainit-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .it-about-2-list ul li span i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		


        $this->end_controls_section();
	}

	/**
	 * Render the widget ouodut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $od_list_items =$settings['od_list_items'];

        ?>


        <div class="it-about-2-list">
            <ul>
                <?php foreach($od_list_items as $single_list_item):
                $font_value = $single_list_item['od_list_item_icon'];

                
                    
                ?>
            <li>
                <span>
                    <i class="<?php echo esc_attr($font_value['value'], 'ordainit-toolkit');?>"></i> <?php echo esc_html($single_list_item['od_list_item_title'], 'ordainit-toolkit');?>
                </span>
            </li>
            <?php endforeach;?>
            </ul>
        </div>


<?php

	
	}

}

$widgets_manager->register( new Od_List_Item() );