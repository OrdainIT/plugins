<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Features extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'features';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                    'layout-5' => esc_html__('Layout 5', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );
        
        $this->end_controls_section();

            // layout Panel
        $this->start_controls_section(
            'od_feature_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );

        $this->add_control(
			'od_feature_section_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/about/t-shape.png',
				],
			]
		);
        $this->add_control(
			'od_feature_section_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/about/t-shape.png',
				],
			]
		);


        $this->end_controls_section();


          // layout Panel
        $this->start_controls_section(
            'tp_bg_area',
            [
                'label' => esc_html__('Background', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-2'],
                ],
            ]
        );


        $this->add_control(
            'tp_section_bg_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/feature/feature-bg.png',
                ],
            ]
        );



        $this->end_controls_section();

             // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-4'],
                ],
            ]
        );


        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Choose Your Career', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Discover Your Gain', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );    
        

        $this->end_controls_section();


         // Feature Area
        $this->start_controls_section(
            'tp_features1',
            [
                'label' => esc_html__('Features List', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' =>[
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4', 'layout-5'],
                ],
            ]
        );


        $this->add_control(
            'tv_feature_area_1',
            [
                'label' => esc_html__( 'Feature List', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_feature_title_1',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'START COURSE' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_feature_desc_1',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__( 'Duis aute irure dolor reprehenderit in voluptate velit esse cillum dolore fugiat nulla pariatur. Excepteur' , 'odcore' ),
                        'show_label' => true,
                    ],
                    [
                        'name' => 'tv_feature_icon_1',
                        'label' => esc_html__( 'Upload Image', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => get_template_directory_uri().'/assets/img/work/work-1.svg',
                        ],
                        'show_label' => true,
                    ],
                    [
                        'name' => 'tv_feature_url_1',
                        'label' => esc_html__( 'URL', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' =>esc_html__('#', 'odcore'),
                        'show_label' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_feature_title_1' => esc_html__( 'START COURSE', 'odcore' ),
                        'tv_feature_desc_1' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon_1' => get_template_directory_uri().'/assets/img/work/work-1.svg',
                        'tv_feature_url_1' => esc_html__( '#', 'odcore' ),
                    ],
                    [
                        'tv_feature_title_1' => esc_html__( 'MAKE DECISION', 'odcore' ),
                        'tv_feature_desc_1' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon_1' => get_template_directory_uri().'/assets/img/work/work-2.svg',
                        'tv_feature_url_1' => esc_html__( '#', 'odcore' ),
                    ],
                    [
                        'tv_feature_title_1' => esc_html__( 'GET A CERTIFICATE', 'odcore' ),
                        'tv_feature_desc_1' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon_1' => get_template_directory_uri().'/assets/img/work/work-2.svg',
                        'tv_feature_url_1' => esc_html__( '#', 'odcore' ),
                    ],
                ],
                'title_field' => '{{{ tv_feature_title_1 }}}',
            ]
        );





         $this->end_controls_section();





        // Feature Area
        $this->start_controls_section(
            'tp_features',
            [
                'label' => esc_html__('Features List', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );


            $this->add_control(
            'tv_feature_area',
            [
                'label' => esc_html__( 'Feature List', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_feature_title',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Best Coaching' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_feature_desc',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__( 'In pellentesque massa vida placerat duis. Cursus sit amet dictum sit amet.' , 'odcore' ),
                        'show_label' => true,
                    ],
                    [
                        'name' => 'tv_feature_icon',
                        'label' => esc_html__( 'Icon', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'flaticon-coach' , 'odcore' ),
                        'show_label' => true,
                    ],
                    [
                        'name' => 'tv_feature_btn_text',
                        'label' => esc_html__( 'Button Text', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'View Details' , 'odcore' ),
                        'show_label' => true,
                    ],
                    [
                        'name' => 'tv_feature_btn_url',
                        'label' => esc_html__( 'URL', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( '#' , 'odcore' ),
                        'show_label' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_feature_title' => esc_html__( 'Best Coaching', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon' => esc_html__( 'flaticon-coach', 'odcore' ),
                        'tv_feature_btn_text' => esc_html__( 'View Details', 'odcore' ),
                        'tv_feature_btn_url' => esc_html__( '#', 'odcore' ),
                    ],
                    [
                        'tv_feature_title' => esc_html__( 'Best Coaching', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon' => esc_html__( 'flaticon-study', 'odcore' ),
                        'tv_feature_btn_text' => esc_html__( 'View Details', 'odcore' ),
                        'tv_feature_btn_url' => esc_html__( '#', 'odcore' ),
                    ],
                    [
                        'tv_feature_title' => esc_html__( 'Best Coaching', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon' => esc_html__( 'flaticon-booking', 'odcore' ),
                        'tv_feature_btn_text' => esc_html__( 'View Details', 'odcore' ),
                        'tv_feature_btn_url' => esc_html__( '#', 'odcore' ),
                    ],
                    [
                        'tv_feature_title' => esc_html__( 'Best Coaching', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'odcore' ),
                        'tv_feature_icon' => esc_html__( 'flaticon-video', 'odcore' ),
                        'tv_feature_btn_text' => esc_html__( 'View Details', 'odcore' ),
                        'tv_feature_btn_url' => esc_html__( '#', 'odcore' ),
                    ],
                ],
                'title_field' => '{{{ tv_feature_title }}}',
            ]
        );
      

     
        $this->end_controls_section();

        // tp_columns_section
        $this->start_controls_section(
            'tp_columns_section',
            [
                'label' => esc_html__('Features - Columns', 'odcore'),
            ]
        );

     
        $this->end_controls_section();




        // TAB_STYLE
		$this->start_controls_section(
			'od_feature_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
                  'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1', 'layout-4'],
                ],

				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_feature_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
				],
			]
		);

      	$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_title_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-section-title-3',
                    '{{WRAPPER}} .ed-section-title',
                ],
			]
		);
        $this->add_control(
			'od_feature_title_content_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
                'description' => esc_html__( 'This only For Style 4','odcore'),
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-2.white-bg' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_feature_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-2.white-bg' => 'color: {{VALUE}}',
				],
			]
		);

      	$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_title_content_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-4',
                    '{{WRAPPER}} .it-section-subtitle-5',
                    '{{WRAPPER}} .it-section-subtitle-2.white-bg',
                ],
			]
		);


		$this->end_controls_section();

          
           // TAB_STYLE
		$this->start_controls_section(
			'od_feature_list_content3',
			[
				'label' => __( 'Feature List', 'odcore' ),  
                'condition' => [
                    'od_design_style' => [ 'layout-5'],
                ],

				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_feature_list_content3_bg_heading',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content3_area_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content3_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content3_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content3_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

          $this->add_control(
			'od_feature_list_content3_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_control(
			'od_feature_list_content3_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content3_title_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content3_title_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content3_title_normal_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-title' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content3_title_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content3_title_hover_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-title' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content3_title_typography',
				'selector' => '{{WRAPPER}} .it-feature-title',
			]
		);

        $this->add_control(
			'od_feature_list_content3_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content3_description_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content3_description_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content3_description_normal_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-text p' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content3_description_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content3_description_hover_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-text p' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content3_description_typography',
				'selector' => '{{WRAPPER}} .it-feature-text p',
			]
		);

        $this->add_control(
			'od_feature_list_content3_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content3_icon_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content3_icon_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content3_icon_bg_normal_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item .it-feature-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content3_icon_normal_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-icon::after' => 'border-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content3_icon_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content3_icon_bg_hover_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content3_icon_hover_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-item:hover .it-feature-icon::after' => 'border-color: {{VALUE}}',
				],
			]
		);
         $this->end_controls_tab();

         $this->end_controls_tabs();


     

        $this->end_controls_section();

        
           // TAB_STYLE
		$this->start_controls_section(
			'od_feature_list_content2',
			[
				'label' => __( 'Feature List', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],

				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content2_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content2_normal_tab',
            [
               'label' => esc_html__( 'Normal Feature Style', 'odcore' ),
            ]
         );

         $this->add_control(
			'od_feature_list_content2_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->add_control(
			'od_feature_list_content2_normal_border_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content2_normal_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_normal_title_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-title-sm' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content2_normal_title_typography',
				'selector' => '{{WRAPPER}} .it-work-title-sm',
			]
		);

        $this->add_control(
			'od_feature_list_content2_normal_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_normal_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content2_normal_description_typography',
				'selector' => '{{WRAPPER}} .it-work-content p',
			]
		);
        $this->add_control(
			'od_feature_list_content2_normal_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_normal_icon_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);

      

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content2_hover_tab',
            [
               'label' => esc_html__( 'Active Feature Style', 'odcore' ),
            ]
         );

           $this->add_control(
			'od_feature_list_content2_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item.active' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->add_control(
			'od_feature_list_content2_hover_border_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item.active' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content2_hover_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_hover_title_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item.active .it-work-title-sm' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content2_hover_title_typography',
				'selector' => '{{WRAPPER}} .it-work-item.active .it-work-title-sm',
			]
		);

        $this->add_control(
			'od_feature_list_content2_hover_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_hover_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item.active .it-work-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content2_hover_description_typography',
				'selector' => '{{WRAPPER}} .it-work-item.active .it-work-content p',
			]
		);
        $this->add_control(
			'od_feature_list_content2_hover_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_feature_list_content2_hover_icon_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-item.active .it-work-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);





         $this->end_controls_tab();

         $this->end_controls_tabs();



        
		$this->end_controls_section();

           // TAB_STYLE
		$this->start_controls_section(
			'od_feature_list_content',
			[
				'label' => __( 'Feature List', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],

				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_feature_list_content_bg_heading',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_feature_list_content_bg_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content_bg_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content_bg_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content_bg_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

           $this->add_control(
			'od_feature_list_content_bg_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


        $this->add_control(
			'od_feature_list_content_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


          $this->start_controls_tabs(
            'od_feature_list_content_title_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content_title_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         $this->add_control(
			'od_feature_list_content_title_normal_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-title' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content_title_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content_title_hover_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-title' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

         
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content_title_typography',
				'selector' => '{{WRAPPER}} .it-feature-3-title',
			]
		);

        $this->add_control(
			'od_feature_list_content_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

          $this->start_controls_tabs(
            'od_feature_list_content_description_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content_description_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content_description_normal_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-content p' => 'color: {{VALUE}}',
				],
			]
		);



         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content_description_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );


        $this->add_control(
			'od_feature_list_content_description_hover_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-content p' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


            
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content_description_typography',
				'selector' => '{{WRAPPER}} .it-feature-3-content p',
			]
		);

        $this->add_control(
			'od_feature_list_content_icon_heading',
			[
				'label' => esc_html__( 'icon', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

          $this->start_controls_tabs(
            'od_feature_list_content_icon_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content_icon_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content_icon_normal_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-icon span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-feature-3-icon span::after' => 'border-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_feature_list_content_icon_normal_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-icon span' => 'color: {{VALUE}}',
				],
			]
		);


         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content_icon_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content_icon_hover_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-icon span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-icon span::after' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content_icon_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-icon span' => 'color: {{VALUE}}',
				],
			]
		);



         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_control(
			'od_feature_list_content_button_heading',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

          $this->start_controls_tabs(
            'od_feature_list_content_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_feature_list_content_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_feature_list_content_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content_button_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
				],
			]
		);



         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_feature_list_content_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_feature_list_content_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content_button_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_feature_list_content_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_feature_list_content_button_typography',
				'selector' => '{{WRAPPER}} .ed-btn-theme.theme-2',
			]
		);


        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $tp_section_title_show = $settings['tp_section_title_show'];
        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $tp_section_bg_img = $settings['tp_section_bg_img'];
        $tv_feature_area = $settings['tv_feature_area'];
        $tv_feature_area_1 = $settings['tv_feature_area_1'];

        $od_feature_section_shap_img_1 = $settings['od_feature_section_shap_img_1'];
        $od_feature_section_shap_img_2 = $settings['od_feature_section_shap_img_2'];


		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ) : ?>

        <!-- work-area-start -->
      <div class="it-wrok-area it-wrok-bg pt-120 pb-90" style="background-image:url(<?php echo esc_url($tp_section_bg_img['url'], 'odcore');?>)">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-xl-6">
                  <div class="it-course-title-box mb-60 text-center">
                     <span class="it-section-subtitle-5">
                        <img src="<?php echo esc_url($od_feature_section_shap_img_1['url'], 'odcore');?>" alt="">
                            <?php echo esc_html($tp_sub_title, 'odcore');?>
                     </span>
                     <h4 class="it-section-title-3"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                  </div>
               </div>
            </div>
            <div class="row">

                <?php $i=0;  foreach($tv_feature_area_1 as $single_item): 
                    $i++;

                    $single_item_img = $single_item['tv_feature_icon_1'];

                ?>
               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-work-item text-center  <?php if ($i == 2) echo 'active'; ?>">
                     <div class="it-work-icon">
                        <span>
                           <img src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt="">
                        </span>
                     </div>
                     <div class="it-work-content">
                        <h4 class="it-work-title-sm"><a href="<?php echo esc_url($single_item['tv_feature_url_1']);?>"><?php echo esc_html($single_item['tv_feature_title_1']);?></a></h4>
                        <p><?php echo tp_kses($single_item['tv_feature_desc_1']);?></p>
                     </div>
                  </div>
               </div>
           <?php endforeach;?>

            </div>
         </div>
      </div>
      <!-- work-area-end -->

        <?php elseif ( $settings['od_design_style']  == 'layout-3' ) : ?>

             <!-- work-area-start -->
      <div class="it-wrok-area fix it-wrok-bg ed-work-style-2 ed-work-style-3 pt-120 pb-90">
         <div class="container container-3">
            <div class="row">

                <?php $i=0;  foreach($tv_feature_area_1 as $single_item): 
                    $i++;

                    $single_item_img = $single_item['tv_feature_icon_1'];

                ?>
               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-work-item <?php if ($i == 2) echo 'active'; ?>">
                     <div class="it-work-icon">
                        <span>
                           <img src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt="">
                        </span>
                     </div>
                     <div class="it-work-content">
                        <h4 class="it-work-title-sm"><a href="<?php echo esc_url($single_item['tv_feature_url_1']);?>"><?php echo esc_html($single_item['tv_feature_title_1']);?></a></h4>
                        <p class="mb-0"><?php echo tp_kses($single_item['tv_feature_desc_1']);?></p>
                     </div>
                  </div>
               </div>
                <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- work-area-end -->


        <?php elseif ( $settings['od_design_style']  == 'layout-4' ) : ?>

                 <!-- work-area-start -->
      <div class="it-wrok-area it-wrok-bg ed-work-style-2 pt-120 pb-90 grey-bg-4">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="row justify-content-center">
               <div class="col-xl-6">
                  <div class="it-course-title-box mb-60 text-center">
                     <span class="it-section-subtitle-2 white-bg"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                     <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                     </h4>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">

                <?php $i=0;  foreach($tv_feature_area_1 as $single_item): 
                    $i++;

                    $single_item_img = $single_item['tv_feature_icon_1'];

                ?>
               <div class="col-xl-4 col-lg-6 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-work-item <?php if ($i == 2) echo 'active'; ?>">
                     <div class="it-work-icon">
                        <span>
                           <img src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt="">
                        </span>
                     </div>
                     <div class="it-work-content">
                        <h4 class="it-work-title-sm"><a href="<?php echo esc_url($single_item['tv_feature_url_1']);?>"><?php echo esc_html($single_item['tv_feature_title_1']);?></a></h4>
                        <p class="mb-0"><?php echo tp_kses($single_item['tv_feature_desc_1']);?></p>
                     </div>
                  </div>
               </div>

           <?php endforeach;?>

            </div>
         </div>
      </div>
      <!-- work-area-end -->

       <?php elseif ( $settings['od_design_style']  == 'layout-5' ) : ?>

         <!-- feature-area-start -->
      <div class="it-feature-area pt-120 pb-120">
         <div class="container">
            <div class="row">

                <?php $i=0;  foreach($tv_feature_area_1 as $single_item): 
                    $i++;

                    $single_item_img = $single_item['tv_feature_icon_1'];

                ?>

               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-feature-item text-center">
                     <div class="it-feature-item-content z-index">
                        <div class="it-feature-icon">
                           <span><img src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt=""></span>
                        </div>
                        <div class="it-feature-text pt-35">
                           <h4 class="it-feature-title"><a href="<?php echo esc_url($single_item['tv_feature_url_1']);?>"><?php echo esc_html($single_item['tv_feature_title_1']);?></a></h4>
                           <p><?php echo tp_kses($single_item['tv_feature_desc_1']);?></p>
                        </div>
                     </div>
                  </div>
               </div>

           <?php endforeach;?>

            </div>
         </div>
      </div>
      <!-- feature-area-end -->

		<?php else: 
        ?>	

           <!-- feature-area-start -->
      <div class="it-feature-3-area it-feature-3-bg grey-bg pt-120 pb-90" style="background-image:url(<?php echo esc_url($tp_section_bg_img['url'], 'odcore');?>)">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="row justify-content-center">
               <div class="col-xl-8 col-lg-7 col-md-8">
                  <div class="it-feature-3-title-box text-center mb-60">
                     <span class="it-section-subtitle-4">
                        <img src="<?php echo esc_url($od_feature_section_shap_img_1['url'], 'odcore');?>" alt="">
                       <?php echo esc_html($tp_sub_title, 'odcore');?>
                        <img src="<?php echo esc_url($od_feature_section_shap_img_2['url'], 'odcore');?>" alt="">
                     </span>
                     <h4 class="it-section-title-3"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
                <?php foreach($tv_feature_area as $single_item):?>
               <div class="col-xl-3 col-lg-6 col-md-6">
                  <div class="it-feature-3-item mb-30 text-center">
                     <div class="it-feature-3-icon">
                        <span><i class="<?php echo esc_attr($single_item['tv_feature_icon']);?>"></i></span>
                     </div>
                     <div class="it-feature-3-content">
                        <h4 class="it-feature-3-title"><a href="<?php echo esc_url($single_item['tv_feature_btn_url']);?>"><?php echo esc_html($single_item['tv_feature_title']);?></a></h4>
                        <p><?php echo tp_kses($single_item['tv_feature_desc']);?></p>
                     </div>
                     <div class="it-feature-3-btn">
                        <a class="ed-btn-theme theme-2" href="<?php echo esc_url($single_item['tv_feature_btn_url']);?>">
                           <?php echo esc_html($single_item['tv_feature_btn_text']);?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
           <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- feature-area-end -->

        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new TP_Features() );