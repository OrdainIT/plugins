<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Main_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Main Slider', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		

         // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
		
		$this->start_controls_section(
            'od_main_slider_settinga',
            [
                'label' => esc_html__('Settings', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

		
		$this->add_control(
			'od_slider_autoplay_switcher',
			[
				'label' => esc_html__( 'Autoplay On/Off', 'odcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'odcore' ),
				'label_off' => esc_html__( 'Off', 'odcores' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->end_controls_section();


      

        

		
		$this->start_controls_section(
            'tp_main_slider',
            [
                'label' => esc_html__('Main Slider', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

      

      

        $repeater = new \Elementor\Repeater();

	        $repeater->add_control(
	            'tp_slider_image',
	            [
	                'label' => esc_html__('Upload Image', 'odcore'),
	                'type' => Controls_Manager::MEDIA,
	                'default' => [
	                    'url' => get_template_directory_uri().'/assets/img/slider/slider-1-1.jpg',
	                ]
	            ]
	        );

            $repeater->add_control(
                'tp_slider_sub_title',
                [
                    'label' => esc_html__('Sub Title', 'odcore'),
                    'description' => tp_get_allowed_html_desc( 'basic' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => '',
                    'placeholder' => esc_html__('Type Before Heading Text', 'odcore'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'tp_slider_title',
                [
                    'label' => esc_html__('Title', 'odcore'),
                    'description' => tp_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => tp_kses('<span> Achieving Your Dreams</span><span> Through <i>Education</i></span>', 'odcore'),
                    'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'tp_slider_description',
                [
                    'label' => esc_html__('Description', 'odcore'),
                    'description' => tp_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration.', 'odcore'),
                    'placeholder' => esc_html__('Type section description here', 'odcore'),
                ]
            );

			$repeater->add_control(
	            'tp_btn_link_switcher',
	            [
	                'label' => esc_html__( 'Add Button link', 'odcore' ),
	                'type' => \Elementor\Controls_Manager::SWITCHER,
	                'label_on' => esc_html__( 'Yes', 'odcore' ),
	                'label_off' => esc_html__( 'No', 'odcore' ),
	                'return_value' => 'yes',
	                'default' => 'yes',
	                'separator' => 'before',
	            ]
	        );
	        $repeater->add_control(
	            'tp_btn_btn_text',
	            [
	                'label' => esc_html__('Button Text', 'odcore'),
	                'type' => Controls_Manager::TEXT,
	                'default' => esc_html__('Discover More', 'odcore'),
	                'title' => esc_html__('Enter button text', 'odcore'),
	                'label_block' => true,
	                'condition' => [
	                    'tp_btn_link_switcher' => 'yes'
	                ],
	            ]
	        );
	        $repeater->add_control(
	            'tp_btn_link_type',
	            [
	                'label' => esc_html__( 'Button Link Type', 'odcore' ),
	                'type' => \Elementor\Controls_Manager::SELECT,
	                'options' => [
	                    '1' => 'Custom Link',
	                    '2' => 'Internal Page',
	                ],
	                'default' => '1',
	                'condition' => [
	                    'tp_btn_link_switcher' => 'yes'
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'tp_btn_link',
	            [
	                'label' => esc_html__( 'Button Link link', 'odcore' ),
	                'type' => \Elementor\Controls_Manager::URL,
	                'dynamic' => [
	                    'active' => true,
	                ],
	                'placeholder' => esc_html__( 'https://your-link.com', 'odcore' ),
	                'show_external' => true,
	                'default' => [
	                    'url' => '#',
	                    'is_external' => false,
	                    'nofollow' => false,
	                ],
	                'condition' => [
	                    'tp_btn_link_type' => '1',
	                    'tp_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'tp_btn_page_link',
	            [
	                'label' => esc_html__( 'Select Button Link Page', 'odcore' ),
	                'type' => \Elementor\Controls_Manager::SELECT2,
	                'label_block' => true,
	                'options' => tp_get_all_pages(),
	                'condition' => [
	                    'tp_btn_link_type' => '2',
	                    'tp_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );
	          $repeater->add_control(
	            'tp_2_btn_text',
	            [
	                'label' => esc_html__('Button Two Text', 'odcore'),
	                'type' => Controls_Manager::TEXT,
	                'default' => esc_html__('Watch Now', 'odcore'),
	                'title' => esc_html__('Enter button text', 'odcore'),
	                'label_block' => true,
	                'condition' => [
	                    'tp_btn_link_switcher' => 'yes'
	                ],
	            ]
	        );
	          $repeater->add_control(
	            'tp_2_btn_url',
	            [
	                'label' => esc_html__('Button Two URL', 'odcore'),
	                'type' => Controls_Manager::TEXT,
	                'default' => esc_html__('#', 'odcore'),
	                'title' => esc_html__('Enter button URL', 'odcore'),
	                'label_block' => true,
	                'condition' => [
	                    'tp_btn_link_switcher' => 'yes'
	                ],
	            ]
	        );


        $this->add_control(
            'slider_list',
            [
                'label' => esc_html__('Slider List', 'odcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_slider_title' => tp_kses('<span> Achieving Your Dreams</span><span> Through <i>Education</i></span>', 'odcore')
                    ],
                    [
                        'tp_slider_title' => tp_kses('<span> Achieving Your Dreams</span><span> Through <i>Education</i></span>', 'odcore')
                    ],
                    [
                        'tp_slider_title' => tp_kses('<span> Achieving Your Dreams</span><span> Through <i>Education</i></span>', 'odcore')
                    ],
                ],
                'title_field' => '{{{ tp_slider_title }}}',
            ]
        );
        $this->end_controls_section();


        // Style
		$this->start_controls_section(
			'od_main_slider_area_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'od_main_slider_area_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-slider-3-height .ed-slider-title div span' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'od_main_slider_area_content_title2_color',
			[
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .ed-slider-title i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_main_slider_area_content_title_typography',
				'selector' => '{{WRAPPER}}  .ed-slider-title ',
			]
		);

		$this->add_control(
			'od_main_slider_area_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-subtitle div span' => 'color: {{VALUE}}',
				],
			]
		);
		
	

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_main_slider_area_content_subtitle_typography',
				'selector' => '{{WRAPPER}}  .ed-slider-2-subtitle div span ',
			]
		);
		$this->add_control(
			'od_main_slider_area_content_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-text div p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-slider-3-text div p' => 'color: {{VALUE}}',
				],
			]
		);
		
	

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_main_slider_area_content_description_typography',
				'selectors' => [
					'{{WRAPPER}}  .ed-slider-2-text div p ',
					'{{WRAPPER}}  .ed-slider-3-text div p ',
				],
			]
		);


		



	

		$this->end_controls_section();
		
        // Style
		$this->start_controls_section(
			'od_main_slider_area_button',
			[
				'label' => __( 'Button', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'od_main_slider_area_button_tabs'
		);

		// Normal

		$this->start_controls_tab(
			'od_main_slider_area_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'odcore' ),
			]
		);

		
		$this->add_control(
			'od_main_slider_area_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		// Hover

		$this->start_controls_tab(
			'od_main_slider_area_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'odcore' ),
			]
		);

			
		$this->add_control(
			'od_main_slider_area_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_main_slider_area_button_typography',
				'selector' => '{{WRAPPER}} .ed-btn-square',
			]
		);

	

		$this->end_controls_section();

		  // Style
		$this->start_controls_section(
			'od_main_slider_area_vide0_button',
			[
				'label' => __( 'Video Button', 'odcore' ),
				  'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_main_slider_area_vide_button_icon_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-3-video span' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_vide_button_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-3-video span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_vide_button_icon_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-3-video a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_main_slider_area_vide_button_icon_text_typography',
				'selector' => '{{WRAPPER}} .ed-slider-3-video a',
			]
		);

		$this->end_controls_section();

        // Style
		$this->start_controls_section(
			'od_main_slider_area_arrow',
			[
				'label' => __( 'Arrow', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->start_controls_tabs(
			'od_main_slider_area_arrow_tabs'
		);

		// Normal

		$this->start_controls_tab(
			'od_main_slider_area_arrow_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'odcore' ),
			]
		);

				
		$this->add_control(
			'od_main_slider_area_arrow__icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_arrow__icon_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_arrow__icon_border_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		// Hover

		$this->start_controls_tab(
			'od_main_slider_area_arrow_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'odcore' ),
			]
		);

				$this->add_control(
			'od_main_slider_area_arrow__icon_hover_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_arrow__icon_bg_hover_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_main_slider_area_arrow__icon_border_hover_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-2-arrow-box button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();








	

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_list = $settings['slider_list'];
		?>


		<?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

			 <!-- slider-area-start -->
      <div class="ed-slider-3-area">
         <div class="ed-slider-3-wrapper p-relative">
            <div class="ed-slider-2-arrow-box">
               <button class="slider-prev">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M9.57031 5.92969L3.50031 11.9997L9.57031 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                     <path d="M20.5 12H3.67" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                   </svg>
               </button>
               <button class="slider-next">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M14.4297 5.92969L20.4997 11.9997L14.4297 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                     <path d="M3.5 12H20.33" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                   </svg>
               </button>          
            </div>
            <div class="swiper-container ed-slider-3-active">
               <div class="swiper-wrapper">
               	<?php foreach($slider_list as $single_item):

               			$single_item_img = $single_item['tp_slider_image'];
               			$tp_btn_link_type = $single_item['tp_btn_link_type'];
               			$tp_btn_page_link = $single_item['tp_btn_page_link'];
               			$tp_btn_link = $single_item['tp_btn_link'];
               			$tp_btn_text = $single_item['tp_btn_btn_text'];
               			$tp_2_btn_text = $single_item['tp_2_btn_text'];
               			$tp_2_btn_url = $single_item['tp_2_btn_url'];
               			  // Link
			            if ('2' == $tp_btn_link_type) {
			                    $this->add_render_attribute('tp-button-arg', 'href', get_permalink($tp_btn_page_link));
			                    $this->add_render_attribute('tp-button-arg', 'target', '_self');
			                    $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
			                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange mr-25');
			                } else {
			                    if ( ! empty( $tp_btn_link['url'] ) ) {
			                        $this->add_link_attributes( 'tp-button-arg', $tp_btn_link );
			                        $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange mr-25');
			                    }
			            }

               		?>

                  <div class="swiper-slide">
                     <div class="ed-slider-3-height ed-slider-3-overley  p-relative">
                        <div class="ed-slider-3-bg" style="background-image:url(<?php echo esc_url($single_item_img['url']);?>)">
                        </div>
                        <div class="container">
                           <div class="row">
                              <div class="col-xl-7 col-lg-8">
                                 <div class="ed-slider-3-content">
                                    <div class="ed-slider-title  pb-5">
                                       <div><?php echo tp_kses($single_item['tp_slider_title'], 'odcore');?></div>
                                    </div>
                                    <div class="ed-slider-3-text">                                       
                                       <div>
                                           <p class=""><?php echo tp_kses($single_item['tp_slider_description'], 'odcore');?></p>
                                       </div>
                                    </div>
                                    <div class="ed-slider-3-button-wrapper">
                                       <div class="ed-slider-3-button d-flex align-content-center ">
					                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
					                                <?php echo esc_html($tp_btn_text, 'odcore'); ?>
                                             <i>
                                                <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                                      stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                                   <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5"
                                                      stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                             </i>
                                          </a>
                                          <div class="ed-slider-3-video">
                                             <span><i class="fa-sharp fa-solid fa-play"></i></span>
                                             <a class="popup-video" href="<?php echo esc_url($tp_2_btn_url, 'odcore');?>"><?php echo esc_html($tp_2_btn_text, 'odcore');?></a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
              <?php endforeach;?>

               </div>
            </div>
         </div>
      </div>
      <!-- slider-area-end -->


		<?php else:?>
		
		 <!-- slider-area-start -->
      <div class="ed-slider-2-area p-relative fix">
         <div class="ed-slider-2-arrow-box">
            <button class="slider-prev">
               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9.57031 5.92969L3.50031 11.9997L9.57031 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                  <path d="M20.5 12H3.67" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <button class="slider-next">
               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14.4297 5.92969L20.4997 11.9997L14.4297 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                  <path d="M3.5 12H20.33" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>          
         </div>
         <div class="ed-slider-2-box">
            <div class="swiper-container ed-slider-2-active">
               <div class="swiper-wrapper">
               	<?php foreach($slider_list as $single_item):

               			$single_item_img = $single_item['tp_slider_image'];
               			$tp_btn_link_type = $single_item['tp_btn_link_type'];
               			$tp_btn_page_link = $single_item['tp_btn_page_link'];
               			$tp_btn_link = $single_item['tp_btn_link'];
               			$tp_btn_text = $single_item['tp_btn_btn_text'];
               			  // Link
			            if ('2' == $tp_btn_link_type) {
			                    $this->add_render_attribute('tp-button-arg', 'href', get_permalink($tp_btn_page_link));
			                    $this->add_render_attribute('tp-button-arg', 'target', '_self');
			                    $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
			                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square');
			                } else {
			                    if ( ! empty( $tp_btn_link['url'] ) ) {
			                        $this->add_link_attributes( 'tp-button-arg', $tp_btn_link );
			                        $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square');
			                    }
			            }

               		?>
                  <div class="swiper-slide">
                     <div class="ed-slider-2-overley p-relative">
                        <!-- line animation - start -->
                        <div class="line_wrap">
                           <div class="line_item"></div>
                           <div class="line_item"></div>
                           <div class="line_item"></div>
                           <div class="line_item"></div>
                           <div class="line_item"></div>
                        </div>
                        <!-- line animation - end -->
                        <div class="ed-slider-2-shape-1">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/slider/shape-3-2.png" alt="">
                        </div>
                        <div class="ed-slider-2-shape-2">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/slider/shape-3-3.png" alt="">
                        </div>
                        <div class="ed-slider-2-wrap p-relative">
                           <div class="ed-slider-2-thumb" style="background-image:url(<?php echo esc_url($single_item_img['url']);?>)"></div>
                           <div class="container">
                              <div class="row">
                                 <div class="col-xl-8 col-lg-9">
                                    <div class="ed-slider-2-content">
                                       <div class="ed-slider-2-subtitle pb-10">
                                          <div>
                                             <span><?php echo esc_html($single_item['tp_slider_sub_title'], 'odcore');?></span>
                                          </div>
                                       </div>
                                       <div class="ed-slider-title ">
                                          <div>
                                          	<?php echo tp_kses($single_item['tp_slider_title'], 'odcore');?>
                                          </div>
                                       </div>
                                       <div class="ed-slider-2-text pb-25">
                                          <div>
                                             <p class=" "><?php echo tp_kses($single_item['tp_slider_description'], 'odcore');?></p>
                                          </div>
                                       </div>
                                       <div class="ed-slider-2-button">
                                          <div>

					                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
					                                <?php echo $tp_btn_text; ?>
                                             </a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
              <?php endforeach;?>
               </div>
            </div>
         </div>
      </div>
      <!-- slider-area-end -->





		<?php endif;
		$od_slider_autoplay_switcher = $settings['od_slider_autoplay_switcher'];
		?>



<script>
    "use strict";
    jQuery(document).ready(function($) {

		const sliderAutoplay = <?php echo $od_slider_autoplay_switcher ? 'true' : 'false'; ?>;
        ////////////////////////////////////////////////////
		// 13. Swiper Js	
		const slider2swiper = new Swiper('.ed-slider-2-active', {
			// Optional parameters
			speed:1500,
			loop: true,
			slidesPerView: 1,
			autoplay:  sliderAutoplay ? { delay: 3000 } : false, // Toggle autoplay,
			effect:'fade',
			breakpoints: {
				'1400': {
					slidesPerView: 1,
				},
				'1200': {
					slidesPerView: 1,
				},
				'992': {
					slidesPerView: 1,
				},
				'768': {
					slidesPerView: 1,
				},
				'576': {
					slidesPerView: 1,
				},
				'0': {
					slidesPerView: 1,
				},
			},
			// Navigation arrows
			navigation: {
				nextEl: '.slider-prev',
				prevEl: '.slider-next',
			},


		});

		const sliderAutoplay2 = <?php echo $od_slider_autoplay_switcher ? 'true' : 'false'; ?>;

		// 13. Swiper Js	
	const slider3swiper = new Swiper('.ed-slider-3-active', {
		// Optional parameters
		speed:1500,
		loop: true,
		slidesPerView: 1,
		autoplay: sliderAutoplay2 ? { delay: 3000 } : false, // Toggle autoplay,,
		effect:'fade',
		breakpoints: {
			'1400': {
				slidesPerView: 1,
			},
			'1200': {
				slidesPerView: 1,
			},
			'992': {
				slidesPerView: 1,
			},
			'768': {
				slidesPerView: 1,
			},
			'576': {
				slidesPerView: 1,
			},
			'0': {
				slidesPerView: 1,
			},
		},
		// Navigation arrows
		navigation: {
			nextEl: '.slider-prev',
			prevEl: '.slider-next',
		},


	  });


    });
</script>


		<?php 
	}
}

$widgets_manager->register( new TP_Main_Slider() );