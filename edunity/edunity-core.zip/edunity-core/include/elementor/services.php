<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Services extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'services';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Services', 'odcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'odcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'odcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

         // Service Area Shap
        $this->start_controls_section(
            'od_service_area_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' => [
                  'od_design_style' => ['layout-1'],
                ],
            ]
        );

      $this->add_control(
			'od_service_area_shap_img_1',
			[
				'label' => esc_html__( 'shap', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  get_template_directory_uri(). '/assets/img/category/ed-shape-1.png',
				],
			]
		);

      $this->end_controls_section();

          // Blog Query
        $this->start_controls_section(
            'tp__service_title_content',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );
        $this->add_control(
            'service_title_content_switch',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'service_sub_title',
            [
                'label' => esc_html__( 'Sub Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Services', 'odcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
                'condition' => [
                    'service_title_content_switch' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'service_title',
            [
                'label' => esc_html__( 'Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Browse By Categories', 'odcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
                'condition' => [
                    'service_title_content_switch' => 'yes',
                ],
            ]
        );

            $this->add_control(
            'hide_empty_category',
            [
                'label' => esc_html__( 'Hide Empty Category ?', 'odcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Hide', 'odcore' ),
                'label_off' => esc_html__( 'Show', 'odcore' ),
                'return_value' => '1',
                'default' => '1',
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );


       
       

     



        $this->end_controls_section();

         

        // Blog Query
        $this->start_controls_section(
            'tp_post_query',
            [
                'label' => esc_html__('Service Query', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
            ]
        );

        $post_type = 'services';
        $taxonomy = 'services-cat';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Services Per Page', 'odcore'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '4',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'odcore'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_category',
            [
                'label' => esc_html__('Exclude Categories', 'odcore'),
                'description' => esc_html__('Select a category to exclude', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post__not_in',
            [
                'label' => esc_html__('Exclude Item', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'options' => tp_get_all_types_post($post_type),
                'multiple' => true,
                'label_block' => true
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => esc_html__('Offset', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '0',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
                    'ID' => 'Post ID',
                    'author' => 'Post Author',
                    'title' => 'Title',
                    'date' => 'Date',
                    'modified' => 'Last Modified Date',
                    'parent' => 'Parent Id',
                    'rand' => 'Random',
                    'comment_count' => 'Comment Count',
                    'menu_order' => 'Menu Order',
                ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc'   => esc_html__( 'Ascending', 'odcore' ),
                    'desc'  => esc_html__( 'Descending', 'odcore' )
                ],
                'default' => 'desc',

            ]
        );

        $this->add_control(
            'tp_blog_title_word',
            [
                'label' => esc_html__('Title Word Count', 'odcore'),
                'description' => esc_html__('Set how many word you want to displa!', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '6',
            ]
        );

        $this->add_control(
            'tp_post_content',
            [
                'label' => __('Content', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'odcore'),
                'label_off' => __('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes ',
            ]
        );

        $this->add_control(
            'tp_post_content_limit',
            [
                'label' => __('Content Limit', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '14',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'tp_post_content' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();

        

        

        // TAB_STYLE
        $this->start_controls_section(
            'od_service_title_content',
            [
                'label' => __( 'Title & Content', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2'],
                ],

                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

      $this->add_control(
			'od_service_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_title_content_title_typography',
				'selectors' => [
               '{{WRAPPER}} .ed-section-title',
               '{{WRAPPER}}  .it-section-title-3',
            ],
			]
		);

      $this->add_control(
			'od_service_title_content_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_service_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_title_content_subtitle_typography',
				'selector' => '{{WRAPPER}} .ed-section-subtitle',
			]
		);

      

      $this->end_controls_section();

            
        // TAB_STYLE
      $this->start_controls_section(
            'od_service_content3',
            [
                'label' => __( 'Service Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
      );

      $this->add_control(
			'od_service_content3_area_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-work-style-2 .it-work-item' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content3_area_bg_logo',
			[
				'label' => esc_html__( 'Service Logo BG', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-work-style-3.inner-style .it-work-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content3_area_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-title-sm' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content3_area_title_typography',
				'selector' => '{{WRAPPER}} .it-work-title-sm',
			]
		);
      $this->add_control(
			'od_service_content3_area_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-work-content p' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content3_area_description_typography',
				'selector' => '{{WRAPPER}} .it-work-content p',
			]
		);


      $this->end_controls_section();

        
        // TAB_STYLE
        $this->start_controls_section(
            'od_service_content2',
            [
                'label' => __( 'Service Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

         $this->add_control(
            'od_service_content2_area',
            [
               'label' => esc_html__( 'Service Contetn BG', 'odcore' ),
               'type' => \Elementor\Controls_Manager::HEADING,
               'separator' => 'before',
            ]
         );

         $this->start_controls_tabs(
            'od_service_content2_area_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_service_content2_area_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         $this->add_control(
            'od_service_content2_area_normal__bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item' => 'background-color: {{VALUE}}',
               ],
            ]
         );

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_service_content2_area_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
         $this->add_control(
            'od_service_content2_area_hover__bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover' => 'background-color: {{VALUE}}',
               ],
            ]
         );

         $this->end_controls_tab();

         $this->end_controls_tabs();


        
        $this->end_controls_section();

           // TAB_STYLE
        $this->start_controls_section(
            'od_service_content2_title',
            [
                'label' => __( 'Service Title', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

          $this->start_controls_tabs(
            'od_service_content2_title_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_service_content2_title_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

             
         $this->add_control(
            'od_service_content2_title_normal_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-title' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_service_content2_title_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );      
         $this->add_control(
            'od_service_content2_title_hover_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-title' => 'color: {{VALUE}}',
               ],
            ]
         );

         

         $this->end_controls_tab();

         $this->end_controls_tabs();

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content2_title_typography',
				'selectors' => [
               '{{WRAPPER}} .it-feature-3-title',
            ],
			]
		);





      $this->end_controls_section();


      $this->start_controls_section(
            'od_service_content1_description',
            [
                'label' => __( 'Description', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


          $this->start_controls_tabs(
            'od_service_content1_description_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_service_content1_description_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );


         $this->add_control(
            'od_service_content1_description_normal_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-content p' => 'color: {{VALUE}}',
               ],
            ]
         );



         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_service_content1_description_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         $this->add_control(
            'od_service_content1_description_hover_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover .it-feature-3-content p' => 'color: {{VALUE}}',
               ],
            ]
         );

      $this->end_controls_tab();

      $this->end_controls_tabs();

         
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content1_description_typography',
				'selectors' => [
               '{{WRAPPER}} .it-feature-3-content p',
            ],
			]
		);



      $this->end_controls_section();


      $this->start_controls_section(
            'od_service_content22_icon',
            [
                'label' => __( 'Icon', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


         $this->start_controls_tabs(
            'od_service_content22_icon_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_service_content22_icon_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );


         $this->add_control(
            'od_service_content22_icon_normal_bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-icon span' => 'background-color: {{VALUE}}',
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-icon span::after' => 'border-color: {{VALUE}}',
               ],
            ]
         );

         $this->add_control(
            'od_service_content22_icon_normal_icon_color',
            [
               'label' => esc_html__( 'Icon Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-icon span' => 'color: {{VALUE}}',
               ],
            ]
         );




         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_service_content22_icon_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
         $this->add_control(
            'od_service_content22_icon_hover_bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-item:hover .it-feature-3-icon span' => 'background-color: {{VALUE}}',
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-item:hover .it-feature-3-icon span::after' => 'border-color: {{VALUE}}',
               ],
            ]
         );

         $this->add_control(
            'od_service_content22_icon_hover_icon_color',
            [
               'label' => esc_html__( 'Icon Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-bg.inner-style .it-feature-3-item:hover .it-feature-3-icon span' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->end_controls_tab();

         $this->end_controls_tabs();

        

        
      $this->end_controls_section();

      
      $this->start_controls_section(
            'od_service_content1_button',
            [
                'label' => __( 'Button', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


         $this->start_controls_tabs(
            'od_service_content1_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_service_content1_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         $this->add_control(
            'od_service_content1_button_normal_bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
               ],
            ]
         );

         $this->add_control(
            'od_service_content1_button_normal_icon_bg_color',
            [
               'label' => esc_html__( 'Icon BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
               ],
            ]
         );
         $this->add_control(
            'od_service_content1_button_normal_text_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
               ],
            ]
         );



         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_service_content1_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         $this->add_control(
            'od_service_content1_button_hover_bg_color',
            [
               'label' => esc_html__( 'BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
               ],
            ]
         );

         $this->add_control(
            'od_service_content1_button_hover_icon_bg_color',
            [
               'label' => esc_html__( 'Icon BG Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
               ],
            ]
         );
         $this->add_control(
            'od_service_content1_button_hover_text_color',
            [
               'label' => esc_html__( 'Text Color', 'odcore' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .it-feature-3-item:hover .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->end_controls_tab();

         $this->end_controls_tabs();


               
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content1_button_typography',
				'selectors' => [
               '{{WRAPPER}} .ed-btn-theme.theme-2',
            ],
			]
		);



        
      $this->end_controls_section();

        // TAB_STYLE
        $this->start_controls_section(
            'od_service_content1',
            [
                'label' => __( 'Service Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_service_content1_category_title_color',
			[
				'label' => esc_html__( 'Category Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-title' => 'color: {{VALUE}}',
				],
			]
		);

      
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_service_content1_category_title_typography',
				'selector' => '{{WRAPPER}} .ed-category-title',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_1',
			[
				'label' => esc_html__( 'Category Box One', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-2 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-2 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-2.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-2 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_2',
			[
				'label' => esc_html__( 'Category Box Two', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon2',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-3 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-3 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box2_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-3.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-3 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_3',
			[
				'label' => esc_html__( 'Category Box Three', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon3',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-4 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-4 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box3_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-4.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-4 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_4',
			[
				'label' => esc_html__( 'Category Box Four', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon4',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-5 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-5 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box4_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-5.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-5 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_5',
			[
				'label' => esc_html__( 'Category Box Five', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon5',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-6 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-6 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box5_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-6.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-6 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_6',
			[
				'label' => esc_html__( 'Category Box Six', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon6',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-7 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-7 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box6_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-7.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-7 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_7',
			[
				'label' => esc_html__( 'Category Box Seven', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon7',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-8 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-8 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box7_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-8.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-8 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_8',
			[
				'label' => esc_html__( 'Category Box Eight', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon8',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-9 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-9 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box8_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-9.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-9 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box_9',
			[
				'label' => esc_html__( 'Category Box Nine', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_service_content1_category_box_icon9',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-1 .ed-category-icon span' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-1 .ed-category-icon span svg path' => 'fill: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_service_content1_category_box9_bg',
			[
				'label' => esc_html__( 'Box BG  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-category-style-1.ed-category-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-category-style-1 .ed-category-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);


      

      

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $od_service_area_shap_img_1 = $settings['od_service_area_shap_img_1'];

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } else if (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }
        // include_categories
        $category_list = '';
        if (!empty($settings['category'])) {
            $category_list = implode(", ", $settings['category']);
        }
        $category_list_value = explode(" ", $category_list);

        // exclude_categories
        $exclude_categories = '';
        if(!empty($settings['exclude_category'])){
            $exclude_categories = implode(", ", $settings['exclude_category']);
        }
        $exclude_category_list_value = explode(" ", $exclude_categories);

        $post__not_in = '';
        if (!empty($settings['post__not_in'])) {
            $post__not_in = $settings['post__not_in'];
            $args['post__not_in'] = $post__not_in;
        }

        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';

        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';
        $offset_value = (!empty($settings['offset'])) ? $settings['offset'] : '0';

        // number
        $off = (!empty($offset_value)) ? $offset_value : 0;
        $offset = $off + (($paged - 1) * $posts_per_page);
        $p_ids = array();

        // build up the array
        if (!empty($settings['post__not_in'])) {
            foreach ($settings['post__not_in'] as $p_idsn) {
                $p_ids[] = $p_idsn;
            }
        }

        $args = array(
            'post_type' => 'services',
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'offset' => $offset,
            'paged' => $paged,
            'post__not_in' => $p_ids,
        );


        // exclude_categories
        if ( !empty($settings['exclude_category'])) {

            // Exclude the correct cats from tax_query
            $args['tax_query'] = array(
                array(
                    'taxonomy'  => 'services-cat',
                    'field'     => 'slug',
                    'terms'     => $exclude_category_list_value,
                    'operator'  => 'NOT IN'
                )
            );

            // Include the correct cats in tax_query
            if ( !empty($settings['category'])) {
                $args['tax_query']['relation'] = 'AND';
                $args['tax_query'][] = array(
                    'taxonomy'  => 'category',
                    'field'     => 'slug',
                    'terms'     => $category_list_value,
                    'operator'  => 'IN'
                );
            }

        } else {
            // Include the cats from $cat_slugs in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query'][] = [
                    'taxonomy' => 'services-cat',
                    'field' => 'slug',
                    'terms' => $category_list_value,
                ];
            }
        }

        $filter_list = $settings['category'];

        $service_title_content_switch = $settings['service_title_content_switch'];
        $service_sub_title = $settings['service_sub_title'];
        $service_title = $settings['service_title'];
        $hide_empty_category = $settings['hide_empty_category'];

        // The Query
        $query = new \WP_Query($args);

        ?>

        <?php if ( $settings['od_design_style']  == 'layout-2' ):
       

       ?>
       
        <!-- feature-area-start -->
      <div class="it-feature-3-area it-feature-3-bg inner-style pt-120 pb-90">
         <div class="container">
            <?php if(!empty($service_title_content_switch)):?>
            <div class="row justify-content-center">
               <div class="col-xl-8 col-lg-7 col-md-8">
                  <div class="it-feature-3-title-box text-center mb-60">
                     <span class="ed-section-subtitle">
                        <?php echo esc_html($service_sub_title, 'odcore');?>
                     </span>
                     <h4 class="it-section-title-3"><?php echo tp_kses($service_title, 'odcore');?></h4>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">


             <?php if ($query->have_posts()) : ?>

                <?php while ($query->have_posts()) : 
                    $flaticon_icon = get_post_meta(get_the_ID(), '_flaticon_icon', true);
                    $query->the_post();
                    global $post;
                    $categories = get_the_category($post->ID);
            ?>
               <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="it-feature-3-item mb-30 text-center">
                     <div class="it-feature-3-icon">
                        <?php if(!empty($flaticon_icon)):?>
                                <span><i class="<?php echo esc_attr($flaticon_icon);?>"></i></span>
                        <?php else:?>
                            <span><i class="flaticon-coach"></i></span>
                       <?php endif;?>
                        
                     </div>
                     <div class="it-feature-3-content">
                        <h4 class="it-feature-3-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                    
                        <?php if (!empty($settings['tp_post_content'])):
                                $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                                ?>

                              <p><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>

                          <?php endif;?>
                     </div>
                     <div class="it-feature-3-btn">
                        <a class="ed-btn-theme theme-2" href="<?php the_permalink();?>">
                           <?php echo esc_html__('view details' , 'odcore');?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>

            <?php endwhile; wp_reset_query(); ?>
            <?php endif; ?>

            </div>
         </div>
      </div>
      <!-- feature-area-end -->

        <?php elseif ( $settings['od_design_style']  == 'layout-3' ):



        ?>
              <!-- work-area-start -->
          <div class="it-wrok-area fix it-wrok-bg ed-work-style-2 ed-work-style-3 inner-style pt-120 pb-90">
             <div class="container container-3">
                <div class="row">



             <?php if ($query->have_posts()) : ?>

                <?php while ($query->have_posts()) : 
                    $flaticon_icon = get_post_meta(get_the_ID(), '_flaticon_icon', true);
                    $query->the_post();
                    global $post;
                    $categories = get_the_category($post->ID);
            ?>
                   <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                      <div class="it-work-item">
                         <div class="it-work-icon">
                            <span>
                                <?php if ( has_post_thumbnail() ) : ?>
                                <img src="<?php the_post_thumbnail_url();?>" alt="">
                            <?php else:?>
                               <img src="<?php echo get_template_directory_uri();?>/assets/img/faq/3.svg" alt="">
                           <?php endif;?>
                            </span>
                         </div>
                         <div class="it-work-content">
                            <h4 class="it-work-title-sm"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                            
                    
                        <?php if (!empty($settings['tp_post_content'])):
                                $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                                ?>

                              <p><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>

                          <?php endif;?>
                         </div>
                      </div>
                   </div>

            <?php endwhile; wp_reset_query(); ?>
            <?php endif; ?>

                </div>
             </div>
          </div>
          <!-- work-area-end --> 
 

        <?php else: 
        ?>  


          <!-- category-area-start -->
      <div class="ed-category-area pt-120 p-relative pb-120">
         <div class="ed-category-shape-1">
            <img src="<?php echo esc_url($od_service_area_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <?php if(!empty($service_title_content_switch)):?>
            <div class="row">
               <div class="col-xl-12">
                  <div class="ed-category-title-box text-center mb-70">
                     <span class="ed-section-subtitle"><?php echo esc_html($service_sub_title, 'odcore');?></span>
                     <h4 class="ed-section-title"><?php echo tp_kses($service_title, 'odcore');?></h4>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row gx-35">
            <?php
                $args = array(
                    'taxonomy'   => 'services-cat',
                    'hide_empty' => $hide_empty_category, // Show categories even if they don't have any posts
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                );

                $categories = get_categories($args);
            ?>
            <?php $i=1; foreach($categories as $single_item): 

             $cat_id = $single_item->term_id;

        // Get the category image (replace 'category_image' with your field key)
             $image_id = get_field('services-cat_add_form_fields', 'services-cat_' . $cat_id); // ACF field
            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : ''; // Get image URL

                $i = $i % 9 + 1; 




            ?>
               <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="ed-category-item ed-category-style-<?php echo esc_attr($i, 'odcore');?> d-flex align-items-center mb-35">
                     <div class="ed-category-icon">
                        <span>
                           <?php if(!empty($image_url)):?>
                           <img src="<?php echo esc_url($image_url, 'odcore');?>" alt="<?php echo esc_attr($category->name, 'odcore');?>">
                           <?php else:?>
                        <?php if($i===1):?>
                           <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M35.9999 22V20.6666C36.3679 20.6666 36.6666 20.3682 36.6666 20V16C36.6666 15.6317 36.3679 15.3333 35.9999 15.3333H32.3999L32.2708 14.8325C31.976 13.6872 31.5182 12.5901 30.9106 11.5752L30.644 11.1291L33.1999 8.56873C33.4572 8.31092 33.4572 7.89321 33.1999 7.6354L30.3687 4.79999C30.1072 4.55077 29.6966 4.55077 29.4351 4.79999L26.8744 7.36066L26.4286 7.09399C25.4122 6.48618 24.314 6.02837 23.1671 5.73332L22.6666 5.60311V2C22.6666 1.63177 22.3682 1.33333 22 1.33333H18C17.6317 1.33333 17.3333 1.63177 17.3333 2V5.59999L16.8325 5.72941C15.6872 6.02394 14.5901 6.48176 13.5747 7.08853L13.1286 7.35545L10.5687 4.79999C10.307 4.54869 9.89373 4.54869 9.63202 4.79999L6.79999 7.63123C6.67551 7.75545 6.60546 7.9242 6.60546 8.09998C6.60546 8.27602 6.67551 8.44451 6.79999 8.56873L9.36066 11.1291L9.094 11.5752C8.48671 12.5901 8.02863 13.6872 7.7341 14.8325L7.60337 15.3333H4C3.63177 15.3333 3.33333 15.6317 3.33333 16V20C3.33333 20.3682 3.63177 20.6666 4 20.6666V22C2.89557 22 2 21.1044 2 20V16C2 14.8955 2.89557 14 4 14H6.57942C6.85442 13.0781 7.22629 12.188 7.68879 11.3448L5.85546 9.51144C5.48046 9.13722 5.26978 8.62941 5.26978 8.09998C5.26978 7.57056 5.48046 7.06274 5.85546 6.68879L8.68879 3.85546C9.47811 3.09999 10.7226 3.09999 11.512 3.85546L13.3448 5.68801C14.188 5.22577 15.0784 4.85468 16 4.57994V2C16 0.895571 16.8955 0 18 0H22C23.1044 0 24 0.895571 24 2V4.57994C24.9218 4.85468 25.8117 5.22655 26.6552 5.68879L28.4885 3.85546C29.2781 3.09999 30.5223 3.09999 31.3119 3.85546L34.1447 6.68801C34.5195 7.06222 34.7299 7.56951 34.7299 8.0992C34.7299 8.62889 34.5195 9.1367 34.1447 9.51066L32.3114 11.344C32.7736 12.1877 33.1452 13.0781 33.4205 14H35.9999C37.1044 14 37.9999 14.8955 37.9999 16V20C37.9999 21.1044 37.1044 22 35.9999 22Z"
                                 fill="#1B75E8" />
                              <path
                                 d="M29.3336 17.9993H28.0003C28.0003 13.5811 24.4185 9.99935 20.0003 9.99935C15.5821 9.99935 12.0003 13.5811 12.0003 17.9993H10.667C10.667 12.8447 14.8456 8.66602 20.0003 8.66602C25.1547 8.66602 29.3336 12.8447 29.3336 17.9993Z"
                                 fill="#1B75E8" />
                              <path
                                 d="M20 23.334C17.7909 23.334 16 21.5428 16 19.334C16 17.1249 17.7909 15.334 20 15.334C22.2094 15.334 24 17.1249 24 19.334C23.9976 21.5423 22.2083 23.3316 20 23.334ZM20 16.6673C18.5273 16.6673 17.3333 17.8613 17.3333 19.334C17.3333 20.8066 18.5273 22.0006 20 22.0006C21.4726 22.0006 22.6667 20.8066 22.6667 19.334C22.6667 17.8613 21.4726 16.6673 20 16.6673Z"
                                 fill="#1B75E8" />
                              <path
                                 d="M31.333 26C29.1239 26 27.333 24.2088 27.333 22C27.333 19.7909 29.1239 18 31.333 18C33.5421 18 35.333 19.7909 35.333 22C35.3306 24.2083 33.5413 25.9976 31.333 26ZM31.333 19.3333C29.8603 19.3333 28.6663 20.5273 28.6663 22C28.6663 23.4726 29.8603 24.6667 31.333 24.6667C32.8057 24.6667 33.9997 23.4726 33.9997 22C33.9997 20.5273 32.8057 19.3333 31.333 19.3333Z"
                                 fill="#1B75E8" />
                              <path
                                 d="M8.66698 26C6.45787 26 4.66699 24.2088 4.66699 22C4.66699 19.7909 6.45787 18 8.66698 18C10.8764 18 12.667 19.7909 12.667 22C12.6646 24.2083 10.8753 25.9976 8.66698 26ZM8.66698 19.3333C7.19433 19.3333 6.00032 20.5273 6.00032 22C6.00032 23.4726 7.19433 24.6667 8.66698 24.6667C10.1396 24.6667 11.3336 23.4726 11.3336 22C11.3336 20.5273 10.1396 19.3333 8.66698 19.3333Z"
                                 fill="#1B75E8" />
                              <path
                                 d="M37.377 27.7104C36.3835 27.0276 35.2057 26.6633 33.9999 26.6667H28.6666C28.3424 26.6696 28.0187 26.699 27.6992 26.7545C27.2726 26.0873 26.7177 25.5118 26.0666 25.0605C25.969 24.9868 25.8664 24.9198 25.7593 24.8607C24.8268 24.2959 23.7567 23.9985 22.6666 24H17.3333C15.2945 23.9927 13.3948 25.0331 12.3026 26.7545C11.9823 26.699 11.658 26.6696 11.3333 26.6667H5.99999C4.7953 26.6633 3.6177 27.0271 2.62473 27.7091C0.983592 28.8258 0.00104166 30.6818 0 32.6667V35.3333C0.00234373 37.1537 1.06146 38.8068 2.71484 39.5693C3.32525 39.8568 3.99218 40.0039 4.66666 40H11.3333V38.6667H5.33332V31.3334H3.99999V38.5997C3.74895 38.5495 3.5052 38.4682 3.27395 38.3586C2.09296 37.8141 1.33593 36.6336 1.33333 35.3333V32.6667C1.33489 31.1219 2.10026 29.6779 3.37734 28.8091C4.14895 28.2795 5.06379 27.9974 5.99999 28H11.3333C11.4508 28 11.564 28.0125 11.6786 28.0203C11.4531 28.6563 11.3362 29.3255 11.3333 30V36.6667C11.3357 38.5068 12.8268 39.9977 14.6666 40H16.6666V29.3334H15.3333V38.6667H14.6666C13.5622 38.6667 12.6666 37.7711 12.6666 36.6667V30C12.6666 27.4224 14.7562 25.3334 17.3333 25.3334H22.6666C23.5244 25.3339 24.3651 25.5714 25.0966 26.0193C25.1643 26.0563 25.2294 26.098 25.2911 26.1438C25.9158 26.5716 26.4286 27.1433 26.7859 27.8104C27.145 28.4844 27.3333 29.2362 27.3333 30V36.6667C27.3333 37.7711 26.4377 38.6667 25.3333 38.6667H24.6666V29.3334H23.3333V40H25.3333C27.1734 39.9977 28.6643 38.5068 28.6666 36.6667V30C28.6635 29.3255 28.5471 28.6565 28.3218 28.0203C28.4367 28.0125 28.5499 28 28.6666 28H33.9999C34.9366 27.9974 35.8523 28.2802 36.6244 28.8104C37.9004 29.6797 38.6648 31.1227 38.6666 32.6667V35.3333C38.6642 36.6383 37.9015 37.8221 36.7148 38.3638C36.4869 38.4716 36.2468 38.5508 35.9999 38.5997V31.3334H34.6666V38.6667H28.6666V40H35.3333C36.0038 40.0042 36.6669 39.8589 37.2739 39.5745C38.9327 38.8143 39.9973 37.1581 39.9999 35.3333V32.6667C39.9989 30.6826 39.0171 28.8274 37.377 27.7104Z"
                                 fill="#1B75E8" />
                              <path d="M17.333 38.666H22.6663V39.9993H17.333V38.666Z" fill="#1B75E8" />
                           </svg>
                       <?php elseif($i===2):?>
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M34.5037 29.3334C34.7154 28.2094 34.71 27.0553 34.4877 25.9334L37.541 18.5648C37.5413 18.5599 37.5413 18.555 37.541 18.5501C38.0358 17.1955 38.7609 15.9366 39.6843 14.8288C39.9141 14.5861 40.0065 14.2442 39.9303 13.9188L38.6783 8.51219C38.6634 8.45567 38.641 8.40141 38.6117 8.35086C38.6063 8.34086 38.6043 8.32886 38.599 8.31952C38.5937 8.31019 38.5703 8.28752 38.557 8.27019C38.5297 8.23025 38.4982 8.19337 38.463 8.16019C38.4398 8.14388 38.4155 8.12918 38.3903 8.11619C38.3578 8.09227 38.3233 8.07129 38.287 8.05353C38.2368 8.03454 38.1844 8.02178 38.131 8.01553C38.1157 8.01553 38.1023 8.00553 38.087 8.00419C37.9592 7.99568 37.8317 8.02415 37.7197 8.08619C37.7097 8.09153 37.6977 8.09353 37.6877 8.09953H37.681L32.9737 11.0375C32.6886 11.214 32.5117 11.5223 32.503 11.8575C32.3723 13.2969 31.9931 14.7028 31.3824 16.0128V16.0201L29.8564 19.7088C29.1074 19.3106 28.3056 19.0211 27.4751 18.8488C27.7895 16.6788 27.9051 14.4846 27.8204 12.2935C29.0614 10.8045 29.657 8.88196 29.4751 6.9522C29.0584 3.06689 25.5471 0.260907 25.3971 0.142908C25.1716 -0.0346298 24.8579 -0.0479817 24.6182 0.109761C24.3785 0.267504 24.2666 0.560943 24.3404 0.838237C24.6838 2.12756 24.3864 3.48822 21.8504 6.2862C20.711 7.38639 20.3499 9.06626 20.9364 10.5375C21.1607 11.1002 21.482 11.6192 21.8858 12.0708C21.7244 13.1008 21.5978 14.0762 21.5104 15.0262C21.3601 16.5974 21.3213 18.1774 21.3944 19.7541C20.7997 20.0766 20.2429 20.4645 19.7345 20.9108L16.5011 7.0842C16.5011 7.0702 16.4878 7.0602 16.4838 7.04753C16.473 7.00308 16.4573 6.95994 16.4371 6.91887L13.1345 0.81957C12.804 0.209089 12.1057 -0.104619 11.4298 0.0536884C10.7539 0.211995 10.2676 0.80314 10.2425 1.4969L9.99185 8.42686C9.99201 8.47687 9.9976 8.52672 10.0085 8.57552C10.0085 8.58619 10.0085 8.59552 10.0085 8.60552L13.3072 22.6834C12.7868 22.7064 12.2702 22.7835 11.7658 22.9134L8.13719 14.1502C7.84622 13.4803 7.07449 13.1642 6.3972 13.4375L0.851237 15.7335C0.172486 16.0168 -0.150077 16.7951 0.129241 17.4755L5.05054 29.3474C2.16623 29.4988 -0.0726425 31.9201 0.00180386 34.8074C0.0762502 37.6947 2.43693 39.9974 5.32521 40H34.6584C36.5638 39.9724 38.3097 38.9303 39.2385 37.2664C40.1672 35.6024 40.1378 33.5694 39.1611 31.9331C38.1845 30.2968 36.4091 29.3058 34.5037 29.3334ZM33.8244 12.0775L36.619 10.3335L35.6297 12.7228C35.4887 13.063 35.6502 13.4531 35.9904 13.5942C36.3306 13.7352 36.7207 13.5737 36.8617 13.2335L37.851 10.8442L38.5917 14.0528C37.7992 15.0196 37.1483 16.0941 36.6584 17.2441C35.9633 17.5663 35.1652 17.583 34.4572 17.2902C33.7493 16.9974 33.1961 16.4218 32.9317 15.7028C33.3999 14.5429 33.7005 13.3222 33.8244 12.0775ZM32.291 17.3115C32.7321 17.8507 33.3044 18.2674 33.953 18.5215C34.4686 18.7432 35.0231 18.8602 35.5844 18.8655C35.7194 18.865 35.8543 18.8567 35.9884 18.8408L33.861 23.9741C33.224 22.5696 32.2386 21.3513 30.9984 20.4348L32.291 17.3115ZM23.1578 12.5502L26.5071 12.7548C26.5277 13.3775 26.5204 14.0215 26.4997 14.6755C25.384 14.7552 24.2627 14.701 23.1598 14.5142C23.0758 14.5022 22.9938 14.4928 22.9104 14.4815C22.9771 13.8535 23.0584 13.2175 23.1564 12.5502H23.1578ZM22.8398 7.18153C24.6098 5.22888 25.5271 3.72689 25.7404 2.31489C27.0127 3.62392 27.8525 5.29191 28.1464 7.09353C28.2864 8.66192 27.8015 10.2221 26.7971 11.4348C25.4802 11.3548 24.1778 11.2748 22.8898 11.1948C22.3363 10.6775 22.018 9.95667 22.0083 9.19913C21.9986 8.44159 22.2984 7.71289 22.8384 7.18153H22.8398ZM22.7891 15.8101L22.9824 15.8355C23.8415 15.9683 24.7086 16.0421 25.5778 16.0561C25.8538 16.0561 26.1444 16.0341 26.4357 16.0115C26.3751 16.8695 26.2757 17.7655 26.1497 18.6915C25.9851 18.6828 25.8238 18.6668 25.6584 18.6668C24.6519 18.6686 23.6529 18.8406 22.7038 19.1755C22.673 18.053 22.7011 16.9297 22.7878 15.8101H22.7891ZM17.6325 23.6061L15.7251 15.4815C15.636 15.129 15.2808 14.913 14.9268 14.9959C14.5728 15.0788 14.3505 15.4301 14.4272 15.7855L16.1411 23.0981C15.6699 22.9296 15.1831 22.8083 14.6878 22.7361L11.7618 10.2495C12.1717 10.4361 12.6168 10.533 13.0672 10.5335C13.1092 10.5335 13.1538 10.5275 13.1965 10.5255L13.6678 12.5382C13.7186 12.7737 13.8926 12.9636 14.1229 13.0347C14.3531 13.1058 14.6038 13.047 14.7786 12.8811C14.9533 12.7151 15.0249 12.4678 14.9658 12.2342L14.4938 10.2202C14.9461 10.0199 15.3451 9.71623 15.6585 9.33352L18.6331 22.0528C18.2468 22.5346 17.9115 23.0552 17.6325 23.6061ZM13.5592 9.13952C12.7066 9.30487 11.836 8.9563 11.3332 8.24819L11.4178 5.90021C11.6498 5.94353 11.8852 5.96584 12.1212 5.96687C12.3491 5.96783 12.5764 5.94255 12.7985 5.89154C13.2482 5.77343 13.6689 5.56422 14.0345 5.27688L15.1572 7.34886C15.0234 8.20854 14.398 8.90989 13.5592 9.14085V9.13952ZM11.7332 1.35157C11.824 1.33053 11.9177 1.37249 11.9625 1.45423L13.3918 4.09755C13.134 4.33081 12.8261 4.50186 12.4918 4.59755C12.1502 4.66026 11.7987 4.64361 11.4645 4.54888L11.5732 1.5449C11.5768 1.45174 11.6423 1.37255 11.7332 1.35157ZM6.90853 14.6668L7.41786 15.8975L4.95121 16.9188C4.65879 17.0416 4.49336 17.3534 4.55566 17.6644C4.61795 17.9754 4.89072 18.1994 5.20788 18.2001C5.29547 18.1999 5.38218 18.1827 5.46321 18.1495L7.92986 17.1275L8.43986 18.3595L7.20586 18.8708C6.91177 18.9925 6.74472 19.3051 6.80702 19.6173C6.86932 19.9294 7.14357 20.154 7.46186 20.1535C7.54922 20.1531 7.6357 20.1359 7.71653 20.1028L8.95052 19.5915L9.46052 20.8235L6.99187 21.8468C6.69777 21.9685 6.53073 22.2811 6.59302 22.5933C6.65532 22.9054 6.92958 23.1299 7.24786 23.1294C7.33523 23.1292 7.42172 23.112 7.50253 23.0788L9.96918 22.0574L10.5085 23.3594C8.33612 24.351 6.74313 26.2899 6.19187 28.6134L1.3599 16.9628L6.90853 14.6668ZM34.6584 38.6667H5.32521C3.11608 38.6667 1.32523 36.8758 1.32523 34.6667C1.32523 32.4576 3.11608 30.6667 5.32521 30.6667C5.71149 30.6654 6.09585 30.7211 6.46587 30.8321C6.66576 30.8924 6.8824 30.8557 7.05118 30.7327C7.21996 30.6098 7.32138 30.4148 7.3252 30.2061C7.37262 27.8301 8.74612 25.6807 10.8823 24.6394C13.0184 23.5982 15.5577 23.8404 17.4585 25.2668C17.6264 25.3918 17.8434 25.4306 18.0443 25.3716C18.2452 25.3127 18.4067 25.1627 18.4805 24.9668C19.7829 21.4956 23.3827 19.4538 27.0303 20.1172C30.678 20.7807 33.3283 23.9592 33.325 27.6667C33.3263 28.4292 33.2128 29.1874 32.9884 29.9161C32.9183 30.1428 32.974 30.3896 33.1346 30.5642C33.2953 30.7389 33.5366 30.815 33.7684 30.7641C34.0607 30.6997 34.3591 30.6671 34.6584 30.6667C36.8675 30.6667 38.6583 32.4576 38.6583 34.6667C38.6583 36.8758 36.8675 38.6667 34.6584 38.6667Z"
                                 fill="#FF6881" />
                              <path
                                 d="M25.7828 10.4662C25.992 10.467 26.1895 10.3695 26.3161 10.2028C27.1484 9.07634 27.4701 7.6524 27.2028 6.27753C27.1459 6.04245 26.9662 5.8566 26.7331 5.79189C26.5001 5.72719 26.2503 5.79378 26.0804 5.9659C25.9105 6.13802 25.8471 6.38867 25.9148 6.62086C26.0744 7.59781 25.8362 8.598 25.2535 9.39818C25.1019 9.60019 25.0776 9.87046 25.1905 10.0963C25.3034 10.3222 25.5343 10.4648 25.7868 10.4648L25.7828 10.4662Z"
                                 fill="#FF6881" />
                              <path
                                 d="M24.9052 30.6662C24.4094 30.6678 23.9205 30.7817 23.4752 30.9996C22.2759 29.3585 20.0366 28.8778 18.2695 29.882C16.5023 30.8862 15.7692 33.056 16.5652 34.9262C16.67 35.172 16.9114 35.3316 17.1786 35.3315C17.2684 35.3318 17.3573 35.3136 17.4399 35.2782C17.6026 35.2089 17.731 35.0778 17.7971 34.9138C17.8631 34.7498 17.8612 34.5662 17.7919 34.4035C17.6468 34.0653 17.5719 33.701 17.5719 33.3329C17.5719 31.8601 18.7658 30.6662 20.2385 30.6662C21.2729 30.6611 22.215 31.2605 22.6485 32.1996C22.663 32.2213 22.6785 32.2422 22.6952 32.2622C22.7057 32.2851 22.7175 32.3073 22.7305 32.3289C22.7425 32.3436 22.7599 32.3502 22.7732 32.3642C22.8045 32.3967 22.8391 32.4257 22.8765 32.4509C22.9098 32.4765 22.9456 32.4989 22.9832 32.5176C23.0219 32.5338 23.0621 32.5463 23.1032 32.5549C23.1442 32.5657 23.1862 32.5721 23.2285 32.5742C23.3151 32.5735 23.4011 32.5591 23.4832 32.5316C23.501 32.5283 23.5185 32.5241 23.5359 32.5189C23.5575 32.5049 23.5782 32.4895 23.5979 32.4729C23.6219 32.4622 23.6452 32.4502 23.6679 32.4369C24.018 32.1537 24.4548 31.9993 24.9052 31.9996C25.6847 32.0008 26.3924 32.4549 26.7185 33.1629C26.8713 33.4979 27.2668 33.6457 27.6018 33.4929C27.9369 33.3401 28.0846 32.9446 27.9318 32.6096C27.389 31.4263 26.207 30.6674 24.9052 30.6662Z"
                                 fill="#FF6881" />
                              <path
                                 d="M11.7812 26.0337C11.6805 26.0664 9.3252 26.881 9.3252 29.333C9.3252 29.7012 9.62367 29.9997 9.99186 29.9997C10.36 29.9997 10.6585 29.7012 10.6585 29.333C10.7129 28.403 11.3248 27.5985 12.2065 27.2977C12.5563 27.1802 12.7446 26.8015 12.6272 26.4517C12.5097 26.1019 12.131 25.9136 11.7812 26.031V26.0337Z"
                                 fill="#FF6881" />
                              <path
                                 d="M21.162 25.314C21.215 25.3274 21.2694 25.3341 21.324 25.334C21.6296 25.3336 21.8958 25.1257 21.97 24.8293C22.2769 23.5844 23.3789 22.6989 24.6607 22.6673C25.0289 22.6664 25.3266 22.3672 25.3257 21.999C25.3247 21.6308 25.0255 21.3331 24.6573 21.334C22.7625 21.3591 21.125 22.6639 20.6774 24.5053C20.5879 24.8624 20.8049 25.2245 21.162 25.314Z"
                                 fill="#FF6881" />
                           </svg>
                          <?php elseif($i===3):?>
                           <svg width="46" height="40" viewBox="0 0 46 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M17.888 29.0993C17.7168 29.0993 17.5442 29.0404 17.4035 28.9205L12.56 24.7963C12.3929 24.6539 12.2969 24.4459 12.2969 24.2262C12.2969 24.0069 12.3934 23.7989 12.56 23.6565L17.4035 19.5322C17.718 19.2641 18.1904 19.3021 18.4586 19.6166C18.7263 19.9315 18.6887 20.4039 18.3738 20.6717L14.1998 24.2262L18.3738 27.7807C18.6887 28.0488 18.7263 28.5212 18.4586 28.8357C18.3103 29.0099 18.0998 29.0993 17.888 29.0993Z"
                                 fill="#00BC65" />
                              <path
                                 d="M27.4491 29.0993C27.2373 29.0993 27.0268 29.0099 26.8789 28.8357C26.6108 28.5212 26.6488 28.0488 26.9633 27.7807L31.1372 24.2262L26.9633 20.6717C26.6488 20.4039 26.6108 19.9315 26.8789 19.6166C27.1467 19.3021 27.6195 19.2641 27.9336 19.5322L32.777 23.6565C32.9441 23.7989 33.0402 24.0069 33.0402 24.2262C33.0402 24.4459 32.9441 24.6539 32.777 24.7963L27.9336 28.9205C27.7928 29.0404 27.6203 29.0993 27.4491 29.0993Z"
                                 fill="#00BC65" />
                              <path
                                 d="M20.9538 32.1926C20.9024 32.1926 20.8506 32.1872 20.7984 32.1763C20.3941 32.0911 20.1351 31.6939 20.2203 31.2896L23.2389 16.9576C23.3241 16.5533 23.7209 16.2943 24.1257 16.3795C24.53 16.4647 24.789 16.8615 24.7038 17.2662L21.6851 31.5983C21.6108 31.9508 21.3 32.1926 20.9538 32.1926Z"
                                 fill="#00BC65" />
                              <path
                                 d="M40.3116 40H5.02558C2.25466 40 0 37.7458 0 34.9744V5.02558C0 2.25466 2.25466 0 5.02558 0H40.3116C43.0825 0 45.3372 2.25466 45.3372 5.02558V34.9744C45.3372 37.7458 43.0825 40 40.3116 40ZM5.02558 1.49698C3.08001 1.49698 1.49698 3.08001 1.49698 5.02558V34.9744C1.49698 36.92 3.08001 38.503 5.02558 38.503H40.3116C42.2572 38.503 43.8402 36.92 43.8402 34.9744V5.02558C43.8402 3.08001 42.2572 1.49698 40.3116 1.49698H5.02558Z"
                                 fill="#00BC65" />
                              <path
                                 d="M44.5887 11.9853H0.748491C0.334983 11.9853 0 11.6503 0 11.2368C0 10.8237 0.334983 10.4883 0.748491 10.4883H44.5887C45.0022 10.4883 45.3372 10.8237 45.3372 11.2368C45.3372 11.6503 45.0022 11.9853 44.5887 11.9853Z"
                                 fill="#00BC65" />
                              <path
                                 d="M12.7886 8.4034C11.4829 8.4034 10.4199 7.34039 10.4199 6.03471C10.4199 4.72861 11.4829 3.66602 12.7886 3.66602C14.0947 3.66602 15.1573 4.72861 15.1573 6.03471C15.1573 7.34039 14.0947 8.4034 12.7886 8.4034ZM12.7886 5.163C12.3083 5.163 11.9169 5.55395 11.9169 6.03471C11.9169 6.51546 12.3083 6.90641 12.7886 6.90641C13.2694 6.90641 13.6603 6.51546 13.6603 6.03471C13.6603 5.55395 13.2694 5.163 12.7886 5.163Z"
                                 fill="#00BC65" />
                              <path
                                 d="M5.51127 8.37996C4.20517 8.37996 3.14258 7.31737 3.14258 6.01127C3.14258 4.70517 4.20517 3.64258 5.51127 3.64258C6.81737 3.64258 7.87996 4.70517 7.87996 6.01127C7.87996 7.31737 6.81737 8.37996 5.51127 8.37996ZM5.51127 5.13956C5.03093 5.13956 4.63956 5.53093 4.63956 6.01127C4.63956 6.49202 5.03093 6.88298 5.51127 6.88298C5.99202 6.88298 6.38298 6.49202 6.38298 6.01127C6.38298 5.53093 5.99202 5.13956 5.51127 5.13956Z"
                                 fill="#00BC65" />
                              <path
                                 d="M20.0665 8.42642C18.7608 8.42642 17.6982 7.36383 17.6982 6.05773C17.6982 4.75204 18.7608 3.68945 20.0665 3.68945C21.3726 3.68945 22.4352 4.75204 22.4352 6.05773C22.4352 7.36383 21.3726 8.42642 20.0665 8.42642ZM20.0665 5.18602C19.5862 5.18602 19.1952 5.57697 19.1952 6.05773C19.1952 6.53848 19.5862 6.92943 20.0665 6.92943C20.5473 6.92943 20.9382 6.53848 20.9382 6.05773C20.9382 5.57697 20.5473 5.18602 20.0665 5.18602Z"
                                 fill="#00BC65" />
                           </svg>
                          <?php elseif($i===4):?>
                           <svg width="38" height="40" viewBox="0 0 38 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M34.2 6.09099C34.994 6.09099 35.6364 5.44856 35.6364 4.65463C35.6364 3.86069 34.994 3.21826 34.2 3.21826C33.4061 3.21826 32.7637 3.86069 32.7637 4.65463C32.7637 5.44856 33.4122 6.09099 34.2 6.09099ZM34.2 4.2425C34.4303 4.2425 34.6182 4.43038 34.6182 4.66069C34.6182 4.89099 34.4303 5.07887 34.2 5.07887C33.9637 5.07887 33.7819 4.89705 33.7819 4.66069C33.7819 4.42432 33.9697 4.2425 34.2 4.2425Z"
                                 fill="#F2A700" />
                              <path
                                 d="M35.7942 0.896973H6.26689C5.14568 0.896973 4.23053 1.81212 4.23053 2.93334V6.04243H2.20629C1.08507 6.04243 0.169922 6.95758 0.169922 8.07879V33.6121C0.169922 34.7333 1.08507 35.6485 2.20629 35.6485H15.7396V38.5939C15.7396 38.8727 15.9699 39.103 16.2487 39.103H25.8123C26.0911 39.103 26.3214 38.8727 26.3214 38.5939V35.6485H31.7336C32.8548 35.6485 33.7699 34.7333 33.7699 33.6121V30.503H35.7942C36.9154 30.503 37.8305 29.5879 37.8305 28.4667V2.93334C37.8305 1.81212 36.9154 0.896973 35.7942 0.896973ZM5.24871 2.93334C5.24871 2.3697 5.70932 1.91515 6.26689 1.91515H35.7942C36.3578 1.91515 36.8123 2.37576 36.8123 2.93334V7.4H17.4911L15.2184 5.04243C15.0426 4.86061 14.8002 4.75758 14.5517 4.75758H9.54568C9.03659 4.75758 8.61841 5.17576 8.61841 5.68485V7.4H5.24871V2.93334ZM2.20629 34.6364C1.64265 34.6364 1.1881 34.1758 1.1881 33.6182V8.07879C1.1881 7.51515 1.64871 7.06061 2.20629 7.06061H4.23053V28.4727C4.23053 29.5939 5.14568 30.5091 6.26689 30.5091H17.3214C17.5214 30.897 17.6123 31.3333 17.576 31.7818H16.7881C16.2063 31.7818 15.7396 32.2545 15.7396 32.8303V34.6364H2.20629ZM20.5275 23.9758C20.6305 23.7939 20.8184 23.6788 21.0305 23.6788C21.3457 23.6788 21.6002 23.9333 21.6002 24.2485C21.6002 24.4545 21.4911 24.6424 21.3154 24.7455C21.1214 24.8606 20.8911 24.8485 20.6548 24.7152C20.6245 24.697 20.5942 24.6727 20.582 24.6424C20.3881 24.3333 20.4669 24.0909 20.5275 23.9758ZM20.5214 22.7576C20.1517 22.8849 19.8366 23.1333 19.6427 23.4849C19.3517 24.0061 19.3881 24.6424 19.7275 25.1879C19.8366 25.3576 19.982 25.497 20.1578 25.6C20.4366 25.7576 20.7396 25.8424 21.0366 25.8424C21.3154 25.8424 21.5881 25.7697 21.8305 25.6303C22.3154 25.3455 22.6184 24.8182 22.6184 24.2545C22.6184 23.5576 22.1639 22.9697 21.5396 22.7576V20.1394L26.0426 28.2667C26.0366 28.2727 26.0305 28.2849 26.0123 28.2909C24.4184 28.703 23.376 30.1939 23.4608 31.7818H18.6063C18.6972 30.1879 17.6487 28.697 16.0245 28.2424L20.5214 20.1394V22.7576ZM25.3033 38.0849H16.7578L16.7881 32.7939H25.273C25.2911 32.7939 25.3033 32.8061 25.3033 32.8242V38.0849ZM32.7517 33.6121C32.7517 34.1758 32.2911 34.6303 31.7336 34.6303H26.3214V32.8242C26.3214 32.2424 25.8487 31.7758 25.273 31.7758H24.4851C24.4487 31.3273 24.5457 30.8909 24.7396 30.503H32.7517V33.6121ZM35.7942 29.4909H25.7275C25.8911 29.4 26.0669 29.3212 26.2608 29.2727C26.582 29.1879 26.8426 28.9636 26.976 28.6606C27.1033 28.3636 27.0851 28.0303 26.9275 27.7455L21.7154 18.3576C21.582 18.1091 21.3214 17.9515 21.0366 17.9515C20.7457 17.9576 20.4851 18.103 20.3457 18.3515L15.1275 27.7455C14.9699 28.0303 14.9578 28.3697 15.0851 28.6667C15.2123 28.9697 15.473 29.1879 15.7942 29.2727C15.9881 29.3212 16.1578 29.4 16.3275 29.4909H6.26689C5.70326 29.4909 5.24871 29.0303 5.24871 28.4727V8.41818H8.70326C9.21235 8.41818 9.63053 8 9.63053 7.49091V5.77576H14.5093L16.782 8.13334C16.9578 8.31516 17.2002 8.41818 17.4487 8.41818H36.8123V28.4667C36.8123 29.0303 36.3578 29.4909 35.7942 29.4909Z"
                                 fill="#F2A700" />
                              <path
                                 d="M30.7337 6.09099C31.5277 6.09099 32.1701 5.44856 32.1701 4.65463C32.1701 3.86069 31.5277 3.21826 30.7337 3.21826C29.9398 3.21826 29.2974 3.86069 29.2974 4.65463C29.2974 5.44856 29.9398 6.09099 30.7337 6.09099ZM30.7337 4.2425C30.964 4.2425 31.1519 4.43038 31.1519 4.66069C31.1519 4.89099 30.964 5.07887 30.7337 5.07887C30.4974 5.07887 30.3155 4.89705 30.3155 4.66069C30.3155 4.42432 30.5034 4.2425 30.7337 4.2425Z"
                                 fill="#F2A700" />
                              <path
                                 d="M27.2611 6.09099C28.055 6.09099 28.6974 5.44856 28.6974 4.65463C28.6974 3.86069 28.055 3.21826 27.2611 3.21826C26.4671 3.21826 25.8247 3.86069 25.8247 4.65463C25.8247 5.44856 26.4671 6.09099 27.2611 6.09099ZM27.2611 4.2425C27.4914 4.2425 27.6793 4.43038 27.6793 4.66069C27.6793 4.89099 27.4914 5.07887 27.2611 5.07887C27.0247 5.07887 26.8429 4.89705 26.8429 4.66069C26.8429 4.42432 27.0308 4.2425 27.2611 4.2425Z"
                                 fill="#F2A700" />
                              <path
                                 d="M30.8424 12.8543C30.5455 13.1513 30.3576 13.527 30.2849 13.927H23.1636V13.127C23.1636 12.5816 22.7212 12.1392 22.1758 12.1392H19.8788C19.3333 12.1392 18.8909 12.5816 18.8909 13.127V13.927H11.7758C11.7091 13.5331 11.5212 13.1573 11.2182 12.8483C10.4485 12.0907 9.13334 12.1028 8.38182 12.8543C8.00001 13.2361 7.79395 13.7392 7.79395 14.2725C7.79395 14.8119 8.00607 15.321 8.38182 15.6907C8.76364 16.0846 9.27273 16.2846 9.80001 16.2846C10.1333 16.2846 10.4727 16.2058 10.7939 16.0422C11.1394 15.8664 11.4242 15.5755 11.5939 15.2179C11.6364 15.127 11.6727 15.0361 11.703 14.9452H16.6424C13.9576 16.2543 11.9333 18.7149 11.2303 21.6846H10.4424C9.89697 21.6846 9.45455 22.127 9.45455 22.6725V24.9695C9.45455 25.5149 9.89697 25.9573 10.4424 25.9573H12.7394C13.2849 25.9573 13.7273 25.5149 13.7273 24.9695V22.6725C13.7273 22.127 13.2849 21.6846 12.7394 21.6846H12.2788C13.1273 18.4846 15.6909 15.9755 18.9091 15.1998V15.4179C18.9091 15.9634 19.3515 16.4058 19.897 16.4058H22.1939C22.7394 16.4058 23.1818 15.9634 23.1818 15.4179V15.1998C26.3939 15.9755 28.9576 18.4846 29.8121 21.6846H29.3939C28.8485 21.6846 28.4061 22.127 28.4061 22.6725V24.9695C28.4061 25.5149 28.8485 25.9573 29.3939 25.9573H31.6909C32.2364 25.9573 32.6788 25.5149 32.6788 24.9695V22.6725C32.6788 22.127 32.2364 21.6846 31.6909 21.6846H30.8606C30.1515 18.7149 28.1273 16.2483 25.4485 14.9452H30.4C30.497 15.224 30.6546 15.4786 30.8667 15.6907C31.2485 16.0846 31.7576 16.2846 32.2849 16.2846C32.6182 16.2846 32.9576 16.2058 33.2788 16.0422C33.6242 15.8664 33.9091 15.5755 34.0788 15.2179C34.4727 14.3876 34.3333 13.4846 33.7091 12.8483C32.9152 12.0967 31.6 12.1028 30.8424 12.8543ZM10.6667 14.7876C10.5939 14.9331 10.4727 15.0604 10.3273 15.1331C9.80001 15.3998 9.34546 15.2301 9.09698 14.9695C8.9091 14.7876 8.80607 14.5392 8.80607 14.2725C8.80607 14.0119 8.9091 13.7634 9.09698 13.5695C9.28485 13.3816 9.53334 13.2786 9.80001 13.2786C10.0606 13.2786 10.3152 13.3816 10.497 13.5634C10.8121 13.8907 10.8727 14.3452 10.6667 14.7876ZM12.7273 24.9392L10.4606 24.9695L10.4303 22.7028H12.697L12.7273 24.9392ZM31.6727 24.9392L29.4061 24.9695L29.3758 22.7028H31.6424L31.6727 24.9392ZM19.9152 15.424L19.903 14.6604C19.9152 14.6058 19.9152 14.5513 19.9091 14.4907V14.4846C19.9091 14.4664 19.9212 14.4543 19.9212 14.4361C19.9212 14.4058 19.9091 14.3816 19.903 14.3573L19.8849 13.1634H22.1515L22.1697 14.3573C22.1636 14.3876 22.1515 14.4119 22.1515 14.4422C22.1515 14.4604 22.1576 14.4725 22.1636 14.4907V14.4967C22.1515 14.5755 22.1576 14.6483 22.1758 14.7149L22.1879 15.3998L19.9152 15.424ZM33.1333 14.7876C33.0606 14.9331 32.9394 15.0604 32.7939 15.1331C32.2667 15.3998 31.8121 15.2301 31.5636 14.9695C31.3758 14.7876 31.2727 14.5392 31.2727 14.2725C31.2727 14.0119 31.3758 13.7634 31.5636 13.5695C31.7515 13.3816 32 13.2786 32.2667 13.2786C32.5273 13.2786 32.7818 13.3816 32.9636 13.5634C33.2788 13.8907 33.3394 14.3452 33.1333 14.7876Z"
                                 fill="#F2A700" />
                           </svg>
                          <?php elseif($i===5):?>
                           <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M39.6505 29.1037L35.5517 27.0543L32.9432 20.2688C32.9124 20.1886 32.8655 20.1156 32.8053 20.0543C32.7451 19.993 32.6729 19.9448 32.5933 19.9127L16.4075 13.4427C16.2943 13.3977 16.1705 13.3867 16.0511 13.4111C15.9318 13.4355 15.8222 13.4943 15.7358 13.5802L13.5771 15.7389C13.4923 15.8254 13.4345 15.9346 13.4107 16.0533C13.3868 16.172 13.398 16.295 13.4428 16.4075L19.9127 32.5932C19.9448 32.6729 19.993 32.7451 20.0543 32.8053C20.1156 32.8655 20.1886 32.9124 20.2688 32.9431L27.0543 35.5517L29.1037 39.6505C29.1468 39.7409 29.2111 39.8196 29.291 39.8799C29.3709 39.9403 29.4642 39.9805 29.5629 39.9973C29.5962 40.0004 29.6296 40.0004 29.6629 39.9973C29.8283 39.9966 29.9867 39.9303 30.1034 39.813L39.813 30.1034C39.8844 30.0344 39.9384 29.9494 39.9705 29.8554C40.0025 29.7614 40.0117 29.6612 39.9973 29.5629C39.9805 29.4642 39.9403 29.3709 39.8799 29.291C39.8196 29.2111 39.7409 29.1468 39.6505 29.1037ZM14.7517 16.3263L15.0985 15.9826L23.1555 24.0396C22.6245 24.792 22.3952 25.7162 22.5128 26.6296C22.6305 27.5429 23.0866 28.3789 23.791 28.9721C24.4953 29.5653 25.3967 29.8727 26.3167 29.8334C27.2368 29.794 28.1086 29.4109 28.7598 28.7597C29.4109 28.1086 29.7941 27.2368 29.8334 26.3167C29.8727 25.3967 29.5654 24.4953 28.9721 23.791C28.3789 23.0866 27.5429 22.6305 26.6296 22.5128C25.7162 22.3951 24.792 22.6245 24.0396 23.1555L15.9826 15.0985L16.3263 14.7517L31.8747 20.9717L34.3271 27.3511L27.3511 34.3271L20.9717 31.8747L14.7517 16.3263ZM26.1577 23.7303C26.7192 23.7311 27.2631 23.9266 27.6967 24.2835C28.1303 24.6403 28.4267 25.1365 28.5355 25.6874C28.6443 26.2383 28.5587 26.8099 28.2933 27.3048C28.028 27.7997 27.5992 28.1872 27.0802 28.4015C26.5611 28.6157 25.9838 28.6434 25.4466 28.4797C24.9095 28.316 24.4456 27.9712 24.1342 27.5039C23.8228 27.0367 23.683 26.4759 23.7386 25.9171C23.7943 25.3583 24.042 24.8361 24.4395 24.4394C24.8956 23.9847 25.5136 23.7297 26.1577 23.7303ZM29.8347 38.3165L28.2727 35.1925L35.1862 28.2789L38.3103 29.8409L29.8347 38.3165Z"
                                 fill="#4500D0" />
                              <path
                                 d="M11.9588 33.4372C11.8393 33.3242 11.6811 33.2613 11.5167 33.2613C11.3523 33.2613 11.1942 33.3242 11.0747 33.4372L10.2812 34.2307C8.1636 31.3567 6.99542 27.8937 6.93942 24.3243C6.88342 20.7549 7.9424 17.2569 9.96875 14.3179C10.5758 14.652 11.2749 14.7803 11.961 14.6836C12.6472 14.587 13.2836 14.2706 13.7748 13.7818C14.266 13.2931 14.5856 12.6583 14.6857 11.9727C14.7858 11.287 14.6609 10.5873 14.3299 9.97858C17.2689 7.95222 20.7669 6.89325 24.3363 6.94925C27.9057 7.00525 31.3687 8.17343 34.2427 10.291L33.4367 11.0751C33.3205 11.1923 33.2554 11.3506 33.2555 11.5156C33.255 11.5978 33.2708 11.6794 33.3019 11.7555C33.333 11.8316 33.3788 11.9008 33.4367 11.9592L36.1921 14.6928C36.3092 14.8092 36.4676 14.8745 36.6326 14.8745C36.7977 14.8745 36.956 14.8092 37.0731 14.6928L39.8129 11.953C39.871 11.895 39.9171 11.826 39.9485 11.7502C39.98 11.6743 39.9962 11.593 39.9962 11.5109C39.9962 11.4288 39.98 11.3475 39.9485 11.2717C39.9171 11.1958 39.871 11.1269 39.8129 11.0689L37.0731 8.32907C36.956 8.2127 36.7977 8.14738 36.6326 8.14738C36.4676 8.14738 36.3092 8.2127 36.1921 8.32907L35.1331 9.38188C32.5229 7.41777 29.4371 6.18377 26.1923 5.80659C22.9476 5.42941 19.6609 5.92265 16.6699 7.23565L20.2719 3.64298C20.6803 3.83813 21.1447 3.88231 21.5826 3.76766C22.0205 3.65302 22.4036 3.38698 22.664 3.01673C22.9244 2.64648 23.0452 2.19596 23.005 1.74509C22.9649 1.29423 22.7663 0.872167 22.4445 0.553787C22.1228 0.235407 21.6987 0.0412896 21.2474 0.00587338C20.7961 -0.0295428 20.3469 0.0960315 19.9794 0.360319C19.6119 0.624606 19.3499 1.01052 19.2399 1.4496C19.1299 1.88867 19.179 2.35253 19.3784 2.75887L13.299 8.84767C12.6817 8.43361 11.9399 8.2467 11.2001 8.31889C10.4603 8.39107 9.76857 8.71787 9.24299 9.24344C8.71741 9.76902 8.39062 10.4608 8.31844 11.2005C8.24625 11.9403 8.43315 12.6822 8.84721 13.2995L2.75842 19.3789C2.35049 19.1801 1.88529 19.1324 1.4455 19.2442C1.00571 19.356 0.619804 19.6201 0.356358 19.9896C0.0929114 20.3591 -0.0310131 20.81 0.00660533 21.2622C0.0442238 21.7145 0.240949 22.1387 0.561823 22.4596C0.882697 22.7805 1.30694 22.9772 1.75916 23.0148C2.21138 23.0524 2.6623 22.9285 3.03178 22.665C3.40126 22.4016 3.66538 22.0157 3.7772 21.5759C3.88902 21.1361 3.8413 20.6709 3.64253 20.263L7.24457 16.6703C5.93025 19.6606 5.43546 22.9468 5.81099 26.1915C6.18652 29.4362 7.41884 32.5225 9.38143 35.1335L8.3255 36.1926C8.20912 36.3096 8.1438 36.468 8.1438 36.6331C8.1438 36.7981 8.20912 36.9565 8.3255 37.0736L11.0653 39.8134C11.1819 39.9307 11.3403 39.997 11.5058 39.9977C11.5882 39.9977 11.6699 39.9815 11.746 39.9499C11.8222 39.9182 11.8913 39.8718 11.9494 39.8134L14.6923 37.0736C14.8087 36.9565 14.874 36.7981 14.874 36.6331C14.874 36.468 14.8087 36.3096 14.6923 36.1926L11.9588 33.4372ZM36.6389 9.64743L38.4946 11.5031L36.6389 13.3588L34.7832 11.5031L36.6389 9.64743ZM20.628 1.45614C20.7209 1.36253 20.8395 1.29862 20.9687 1.2725C21.0979 1.24639 21.232 1.25925 21.3539 1.30946C21.4758 1.35966 21.58 1.44495 21.6534 1.55449C21.7267 1.66404 21.7659 1.79291 21.7659 1.92474C21.7659 2.05658 21.7267 2.18545 21.6534 2.295C21.58 2.40454 21.4758 2.48983 21.3539 2.54003C21.232 2.59024 21.0979 2.6031 20.9687 2.57698C20.8395 2.55087 20.7209 2.48696 20.628 2.39335C20.5665 2.33184 20.5176 2.2588 20.4843 2.17839C20.4509 2.09798 20.4338 2.01179 20.4338 1.92474C20.4338 1.8377 20.4509 1.75151 20.4843 1.6711C20.5176 1.59069 20.5665 1.51765 20.628 1.45614ZM10.1312 10.1317C10.3126 9.94935 10.5283 9.80469 10.7658 9.70598C11.0033 9.60727 11.258 9.55646 11.5152 9.55646C11.7724 9.55646 12.027 9.60727 12.2645 9.70598C12.502 9.80469 12.7177 9.94935 12.8991 10.1317C13.1734 10.4055 13.3602 10.7545 13.4361 11.1345C13.5119 11.5146 13.4733 11.9086 13.3251 12.2667C13.177 12.6248 12.9259 12.9309 12.6037 13.1463C12.2815 13.3617 11.9027 13.4766 11.5152 13.4766C11.1276 13.4766 10.7488 13.3617 10.4266 13.1463C10.1044 12.9309 9.85334 12.6248 9.70518 12.2667C9.55702 11.9086 9.51841 11.5146 9.59424 11.1345C9.67008 10.7545 9.85695 10.4055 10.1312 10.1317ZM2.39603 21.5657C2.26847 21.6721 2.10574 21.7269 1.93982 21.7194C1.77389 21.7119 1.61677 21.6426 1.49933 21.5252C1.38188 21.4078 1.3126 21.2506 1.3051 21.0847C1.29761 20.9188 1.35243 20.7561 1.45881 20.6285C1.58384 20.5056 1.75212 20.4368 1.92742 20.4368C2.10272 20.4368 2.271 20.5056 2.39603 20.6285C2.45761 20.69 2.50647 20.7631 2.53981 20.8435C2.57314 20.9239 2.5903 21.0101 2.5903 21.0971C2.5903 21.1842 2.57314 21.2703 2.53981 21.3508C2.50647 21.4312 2.45761 21.5042 2.39603 21.5657ZM11.5152 38.4763L9.65947 36.6206L11.5152 34.7649L13.3709 36.6206L11.5152 38.4763Z"
                                 fill="#4500D0" />
                           </svg>
                          <?php elseif($i===6):?>
                           <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M10.7003 25.1745C11.0738 24.9591 11.2017 24.4809 10.9863 24.1073C10.7705 23.7341 10.2926 23.6059 9.91905 23.8214C9.54552 24.0371 9.41734 24.5153 9.6331 24.8886C9.84856 25.2621 10.3268 25.3903 10.7003 25.1745Z"
                                 fill="#BB0064" />
                              <path
                                 d="M7.49877 30.5668L11.4331 37.3817C12.2821 38.8538 14.1919 39.3989 15.7022 38.5258C17.1966 37.6621 17.7103 35.7526 16.8457 34.257L14.5019 30.1969L16.5317 29.025C16.9052 28.809 17.0334 28.3314 16.8176 27.9578L15.8017 26.1982C15.9228 26.1747 16.7194 26.0184 30.7657 23.263C32.5021 23.1687 33.5425 21.2696 32.6654 19.7513L30.069 15.2543L31.7282 12.7411C31.8912 12.494 31.9009 12.1763 31.7529 11.9199L30.1904 9.21362C30.0424 8.95728 29.7613 8.80713 29.4668 8.82452L26.4612 9.00488L23.5788 4.01221C23.1613 3.28894 22.4133 2.85101 21.5784 2.84064C21.5683 2.84033 21.5585 2.84033 21.5485 2.84033C20.7416 2.84033 20.0091 3.24194 19.5752 3.92096L9.3695 16.9221L2.73467 20.7526C0.12511 22.2587 -0.778821 25.6064 0.73302 28.223C2.11425 30.6156 5.02623 31.5568 7.49877 30.5668ZM15.4928 35.0385C15.9244 35.785 15.6689 36.7402 14.9203 37.1726C14.1693 37.6069 13.2129 37.3401 12.7862 36.6007L8.87999 29.834L11.5863 28.2715C16.1072 36.103 15.4202 34.9131 15.4928 35.0385ZM13.7207 28.8434L12.9394 27.4903L14.2926 26.709L15.0738 28.0622L13.7207 28.8434ZM29.0787 10.413L30.1584 12.2831L29.1955 13.7412L27.3346 10.5176L29.0787 10.413ZM20.8819 4.77759C21.0916 4.43457 21.4242 4.39917 21.5591 4.40283C21.6925 4.40436 22.0248 4.44586 22.2253 4.79315L31.3122 20.5326C31.6083 21.045 31.2485 21.6892 30.6549 21.7039C30.5484 21.7063 30.4993 21.7255 30.2264 21.7765L20.6143 5.12762C20.816 4.86823 20.842 4.8432 20.8819 4.77759ZM19.5746 6.45209L28.6056 22.0945L14.9759 24.7678L10.8316 17.5898L19.5746 6.45209ZM2.08617 27.4418C1.74315 26.8482 1.56188 26.1744 1.56188 25.4926C1.56188 24.0992 2.31078 22.8016 3.51592 22.1058L9.60509 18.5901L13.5113 25.3559L7.42217 28.8718C5.55663 29.9485 3.16313 29.307 2.08617 27.4418Z"
                                 fill="#BB0064" />
                              <path
                                 d="M8.27995 25.67C8.06419 25.2965 7.58629 25.1683 7.21275 25.3841L5.8596 26.1653C5.48668 26.3808 5.00786 26.2523 4.7924 25.8794C4.57664 25.5058 4.09874 25.3777 3.7252 25.5934C3.35167 25.8092 3.2235 26.2871 3.43925 26.6606C4.08226 27.7745 5.51659 28.1673 6.64085 27.5185L7.994 26.7372C8.36754 26.5215 8.49571 26.0439 8.27995 25.67Z"
                                 fill="#BB0064" />
                              <path
                                 d="M38.8388 4.51144L34.4855 6.93392C34.1086 7.14388 33.9728 7.61965 34.1828 7.99654C34.3921 8.37313 34.8676 8.50954 35.2454 8.29928L39.5984 5.87679C39.9756 5.66683 40.1111 5.19106 39.9011 4.81417C39.6915 4.43697 39.2157 4.30147 38.8388 4.51144Z"
                                 fill="#BB0064" />
                              <path
                                 d="M38.3822 12.6026L35.3637 11.7939C34.9469 11.6822 34.5184 11.9294 34.4067 12.3463C34.295 12.7632 34.5425 13.1913 34.9594 13.303L37.9782 14.1117C38.3975 14.2243 38.8238 13.9732 38.9349 13.5594C39.0466 13.1425 38.7991 12.714 38.3822 12.6026Z"
                                 fill="#BB0064" />
                              <path
                                 d="M30.7969 1.67295L29.9873 4.69175C29.8756 5.10862 30.1228 5.53678 30.5396 5.64878C30.9562 5.76017 31.3847 5.51359 31.4967 5.09641L32.306 2.07761C32.4177 1.66074 32.1705 1.23228 31.7536 1.12058C31.3371 1.00889 30.9086 1.25608 30.7969 1.67295Z"
                                 fill="#BB0064" />
                           </svg>
                          <?php elseif($i===7):?>
                           <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M34.935 19.6406C35.5513 18.9281 36.25 18.1197 36.25 17.0835C36.25 16.0472 35.5513 15.2393 34.9354 14.5268C34.5654 14.0993 34.1833 13.6572 34.09 13.3077C33.9888 12.9281 34.1008 12.3347 34.2092 11.7606C34.3808 10.8518 34.5758 9.82225 34.0746 8.956C33.5667 8.0785 32.5688 7.73141 31.6879 7.42475C31.1433 7.23558 30.5804 7.03933 30.3121 6.77183C30.0442 6.5035 29.8483 5.94058 29.6592 5.396C29.3529 4.51516 29.0058 3.51725 28.1275 3.00891C27.2612 2.50766 26.2308 2.70266 25.3229 2.87433C24.7488 2.98266 24.155 3.09433 23.7758 2.99308C23.4263 2.89975 22.9846 2.51766 22.5571 2.1485C21.8446 1.53225 21.0362 0.833496 20 0.833496C18.9637 0.833496 18.1558 1.53225 17.4433 2.14808C17.0158 2.51808 16.5737 2.90016 16.2242 2.9935C15.8442 3.09308 15.2512 2.98308 14.6771 2.87433C13.7687 2.70183 12.7387 2.50766 11.8725 3.00891C10.995 3.51683 10.6479 4.51475 10.3412 5.39558C10.1521 5.94016 9.95583 6.50308 9.68833 6.77141C9.42 7.03933 8.85708 7.23516 8.3125 7.42433C7.43167 7.73058 6.43375 8.07766 5.92542 8.956C5.42458 9.82183 5.61917 10.8522 5.79083 11.7606C5.89958 12.3347 6.01125 12.9281 5.90958 13.3077C5.81625 13.6572 5.43417 14.0989 5.065 14.5264C4.44875 15.2389 3.75 16.0472 3.75 17.0835C3.75 18.1197 4.44875 18.9277 5.06458 19.6402C5.43458 20.0677 5.81667 20.5097 5.91 20.8593C6.01125 21.2389 5.89917 21.8322 5.79083 22.4064C5.61917 23.3152 5.42417 24.3447 5.92542 25.211C6.43333 26.0885 7.43125 26.4356 8.31208 26.7422C8.85667 26.9314 9.41958 27.1277 9.68792 27.3952C9.72042 27.4277 9.75167 27.4647 9.78208 27.5056L6.70542 37.2493C6.62583 37.5027 6.67083 37.7789 6.82792 37.9931C6.985 38.2068 7.23417 38.3335 7.5 38.3335H15C15.3633 38.3335 15.6854 38.0981 15.7946 37.7514L17.5704 32.1281C18.2521 32.7147 19.0246 33.3335 20 33.3335C20.9758 33.3335 21.7479 32.7143 22.4296 32.1277L24.2054 37.751C24.3146 38.0981 24.6362 38.3335 25 38.3335H32.5C32.7658 38.3335 33.015 38.2068 33.1721 37.9931C33.3292 37.7785 33.3742 37.5027 33.2946 37.2493L30.2179 27.5056C30.2483 27.4652 30.2796 27.4281 30.3117 27.3956C30.58 27.1277 31.1429 26.9318 31.6875 26.7427C32.5683 26.4364 33.5662 26.0893 34.0746 25.211C34.5754 24.3452 34.3808 23.3147 34.2092 22.4064C34.1004 21.8322 33.9888 21.2389 34.0904 20.8593C34.1833 20.5097 34.5654 20.0677 34.935 19.6406ZM14.3892 36.6668H8.63708L10.78 29.881C11.0283 30.3931 11.3583 30.8602 11.8725 31.1581C12.7387 31.6593 13.7692 31.4639 14.6771 31.2927C15.2079 31.1922 15.7475 31.0964 16.1275 31.1618L14.3892 36.6668ZM25.6108 36.6668L23.8725 31.1614C24.2521 31.0968 24.7917 31.1918 25.3229 31.2922C26.2313 31.4643 27.2612 31.6589 28.1275 31.1577C28.6421 30.8602 28.9717 30.3927 29.22 29.8802L31.3629 36.6668H25.6108ZM33.6742 18.5506C33.1812 19.1202 32.6721 19.7093 32.48 20.4289C32.2804 21.1752 32.4283 21.9585 32.5712 22.7156C32.695 23.3697 32.8229 24.0464 32.6317 24.3764C32.4338 24.7181 31.7762 24.9472 31.1404 25.1681C30.4183 25.4193 29.6717 25.6789 29.1337 26.2172C28.5954 26.7552 28.3358 27.5018 28.0846 28.2239C27.8633 28.8597 27.6346 29.5172 27.2929 29.7152C26.9629 29.906 26.2862 29.7785 25.6329 29.6547C24.8746 29.511 24.0917 29.3635 23.3458 29.5627C22.6258 29.7552 22.0367 30.2647 21.4671 30.7577C20.9496 31.2052 20.4158 31.6668 20 31.6668C19.5842 31.6668 19.05 31.2047 18.5329 30.7577C17.9633 30.2647 17.3742 29.7556 16.6546 29.5635C16.3942 29.4935 16.1292 29.4664 15.8629 29.4664C15.3654 29.4664 14.8613 29.5618 14.3679 29.6547C13.7129 29.7785 13.0367 29.906 12.7071 29.7152C12.3654 29.5172 12.1362 28.8597 11.9154 28.2239C11.6642 27.5018 11.4046 26.7552 10.8663 26.2172C10.3283 25.6789 9.58167 25.4193 8.85958 25.1681C8.22375 24.9468 7.56625 24.7181 7.36833 24.3764C7.17708 24.0464 7.30542 23.3702 7.42875 22.7164C7.57208 21.9589 7.72 21.1756 7.52083 20.4293C7.32833 19.7093 6.81875 19.1202 6.32583 18.5506C5.87833 18.0331 5.41667 17.4993 5.41667 17.0835C5.41667 16.6677 5.87875 16.1335 6.32583 15.6164C6.81875 15.0468 7.32792 14.4577 7.52 13.7381C7.71958 12.9918 7.57167 12.2085 7.42875 11.4514C7.305 10.7972 7.17708 10.1206 7.36833 9.79058C7.56625 9.44891 8.22375 9.21975 8.85958 8.99891C9.58167 8.74766 10.3283 8.48808 10.8663 7.94975C11.4046 7.41183 11.6642 6.66516 11.9154 5.94308C12.1367 5.30725 12.3654 4.64975 12.7071 4.45183C13.0363 4.26058 13.7133 4.3885 14.3671 4.51225C15.125 4.656 15.9083 4.8035 16.6542 4.60433C17.3742 4.41183 17.9633 3.90225 18.5329 3.40933C19.0504 2.96183 19.5842 2.50016 20 2.50016C20.4158 2.50016 20.95 2.96225 21.4671 3.40933C22.0367 3.90225 22.6258 4.41141 23.3454 4.6035C24.0921 4.8035 24.875 4.65558 25.6321 4.51225C26.2862 4.38808 26.9629 4.26058 27.2929 4.45183C27.6346 4.64975 27.8637 5.30725 28.0846 5.94308C28.3358 6.66516 28.5954 7.41183 29.1337 7.94975C29.6717 8.48808 30.4183 8.74766 31.1404 8.99891C31.7762 9.22016 32.4338 9.44891 32.6317 9.79058C32.8229 10.1206 32.6946 10.7968 32.5712 11.4506C32.4279 12.2081 32.28 12.9914 32.4792 13.7377C32.6717 14.4577 33.1812 15.0468 33.6742 15.6164C34.1217 16.1339 34.5833 16.6677 34.5833 17.0835C34.5833 17.4993 34.1213 18.0335 33.6742 18.5506ZM20 6.66683C14.2562 6.66683 9.58333 11.3397 9.58333 17.0835C9.58333 22.8272 14.2562 27.5002 20 27.5002C25.7437 27.5002 30.4167 22.8272 30.4167 17.0835C30.4167 11.3397 25.7437 6.66683 20 6.66683ZM20 25.8335C15.1754 25.8335 11.25 21.9081 11.25 17.0835C11.25 12.2589 15.1754 8.3335 20 8.3335C24.8246 8.3335 28.75 12.2589 28.75 17.0835C28.75 21.9081 24.8246 25.8335 20 25.8335ZM25.1258 14.6622L22.1108 14.2022L20.7546 11.3127C20.6171 11.0202 20.3229 10.8335 20 10.8335C19.6771 10.8335 19.3829 11.0202 19.2454 11.3127L17.8892 14.2022L14.8742 14.6622C14.5654 14.7093 14.3092 14.9256 14.2096 15.2218C14.11 15.5181 14.185 15.8447 14.4033 16.0681L16.5854 18.3047L15.8542 21.4793C15.7812 21.7956 15.8983 22.1247 16.1542 22.3239C16.41 22.5235 16.7579 22.5556 17.0467 22.4081L20 20.8947L22.9533 22.4085C23.0733 22.4702 23.2033 22.5002 23.3333 22.5002C23.5154 22.5002 23.6962 22.4406 23.8454 22.3243C24.1008 22.1247 24.2183 21.7956 24.1454 21.4797L23.4142 18.3052L25.5962 16.0685C25.8142 15.8452 25.8892 15.5185 25.79 15.2222C25.6908 14.926 25.4346 14.7097 25.1258 14.6622ZM21.9033 17.4668C21.705 17.6697 21.6242 17.9597 21.6875 18.236L22.1187 20.1085L20.3796 19.2168C20.2604 19.156 20.1296 19.1252 19.9996 19.1252C19.8692 19.1252 19.7388 19.1556 19.6196 19.2168L17.8804 20.1085L18.3117 18.236C18.375 17.9597 18.2942 17.6702 18.0958 17.4668L16.7283 16.0656L18.58 15.7827C18.8546 15.7402 19.0908 15.5643 19.2088 15.3127L20 13.6281L20.7904 15.3127C20.9083 15.5643 21.1446 15.7402 21.4192 15.7827L23.2708 16.0656L21.9033 17.4668Z"
                                 fill="#0011BB" />
                           </svg>
                          <?php elseif($i===8):?>
                           <svg width="42" height="41" viewBox="0 0 42 41" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M39.5688 31.3843H2.06936C0.997677 31.3843 0.132812 30.5195 0.132812 29.4478V2.76858C0.132812 1.7063 1.00708 0.832031 2.06936 0.832031H39.5688C40.6404 0.832031 41.5053 1.6969 41.5053 2.76858V29.4478C41.5053 30.5195 40.6404 31.3843 39.5688 31.3843ZM2.06936 1.7721C1.52412 1.7721 1.07288 2.22334 1.07288 2.76858V29.4478C1.07288 30.0024 1.52412 30.4443 2.06936 30.4443H39.5688C40.1234 30.4443 40.5652 29.993 40.5652 29.4478V2.76858C40.5652 2.22334 40.114 1.7721 39.5688 1.7721H2.06936Z"
                                 fill="#D16900" />
                              <path
                                 d="M38.516 28.8651H3.12238C2.85916 28.8651 2.65234 28.6583 2.65234 28.395V3.8216C2.65234 3.55838 2.85916 3.35156 3.12238 3.35156H38.5066C38.7699 3.35156 38.9767 3.55838 38.9767 3.8216V28.395C38.9861 28.6583 38.7699 28.8651 38.516 28.8651ZM3.59241 27.925H38.0366V4.29163H3.59241V27.925Z"
                                 fill="#D16900" />
                              <path
                                 d="M15.5688 38.1246C15.4466 38.1246 15.315 38.0776 15.221 37.9742C15.0424 37.7862 15.0518 37.4854 15.2492 37.3068C18.2668 34.5053 17.0165 31.2245 16.9601 31.0835C16.8661 30.8391 16.9789 30.5665 17.2234 30.4724C17.4678 30.3784 17.7404 30.4912 17.8344 30.7357C17.8532 30.7733 18.2386 31.7603 18.1916 33.1422C18.1446 34.4207 17.7122 36.2915 15.8885 37.993C15.7945 38.087 15.6816 38.1246 15.5688 38.1246Z"
                                 fill="#D16900" />
                              <path
                                 d="M26.0701 38.125C25.9573 38.125 25.8445 38.0874 25.7505 38.0028C23.9268 36.3106 23.4943 34.4305 23.4473 33.152C23.4003 31.7701 23.7858 30.783 23.8046 30.7454C23.8986 30.501 24.1712 30.3882 24.4156 30.4822C24.66 30.5762 24.7728 30.8488 24.6788 31.0933C24.6224 31.2343 23.3815 34.5151 26.3898 37.3165C26.5778 37.4951 26.5872 37.7866 26.418 37.984C26.3239 38.078 26.2017 38.125 26.0701 38.125Z"
                                 fill="#D16900" />
                              <path
                                 d="M30.2533 40.8311H11.3861C11.1228 40.8311 10.916 40.6243 10.916 40.361V39.0073C10.916 38.0015 11.7339 37.1836 12.7398 37.1836H28.8996C29.9054 37.1836 30.7233 38.0015 30.7233 39.0073V40.361C30.7233 40.6149 30.5165 40.8311 30.2533 40.8311ZM11.8561 39.891H29.7832V39.0073C29.7832 38.5185 29.3884 38.1237 28.8996 38.1237H12.7398C12.2509 38.1237 11.8561 38.5185 11.8561 39.0073V39.891Z"
                                 fill="#D16900" />
                              <path
                                 d="M12.2696 22.7263C12.185 22.7263 12.1004 22.7075 12.0252 22.6605L6.61038 19.4173C6.46937 19.3327 6.38477 19.1823 6.38477 19.0131V12.8744C6.38477 12.7052 6.47877 12.5454 6.61978 12.4608C6.76079 12.3762 6.94881 12.3762 7.08982 12.4702L12.5046 15.7134C12.6456 15.798 12.7302 15.9484 12.7302 16.1176V22.2563C12.7302 22.4255 12.6362 22.5853 12.4952 22.6699C12.4294 22.7075 12.3448 22.7263 12.2696 22.7263ZM7.32484 18.7498L11.7996 21.429V16.3809L7.32484 13.7017V18.7498Z"
                                 fill="#D16900" />
                              <path
                                 d="M12.2689 22.7271C12.1843 22.7271 12.1091 22.7083 12.0338 22.6707C11.8834 22.5861 11.7988 22.4357 11.7988 22.2571V16.1184C11.7988 15.9492 11.8834 15.7988 12.0244 15.7142L17.4393 12.4709C17.5803 12.3863 17.7683 12.3863 17.9093 12.4615C18.0597 12.5461 18.1443 12.7059 18.1443 12.8752V19.0138C18.1443 19.183 18.0597 19.3334 17.9187 19.4181L12.5039 22.6613C12.4381 22.7083 12.3535 22.7271 12.2689 22.7271ZM12.7389 16.3816V21.4298L17.2136 18.7506V13.7024L12.7389 16.3816Z"
                                 fill="#D16900" />
                              <path
                                 d="M6.85439 13.3445C6.68517 13.3445 6.52536 13.2599 6.44076 13.1001C6.31855 12.8745 6.40315 12.5831 6.62877 12.4609L12.0436 9.54664C12.1846 9.47143 12.3538 9.47143 12.4854 9.54664L17.9002 12.4609C18.1258 12.5831 18.2104 12.8651 18.0882 13.1001C17.966 13.3351 17.684 13.4103 17.449 13.2881L12.2598 10.4961L7.0706 13.2881C7.0048 13.3257 6.92959 13.3445 6.85439 13.3445Z"
                                 fill="#D16900" />
                              <path
                                 d="M16.3305 8.13734H8.20832C7.9451 8.13734 7.73828 7.93052 7.73828 7.6673C7.73828 7.40408 7.9451 7.19727 8.20832 7.19727H16.3305C16.5937 7.19727 16.8006 7.40408 16.8006 7.6673C16.8006 7.93052 16.5937 8.13734 16.3305 8.13734Z"
                                 fill="#D16900" />
                              <path
                                 d="M14.9669 9.49993C14.8447 9.49993 14.7225 9.45293 14.6379 9.35892C14.4593 9.18031 14.4593 8.87949 14.6379 8.69147L15.6719 7.65739L14.6379 6.62332C14.4593 6.4447 14.4593 6.14388 14.6379 5.95587C14.8165 5.76785 15.1173 5.77725 15.3053 5.95587L16.659 7.33777C16.8376 7.51638 16.8376 7.81721 16.659 8.00522L15.2959 9.36832C15.2019 9.45293 15.0891 9.49993 14.9669 9.49993Z"
                                 fill="#D16900" />
                              <path
                                 d="M9.57218 9.50066C9.44997 9.50066 9.32776 9.45365 9.24316 9.35965L7.88005 7.99654C7.70144 7.81793 7.70144 7.51711 7.88005 7.32909L9.24316 5.96599C9.42177 5.78738 9.72259 5.78738 9.91061 5.96599C10.0892 6.1446 10.0892 6.44543 9.91061 6.63344L8.87653 7.66752L9.91061 8.7016C10.0892 8.88021 10.0892 9.18103 9.91061 9.36905C9.8166 9.45365 9.69439 9.50066 9.57218 9.50066Z"
                                 fill="#D16900" />
                              <path
                                 d="M16.3305 25.0299H8.20832C7.9451 25.0299 7.73828 24.8231 7.73828 24.5599C7.73828 24.2967 7.9451 24.0898 8.20832 24.0898H16.3305C16.5937 24.0898 16.8006 24.2967 16.8006 24.5599C16.8006 24.8231 16.5937 25.0299 16.3305 25.0299Z"
                                 fill="#D16900" />
                              <path
                                 d="M14.9669 26.3921C14.8447 26.3921 14.7225 26.3451 14.6379 26.2511C14.4593 26.0631 14.4593 25.7717 14.6379 25.5836L15.6719 24.5496L14.6379 23.5155C14.4593 23.3275 14.4593 23.0361 14.6379 22.848C14.8165 22.66 15.1173 22.66 15.3053 22.848L16.6684 24.2111C16.847 24.3992 16.847 24.6906 16.6684 24.8786L15.3053 26.2417C15.2019 26.3451 15.0891 26.3921 14.9669 26.3921Z"
                                 fill="#D16900" />
                              <path
                                 d="M9.57218 26.3925C9.44997 26.3925 9.32776 26.3455 9.24316 26.2515L7.88005 24.8884C7.70144 24.7003 7.70144 24.4089 7.88005 24.2209L9.24316 22.8578C9.42177 22.6698 9.72259 22.6698 9.91061 22.8578C10.0892 23.0458 10.0892 23.3372 9.91061 23.5253L8.87653 24.5593L9.91061 25.5934C10.0892 25.7814 10.0892 26.0728 9.91061 26.2609C9.8166 26.3455 9.69439 26.3925 9.57218 26.3925Z"
                                 fill="#D16900" />
                              <path
                                 d="M23.0507 26.392H21.4808C20.7945 26.392 20.2305 25.8374 20.2305 25.1511V10.345C20.2305 10.0818 20.4373 9.875 20.7005 9.875H23.8215C24.0848 9.875 24.2916 10.0818 24.2916 10.345V25.1417C24.301 25.828 23.7369 26.392 23.0507 26.392ZM21.1799 10.8151V25.1417C21.1799 25.311 21.321 25.4426 21.4902 25.4426H23.0507C23.2199 25.4426 23.3515 25.3016 23.3515 25.1417V10.8151H21.1799Z"
                                 fill="#D16900" />
                              <path
                                 d="M23.8309 10.8164C23.6429 10.8164 23.4643 10.7035 23.3891 10.5155L22.2704 7.61072L21.1517 10.5155C21.0577 10.76 20.7851 10.8822 20.5406 10.7882C20.2962 10.6941 20.174 10.4215 20.268 10.1771L21.8285 6.13481C21.8943 5.95619 22.073 5.83398 22.2704 5.83398C22.4678 5.83398 22.637 5.95619 22.7122 6.13481L24.2727 10.1771C24.3667 10.4215 24.2445 10.6941 24.0001 10.7882C23.9437 10.807 23.8873 10.8164 23.8309 10.8164Z"
                                 fill="#D16900" />
                              <path
                                 d="M23.8313 23.6198H20.7103C20.447 23.6198 20.2402 23.4129 20.2402 23.1497C20.2402 22.8865 20.447 22.6797 20.7103 22.6797H23.8313C24.0945 22.6797 24.3013 22.8865 24.3013 23.1497C24.3013 23.4129 24.0851 23.6198 23.8313 23.6198Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 8.00452H26.6243C26.3611 8.00452 26.1543 7.79771 26.1543 7.53449C26.1543 7.27127 26.3611 7.06445 26.6243 7.06445H34.7841C35.0474 7.06445 35.2542 7.27127 35.2542 7.53449C35.2542 7.79771 35.0474 8.00452 34.7841 8.00452Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 10.8619H26.6243C26.3611 10.8619 26.1543 10.6551 26.1543 10.3919C26.1543 10.1287 26.3611 9.92188 26.6243 9.92188H34.7841C35.0474 9.92188 35.2542 10.1287 35.2542 10.3919C35.2542 10.6551 35.0474 10.8619 34.7841 10.8619Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 13.7194H26.6243C26.3611 13.7194 26.1543 13.5126 26.1543 13.2493C26.1543 12.9861 26.3611 12.7793 26.6243 12.7793H34.7841C35.0474 12.7793 35.2542 12.9861 35.2542 13.2493C35.2542 13.5126 35.0474 13.7194 34.7841 13.7194Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 16.5787H26.6243C26.3611 16.5787 26.1543 16.3719 26.1543 16.1087C26.1543 15.8455 26.3611 15.6387 26.6243 15.6387H34.7841C35.0474 15.6387 35.2542 15.8455 35.2542 16.1087C35.2542 16.3719 35.0474 16.5787 34.7841 16.5787Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 19.4362H26.6243C26.3611 19.4362 26.1543 19.2293 26.1543 18.9661C26.1543 18.7029 26.3611 18.4961 26.6243 18.4961H34.7841C35.0474 18.4961 35.2542 18.7029 35.2542 18.9661C35.2542 19.2293 35.0474 19.4362 34.7841 19.4362Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 22.2936H26.6243C26.3611 22.2936 26.1543 22.0868 26.1543 21.8236C26.1543 21.5603 26.3611 21.3535 26.6243 21.3535H34.7841C35.0474 21.3535 35.2542 21.5603 35.2542 21.8236C35.2542 22.0868 35.0474 22.2936 34.7841 22.2936Z"
                                 fill="#D16900" />
                              <path
                                 d="M34.7841 25.151H26.6243C26.3611 25.151 26.1543 24.9442 26.1543 24.681C26.1543 24.4178 26.3611 24.2109 26.6243 24.2109H34.7841C35.0474 24.2109 35.2542 24.4178 35.2542 24.681C35.2542 24.9442 35.0474 25.151 34.7841 25.151Z"
                                 fill="#D16900" />
                           </svg>
                          <?php elseif($i===9):?>

                           <svg width="40" height="40" viewBox="0 0 40 40" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path
                                 d="M36.0413 33.125H31.25C30.9864 32.2229 30.4375 31.4306 29.6856 30.8669C28.9336 30.3032 28.0192 29.9985 27.0794 29.9985C26.1396 29.9985 25.2252 30.3032 24.4732 30.8669C23.7212 31.4306 23.1723 32.2229 22.9087 33.125H2.5C2.16848 33.125 1.85054 33.2567 1.61612 33.4911C1.3817 33.7255 1.25 34.0434 1.25 34.375C1.25 34.7065 1.3817 35.0244 1.61612 35.2589C1.85054 35.4933 2.16848 35.625 2.5 35.625H22.9125C23.1771 36.5255 23.7263 37.3162 24.4777 37.8786C25.2292 38.441 26.1426 38.745 27.0813 38.745C28.0199 38.745 28.9333 38.441 29.6848 37.8786C30.4362 37.3162 30.9854 36.5255 31.25 35.625H36.0375C36.369 35.625 36.687 35.4933 36.9214 35.2589C37.1558 35.0244 37.2875 34.7065 37.2875 34.375C37.2875 34.0434 37.1558 33.7255 36.9214 33.4911C36.687 33.2567 36.369 33.125 36.0375 33.125H36.0413ZM27.0837 36.25C26.7129 36.25 26.3504 36.14 26.0421 35.934C25.7337 35.7279 25.4934 35.4351 25.3515 35.0925C25.2096 34.7499 25.1724 34.3729 25.2448 34.0092C25.3171 33.6455 25.4957 33.3114 25.7579 33.0491C26.0201 32.7869 26.3542 32.6083 26.718 32.536C27.0817 32.4636 27.4587 32.5008 27.8013 32.6427C28.1439 32.7846 28.4367 33.0249 28.6428 33.3333C28.8488 33.6416 28.9587 34.0041 28.9587 34.375C28.9587 34.8722 28.7612 35.3492 28.4096 35.7008C28.0579 36.0524 27.581 36.25 27.0837 36.25Z"
                                 fill="#00A9ED" />
                              <path
                                 d="M34.825 1.25H5.175C4.13433 1.25099 3.13657 1.66484 2.4007 2.4007C1.66484 3.13657 1.25099 4.13433 1.25 5.175V24.825C1.25099 25.8657 1.66484 26.8634 2.4007 27.5993C3.13657 28.3352 4.13433 28.749 5.175 28.75H34.825C35.8657 28.749 36.8634 28.3352 37.5993 27.5993C38.3352 26.8634 38.749 25.8657 38.75 24.825V5.175C38.749 4.13433 38.3352 3.13657 37.5993 2.4007C36.8634 1.66484 35.8657 1.25099 34.825 1.25ZM36.25 24.825C36.2497 25.2028 36.0994 25.5651 35.8323 25.8323C35.5651 26.0994 35.2028 26.2497 34.825 26.25H5.175C4.79717 26.2497 4.43491 26.0994 4.16774 25.8323C3.90057 25.5651 3.75033 25.2028 3.75 24.825V5.175C3.75033 4.79717 3.90057 4.43491 4.16774 4.16774C4.43491 3.90057 4.79717 3.75033 5.175 3.75H34.825C35.2028 3.75033 35.5651 3.90057 35.8323 4.16774C36.0994 4.43491 36.2497 4.79717 36.25 5.175V24.825Z"
                                 fill="#00A9ED" />
                              <path
                                 d="M26.9125 13.94L16.9125 7.69C16.7233 7.57174 16.5059 7.50629 16.2828 7.50043C16.0598 7.49457 15.8392 7.54853 15.644 7.6567C15.4489 7.76486 15.2862 7.9233 15.173 8.11555C15.0597 8.30781 15 8.52687 15 8.75V21.25C15 21.4731 15.0597 21.6922 15.173 21.8845C15.2862 22.0767 15.4489 22.2351 15.644 22.3433C15.8392 22.4515 16.0598 22.5054 16.2828 22.4996C16.5059 22.4937 16.7233 22.4283 16.9125 22.31L26.9125 16.06C27.0934 15.9479 27.2427 15.7915 27.3462 15.6055C27.4497 15.4196 27.504 15.2103 27.504 14.9975C27.504 14.7847 27.4497 14.5754 27.3462 14.3895C27.2427 14.2035 27.0934 14.0471 26.9125 13.935V13.94ZM17.5 19V11L23.8913 15L17.5 19Z"
                                 fill="#00A9ED" />
                           </svg>


                        <?php endif;?>
                        <?php endif; ?>


                        </span>
                     </div>
                     <h4 class="ed-category-title"><?php echo esc_html($single_item->name);?></h4>
                  </div>
               </div>

            <?php endforeach;?>

            </div>
         </div>
      </div>
      <!-- category-area-end -->


        <?php endif; ?>

        <?php 
    }
}

$widgets_manager->register( new TP_Services() );