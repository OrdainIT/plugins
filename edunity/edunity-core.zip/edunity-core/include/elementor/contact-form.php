<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Contact_Form extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'contactform';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Form', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}


    public function get_od_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $tp_cfa         = array();
        $tp_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $tp_forms       = get_posts( $tp_cf_args );
        $tp_cfa         = ['0' => esc_html__( 'Select Form', 'odcore' ) ];
        if( $tp_forms ){
            foreach ( $tp_forms as $tp_form ){
                $tp_cfa[$tp_form->ID] = $tp_form->post_title;
            }
        }else{
            $tp_cfa[ esc_html__( 'No contact form found', 'odcore' ) ] = 0;
        }
        return $tp_cfa;
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            'od_contact_form_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );

		$this->add_control(
			'od_contact_form_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/contact/shape-1-1.png',
				],
			]
		);
		$this->add_control(
			'od_contact_form_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/contact/shape-1-2.png',
				],
			]
		);
		$this->add_control(
			'od_contact_form_shap_img_3',
			[
				'label' => esc_html__( 'Shap 3', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/category/title.svg',
				],
			]
		);
		$this->add_control(
			'od_contact_form_shap_img_4',
			[
				'label' => esc_html__( 'Shap 4', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/video/svg.svg',
				],
			]
		);
		$this->add_control(
			'od_contact_form_shap_img_5',
			[
				'label' => esc_html__( 'Shap 5', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/contact/bg-5.jpg',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'tv_title_section',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );


        $this->add_control(
			'tv_sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'CONTACT WITH US', 'odcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
			]
		);
        $this->add_control(
			'tv_title',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Register Now Get Premium Online Admison', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);
        $this->add_control(
			'tv_description',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo', 'odcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'tv_contact_count',
            [
                'label' => esc_html__('Countdown', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );

        $this->add_control(
			'show_countdown',
			[
				'label' => esc_html__( 'Show Countdown', 'odcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'odcore' ),
				'label_off' => esc_html__( 'Hide', 'odcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


        $this->add_control(
			'tv_countdown',
			[
				'label' => esc_html__( 'Countdown', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sep 30 2024 20:20:22', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);


        $this->end_controls_section();

         $this->start_controls_section(
            'tv_contact_title_section2',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );


        $this->add_control(
			'tv_contact_title2',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Get in Touch', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_contact_description2',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Suspendisse ultrice gravida dictum fusce placerat ultricies integer', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);



      $this->end_controls_section();

      $this->start_controls_section(
            'tv_contact_info_area',
            [
                'label' => esc_html__('Contact Info', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );



      $this->add_control(
			'tv_contact_info_address',
			[
				'label' => esc_html__( 'Address', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => tp_kses( '<span>Our Address</span><a target="_blank" href="https://www.google.com/maps/@24.0161372,45.4773,7.67z?entry=ttup">1564 Goosetown Drive <br>Matthews, NC 28105</a> ', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_contact_info_location',
			[
				'label' => esc_html__( 'Time/Location', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => tp_kses( '<span>Hours of Operation</span><a href="#">Mon - Fri: 9.00am to 5.00pm</a><span>[2nd sat Holiday]</span> ', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);


      $this->add_control(
			'tv_contact_info_email',
			[
				'label' => esc_html__( 'Phone/Email', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => tp_kses( '<span>contact</span><a href="tel:+99358954565">+99- 35895-4565</a><a href="mailto:supportyou@info.com">supportyou@info.com</a> ', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);



      $this->end_controls_section();





        $this->start_controls_section(
            'odcore_contact',
            [
                'label' => esc_html__('Contact Form', 'odcore'),
            ]
        );
        $this->add_control(
			'tv_form__sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'GET IN TOUCH', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
			]
		);
        $this->add_control(
			'tv_form_title',
			[
				'label' => esc_html__( 'Sub Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sign Up For Free Resources', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
			]
		);



        $this->add_control(
            'odcore_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'odcore' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_od_contact_form(),
            ]
        );

      $this->end_controls_section();

      $this->start_controls_section(
            'tv_contact_extra_info',
            [
                'label' => esc_html__('Extra Info', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );


      $this->add_control(
			'tv_customer_care',
			[
				'label' => esc_html__( 'Customer Care', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Customer Care', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_customer_care_url',
			[
				'label' => esc_html__( 'Customer Care URL', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_facebook_url',
			[
				'label' => esc_html__( 'Facebook URL', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_instagram_url',
			[
				'label' => esc_html__( 'Instagram URL', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_pinterest_url',
			[
				'label' => esc_html__( 'Pinterest URL', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);

      $this->add_control(
			'tv_twitter_url',
			[
				'label' => esc_html__( 'Twitter URL', 'odcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#', 'odcore' ),
				'placeholder' => esc_html__( 'Type Text here', 'odcore' ),
			]
		);



      $this->end_controls_section();

	  $this->start_controls_section(
				'od_contact_form_title_content2',
				[
					'label' => __( 'Contact Form Style ', 'odcore' ),
					'condition' => [
						'od_design_style' => ['layout-2'],
					],
					'tab' => Controls_Manager::TAB_STYLE,
				]
		);


		$this->add_control(
			'od_contact_form_title_content2_shap_img1',
			[
				'label' => esc_html__( 'Shap', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/contact/shape-2-1.png',
				],
			]
		);

		
		$this->add_control(
			'od_contact_form_title_content2_heading',
			[
				'label' => esc_html__( 'Title & Content', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'od_contact_form_title_content2_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content2_title_typography',
				'selector' => '{{WRAPPER}} .it-contact__title',
			]
		);
		$this->add_control(
			'od_contact_form_title_content2_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__section-box p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content2_title_description',
				'selector' => '{{WRAPPER}} it-contact__section-box p ',
			]
		);

		$this->add_control(
			'od_contact_form_title_contactinfo_heading',
			[
				'label' => esc_html__( 'Contact Info', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'od_contact_form_title_contactinfo_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__text > a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_contact_form_title_contactinfo_title_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__text > a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_contactinfo_title_typography',
				'selector' => '{{WRAPPER}} .it-contact__text > a',
			]
		);

		$this->add_control(
			'od_contact_form_title_contactinfo_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__text span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_contactinfo_subtitle_typography',
				'selector' => '{{WRAPPER}} .it-contact__text span',
			]
		);

		$this->add_control(
			'od_contact_form_title_contactinfo_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__icon span' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_contact_form_title_contactinfo_icon_color',
			[
				'label' => esc_html__( 'Icon  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__icon span' => 'color: {{VALUE}}',
				],
			]
		);


		
		$this->add_control(
			'od_contact_form_title_extrainfo_heading',
			[
				'label' => esc_html__( 'Extra Info', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'od_contact_form_title_extrainfo_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__scrool a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_extrainfo_title_typography',
				'selector' => '{{WRAPPER}} .it-contact__scrool a',
			]
		);

		$this->add_control(
			'od_contact_form_title_socialicon_heading',
			[
				'label' => esc_html__( 'Social Icon', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

	  $this->start_controls_tabs(
            'od_contact_form_title_socialicon_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_contact_form_title_socialicon_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_contact_form_title_socialicon_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__right-box .it-footer-social a' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_contact_form_title_socialicon_normal_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__right-box .it-footer-social a' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_contact_form_title_socialicon_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

		 
		$this->add_control(
			'od_contact_form_title_socialicon_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__right-box .it-footer-social a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_contact_form_title_socialicon_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact__right-box .it-footer-social a:hover' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

	
		$this->add_control(
			'od_contact_form_title_contact_form_button_heading',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		  $this->start_controls_tabs(
            'od_contact_form_title_contact_form_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_contact_form_title_contact_form_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_contact_form_title_contact_form_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-4' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_contact_form_title_contact_form_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-4' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_contact_form_title_contact_form_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

		 
		$this->add_control(
			'od_contact_form_title_contact_form_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-4:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_contact_form_title_contact_form_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-4:hover' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();



		$this->end_controls_section();


		$this->start_controls_section(
				'od_contact_form_title_content',
				[
					'label' => __( 'Title & Content', 'odcore' ),
					'condition' => [
						'od_design_style' => ['layout-1'],
					],
					'tab' => Controls_Manager::TAB_STYLE,
				]
		);

		$this->add_control(
			'od_contact_form_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-3',
			]
		);
		$this->add_control(
			'od_contact_form_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-left .it-section-subtitle-5' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content_subtitle_typography',
				'selector' => '{{WRAPPER}} .it-contact-left .it-section-subtitle-5',
			]
		);
		$this->add_control(
			'od_contact_form_title_content_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .it-contact-text p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content_description_typography',
				'selector' => '{{WRAPPER}} .it-contact-text p',
			]
		);

		
		$this->add_control(
			'od_contact_form_title_content_counter_heading',
			[
				'label' => esc_html__( 'Counter', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'od_contact_form_title_content_counter_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-style-4 .it-contact-timer h6' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'od_contact_form_title_content_counter_number_color',
			[
				'label' => esc_html__( 'Counter Number Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-timer h6' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content_counter_bg_typography',
				'selector' => '{{WRAPPER}} .it-contact-timer h6',
			]
		);



		$this->add_control(
			'od_contact_form_title_content_counter_bottom_bg_color',
			[
				'label' => esc_html__( 'Bottm BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-style-4 .it-contact-timer i' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_contact_form_title_content_counter_bottom_bg_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-style-4 .it-contact-timer i' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form_title_content_counter_bottom_bg_text_typography',
				'selector' => '{{WRAPPER}} .it-contact-style-4 .it-contact-timer i',
			]
		);



	

		$this->end_controls_section();

		$this->start_controls_section(
				'od_contact_form__content',
				[
					'label' => __( 'Contact Form Content', 'odcore' ),
					'condition' => [
						'od_design_style' => ['layout-1'],
					],

					'tab' => Controls_Manager::TAB_STYLE,
				]
		);

		$this->add_control(
			'od_contact_form__content_title',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-contact-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form__content_title_typography',
				'selector' => '{{WRAPPER}} .it-contact-title',
			]
		);

		$this->add_control(
			'od_contact_form__content_description',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-5.sky' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form__content_description_typography',
				'selector' => '{{WRAPPER}} .it-section-subtitle-5.sky',
			]
		);

		$this->add_control(
			'od_contact_form__content_button_heading',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		  $this->start_controls_tabs(
            'od_contact_form__content_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_contact_form__content_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_contact_form__content_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_contact_form__content_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_contact_form__content_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

		 
		$this->add_control(
			'od_contact_form__content_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_contact_form__content_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square:hover' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

		 
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_contact_form__content_button_typography',
				'selector' => '{{WRAPPER}} .ed-btn-square',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$tv_sub_title = $settings['tv_sub_title'];
		$tv_title = $settings['tv_title'];
		$tv_description = $settings['tv_description'];
		$show_countdown = $settings['show_countdown'];
		$tv_countdown = $settings['tv_countdown'];
		$tv_form__sub_title = $settings['tv_form__sub_title'];
		$tv_form_title = $settings['tv_form_title'];

		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ):

			$tv_contact_title2 = $settings['tv_contact_title2'];
			$tv_contact_description2 = $settings['tv_contact_description2'];
			$tv_contact_info_address = $settings['tv_contact_info_address'];
			$tv_contact_info_location = $settings['tv_contact_info_location'];
			$tv_contact_info_email = $settings['tv_contact_info_email'];



			$tv_customer_care = $settings['tv_customer_care'];
			$tv_customer_care_url = $settings['tv_customer_care_url'];
			$tv_facebook_url = $settings['tv_facebook_url'];
			$tv_instagram_url = $settings['tv_instagram_url'];
			$tv_pinterest_url = $settings['tv_pinterest_url'];
			$tv_twitter_url = $settings['tv_twitter_url'];

			$od_contact_form_title_content2_shap_img1 = $settings['od_contact_form_title_content2_shap_img1'];


		




		?>

        <!-- contact-area-start -->
      <div class="it-contact__area pt-120 pb-120">
         <div class="container">
            <div class="it-contact__wrap fix z-index-3 p-relative">
               <div class="it-contact__shape-1 d-none d-xl-block">
                  <img src="<?php echo esc_url($od_contact_form_title_content2_shap_img1['url'], 'odcore');?>" alt="">
               </div>
               <div class="row align-items-end">
                  <div class="col-xl-7">
                     <div class="it-contact__right-box">
                        <div class="it-contact__section-box pb-20">
                           <h4 class="it-contact__title pb-15"><?php echo esc_html($tv_contact_title2, 'odcore');?></h4>
                           <p><?php echo tp_kses($tv_contact_description2, 'odcore');?> </p>
                        </div>
                        <div class="it-contact__content mb-55">
                           <ul>
                              <li>
                                 <div class="it-contact__list d-flex align-items-start">
                                    <div class="it-contact__icon">
                                       <span><i class="fa-solid fa-location-dot"></i></span>
                                    </div>
                                    <div class="it-contact__text">
                                       <?php echo tp_kses($tv_contact_info_address, 'odcore');?>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="it-contact__list d-flex align-items-start">
                                    <div class="it-contact__icon">
                                       <span><i class="fa-solid fa-clock"></i></span>
                                    </div>
                                    <div class="it-contact__text">
                                        <?php echo tp_kses($tv_contact_info_location, 'odcore');?>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="it-contact__list d-flex align-items-start">
                                    <div class="it-contact__icon">
                                       <span><i class="fa-solid fa-phone phone"></i></span>
                                    </div>
                                    <div class="it-contact__text">
                                        <?php echo tp_kses($tv_contact_info_email, 'odcore');?>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                        <div class="it-contact__bottom-box d-flex align-items-center justify-content-between">
                        	<?php if(!empty($tv_customer_care)):?>
                           <div class="it-contact__scrool smooth">
                              <a href="<?php echo esc_html($tv_customer_care_url, 'odcore');?>"><i class="fa-solid fa-arrow-down"></i><?php echo esc_html($tv_customer_care, 'odcore');?></a>
                           </div>
                        <?php endif;?>
                           <div class="it-footer-social">

                           <?php if(!empty($tv_facebook_url)):?>
                              <a href="<?php echo esc_attr($tv_facebook_url, 'odcore');?>"><i class="fa-brands fa-facebook-f"></i></a>
                           <?php endif;?>

                           <?php if(!empty($tv_instagram_url)):?>
                              <a href="<?php echo esc_attr($tv_instagram_url, 'odcore');?>"><i class="fa-brands fa-instagram"></i></a>
                           <?php endif;?>

                           <?php if(!empty($tv_pinterest_url)):?>
                              <a href="<?php echo esc_attr($tv_pinterest_url, 'odcore');?>"><i class="fa-brands fa-pinterest-p"></i></a>
                           <?php endif;?>

                           <?php if(!empty($tv_twitter_url)):?>
                              <a href="<?php echo esc_attr($tv_twitter_url, 'odcore');?>"><i class="fa-brands fa-twitter"></i></a>
                           <?php endif;?>

                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-5">
                     <div class="it-contact__form-box">
                       <?php echo do_shortcode( '[contact-form-7  id="'.$settings['odcore_select_contact_form'].'"]' ); ?> 
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- contact-area-end -->

		<?php else :
			$od_contact_form_shap_img_1 = $settings['od_contact_form_shap_img_1'];
			$od_contact_form_shap_img_2 = $settings['od_contact_form_shap_img_2'];
			$od_contact_form_shap_img_3 = $settings['od_contact_form_shap_img_3'];
			$od_contact_form_shap_img_4 = $settings['od_contact_form_shap_img_4'];
			$od_contact_form_shap_img_5 = $settings['od_contact_form_shap_img_5']; 
			?>

			 <!-- contact-area-start -->
      <div class="it-contact-area it-contact-style-4 z-index p-relative pt-120 pb-100">
         <div class="it-contact-shape-1 d-none d-lg-block">
            <img src="<?php echo esc_url($od_contact_form_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-contact-shape-2 d-none d-lg-block">
            <img src="<?php echo esc_url($od_contact_form_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-contact-shape-3 d-none d-xxl-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/contact/shape-1-3.png" alt="">
         </div>
         <div class="it-contact-shape-4 d-none d-lg-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/contact/shape-1-4.png" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-7 col-lg-7">
                  <div class="it-contact-left">
                     <div class="it-contact-title-box pb-20">
                        <span class="it-section-subtitle-5">
                           <img src="<?php echo esc_url($od_contact_form_shap_img_3['url'], 'odcore');?>" alt="">
                           <?php echo esc_html($tv_sub_title, 'odcore');?>
                        </span>
                        <h2 class="it-section-title-3"><?php echo tp_kses($tv_title, 'odcore');?></h2>
                     </div>
                     <div class="it-contact-text pb-15">
                        <p><?php echo tp_kses($tv_description, 'odcore');?></p>
                     </div>
                     <?php if(!empty($show_countdown)):?>
                     <div class="it-contact-timer-box mb-40" data-countdown data-date="<?php echo esc_attr($tv_countdown, 'odcore');?>">
                        <div class="row">
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                              <div class="it-contact-timer text-center">
                                 <h6 data-days>00</h6>
                                 <i><?php echo esc_html__('DAYS', 'odcore');?></i>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                              <div class="it-contact-timer text-center">
                                 <h6 data-hours>00</h6>
                                 <i><?php echo esc_html__('HOURS', 'odcore');?></i>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                              <div class="it-contact-timer text-center">
                                 <h6 data-minutes>00</h6>
                                 <i><?php echo esc_html__('MINUTES', 'odcore');?></i>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                              <div class="it-contact-timer text-center">
                                 <h6 data-seconds>00</h6>
                                 <i><?php echo esc_html__('SECONDS', 'odcore');?></i>
                              </div>
                           </div>
                        </div>
                     </div>
                 <?php endif;?>
                  </div>
               </div>
               <div class="col-xl-5 col-lg-5 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="it-contact-wrap" style="background-image:url(<?php echo esc_url($od_contact_form_shap_img_5['url'], 'odcore');?>)">
                     <span class="it-section-subtitle-5 sky">
                        <img src="<?php echo esc_url($od_contact_form_shap_img_4['url'], 'odcore');?>" alt="">
                        <?php echo esc_html($tv_form__sub_title, 'odcore');?>
                     </span>
                     <h4 class="it-contact-title pb-15"><?php echo esc_html($tv_form_title, 'odcore');?></h4>
                        <div class="row">

                        	<?php echo do_shortcode( '[contact-form-7  id="'.$settings['odcore_select_contact_form'].'"]' ); ?> 
                          
                        </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- contact-area-end --



        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new TP_Contact_Form() );