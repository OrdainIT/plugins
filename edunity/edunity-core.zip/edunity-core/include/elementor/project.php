<?php
namespace tvcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Project extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'project';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Project', 'tvcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tvcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tvcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tvcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tvcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tvcore'),
                    'layout-2' => esc_html__('Layout 2', 'tvcore'),
                    'layout-3' => esc_html__('Layout 3', 'tvcore'),
                    'layout-4' => esc_html__('Layout 4', 'tvcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'tvcore'),
                'condition' =>[
                    'tp_design_style' => ['layout-1', 'layout-2'],
                ],
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'tvcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
         $this->add_control(
            'tp_section_shap_hide',
            [
                'label' => esc_html__( 'Shape', 'tvcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
         $this->add_control(
            'tp_section_watermark_hide',
            [
                'label' => esc_html__( 'Watermark', 'tvcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Sub Title', 'tvcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'tvcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Title Here', 'tvcore'),
                'placeholder' => esc_html__('Type Heading Text', 'tvcore'),
                'label_block' => true,
            ]
        );      

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TP section description here', 'tvcore'),
                'placeholder' => esc_html__('Type section description here', 'tvcore'),
            ]
        );

        $this->add_control(
            'tp_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'tvcore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'tvcore'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'tvcore'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'tvcore'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'tvcore'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'tvcore'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'tvcore'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'tp_align',
            [
                'label' => esc_html__('Alignment', 'tvcore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'text-left' => [
                        'title' => esc_html__('Left', 'tvcore'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__('Center', 'tvcore'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__('Right', 'tvcore'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => false,
            ]
        );
        $this->end_controls_section();

        // Project Slider Section
        $this->start_controls_section(
            'project_area_section',
            [
                'label' => esc_html__('Project List', 'tvcore'),
                'condition' =>[
                    'tp_design_style' => ['layout-1', 'layout-2'],
                ],
            ]
        );

        $this->add_control(
			'project_list_section',
			[
				'label' => esc_html__( 'Project list', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'project_title',
						'label' => esc_html__( 'Title', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Title' , 'textdomain' ),
						'label_block' => true,
					],
					[
						'name' => 'project__sub_title',
						'label' => esc_html__( 'Sub Title', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Sub Title' , 'textdomain' ),
						'label_block' => true,
					],
					[
						'name' => 'project__url',
						'label' => esc_html__( 'URL', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'textdomain' ),
						'label_block' => true,
					],
					[
						'name' => 'project__thumbnail',
						'label' => esc_html__( 'Thumbnail', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => \Elementor\Utils::get_placeholder_image_src(),
						],
						'label_block' => true,
					],
				],
				'default' => [
					[
						'project_title' => esc_html__( 'Title #1', 'textdomain' ),
					],
					[
						'project_title' => esc_html__( 'Title #2', 'textdomain' ),
					],
					[
						'project_title' => esc_html__( 'Title #3', 'textdomain' ),
					],
					[
						'project_title' => esc_html__( 'Title #4', 'textdomain' ),
					],
					[
						'project_title' => esc_html__( 'Title #5', 'textdomain' ),
					],
				],
				'title_field' => '{{{ project_title }}}',
			]
		);


         $this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'tvcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'tvcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'tvcore' ),
					'uppercase' => __( 'UPPERCASE', 'tvcore' ),
					'lowercase' => __( 'lowercase', 'tvcore' ),
					'capitalize' => __( 'Capitalize', 'tvcore' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<?php if ( $settings['tp_design_style']  == 'layout-2' ):
			$this->add_render_attribute('title_args', 'class', 'it-section-title');
		?>

			  <!-- service-3 area start -->
	      <div class="it-service-3-area service-style-3 p-relative pt-115 pb-120 fix">
	         <div class="container">
	         	<?php if(!empty($settings['tp_section_shap_hide'])):?>
	         	<div class="it-service-6-shape">
	               <img src="<?php echo get_template_directory_uri();?>/assets/img/service/service-6-shape-1.png" alt="">
	            </div>
	        <?php endif;?>
	            <div class="row justify-content-center text-center">
	               <div class="col-xl-5">
	               	<?php if(!empty($settings['tp_section_title_show'])):?>
	                  <div class="it-service-3-title-box mb-70">
	                  	<?php if(!empty($settings['tp_section_watermark_hide'])):?>
	                     <h3 class="it-section-title-big"><?php echo esc_html($settings['tp_sub_title']);?></h3>
	                 <?php endif;?>
	                     <span class="it-subtitle"><?php echo esc_html($settings['tp_sub_title']);?></span>

			                <?php
			                    if ( !empty($settings['tp_title' ]) ) :
			                        printf( '<%1$s %2$s>%3$s</%1$s>',
			                            tag_escape( $settings['tp_title_tag'] ),
			                            $this->get_render_attribute_string( 'title_args' ),
			                            tp_kses( $settings['tp_title' ] )
			                            );
			                    endif;
			                ?> 
	                  </div>
	              <?php endif;?>
	               </div>
	            </div>
	            <div class="it-service-3-wrapp p-relative">
	               <div class="swiper-container service-active-3">
	                  <div class="swiper-wrapper">
		                  <?php foreach($settings['project_list_section'] as $single_project_list2):?>
		                     <div class="swiper-slide">
		                        <div class="it-service-3-item p-relative fix">
		                           <div class="it-service-3-thumb">
		                              <img src="<?php echo esc_url($single_project_list2['project__thumbnail']['url']);?>" alt="thumbnail">
		                           </div>
		                           <div class="it-service-3-content">
		                              <span class="it-service-3-categories"><?php echo esc_html($single_project_list2['project__sub_title']);?></span>
		                              <h3 class="it-service-3-item-title">
		                                 <a href="<?php echo esc_url($single_project_list2['project__url']);?>"><?php echo esc_html($single_project_list2['project_title']);?></a>
		                              </h3>
		                           </div>
		                        </div>
		                     </div>
		                 <?php endforeach;?>
	                  </div>
	               </div>
	               <div class="it-service-3-arrow-box d-none d-md-flex d-flex justify-content-between">
	                  <button class="service-prev">
	                     Prev
	                  </button>
	                  <button class="service-next">
	                     Next
	                  </button>
	               </div>
	            </div>
	            <div class="row text-center mt-25">
	               <div class="it-service-3-dots"></div>
	            </div>
	         </div>
	      </div>
	      <!-- service-3 area end -->

		<?php elseif($settings['tp_design_style']  == 'layout-3'):?>

		<?php else:
			$this->add_render_attribute('title_args', 'class', 'it-section-title text-white');
		?>

			<!-- project area start  -->
	      <div class="it-project-area fix pt-115 pb-120 black-bg" data-background="<?php echo get_template_directory_uri();?>/assets/img/project/project-bg.png">
	         <div class="container">
	            <div class="row align-items-center">
	               <div class="col-xl-6 col-lg-8">
	               	<?php if(!empty($settings['tp_section_title_show'])):?>
	                  <div class="it-project-title-box">
	                     <span class="it-subtitle subtitle-yellow"><?php echo esc_html($settings['tp_sub_title']);?></span>
		                <?php
		                    if ( !empty($settings['tp_title' ]) ) :
		                        printf( '<%1$s %2$s>%3$s</%1$s>',
		                            tag_escape( $settings['tp_title_tag'] ),
		                            $this->get_render_attribute_string( 'title_args' ),
		                            tp_kses( $settings['tp_title' ] )
		                            );
		                    endif;
		                ?>
	                  </div>
	              <?php endif;?>
	               </div>
	               <div class="col-xl-6 col-lg-4">
	                  <div class="it-project-arrow-box text-end">
	                     <button class="project-prev">
	                        <i class="fa-solid fa-arrow-left"></i>
	                     </button>
	                     <button class="project-next">
	                        <i class="fa-solid fa-arrow-right"></i>
	                     </button>
	                  </div>
	               </div>
	            </div>
	            <div class="it-project-box mt-60">
	               <div class="swiper-container it-project-active">
	                  <div class="swiper-wrapper">
		                  <?php foreach($settings['project_list_section'] as $single_project_list):?>
		                     <div class="swiper-slide">
		                        <div class="it-project-item p-relative">
		                           <div class="it-project-thumb">
		                              <img src="<?php echo esc_url($single_project_list['project__thumbnail']['url']);?>" alt="">
		                           </div>
		                           <div class="it-project-dsc-box d-flex align-items-center justify-content-between">
		                              <div class="it-project-dsc-content">
		                                 <h3 class="it-project-dsc-name"><a href="<?php echo esc_url($single_project_list['project__url']);?>"><?php echo esc_html($single_project_list['project_title']);?></a></h3>
		                                 <span class="it-project-dsc-subname"><?php echo esc_html($single_project_list['project__sub_title']);?></span>
		                              </div>
		                              <div class="it-project-dsc-btn">
		                                 <a href="<?php echo esc_url($single_project_list['project__url']);?>"><i class="flaticon-right-arrow"></i></a>
		                              </div>
		                           </div>
		                        </div>
		                     </div>
		                 <?php endforeach;?>
	                  </div>
	               </div>
	            </div>
	         </div>
	      </div>
	      <!-- project area end  -->

		<?php endif;?>

		<script>
			"use strict";
			jQuery(document).ready(function($) {
				// 14. Swiper Js
				const projectSwiper = new Swiper('.it-project-active', {
					// Optional parameters
					speed:1000,
					loop: true,
					slidesPerView: 5,
			        spaceBetween: 36,
					autoplay: true,
					breakpoints: {
						'1400': {
							slidesPerView: 5,
						},
						'1200': {
							slidesPerView: 4,
						},
						'992': {
							slidesPerView: 3,
						},
						'768': {
							slidesPerView: 2,
						},
						'576': {
							slidesPerView: 1,
						},
						'0': {
							slidesPerView: 1,
						},
					},
					navigation: {
						prevEl: '.project-prev',
						nextEl: '.project-next',
					},
				  });
			const service3swiper = new Swiper('.service-active-3', {
				// Optional parameters
				speed:1000,
				loop: true,
				slidesPerView: 3,
		        spaceBetween: 30,
				autoplay: true,
				roundLengths: true,
				breakpoints: {
					'1400': {
						slidesPerView: 3,
					},
					'1200': {
						slidesPerView: 3,
					},
					'992': {
						slidesPerView: 3,
					},
					'768': {
						slidesPerView: 2,
					},
					'576': {
						slidesPerView: 1,
					},
					'0': {
						slidesPerView: 1,
					},
				},
				navigation: {
					prevEl: '.service-prev',
					nextEl: '.service-next',
				},
				pagination: {
					el: ".it-service-3-dots",
					clickable:true,
				  },
			  });

			});
		</script>


		<?php



		
	}

	
}

$widgets_manager->register( new Project() );