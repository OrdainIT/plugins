<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class OD_Events extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-events';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Events Post', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        
         // od_event_section Shap
        $this->start_controls_section(
            'od_events_post_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
         );

         $this->add_control(
			'od_events_post_section_shap_img_1',
            [
               'label' => esc_html__( 'Shap 1', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/ed-shape-3-2.png',
               ],
            ]
         );

         $this->add_control(
			'od_events_post_section_shap_img_2',
            [
               'label' => esc_html__( 'Shap 2', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/ed-shape-3-1.png',
               ],
            ]
         );
         $this->add_control(
			'od_events_post_section_shap_img_3',
            [
               'label' => esc_html__( 'Shap 3', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '',
               ],
            ]
         );

         $this->end_controls_section();

         // Title Content
        $this->start_controls_section(
            'od_title_content_section',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],

            ]
        );

            $this->add_control(
            'show_hide_content_section',
            [
                'label' => esc_html__( 'Show/Hide', 'odcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'od_sub_title',
            [
                'label' => esc_html__( 'Sub Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Our Events', 'odcore' ),
                'placeholder' => esc_html__( 'Type  here', 'odcore' ),
            ]
        );

        $this->add_control(
            'od_title',
            [
                'label' => esc_html__( 'Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'yearly events and program', 'odcore' ),
                'placeholder' => esc_html__( 'Type here', 'odcore' ),
            ]
        );


         $this->end_controls_section();

        // Blog Query
		$this->start_controls_section(
            'tp_post_query',
            [
                'label' => esc_html__('Events Query', 'odcore'),
            ]
        );

        $post_type = 'event';
        $taxonomy = 'event-cat';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'odcore'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'odcore'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_category',
            [
                'label' => esc_html__('Exclude Categories', 'odcore'),
                'description' => esc_html__('Select a category to exclude', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post__not_in',
            [
                'label' => esc_html__('Exclude Item', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'options' => tp_get_all_types_post($post_type),
                'multiple' => true,
                'label_block' => true
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => esc_html__('Offset', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '0',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
			        'ID' => 'Post ID',
			        'author' => 'Post Author',
			        'title' => 'Title',
			        'date' => 'Date',
			        'modified' => 'Last Modified Date',
			        'parent' => 'Parent Id',
			        'rand' => 'Random',
			        'comment_count' => 'Comment Count',
			        'menu_order' => 'Menu Order',
			    ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' 	=> esc_html__( 'Ascending', 'odcore' ),
                    'desc' 	=> esc_html__( 'Descending', 'odcore' )
                ],
                'default' => 'desc',

            ]
        );
        $this->add_control(
            'ignore_sticky_posts',
            [
                'label' => esc_html__( 'Ignore Sticky Posts', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'odcore' ),
                'label_off' => esc_html__( 'No', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_post_content',
            [
                'label' => __('Content', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'odcore'),
                'label_off' => __('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'tp_post_content_limit',
            [
                'label' => __('Content Limit', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '14',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'tp_post_content' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();


        // layout Panel
        $this->start_controls_section(
            'tp_post_',
            [
                'label' => esc_html__('Event - Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 01', 'odcore'),
                    'layout-2' => esc_html__('Layout 02', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'tp_post__height',
            [
                'label' => esc_html__( 'Height', 'odcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tp-project-img img' => 'height: {{SIZE}}{{UNIT}};object-fit: cover;',
                ],
            ]
        );
        $this->add_control(
            'tp_post__dots',
            [
                'label' => esc_html__('Dots?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'odcore'),
                'label_off' => esc_html__('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_post__arrow',
            [
                'label' => esc_html__('Arrow Icons?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'odcore'),
                'label_off' => esc_html__('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_post__infinite',
            [
                'label' => esc_html__('Infinite?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_post__autoplay',
            [
                'label' => esc_html__('Autoplay?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );        
        $this->add_control(
            'tp_post__autoplay_speed',
            [
                'label' => esc_html__('Autoplay Speed', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => '2500',
                'title' => esc_html__('Enter autoplay speed', 'odcore'),
                'label_block' => true,
                'condition' => array(
                    'tp_post__autoplay' => 'yes',
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_post__filter',
            [
                'label' => esc_html__('Filter?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-3',
                ),
            ]
        );
        
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'tp-post-thumb',
            ]
        );
        $this->add_control(
            'od_post_pagination',
            [
                'label' => esc_html__( 'Pagination', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => array(
                    'od_design_style' => 'layout-1',
                ),
            ]
        );
        $this->end_controls_section();

        // style control
		$this->start_controls_section(
			'od_events_post_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

            $this->add_control(
			'od_events_post_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_post_title_content_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-3',
			]
		);
      $this->add_control(
			'od_events_post_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_post_title_content_subtitle_typography',
				'selectors' => [
               '{{WRAPPER}} .it-section-subtitle-4',
               '{{WRAPPER}} .it-section-subtitle-5',
            ]
			]
		);
  


	

		$this->end_controls_section();

        
      $this->start_controls_section(
			'od_events_post_area_events_lists',
			[
				'label' => __( 'Events List', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-1', 'layout-2'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-content' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-title' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_post_area_events_list_title_hover_color',
			[
				'label' => esc_html__( 'Title hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_post_area_events_list_title_typography',
				'selector' => '{{WRAPPER}} .it-event-2-title',
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-text p' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_post_area_events_list_description_typography',
				'selectors' => [
               '{{WRAPPER}} .it-event-2-title',
               '{{WRAPPER}} .it-event-2-text p',
            ],
			]
		);
      $this->add_control(
			'od_events_post_area_events_list_time_location_heading',
			[
				'label' => esc_html__( 'Time/Location', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_timelocatio_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-meta span' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_post_area_events_list_timelocatio_typography',
				'selectors' => [
               '{{WRAPPER}} .it-event-2-meta span',
            ],
			]
		);

      
      $this->add_control(
			'od_events_post_area_events_list_timelocation_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-meta span i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-meta span i' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_events_post_area_events_list_date_heading',
			[
				'label' => esc_html__( 'Date', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
            'od_events_post_area_events_list_date_tabs'
         );

         // Normal

      $this->start_controls_tab(
            'od_events_post_area_events_list_date_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
      $this->add_control(
			'od_events_post_area_events_list_date_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'background-color: {{VALUE}}',
				],
			]
		);

          
      $this->add_control(
			'od_events_post_area_events_list_date_normal_border_color',
			[
				'label' => esc_html__( 'border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'border-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_post_area_events_list_date_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'color: {{VALUE}}',
				],
			]
		);






      $this->end_controls_tab();

         // Hover

      $this->start_controls_tab(
            'od_events_post_area_events_list_date_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );


          $this->add_control(
			'od_events_post_area_events_list_date_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date' => 'background-color: {{VALUE}}',
				],
			]
		);

          
      $this->add_control(
			'od_events_post_area_events_list_date_hover_border_color',
			[
				'label' => esc_html__( 'border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date' => 'border-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_post_area_events_list_date_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date span' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();


     

      $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $od_events_post_section_shap_img_1 = $settings['od_events_post_section_shap_img_1'];
        $od_events_post_section_shap_img_2 = $settings['od_events_post_section_shap_img_2'];
        $od_events_post_section_shap_img_3 = $settings['od_events_post_section_shap_img_3'];

		if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } else if (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        // include_categories
        $category_list = '';
        if (!empty($settings['category'])) {
            $category_list = implode(", ", $settings['category']);
        }
        $category_list_value = explode(" ", $category_list);

        // exclude_categories
        $exclude_categories = '';
        if(!empty($settings['exclude_category'])){
            $exclude_categories = implode(", ", $settings['exclude_category']);
        }
        $exclude_category_list_value = explode(" ", $exclude_categories);

        $post__not_in = '';
        if (!empty($settings['post__not_in'])) {
            $post__not_in = $settings['post__not_in'];
            $args['post__not_in'] = $post__not_in;
        }
        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';
        $offset_value = (!empty($settings['offset'])) ? $settings['offset'] : '0';
        $ignore_sticky_posts = (! empty( $settings['ignore_sticky_posts'] ) && 'yes' == $settings['ignore_sticky_posts']) ? true : false ;


        // number
        $off = (!empty($offset_value)) ? $offset_value : 0;
        $offset = $off + (($paged - 1) * $posts_per_page);
        $p_ids = array();

        // build up the array
        if (!empty($settings['post__not_in'])) {
            foreach ($settings['post__not_in'] as $p_idsn) {
                $p_ids[] = $p_idsn;
            }
        }

        $args = array(
            'post_type' => 'event',
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'offset' => $offset,
            'paged' => $paged,
            'post__not_in' => $p_ids,
            'ignore_sticky_posts' => $ignore_sticky_posts
        );

        // exclude_categories
        if ( !empty($settings['exclude_category'])) {

            // Exclude the correct cats from tax_query
            $args['tax_query'] = array(
                array(
                    'taxonomy'	=> 'event-cat',
                    'field'	 	=> 'slug',
                    'terms'		=> $exclude_category_list_value,
                    'operator'	=> 'NOT IN'
                )
            );

            // Include the correct cats in tax_query
            if ( !empty($settings['category'])) {
                $args['tax_query']['relation'] = 'AND';
                $args['tax_query'][] = array(
                    'taxonomy'	=> 'event-cat',
                    'field'		=> 'slug',
                    'terms'		=> $category_list_value,
                    'operator'	=> 'IN'
                );
            }

        } else {
            // Include the cats from $cat_slugs in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query'][] = [
                    'taxonomy' => 'event-cat',
                    'field' => 'slug',
                    'terms' => $category_list_value,
                ];
            }
        }

        $filter_list = $settings['category'];

        // The Query
        $query = new \WP_Query($args);

        $show_hide_content_section = $settings['show_hide_content_section'];
        $od_sub_title = $settings['od_sub_title'];
        $od_title = $settings['od_title'];

      

        ?>

        <?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

            <div class="it-event-2-area it-event-style-3 p-relative pt-90 pb-90">
         <div class="container">
            <div class="row">

                

                <?php while ($query->have_posts()) : 
                $query->the_post();
                  $time = function_exists('get_field') ? get_field('time') : '';
                  $location = function_exists('get_field') ? get_field('location') : '';

                ?>

               <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
                  <div class="it-event-2-item-box">                  
                     <div class="it-event-2-item">
                        <div class="it-event-2-thumb fix">
                           <a href="<?php the_permalink();?>"><img  src="<?php the_post_thumbnail_url();?>" alt=""></a>
                           <div class="it-event-2-date">
                              <span><i><?php echo date('j');?></i> <br>
                                 <?php echo date('F');?></span>
                           </div>
                        </div> 
                        <div class="it-event-2-content">
                           <h4 class="it-event-2-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4> 
                           <div class="it-event-2-text">
                              <p class="mb-0 pb-10"><?php
                                echo wp_trim_words( get_the_content(), 10, '...' );
                                ?></p>
                           </div>
                           <div class="it-event-2-meta">
                             <?php if(!empty($time)):?>
                              <span>
                                 <i class="fa-light fa-clock"></i>
                                 <?php echo esc_html__('Time:', 'odcore');?> <?php echo esc_html($time, 'odcore');?>
                              </span>
                          <?php endif;?>
                              <?php if(!empty($location)):?>
                              <span>
                                 <a href="#">
                                    <i class="fa-light fa-location-dot"></i>
                                 </a>
                                 <?php echo esc_html__('Location:', 'odcore');?> <?php echo esc_html($location, 'location');?>
                              </span>
                          <?php endif;?>
                           </div>
                        </div>              
                     </div>
                  </div>
               </div> 
              <?php endwhile; wp_reset_query(); ?>

            </div>
         </div>
      </div>



        <?php else: 

        ?>

           <!-- event-area-start -->
      <div class="it-event-2-area it-event-style-4 p-relative z-index pt-115 fix pb-70 grey-bg">
         <div class="ed-event-shape-1">
            <img src="<?php echo esc_url($od_events_post_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-event-shape-2">
            <img src="<?php echo esc_url($od_events_post_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <?php if(!empty($show_hide_content_section)):?>
            <div class="it-event-2-title-wrap mb-60">
               <div class="row align-items-end">
                  <div class="col-12">
                     <div class="it-event-2-title-box text-center">
                        <span class="it-section-subtitle-5 purple-2">
                           <img src="<?php echo esc_url($od_events_post_section_shap_img_3['url'], 'odcore');?>" alt="">
                           <?php echo esc_html($od_sub_title, 'odcore');?>
                        </span>
                        <h2 class="it-section-title-3"><?php echo edunity_kses($od_title, 'odcore');?></h2>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">

                <?php while ($query->have_posts()) : 
                $query->the_post();
                  $time = function_exists('get_field') ? get_field('time') : '';
                  $location = function_exists('get_field') ? get_field('location') : '';

                ?>

               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="it-event-2-item-box">                  
                     <div class="it-event-2-item">
                        <div class="it-event-2-thumb fix">
                           <a href="event-details.html"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                           <div class="it-event-2-date">
                              <span><i><?php echo date('j');?></i> <br>
                                 <?php echo date('F');?></span>
                           </div>
                        </div> 
                        <div class="it-event-2-content">
                           <h4 class="it-event-2-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4> 
                           <div class="it-event-2-text">
                              <p class="mb-0 pb-10"><?php
                                echo wp_trim_words( get_the_content(), 10, '...' );
                                ?></p>
                           </div>
                           <div class="it-event-2-meta">
                             <?php if(!empty($time)):?>
                              <span>
                                 <i class="fa-light fa-clock"></i>
                                 <?php echo esc_html__('Time:', 'odcore');?> <?php echo esc_html($time, 'odcore');?>
                              </span>
                          <?php endif;?>
                              <?php if(!empty($location)):?>
                              <span>
                                 <a href="#">
                                    <i class="fa-light fa-location-dot"></i>
                                 </a>
                                 <?php echo esc_html__('Location:', 'odcore');?> <?php echo esc_html($location, 'location');?>
                              </span>
                          <?php endif;?>
                           </div>
                        </div>              
                     </div>
                  </div>
               </div>


              <?php endwhile; wp_reset_query(); ?>

            </div>
         </div>
      </div>
      <!-- event-area-end -->

      

    	<?php endif; ?>

       <?php
	}

}

$widgets_manager->register( new OD_Events() );