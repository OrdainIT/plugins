<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Process extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'process';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Why Choose', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );


        $this->end_controls_section();

        // section Shap
        $this->start_controls_section(
            'od_why_choose_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4'],
                ],
            ]
        );

        $this->add_control(
			'od_why_choose_section_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/choose/shape-1-4.png',
				],
			]
		);

        $this->add_control(
			'od_why_choose_section_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/choose/shape-1-3.png',
				],
			]
		);

        $this->add_control(
			'od_why_choose_section_shap_img_3',
			[
				'label' => esc_html__( 'Shap 3', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/choose/shape-1-1.png',
				],
			]
		);

        $this->add_control(
			'od_why_choose_section_shap_img_4',
			[
				'label' => esc_html__( 'Shap 4', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/choose/shape-1-2.png',
				],
			]
		);
        $this->add_control(
			'od_why_choose_section_shap_img_5',
			[
				'label' => esc_html__( 'Shap 5', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/value/value-shape-5.jpg',
				],
			]
		);
        $this->add_control(
			'od_why_choose_section_shap_img_6',
			[
				'label' => esc_html__( 'Shap 6', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>   get_template_directory_uri(). '/assets/img/value/value-shape-5.jpg',
				],
			]
		);



        $this->end_controls_section();


        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sub Title', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );  
        $this->add_control(
            'tp_title1',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('itle Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );       

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('section description here', 'odcore'),
                'placeholder' => esc_html__('Type section description here', 'odcore'),
            ]
        );


        $this->end_controls_section();

        // List Item 1
        $this->start_controls_section(
            'tp_why_choose_list',
            [
                'label' => esc_html__('List Items', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );


            $this->add_control(
            'tv_list_item',
            [
                'label' => esc_html__( 'List Item', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_list_title',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('World Class Trainers ', 'odcore'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_list_description',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__('Gravida dictum fusce placerat ultricies integer ', 'odcore'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_list_title' => esc_html__( 'World Class Trainers', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Easy Learning', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Flexible', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Affordable Price', 'odcore' ),
                    ],
                    
                ],
                'title_field' => '{{{ tv_list_title }}}',
            ]
        );

        $this->end_controls_section();

             // Progress Bar Items
        $this->start_controls_section(
            'tp_why_progress_section',
            [
                'label' => esc_html__('Progress Bar', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );

        $this->add_control(
            'tv_progress_bar_item',
            [
                'label' => esc_html__( 'Progress Item', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_progress_title',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Case study success', 'odcore'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_progress_value',
                        'label' => esc_html__( 'Value', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('90', 'odcore'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_progress_title' => esc_html__( 'Case study success', 'odcore' ),
                        'tv_progress_value' => esc_html__( '90', 'odcore' ),
                    ],
                    [
                        'tv_progress_title' => esc_html__( 'Happy student', 'odcore' ),
                        'tv_progress_value' => esc_html__( '80', 'odcore' ),
                    ],
                    [
                        'tv_progress_title' => esc_html__( 'Engaging', 'odcore' ),
                        'tv_progress_value' => esc_html__( '65', 'odcore' ),
                    ],
                    [
                        'tv_progress_title' => esc_html__( 'Student Community', 'odcore' ),
                        'tv_progress_value' => esc_html__( '58', 'odcore' ),
                    ],
                    
                ],
                'title_field' => '{{{ tv_progress_title }}}',
            ]
        );






        $this->end_controls_section();

             // list items 3 sections
        $this->start_controls_section(
            'tv_list_items_section',
            [
                'label' => esc_html__('List Items', 'odcore'),

                'condition' => [
                    'od_design_style' => [ 'layout-3'  ],
                ],
            ]
        );


         $this->add_control(
            'tv_list_items',
            [
                'label' => esc_html__( 'List Item', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_list_title',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Best Teaching', 'odcore'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_list_title' => esc_html__( 'Best Teaching', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Quality Educators', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Best Teaching', 'odcore' ),
                    ],
                    [
                        'tv_list_title' => esc_html__( 'Quality Educators', 'odcore' ),
                    ],
                    
                ],
                'title_field' => '{{{ tv_list_title }}}',
            ]
        );




        $this->end_controls_section();

             // list items 4 sections
        $this->start_controls_section(
            'tv_list_items_section_4',
            [
                'label' => esc_html__('List Items', 'odcore'),

                'condition' => [
                    'od_design_style' => [ 'layout-4'  ],
                ],
            ]
        );


         $this->add_control(
            'tv_list_items_4',
            [
                'label' => esc_html__( 'List Item', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_list_title_4',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Affordable Courses', 'odcore'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_list_description_4',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit eiusmod tempor incididunt ut labore.', 'odcore'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_list_icon_4',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('flaticon-skill', 'odcore'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'tv_list_title_4' => esc_html__( 'Affordable Course', 'odcore' ),
                        'tv_list_description_4' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit eiusmod tempor incididunt ut labore.', 'odcore' ),
                        'tv_list_icon_4' => esc_html__( 'flaticon-skill', 'odcore' ),
                    ],
                    [
                        'tv_list_title_4' => esc_html__( 'Efficient & Flexible', 'odcore' ),
                        'tv_list_description_4' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit eiusmod tempor incididunt ut labore.', 'odcore' ),
                        'tv_list_icon_4' => esc_html__( 'flaticon-funds', 'odcore' ),
                    ],
                    [
                        'tv_list_title_4' => esc_html__( 'Skilled Teachers', 'odcore' ),
                        'tv_list_description_4' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit eiusmod tempor incididunt ut labore.', 'odcore' ),
                        'tv_list_icon_4' => esc_html__( 'flaticon-flexibility', 'odcore' ),
                    ],
                    
                ],
                'title_field' => '{{{ tv_list_title_4 }}}',
            ]
        );




        $this->end_controls_section();




          // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'odcore'),

                'condition' => [
                    'od_design_style' => [ 'layout-3'  ],
                ],
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();


           // Service group
        $this->start_controls_section(
            'tp_why_thumbnail_section',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'tv_why_thumbnail',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/choose/choose-2-1.jpg',
                ],
            ]
        );

      
       
      
     
      

       
       

        $this->end_controls_section();

        // TAB_STYLE
		$this->start_controls_section(
			'od_why_choose_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_why_choose_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_why_choose_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_title2_color',
			[
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3 span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_title_shap_color',
			[
				'label' => esc_html__( 'Title Shap Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title span svg path' => 'stroke: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-title',
                    '{{WRAPPER}} .it-section-title-3',
                ],
			]
		);


        $this->add_control(
			'od_why_choose_subtitle_heading',
			[
				'label' => esc_html__( 'Sub Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_why_choose_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-2.white-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_why_choose_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5.orange' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-2.white-bg' => 'color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-subtitle',
                    '{{WRAPPER}} .it-section-subtitle-4',
                    '{{WRAPPER}} .it-section-subtitle-5.orange',
                    '{{WRAPPER}} .it-section-subtitle-2.white-bg',
                ],
			]
		);

        $this->add_control(
			'od_why_choose_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),    
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],

				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_why_choose_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),    
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-value-title-box p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-video-2-text p' => 'color: {{VALUE}}',
				],
			]
		);

             
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_description_typography',    
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
				'selectors' => [
                    '{{WRAPPER}} .it-choose-text p',
                    '{{WRAPPER}} .it-value-title-box p',
                    '{{WRAPPER}} .it-video-2-text p',
                ],
			]
		);

		

		$this->end_controls_section();

        // TAB_STYLE
		$this->start_controls_section(
			'od_why_choose_list_item_content',
			[
				'label' => __( 'List Item', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_why_choose_list_item_content_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-4'],
                ],
				'selectors' => [
					'{{WRAPPER}} .it-choose-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-progress-bar .progress-bar' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-progress-bar .progress-bar span' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-progress-bar .progress-bar span::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_bg_hover_color',
			[
				'label' => esc_html__( 'BG Hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'od_design_style' => [ 'layout-4'],
                ],
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-content h5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-progress-bar-item label' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-5-list ul li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-style-2 .it-choose-title' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_title_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content:hover .it-choose-title' => 'color: {{VALUE}}',
				],
			]
		);
    
        $this->add_control(
			'od_why_choose_list_item_content_title_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3', 'layout-4'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-content h5 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-about-5-content .it-about-5-list ul li i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-choose-style-2 .it-choose-icon span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_title_icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-4'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content:hover .it-choose-icon span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_title_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-4'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_title_icon_bg_hover_color',
			[
				'label' => esc_html__( 'Icon BG Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-4'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content:hover .it-choose-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);

             
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_list_item_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-choose-content h5',
                    '{{WRAPPER}} .it-about-5-list ul li',
                    '{{WRAPPER}} .it-progress-bar-item label',
                    '{{WRAPPER}} .it-choose-style-2 .it-choose-title',
                ],
			]
		);

        $this->add_control(
			'od_why_choose_list_item_content_percentage_color',
			[
				'label' => esc_html__( 'Percentage Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-progress-bar .progress-bar span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
            
			[
                
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'name' => 'od_why_choose_list_item_content_percentage_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-progress-bar .progress-bar span',
                ],
			]
		);

        $this->add_control(
			'od_why_choose_list_item_content_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-content p' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_content_description_hover_color',
			[
				'label' => esc_html__( 'Description Hover Color', 'odcore' ),    
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],

				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-choose-style-2 .it-choose-content:hover p' => 'color: {{VALUE}}',
				],
			]
		);

             
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_why_choose_list_item_content_description_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-choose-content p',
                ],
			]
		);

		

		$this->end_controls_section();

          // TAB_STYLE
		$this->start_controls_section(
			'od_why_choose_list_item_button',
			[
				'label' => __( 'Button', 'odcore' ),    
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_why_choose_list_item_button_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_why_choose_list_item_button_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_why_choose_list_item_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-radius.sky-bg' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-radius.sky-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_why_choose_list_item_button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_why_choose_list_item_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-radius.sky-bg:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_why_choose_list_item_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-radius.sky-bg:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();
        
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
   

       $tv_list_item  = $settings['tv_list_item'];
       $tp_section_title_show  = $settings['tp_section_title_show'];
       $tp_sub_title  = $settings['tp_sub_title'];
       $tp_title  = $settings['tp_title'];
       $tp_title1  = $settings['tp_title1'];
       $tp_desctiption  = $settings['tp_desctiption'];
       $tv_why_thumbnail  = $settings['tv_why_thumbnail'];

       $od_why_choose_section_shap_img_1 = $settings['od_why_choose_section_shap_img_1'];
       $od_why_choose_section_shap_img_2 = $settings['od_why_choose_section_shap_img_2'];
       $od_why_choose_section_shap_img_3 = $settings['od_why_choose_section_shap_img_3']; 
       $od_why_choose_section_shap_img_4 = $settings['od_why_choose_section_shap_img_4'];
       $od_why_choose_section_shap_img_5 = $settings['od_why_choose_section_shap_img_5'];
       $od_why_choose_section_shap_img_6 = $settings['od_why_choose_section_shap_img_6'];

		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ):
            $tv_progress_bar_item = $settings['tv_progress_bar_item'];
        ?>

              <!-- valu-area-start -->
      <div class="it-value-area pt-120 pb-120 p-relative fix">
         <div class="it-value-shape-1 d-none d-xxl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-value-shape-2 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-value-shape-3 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="it-value-title-box">
                     <span class="it-section-subtitle-4">
                        <img src="<?php echo esc_url($od_why_choose_section_shap_img_1['url'], 'odcore');?>" alt="">
                        <?php echo esc_html($tp_sub_title, 'odcore');?>
                     </span>
                     <h4 class="it-section-title-3 pb-25"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                  </div>
                  <div class="it-progress-bar-wrap">
                    <?php foreach($tv_progress_bar_item as $single_item):?>
                     <div class="it-progress-bar-item">
                        <label><?php echo esc_html($single_item['tv_progress_title']);?> </label>
                        <div class="it-progress-bar">
                           <div class="progress">
                              <div class="progress-bar wow slideInLeft" data-wow-delay=".1s" data-wow-duration="2s"
                                 role="progressbar" data-width="<?php echo esc_attr($single_item['tv_progress_value']);?>%" aria-valuenow="<?php echo esc_attr($single_item['tv_progress_value']);?>" aria-valuemin="0"
                                 aria-valuemax="100"
                                 style="width: <?php echo esc_attr($single_item['tv_progress_value']);?>%; visibility: visible; animation-duration: 2s; animation-delay: 0.1s; animation-name: slideInLeft;">
                                 <span><?php echo esc_attr($single_item['tv_progress_value']);?>%</span>
                              </div>
                           </div>
                        </div>
                     </div>
                 <?php endforeach;?>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-value-right-wrap text-end p-relative">
                     <div class="it-value-right-img p-relative">
                        <img src="<?php echo esc_url($tv_why_thumbnail['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="it-value-img-shape d-none d-xl-block">
                        <img src="<?php echo esc_url($od_why_choose_section_shap_img_5['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="it-value-img-shape-2 d-none d-xl-block">
                        <img src="<?php echo esc_url($od_why_choose_section_shap_img_6['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- valu-area-end -->
        <?php elseif ( $settings['od_design_style']  == 'layout-3' ):

            $tp_btn_text = $settings['tp_btn_text'];
            $tp_btn_button_show = $settings['tp_btn_button_show'];
            $tv_list_items = $settings['tv_list_items'];


             // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius sky-bg');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius sky-bg');
                }
            }
        ?>
		  <!-- choose-area-start -->
      <div class="ed-choose-area it-video-2-bg p-relative fix z-index pt-120 pb-120" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/video/bg-5-1.jpg');"
>
         <div class="ed-choose-shape-2 d-none d-lg-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-choose-shape-3 d-none d-lg-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-choose-shape-4 d-none d-lg-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-choose-shape-5 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="it-video-2-left">
                     <div class="it-video-2-title-box mb-10">
                        <span class="it-section-subtitle-5 orange"><i class="fa-light fa-book"></i><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                     <div class="it-video-2-text mb-20">
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     <div class="ed-about-5-content mb-30">
                        <div class="it-about-5-list">
                           <ul>
                            <?php foreach($tv_list_items as $single_item):?>
                              <li><i class="fa-regular fa-check"></i><?php echo esc_html($single_item['tv_list_title']);?></li>
                          <?php endforeach;?>

                           </ul>
                        </div>
                     </div>
                     <div class="it-video-2-button">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                                <?php echo $tp_btn_text; ?>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-video-2-thumb p-relative">
                     <img src="<?php echo esc_url($tv_why_thumbnail['url'], 'odcore');?>" alt="">
                     <div class="ed-choose-shape-1">
                        <img src="<?php echo esc_url($od_why_choose_section_shap_img_5['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- choose-area-end -->
  <?php elseif ( $settings['od_design_style']  == 'layout-4' ):

    $tv_list_items_4 = $settings['tv_list_items_4'];

    ?>

     <!-- choose-area-start -->
      <div class="it-choose-area it-choose-style-2 z-index fix p-relative grey-bg pt-180 pb-110">
         <div class="it-choose-shape-5 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-choose-shape-6 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-choose-shape-7 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-choose-shape-8 d-none d-xl-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 mb-30">
                <?php if(!empty($tv_why_thumbnail['url'])):?>
                  <div class="it-choose-thumb-box text-center text-lg-end">
                     <div class="it-choose-thumb p-relative">
                        <img src="<?php echo esc_url($tv_why_thumbnail['url'], 'odcore');?>" alt="">
                        <div class="it-choose-shape-1">
                           <img src="<?php echo esc_url($od_why_choose_section_shap_img_5['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="it-choose-shape-2">
                           <img src="<?php echo esc_url($od_why_choose_section_shap_img_6['url'], 'odcore');?>" alt="">
                        </div>
                     </div>
                  </div>
              <?php endif;?>
               </div>
               <div class="col-xl-6 col-lg-6 mb-30">
                  <div class="it-choose-left">
                     <div class="it-choose-title-box mb-30">
                        <span class="it-section-subtitle-2 white-bg"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                     <div class="it-choose-content-box">
                        <?php foreach($tv_list_items_4 as $single_item):?>
                        <div class="it-choose-content d-flex align-items-center mb-30">
                           <div class="it-choose-icon">
                              <span><i class="<?php echo esc_attr($single_item['tv_list_icon_4'], 'odcore');?>"></i></span>
                           </div>
                           <div class="it-choose-text">
                              <h4 class="it-choose-title"><?php echo esc_html($single_item['tv_list_title_4'], 'odcore');?></h4>
                              <p class="mb-0"><?php echo tp_kses($single_item['tv_list_description_4'], 'odcore');?></p>
                           </div>
                        </div>
                    <?php endforeach;?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- choose-area-end -->


	<?php else: 

	?>	
         
          <!-- choose-area-start -->
      <div class="it-choose-area p-relative fix pt-180 pb-110">
         <div class="it-choose-shape-4 d-none d-md-block">
            <img src="<?php echo esc_url($od_why_choose_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 mb-30 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="it-choose-left">
                     <div class="it-choose-title-box mb-30">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        <?php if(!empty($tp_title1)):?>
                           <span class="p-relative ed-title-shape z-index"><?php echo tp_kses($tp_title1, 'odcore');?>
                              <svg width="168" height="65" viewBox="0 0 168 65" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path
                                    d="M73.3791 8.52241C78.4861 6.03398 82.5735 4.26476 88.8944 3.31494C94.2074 2.51659 99.6315 2.08052 104.982 1.95274C120.428 1.5839 135.136 4.94481 146.513 9.7789C158.639 14.931 166.74 22.7171 166.094 31.8511C165.316 42.8363 151.375 52.0035 133.539 57.1364C110.286 63.8284 81.7383 64.1305 58.5896 61.1289C37.5299 58.3982 11.6525 51.9446 3.59702 40.1836C-3.42072 29.9382 12.0777 18.2085 27.5463 11.6691C40.3658 6.24978 55.7075 2.97602 70.8049 4.09034C81.9407 4.91227 93.2195 6.91079 102.467 10.0494C112.882 13.5844 120.151 18.7016 127.875 23.7722"
                                    stroke="#704FE6" stroke-width="3" stroke-linecap="round" />
                              </svg>
                           </span>
                           <?php endif;?>
                        </h4>
                     </div>
                     <div class="it-choose-text pb-15">
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     <div class="it-choose-content-box">
                        <div class="row gx-20">
                        <?php foreach($tv_list_item as $single_item):?>
                           <div class="col-md-6 col-sm-6 mb-20">
                              <div class="it-choose-content">
                                 <h5><i class="fa-solid fa-circle-check"></i><?php echo esc_html($single_item['tv_list_title']);?></h5>
                                 <p><?php echo tp_kses($single_item['tv_list_description']);?> </p>
                              </div>
                           </div>
                       <?php endforeach;?>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 mb-30 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
               <?php if(!empty($tv_why_thumbnail['url'])):?>
                  <div class="it-choose-thumb-box text-center text-lg-end">
                     <div class="it-choose-thumb p-relative">
                        <img src="<?php echo esc_url($tv_why_thumbnail['url'], 'odcore');?>" alt="">
                        <div class="it-choose-shape-1">
                           <img src="<?php echo esc_url($od_why_choose_section_shap_img_3['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="it-choose-shape-2">
                           <img src="<?php echo esc_url($od_why_choose_section_shap_img_4['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="it-choose-shape-3 d-none d-lg-block">
                           <img src="<?php echo esc_url($od_why_choose_section_shap_img_2['url'], 'odcore');?>" alt="">
                        </div>
                     </div>
                  </div>
              <?php endif;?>
               </div>
            </div>
         </div>
      </div>
      <!-- choose-area-end --> 

        <?php endif; ?>

        

        <?php 
	}
}

$widgets_manager->register( new TP_Process() );