<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_About extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                    'layout-5' => esc_html__('Layout 5', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our about us', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn And Grow Your', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'secondary_sub_title',
            [
                'label' => esc_html__('Secondary Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Skills', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-1']
                ],

            ]
        );
         $this->add_control(
            'secondary_sub_title2',
            [
                'label' => esc_html__('Secondary 2 Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('From Any Where', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-1']
                ],
            ]
        );
       

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('section description here', 'odcore'),
                'placeholder' => esc_html__('Type section description here', 'odcore'),
            ]
        );


 
        $this->end_controls_section();

           // Features group
        $this->start_controls_section(
            'tv_about_feature_list_section',
            [
                'label' => esc_html__('Feature Item', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-4', 'layout-5']
                ],
            ]
        );


        $repeater2 = new \Elementor\Repeater();
        $repeater2->add_control(
            'tv_about_mission_title1', [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('QUALITY EDUCATIORS ', 'odcore'),
                'label_block' => true,
            ]
        );
     
        $this->add_control(
            'tv_features_list_4',
            [
                'label' => esc_html__('List Item 1', 'odcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater2->get_controls(),
                'default' => [
                    [
                        'tv_about_mission_title1' => esc_html__('QUALITY EDUCATIORS ', 'odcore'),
                    ],
                    [
                        'tv_about_mission_title1' => esc_html__('SAFETY AND SECURITY ', 'odcore'),
                    ],
                ],
                'title_field' => '{{{ tv_about_mission_title1 }}}',
            ]
        );


        $repeater3 = new \Elementor\Repeater();
        $repeater3->add_control(
            'tv_about_mission_title2', [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('PLAY TO LEARN ', 'odcore'),
                'label_block' => true,
            ]
        );
     
        $this->add_control(
            'tv_features_list_41',
            [
                'label' => esc_html__('List Item 2', 'odcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater3->get_controls(),
                'default' => [
                    [
                        'tv_about_mission_title2' => esc_html__('PLAY TO LEARN ', 'odcore'),
                    ],
                    [
                        'tv_about_mission_title2' => esc_html__('HOMELIKE ENVIROMEND ', 'odcore'),
                    ],
                ],
                'title_field' => '{{{ tv_about_mission_title2 }}}',
            ]
        );



         $this->end_controls_section();

             //Tooltip Section Style Four
        $this->start_controls_section(
            'about_tolltip_section',
            [
                'label' => esc_html__('Tolltip', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-4']
                ],
            ]
        );

        $this->add_control(
            'tooltip_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => tp_kses('<i>Happy <br></i> Student', 'odcore'),
                'placeholder' => esc_html__('Type Here', 'odcore'),
                'label_block' => true,
            ]
        );



         $this->add_control(
            'tooltip_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/hero/student.png',
                ],
            ]
        );

      



        $this->end_controls_section();

        // Features group
        $this->start_controls_section(
            'tv_about_feature',
            [
                'label' => esc_html__('Mission & Vission', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2']
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();


        $repeater->add_control(
            'tv_about_mission_title', [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('FLEXIBLE CLASSES', 'odcore'),
                'label_block' => true,
            ]
        );
          $repeater->add_control(
            'tv_about_mission_desc', [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Suspendisse ultrice gravida dictum fusce placerat ultricies integer quis auctor elit sed vulputate mi sit.', 'odcore'),
                'label_block' => true,
            ]
        );
     
        $this->add_control(
            'tv_features_list',
            [
                'label' => esc_html__('List Item', 'odcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tv_about_mission_title' => esc_html__('FLEXIBLE CLASSES', 'odcore'),
                        'tv_about_mission_desc' => esc_html__('Suspendisse ultrice gravida dictum fusce placerat ultricies integer quis auctor elit sed vulputate mi sit.', 'odcore'),
                    ],
                    [
                        'tv_about_mission_title' => esc_html__('FLEXIBLE CLASSES', 'odcore'),
                        'tv_about_mission_desc' => esc_html__('Suspendisse ultrice gravida dictum fusce placerat ultricies integer quis auctor elit sed vulputate mi sit.', 'odcore'),
                    ],
                ],
                'title_field' => '{{{ tv_about_mission_title }}}',
            ]
        );

      


        $this->end_controls_section();



         // Feature Item for About 3
        $this->start_controls_section(
            'tv_feature_about_3_group',
            [
                'label' => esc_html__('Features Items', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
            ]
        );
        $this->add_control(
            'tv_about_3_feature_swticher',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tv_about_3_feature_list',
            [
                'label' => esc_html__( 'Feature List', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tv_feature_title',
                        'label' => esc_html__( 'Title', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Sharing A Screen' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tv_feature_desc',
                        'label' => esc_html__( 'Descriptions', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore et dolore magna aliqua.' , 'odcore' ),
                        'show_label' => false,
                    ],
                    [
                        'name' => 'tv_feature_icon_class',
                        'label' => esc_html__( 'Icon Class', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'flaticon-video-1' , 'odcore' ),
                        'label_block' => true,
                    ]
                ],
                'default' => [
                    [
                        'tv_feature_title' => esc_html__( 'Sharing A Screen', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore et dolore magna aliqua.', 'odcore' ),
                        'tv_feature_icon_class' => esc_html__( 'flaticon-video-1', 'odcore' ),
                    ],
                    [
                        'tv_feature_title' => esc_html__( 'Presenter Control', 'odcore' ),
                        'tv_feature_desc' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore et dolore magna aliqua.', 'odcore' ),
                        'tv_feature_icon_class' => esc_html__( 'flaticon-puzzle', 'odcore' ),
                    ],
                ],
                'title_field' => '{{{ tv_feature_title }}}',
            ]
        );


        $this->end_controls_section();


        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Load More', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();


 

    
     // thumbnail for style 3 and 4
        $this->start_controls_section(
            'tv_about_3_4_thumb',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-4', 'layout-3', 'layout-5'],
                ],
            ]
        );

         $this->add_control(
            'about_image341',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/thumb-4-1.jpg',
                ],
            ]
        );
         $this->add_control(
            'about_image342',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/thumb-4-2.jpg',
                ],
            ]
        );




        $this->end_controls_section();
 


        // _tp_image
		$this->start_controls_section(
            '_tp_image',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1','layout-2',],
                ],
            ]
        );
        $this->add_control(
            'about_image11',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/ed-about-1-1.jpg',
                ],
            ]
        );
        $this->add_control(
            'about_image12',
            [
                'label' => esc_html__( 'Choose Image 2', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/ed-about-1-2.jpg',
                ],
            ]
        );
        $this->add_control(
            'about_image13',
            [
                'label' => esc_html__( 'Choose Image 3', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/about/ed-about-1-3.jpg',
                ],
            ]
        );
        $this->end_controls_section();

          // _Section Experience
        $this->start_controls_section(
            '_section_experience_info',
            [
                'label' => __('Experience Info', 'odcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );
        $this->add_control(
        'experienced_area_switcher',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
         $this->add_control(
            'exp_nums',
            [
                'label' => __('Number', 'odcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('8+', 'odcore'),
                'placeholder' => __('Type number Here', 'odcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
           $this->add_control(
            'exp_titles',
                [
                    'label' => __('Title', 'odcore'),
                    'label_block' => true,
                    'type' => Controls_Manager::TEXT,
                    'default' => __('years of experience', 'odcore'),
                    'placeholder' => __('Type your text', 'odcore'),
                    'dynamic' => [
                        'active' => true,
                    ]
                ]
            );

        $this->end_controls_section();


            // _Section Experience
        $this->start_controls_section(
            'od_about_section_shap',
            [
                'label' => __('Shap', 'odcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        
		$this->add_control(
			'od_about_image_shap_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/about/shape-1-4.png',
				],
			]
		);
        
		$this->add_control(
			'od_about_image_shap_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/about/ed-shape-1-1.png',
				],
			]
		);

        $this->add_control(
			'od_about_image_shap_3',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-4'],
                ],
				'label' => esc_html__( 'Shap 3', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        $this->add_control(
			'od_about_image_shap_4',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
				'label' => esc_html__( 'Shap 4', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/shape-1-2.png',
				], 
			]
		);
        $this->add_control(
			'od_about_image_shap_5',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
				'label' => esc_html__( 'Shap 5', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>get_template_directory_uri() . '/assets/img/hero/shape-1-3.png',
				], 
			]
		);
        $this->add_control(
			'od_about_image_shap_6',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
				'label' => esc_html__( 'Shap 6', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/about/shape-4-2.png',
				], 
			
			]
		);
        $this->add_control(
			'od_about_image_shap_7',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
				'label' => esc_html__( 'Shap 7', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>get_template_directory_uri() . '/assets/img/about/shape-4-1.png',
				], 
				
			]
		);


        $this->end_controls_section();


      



		
        //Style

        $this->start_controls_section(
            'od_about_title_content',
            [
                'label' => __( 'Title & Content', 'odcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_about_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-5' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_title2_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-4'],
                ],
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3 span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_title_shap_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'label' => esc_html__( 'Shap Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
                'description' => esc_html__( 'This only for design Style 01', 'odcore'),
				'selectors' => [
					'{{WRAPPER}} .ed-title-shape svg path' => 'stroke: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-title',
                    '{{WRAPPER}} .it-section-title-3',
                    '{{WRAPPER}} .it-section-title-5',
                ],
			]
		);

        
        $this->add_control(
			'od_about_subtitle_bg_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-5'],
                ],
				'label' => esc_html__( 'SubTitle Bg Color', 'odcore' ),
                'description' => esc_html__( 'This only for design Style 01', 'odcore'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);
        
        $this->add_control(
			'od_about_subtitle_color',
			[
				'label' => esc_html__( 'SubTitle Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5' => 'color: {{VALUE}}',
				],
			]
		);


        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-subtitle',
                    '{{WRAPPER}} .it-section-subtitle-3',
                    '{{WRAPPER}} .it-section-subtitle-5',
                ],
			]
		);
    
        
        $this->add_control(
			'od_about_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-3-title-box p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-5-text p' => 'color: {{VALUE}}',
				],
			]
		);

       

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_description_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-about-text p',
                    '{{WRAPPER}} .it-about-3-title-box p',
                    '{{WRAPPER}} .it-about-5-text p',
                ]
			]
		);



    


        $this->end_controls_section();

               //Style

        $this->start_controls_section(
            'od_about_mission_vission_area',
            [
                'label' => __( 'Mission & Visson / Features Item', 'odcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
			'od_about_mission_vission_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-content h5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-3-mv-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-about-4-wrap .it-about-5-list ul li' => 'color: {{VALUE}}',
					'{{WRAPPER}} ..ed-about-5-content .it-about-5-list ul li' => 'color: {{VALUE}}',
				],
			]
		);

       

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_mission_vission_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-about-content h5',
                    '{{WRAPPER}} .it-about-3-mv-title',
                    '{{WRAPPER}} .ed-about-4-wrap .it-about-5-list ul li',
                    '{{WRAPPER}} .ed-about-5-content .it-about-5-list ul li',
                ],
			]
		);

        $this->add_control(
			'od_about_mission_vission_description_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-content p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-about-3-mv-item p' => 'color: {{VALUE}}',
				],
			]
		);

       

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
				'name' => 'od_about_mission_vission_description_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-about-content p',
                    '{{WRAPPER}} .it-about-3-mv-item p',
                ],
			]
		);

        $this->add_control(
			'od_about_feature_icon_bg_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-4-list-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_feature_icon_color',
			[
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-4', 'layout-5'],
                ],
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-about-4-list-icon span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-about-4-wrap .it-about-5-list ul li i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-about-5-content .it-about-5-list ul li i' => 'color: {{VALUE}}',
				],
			]
		);


        


        

        $this->end_controls_section();

        $this->start_controls_section(
            'od_about_tooltip_area',
            [
                'label' => __( 'Tooltip', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_about_tooltip_area_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-thumb-student' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_tooltip_area_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-thumb-student > span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_tooltip_area_title2_color',
			[
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-about-4-wrap .ed-hero-thumb-student span i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_tooltip_area_title_typography',
				'selector' => '{{WRAPPER}} .ed-about-4-wrap .ed-hero-thumb-student span',
			]
		);


        $this->end_controls_section();

        $this->start_controls_section(
            'od_about_button_area',
            [
                'label' => __( 'Button', 'odcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'od_about_button_area_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_about_button_area_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );

        $this->add_control(
			'od_about_button_area_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-radius' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_button_area_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme i' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_button_area_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-radius' => 'color: {{VALUE}}',
				],
			]
		);


        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_about_button_area_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'textdomain' ),
            ]
        );

          $this->add_control(
			'od_about_button_area_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-radius:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_button_area_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_button_area_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-radius:hover' => 'color: {{VALUE}}',
				],
			]
		);


        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_button_area_hover_text_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-btn-theme',
                    '{{WRAPPER}} .ed-btn-square',
                    '{{WRAPPER}} .ed-btn-radius',
                ],
			]
		);


        

        $this->end_controls_section();

        $this->start_controls_section(
            'od_about_experience_area',
            [
                'label' => __( 'Experience Info', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'od_about_experience_area_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-about-experience' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_about_experience_area_border_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-about-experience' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_about_experience_area_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-about-experience span b' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_experience_area_title_typography',
				'selector' => '{{WRAPPER}} .ed-about-experience span b',
			]
		);
        $this->add_control(
			'od_about_experience_area_title2_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-about-experience span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_about_experience_area_subtitle_typography',
				'selector' => '{{WRAPPER}} .ed-about-experience span',
			]
		);



        

        $this->end_controls_section();
        
      




	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
        $settings = $this->get_settings_for_display();


        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $secondary_sub_title = $settings['secondary_sub_title'];
        $secondary_sub_title2 = $settings['secondary_sub_title2'];
        $tp_desctiption = $settings['tp_desctiption'];
        $about_image11 = $settings['about_image11'];
        $about_image12 = $settings['about_image12'];
        $about_image13 = $settings['about_image13'];
        $experienced_area_switcher = $settings['experienced_area_switcher'];
        $exp_nums = $settings['exp_nums'];
        $exp_titles = $settings['exp_titles'];
        $tp_btn_text = $settings['tp_btn_text'];
        $tv_features_list = $settings['tv_features_list'];
        $about_image341 = $settings['about_image341'];
        $about_image342 = $settings['about_image342'];
        $od_about_image_shap_1 = $settings['od_about_image_shap_1'];
        $od_about_image_shap_2 = $settings['od_about_image_shap_2'];

        ?>


        <?php if ( $settings['od_design_style']  == 'layout-2' ):

    

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
                }
            }

        ?>

      
      <!-- about-area-start -->
      <div class="it-about-3-area fix pt-120 pb-120 p-relative">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="ed-about-2-left p-relative text-end">
                     <div class="ed-about-2-left-box d-inline-flex align-items-end">
                        <div class="ed-about-2-thumb-one pb-110 mr-20">
                           <img src="<?php echo esc_url($about_image11['url'], 'odcore');?>" alt="">
                        </div>             
                        <div class="ed-about-2-thumb-two text-start">
                           <img class="mb-20 inner-top-img" src="<?php echo esc_url($about_image13['url'], 'odcore');?>" alt="">
                           <img src="<?php echo esc_url($about_image12['url'], 'odcore');?>" alt="">
                        </div>             
                     </div>
                     <div class="ed-about-2-thumb-shape-1 d-none lg-block">
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/about/ed-shape-2-1.png" alt="">
                     </div>             
                     <div class="ed-about-2-thumb-shape-2 d-none d-xxl-block">
                        <img src="<?php echo esc_url($od_about_image_shap_1['url'], 'odcore');?>" alt="">
                     </div>             
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-about-3-title-box">
                     <span class="it-section-subtitle-3">
                        <img src="<?php echo esc_url($od_about_image_shap_2['url'], 'odcore');?>" alt="">
                        <?php echo esc_html($tp_sub_title,'odcore');?>
                     </span>
                     <h2 class="it-section-title-3 pb-30"><?php echo tp_kses($tp_title,'odcore');?>
                     </h2>
                     <p><?php echo tp_kses($tp_desctiption,'odcore');?></p>
                  </div>
                  <div class="it-about-3-mv-box">
                     <div class="row">
                        <?php foreach($tv_features_list as $single_item):?>
                        <div class="col-xl-6 col-md-6">
                           <div class="it-about-3-mv-item">
                              <span class="it-about-3-mv-title"><?php echo esc_html($single_item['tv_about_mission_title'], 'odcore');?></span>
                              <p><?php echo tp_kses($single_item['tv_about_mission_desc'], 'odcore');?></p>
                           </div>
                        </div>
                    <?php endforeach;?>
                     </div>
                  </div>
                  <div class="it-about-3-btn-box p-relative ms-center">
                        <div class="it-about-btn mr-30">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <?php echo $settings['tp_btn_text']; ?>
                        <i>
                           <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                 stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                 stroke-linecap="round" stroke-linejoin="round" />
                           </svg>
                        </i>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->



        <?php elseif ( $settings['od_design_style']  == 'layout-3' ):
            $tv_about_3_feature_list = $settings['tv_about_3_feature_list'];
            $od_about_image_shap_3 = $settings['od_about_image_shap_3'];
            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square');
                }
            }

        ?>



        <!-- about-area-start -->
      <div class="it-about-3-area it-about-4-style p-relative grey-bg pt-120 pb-120">
         <div class="ed-about-3-shape-2">
            <img src="<?php echo esc_url($od_about_image_shap_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6">
                  <div class="ed-about-3-thumb-wrap p-relative">
                     <div class="ed-about-3-shape-1 d-none d-md-block">
                        <img src="<?php echo esc_url($od_about_image_shap_2['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-3-thumb">
                        <img src="<?php echo esc_url($about_image341['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-3-thumb-sm">
                        <img src="<?php echo esc_url($about_image342['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6">
                  <div class="it-about-3-title-box">
                     <span class="it-section-subtitle-5 purple-2">
                        <img src="<?php echo esc_url($od_about_image_shap_3['url'], 'odcore');?>" alt="">
                        <?php echo esc_html($tp_sub_title, 'odcore');?>
                     </span>
                     <h2 class="it-section-title-3 pb-30"> <?php echo tp_kses($tp_title, 'odcore');?>
                     </h2>
                     <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                  </div>
                  <div class="it-about-3-mv-box">
                     <div class="row">
                        <?php foreach($tv_about_3_feature_list as $single_item):?>
                        <div class="col-xl-12">
                           <div class="it-about-4-list-wrap d-flex align-items-start">
                              <div class="it-about-4-list-icon">
                                 <span><i class="<?php echo esc_attr($single_item['tv_feature_icon_class'], 'odcore');?>"></i></span>
                              </div>
                              <div class="it-about-3-mv-item">
                                 <span class="it-about-3-mv-title"><?php echo esc_html($single_item['tv_feature_title'], 'odcore');?></span>
                                 <p><?php echo tp_kses($single_item['tv_feature_desc'], 'odcore');?></p>
                              </div>
                           </div>
                        </div>
                    <?php endforeach;?>
                     </div>
                  </div>
                  <div class="it-about-3-btn-box p-relative">
                   <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                        <span>
                        <?php echo $settings['tp_btn_text']; ?>
                        </span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->






        <?php elseif ( $settings['od_design_style']  == 'layout-4' ):
            $tv_features_list_4 = $settings['tv_features_list_4'];
            $tv_features_list_41 = $settings['tv_features_list_41'];
            $tooltip_title = $settings['tooltip_title'];
            $tooltip_img = $settings['tooltip_img'];
            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius');
                }
            }

            
            $od_about_image_shap_3 = $settings['od_about_image_shap_3'];
            $od_about_image_shap_4 = $settings['od_about_image_shap_4'];
            $od_about_image_shap_5 = $settings['od_about_image_shap_5'];
            $od_about_image_shap_6 = $settings['od_about_image_shap_6'];
            $od_about_image_shap_7 = $settings['od_about_image_shap_7']
         
        ?>


        <!-- about-area-start -->
      <div class="it-about-5-area fix ed-about-4-wrap p-relative pb-120">
         <div class="it-about-5-shape-2">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/about/shape-5-2.png" alt="">
         </div>
         <div class="it-about-5-shape-3 d-none d-xl-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/about/shape-5-3.png" alt="">
         </div>
         <div class="it-about-5-shape-4 d-none d-md-block">
            <img src="<?php echo esc_url($od_about_image_shap_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-about-5-shape-5 d-none d-xl-block">
            <img src="<?php echo esc_url($od_about_image_shap_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="ed-hero-thumb-wrap text-center text-md-end  p-relative">
                    <?php if(!empty($about_image341['url'])):?>
                     <div class="ed-hero-thumb-main p-relative">
                        <img src="<?php echo esc_url($about_image341['url'], 'odcore');?>" alt="">
                        <div class="ed-hero-thumb-shape-1 d-none d-md-block">
                           <img src="<?php echo esc_url($od_about_image_shap_7['url'], 'odcore');?>" alt="">
                        </div>
                     </div>
                 <?php endif;?>
                 <?php if(!empty($about_image342['url'])):?>
                     <div class="ed-hero-thumb-sm p-relative">
                        <img src="<?php echo esc_url($about_image342['url'], 'odcore');?>" alt="">
                        <div class="ed-hero-thumb-shape-1">
                           <img src="<?php echo esc_url($od_about_image_shap_6['url'], 'odcore');?>" alt="">
                        </div>
                     </div>
                 <?php endif;?>
                     <div class="ed-hero-thumb-shape-2">
                        <img src="<?php echo esc_url($od_about_image_shap_3['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-hero-thumb-shape-3">
                        <img src="<?php echo esc_url($od_about_image_shap_4['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-hero-thumb-shape-4">
                        <img src="<?php echo esc_url($od_about_image_shap_5['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-hero-thumb-student d-none d-md-flex align-items-center">
                        <span><?php echo tp_kses($tooltip_title, 'odcore');?></span>
                        <img src="<?php echo esc_url($tooltip_img['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-about-5-right">
                     <div class="it-about-5-title-box pb-10">
                        <span class="it-section-subtitle-5 orange"><i class="fa-light fa-book"></i><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title orange"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                     <div class="it-about-5-text mb-30">
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     <div class="it-about-5-content">
                        <div class="row">
                           <div class="col-xl-6 col-lg-6">
                              <div class="it-about-5-list list-style-1 mb-20">
                                 <ul>
                                    <?php foreach($tv_features_list_4 as $single_item):?>
                                    <li><i class="fa-sharp fa-solid fa-circle-check"></i><?php echo esc_html($single_item['tv_about_mission_title1'], 'odcore');?></li>
                                <?php endforeach;?>

                                 </ul>
                              </div>                              
                           </div>
                           <div class="col-xl-6 col-lg-6">
                              <div class="it-about-5-list list-style-2 mb-20">
                                 <ul>

                                    <?php foreach($tv_features_list_41 as $single_item):?>
                                    <li><i class="fa-sharp fa-solid fa-circle-check"></i><?php echo esc_html($single_item['tv_about_mission_title2'], 'odcore');?></li> 
                                <?php endforeach;?> 

                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="it-feature-button">
                   <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                        <?php echo $settings['tp_btn_text']; ?>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end --> 







        <?php elseif ( $settings['od_design_style']  == 'layout-5' ):

            $tv_features_list_4 = $settings['tv_features_list_4'];
            $tv_features_list_41 = $settings['tv_features_list_41'];

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
                }
            }

        ?>


              <!-- about-area-start -->
      <div class="it-about-5-area p-relative fix pt-60 pb-120">
         <div class="ed-about-5-shape-2">
            <img src="<?php echo esc_url($od_about_image_shap_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6">
                  <div class="it-about-5-right">
                     <div class="it-about-5-title-box pb-10">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="it-section-title-5"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                     <div class="it-about-5-text mb-30">
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     <div class="ed-about-5-content">
                        <div class="it-about-5-list mb-10">
                           <ul>
                            <?php foreach($tv_features_list_4 as $single_item):?>

                              <li><i class="fa-regular fa-check"></i><?php echo esc_html($single_item['tv_about_mission_title1'], 'odcore');?></li>
                          <?php endforeach;?>
                            </ul>
                        </div>
                        <div class="it-about-5-list mb-40">
                           <ul>
                            <?php foreach($tv_features_list_41 as $single_item):?>
                              <li><i class="fa-regular fa-check"></i><?php echo esc_html($single_item['tv_about_mission_title2'], 'odcore');?></li>
                            <?php endforeach;?>
                           </ul>
                        </div>
                     </div>
                     <div class="it-feature-button">
                   <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                        <?php echo $settings['tp_btn_text']; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6">
                  <div class="ed-about-5-right d-flex justify-content-between p-relative">
                     <div class="ed-about-5-thumb-2">
                        <img src="<?php echo esc_url($about_image341['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-5-thumb-1">
                        <img src="<?php echo esc_url($about_image342['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-5-shape-1">
                        <img src="<?php echo esc_url($od_about_image_shap_2['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->
        


        <?php else:

          $experienced_area_switcher = $settings['experienced_area_switcher'];
          $tp_section_title_show = $settings['tp_section_title_show'];

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme');
                }
            }

        ?>
           

             <!-- about-area-start -->
      <div class="it-about-area ed-about-style-2 p-relative pt-185 pb-185">
         <div class="it-about-shape-4 d-none d-md-block">
            <img src="<?php echo esc_url($od_about_image_shap_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6  wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="ed-about-thumb-box p-relative">
                     <div class="ed-about-thumb-1">
                        <img src="<?php echo esc_url($about_image11['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-thumb-2">
                        <img src="<?php echo esc_url($about_image12['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-thumb-3">
                        <img src="<?php echo esc_url($about_image13['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-about-shape-1 d-none d-md-block">
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/about/ed-shape-1-1.png" alt="">
                     </div>
                    <?php if(!empty($experienced_area_switcher)):?>
                     <div class="ed-about-experience d-none d-md-block">
                        <span><b><?php echo esc_html($exp_nums, 'odcore');?></b> <br>
                           <?php echo tp_kses($exp_titles, 'odcore');?></span>
                     </div>
                    <?php endif;?>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6  wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-about-right-box">
                    <?php if(!empty($tp_section_title_show)):?>
                     <div class="it-about-title-box mb-20">
                        <?php if(!empty($tp_sub_title)):?>
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                    <?php endif;?>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        <?php if(!empty($secondary_sub_title)):?>
                           <span class="p-relative ed-title-shape z-index"><?php echo esc_html($secondary_sub_title, 'odcore');?>
                              <svg width="168" height="65" viewBox="0 0 168 65" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path
                                    d="M73.3791 8.52241C78.4861 6.03398 82.5735 4.26476 88.8944 3.31494C94.2074 2.51659 99.6315 2.08052 104.982 1.95274C120.428 1.5839 135.136 4.94481 146.513 9.7789C158.639 14.931 166.74 22.7171 166.094 31.8511C165.316 42.8363 151.375 52.0035 133.539 57.1364C110.286 63.8284 81.7383 64.1305 58.5896 61.1289C37.5299 58.3982 11.6525 51.9446 3.59702 40.1836C-3.42072 29.9382 12.0777 18.2085 27.5463 11.6691C40.3658 6.24978 55.7075 2.97602 70.8049 4.09034C81.9407 4.91227 93.2195 6.91079 102.467 10.0494C112.882 13.5844 120.151 18.7016 127.875 23.7722"
                                    stroke="#704FE6" stroke-width="3" stroke-linecap="round" />
                              </svg>
                           </span>
                       <?php endif;?>
                           <br><?php echo esc_html($secondary_sub_title2, 'odcore');?>
                        </h4>
                     </div>
                 <?php endif;?>
                     <div class="it-about-text pb-10">
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     
                     <div class="it-about-content-wrapper d-flex align-items-center justify-content-between pb-15">

                        <?php foreach($tv_features_list as $single_item):?>
                            <div class="it-about-content">
                               <h5><?php echo esc_html($single_item['tv_about_mission_title'], 'odcore');?></h5>
                               <p><?php echo tp_kses($single_item['tv_about_mission_desc'], 'odcore');?></p>
                            </div>
                        <?php endforeach;?>

                     </div>
                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <?php echo esc_html($tp_btn_text, 'odcore'); ?>
                        <i>
                           <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                 stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                 stroke-linecap="round" stroke-linejoin="round" />
                           </svg>
                        </i>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about-area-end -->



        <?php endif; ?>



        <?php

		
}
}

$widgets_manager->register( new TP_About() );