<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Event_Two extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'event-two';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Events', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		  // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );
        
        $this->end_controls_section();

         // od_event_section Shap
        $this->start_controls_section(
            'od_events_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
            ]
         );

         $this->add_control(
			'od_events_section_shap_img_1',
            [
               'label' => esc_html__( 'Shap 1', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-5.png',
               ],
            ]
         );

         $this->add_control(
			'od_events_section_shap_img_2',
            [
               'label' => esc_html__( 'Shap 2', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-6.png',
               ],
            ]
         );
         $this->add_control(
			'od_events_section_shap_img_3',
            [
               'label' => esc_html__( 'Shap 3', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-1.png',
               ],
            ]
         );
         $this->add_control(
			'od_events_section_shap_img_4',
            [
               'label' => esc_html__( 'Shap 4', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-2.png',
               ],
            ]
         );
         $this->add_control(
			'od_events_section_shap_img_5',
            [
               'label' => esc_html__( 'Shap 5', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-3.png',
               ],
            ]
         );
         $this->add_control(
			'od_events_section_shap_img_6',
            [
               'label' => esc_html__( 'Shap 6', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>   get_template_directory_uri(). '/assets/img/event/shape-1-4.png',
               ],
            ]
         );

         $this->end_controls_section();



             // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );


        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Choose Your Career', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Discover Your Gain', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );  
        $this->add_control(
            'tp_description',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Description', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );    
        

        $this->end_controls_section();


		$this->start_controls_section(
			'tv_event_repeater_section',
			[
				'label' => __( 'Event List', 'odcore' ),
                'condition' =>[
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
			]
		);


		$this->add_control(
			'tv_event_list',
			[
				'label' => esc_html__( 'Event List', 'odcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'tv_event_title',
						'label' => esc_html__( 'Title', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'print, and publishing industries for previewing' , 'odcore' ),
						'label_block' => true,
					],
					[
						'name' => 'tv_event_description',
						'label' => esc_html__( 'Description', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur elit, sed doeiusmod tempor' , 'textdoodcoremain' ),
						'show_label' => true,
					],
					[
						'name' => 'tv_event_thumbnail',
						'label' => esc_html__( 'Thumbnail', 'odcore' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => get_template_directory_uri().'/assets/img/event/event-3-1.jpg'
						],
						'show_label' => true,
					],
					[
						'name' => 'tv_event_date',
						'label' => esc_html__( 'Event Date', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => tp_kses( '<i>08</i> <br>October' , 'odcore' ),
						'label_block' => true,
					],

					[
						'name' => 'tv_event_location',
						'label' => esc_html__( 'Event Location', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Location: USA' , 'odcore' ),
						'label_block' => true,
					],
					[
						'name' => 'tv_event_time',
						'label' => esc_html__( 'Event Time', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Time: 11:00am  03;00pm' , 'odcore' ),
						'label_block' => true,
					],
					[
						'name' => 'tv_event_url',
						'label' => esc_html__( 'Event URL', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'odcore' ),
						'label_block' => true,
					],

				],
				'default' => [
					[
						'tv_event_title' => esc_html__( 'print, and publishing industries for previewing', 'odcore' ),
					],
					[
						'tv_event_title' => esc_html__( 'print, and publishing industries for previewing', 'odcore' ),
					],
					[
						'tv_event_title' => esc_html__( 'print, and publishing industries for previewing', 'odcore' ),
					],
				],
				'title_field' => '{{{ tv_event_title }}}',
			]
		);

		

		$this->end_controls_section();


		$this->start_controls_section(
			'tv_event_thumbnail_section',
			[
				'label' => __( 'Thumbnail', 'odcore' ),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
			]
		);


		$this->add_control(
			'tv_event_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri().'/assets/img/event/thumb-1.png',
				],
			]
		);

		

		$this->end_controls_section();

		//Button
		$this->start_controls_section(
			'tv_button_group',
			[
				'label' => __( 'Button', 'odcore' ),
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
			]
		);

		$this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
		

		$this->end_controls_section();


      $this->start_controls_section(
			'od_events_area2',
			[
				'label' => __( 'Events Area', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-2'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_events_area2_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .grey-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_section();


	

		$this->start_controls_section(
			'od_events_title_content1',
			[
				'label' => __( 'Title & Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_events_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_title_content_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-3',
			]
		);
      $this->add_control(
			'od_events_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_title_content_subtitle_typography',
				'selectors' => [
               '{{WRAPPER}} .it-section-subtitle-4',
               '{{WRAPPER}} .it-section-subtitle-5',
            ]
			]
		);
      $this->add_control(
			'od_events_title_content_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-content p' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_title_content_description_typography',
				'selector' => '{{WRAPPER}} .it-event-content p',
			]
		);




		$this->end_controls_section();

      
		$this->start_controls_section(
			'od_events_title_content_button',
			[
				'label' => __( 'Button', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->start_controls_tabs(
            'od_events_title_content_button_tabs'
      );

         // Normal

      $this->start_controls_tab(
            'od_events_title_content_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
      );

      $this->add_control(
			'od_events_title_content_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_title_content_button_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_title_content_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
				],
			]
		);



      $this->end_controls_tab();

         // Hover

      $this->start_controls_tab(
            'od_events_title_content_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
      );

      $this->add_control(
			'od_events_title_content_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_title_content_button_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_title_content_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();

      $this->end_controls_section();

      

      $this->start_controls_section(
			'od_events_area_events_lists',
			[
				'label' => __( 'Events List', 'odcore' ),
                'condition' => [
                    'od_design_style' => [ 'layout-2',  'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_events_area_events_list_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-content' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_events_area_events_list_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_area_events_list_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-title' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_area_events_list_title_hover_color',
			[
				'label' => esc_html__( 'Title hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_area_events_list_title_typography',
				'selector' => '{{WRAPPER}} .it-event-2-title',
			]
		);

      $this->add_control(
			'od_events_area_events_list_description_heading',
			[
				'label' => esc_html__( 'Description', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_area_events_list_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-text p' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_area_events_list_description_typography',
				'selectors' => [
               '{{WRAPPER}} .it-event-2-title',
               '{{WRAPPER}} .it-event-2-text p',
            ],
			]
		);
      $this->add_control(
			'od_events_area_events_list_time_location_heading',
			[
				'label' => esc_html__( 'Time/Location', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_events_area_events_list_timelocatio_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-2-meta span' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_events_area_events_list_timelocatio_typography',
				'selectors' => [
               '{{WRAPPER}} .it-event-2-meta span',
            ],
			]
		);

      
      $this->add_control(
			'od_events_area_events_list_timelocation_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-meta span i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-meta span i' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_events_area_events_list_date_heading',
			[
				'label' => esc_html__( 'Date', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
            'od_events_area_events_list_date_tabs'
         );

         // Normal

      $this->start_controls_tab(
            'od_events_area_events_list_date_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
      $this->add_control(
			'od_events_area_events_list_date_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'background-color: {{VALUE}}',
				],
			]
		);

          
      $this->add_control(
			'od_events_area_events_list_date_normal_border_color',
			[
				'label' => esc_html__( 'border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'border-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_area_events_list_date_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-date span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-date' => 'color: {{VALUE}}',
				],
			]
		);






      $this->end_controls_tab();

         // Hover

      $this->start_controls_tab(
            'od_events_area_events_list_date_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );


          $this->add_control(
			'od_events_area_events_list_date_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date' => 'background-color: {{VALUE}}',
				],
			]
		);

          
      $this->add_control(
			'od_events_area_events_list_date_hover_border_color',
			[
				'label' => esc_html__( 'border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date' => 'border-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_events_area_events_list_date_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-event-style-4 .it-event-2-item:hover .it-event-2-date span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-event-style-3 .it-event-2-item:hover .it-event-2-date span' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();


     

      $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

			$tp_section_title_show = $settings['tp_section_title_show'];
			$tp_sub_title = $settings['tp_sub_title'];
			$tp_title = $settings['tp_title'];
			$tp_description = $settings['tp_description'];
			$tp_btn_button_show = $settings['tp_btn_button_show'];
			$tv_event_thumb = $settings['tv_event_thumb'];
			$tp_btn_text = $settings['tp_btn_text'];

         $od_events_section_shap_img_1 = $settings['od_events_section_shap_img_1'];
         $od_events_section_shap_img_2 = $settings['od_events_section_shap_img_2'];
         $od_events_section_shap_img_3 = $settings['od_events_section_shap_img_3'];
         $od_events_section_shap_img_4 = $settings['od_events_section_shap_img_4'];
         $od_events_section_shap_img_5 = $settings['od_events_section_shap_img_5'];
         $od_events_section_shap_img_6 = $settings['od_events_section_shap_img_6'];


			?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ):

			$tv_event_list = $settings['tv_event_list'];
		?>

			 <!-- event-area-start -->
      <div class="it-event-2-area it-event-style-4 p-relative z-index pt-115 fix pb-70 grey-bg">
         <div class="ed-event-shape-1">
            <img src="<?php echo esc_url($od_events_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-event-shape-2">
            <img src="<?php echo esc_url($od_events_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
         	<?php if(!empty($tp_section_title_show)):?>
            <div class="it-event-2-title-wrap mb-60">
               <div class="row align-items-end">
                  <div class="col-12">
                     <div class="it-event-2-title-box text-center">
                        <span class="it-section-subtitle-5 purple-2">
                           <img src="<?php echo esc_url($od_events_section_shap_img_3['url'], 'odcore');?>" alt="">
                          <?php echo esc_html($tp_sub_title, 'odcore');?>
                        </span>
                        <h2 class="it-section-title-3"><?php echo tp_kses($tp_title, 'odcore');?></h2>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
            	<?php foreach($tv_event_list as $single_item):
            		$event_thumb = $single_item['tv_event_thumbnail'];
            	?>
               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-event-2-item-box">                  
                     <div class="it-event-2-item">
                        <div class="it-event-2-thumb fix">
                           <a href="<?php echo esc_url($single_item['tv_event_url'], 'odcore');?>"><img src="<?php echo esc_url($event_thumb['url'], 'odcore');?>" alt=""></a>
                           <div class="it-event-2-date">
                              <span><?php echo tp_kses($single_item['tv_event_date'], 'odcore');?></span>
                           </div>
                        </div> 
                        <div class="it-event-2-content">
                           <h4 class="it-event-2-title"><a href="<?php echo esc_url($single_item['tv_event_url'], 'odcore');?>"><?php echo esc_html($single_item['tv_event_title'], 'odcore');?></a></h4> 
                           <div class="it-event-2-text">
                              <p class="mb-0 pb-10"><?php echo tp_kses($single_item['tv_event_description'], 'odcore');?></p>
                           </div>
                           <div class="it-event-2-meta">
                              <span>
                                 <i class="fa-light fa-clock"></i>
                                 <?php echo esc_html($single_item['tv_event_time'], 'odcore');?>
                              </span>
                              <span>
                                 <a href="#">
                                    <i class="fa-light fa-location-dot"></i>
                                 </a>
                                 <?php echo esc_html($single_item['tv_event_location'], 'odcore');?>
                              </span>
                           </div>
                        </div>              
                     </div>
                  </div>
               </div>
           <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- event-area-end -->

		<?php elseif ( $settings['od_design_style']  == 'layout-3' ):

			$tv_event_list = $settings['tv_event_list'];
		?>


		      <!-- event-area-start -->
      <div class="it-event-2-area it-event-style-3 p-relative pt-90 pb-90">
         <div class="container">
            <div class="row">

            	<?php foreach($tv_event_list as $single_item):
            		$event_thumb = $single_item['tv_event_thumbnail']; ?>


               <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
                  <div class="it-event-2-item-box">                  
                     <div class="it-event-2-item">
                        <div class="it-event-2-thumb fix">
                           <a href="<?php echo esc_url($single_item['tv_event_url'], 'odcore');?>"><img src="<?php echo esc_url($event_thumb['url'], 'odcore');?>" alt=""></a>
                           <div class="it-event-2-date">
                             <span><?php echo tp_kses($single_item['tv_event_date'], 'odcore');?></span>
                           </div>
                        </div> 
                        <div class="it-event-2-content">
                           <h4 class="it-event-2-title"><a href="<?php echo esc_url($single_item['tv_event_url'], 'odcore');?>"><?php echo esc_html($single_item['tv_event_title'], 'odcore');?></a></h4> 
                           <div class="it-event-2-text">
                              <p class="mb-0 pb-10"><?php echo tp_kses($single_item['tv_event_description'], 'odcore');?></p>
                           </div>
                           <div class="it-event-2-meta">
                              <span>
                                 <i class="fa-light fa-clock"></i>
                                 <?php echo esc_html($single_item['tv_event_time'], 'odcore');?>
                              </span>
                              <span>
                                 <a href="#">
                                    <i class="fa-light fa-location-dot"></i>
                                 </a>
                                 <?php echo esc_html($single_item['tv_event_location'], 'odcore');?>
                              </span>
                           </div>
                        </div>              
                     </div>
                  </div>
               </div> 

           <?php endforeach;?>
           </div>
         </div>
      </div>
      <!-- event-area-end -->


		<?php else:

			  // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
                }
            }
		?>

			   <!-- event-area-start -->
      <div class="it-event-area p-relative pt-120 pb-120 fix">
      <div class="it-event-shape-3 d-none d-xxl-block">
         <img src="<?php echo esc_url($od_events_section_shap_img_3['url'], 'odcore');?>" alt="">
      </div>
      <div class="it-event-shape-4 d-none d-xl-block">
         <img src="<?php echo esc_url($od_events_section_shap_img_4['url'], 'odcore');?>" alt="">
      </div>
      <div class="it-event-shape-5">
         <img src="<?php echo esc_url($od_events_section_shap_img_5['url'], 'odcore');?>" alt="">
      </div>
      <div class="it-event-shape-6">
         <img src="<?php echo esc_url($od_events_section_shap_img_6['url'], 'odcore');?>" alt="">
      </div>
      <div class="container">
         <div class="row align-items-center">
            <div class="col-xl-7 col-lg-7">
               <div class="it-event-left">
                  <div class="it-event-title-box">
                     <span class="it-section-subtitle-4">
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/about/t-shape.png" alt="">
                        <?php echo esc_html($tp_sub_title, 'odcore');?>
                     </span>
                     <h2 class="it-section-title-3 pb-20"><?php echo tp_kses($tp_title, 'odcore');?></h2>
                  </div>
                  <div class="it-event-content">
                     <p><?php echo tp_kses($tp_description, 'odcore');?></p>
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                                <?php echo $tp_btn_text; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                  </div>
               </div>
            </div>
            <div class="col-xl-5 col-lg-5">
            	<?php if(!empty($tv_event_thumb['url'])):?>
               <div class="it-event-thumb-box text-center text-lg-start p-relative">
                  <div class="it-event-shape-1 d-none d-lg-block">
                     <img src="<?php echo esc_url($od_events_section_shap_img_1['url'], 'odcore');?>" alt="">
                  </div>
                  <div class="it-event-shape-2">
                     <img src="<?php echo esc_url($od_events_section_shap_img_2['url'], 'odcore');?>" alt="">
                  </div>
                  <div class="it-event-thumb">
                     <img src="<?php echo esc_url($tv_event_thumb['url'], 'odcore');?>" alt="">
                  </div>
               </div>
           <?php endif;?>
            </div>
         </div>
      </div>
      </div>
      <!-- event-area-end -->


		<?php endif;?>


		<?php
	}

	
}

$widgets_manager->register( new Event_Two() );