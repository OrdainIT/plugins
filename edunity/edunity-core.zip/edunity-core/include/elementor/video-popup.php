<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Video_Popup extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'cta-video';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA Video', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                    'layout-5' => esc_html__('Layout 5', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

          // Background Image Section
        $this->start_controls_section(
            'tv_background',
            [
                'label' => esc_html__('Background', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5'],
                ],
            ]
        );

        $this->add_control(
            'tv_video_bg_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/video/bg-1-1.jpg',
                ],
            ]
        );

        $this->end_controls_section();

        // Background Shap
        $this->start_controls_section(
            'od_cta_bg_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5'],
                ],
            ]
        );

        $this->add_control(
			'od_cta_bg_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/video/shape-1-3.png',
				],
			]
		);

        $this->add_control(
			'od_cta_bg_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/video/shape-1-2.png',
				],
			]
		);

        $this->add_control(
			'od_cta_bg_shap_img_3',
			[
				'label' => esc_html__( 'Shap 3', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/video/shape-1-4.png',
				],
			]
		);

        $this->add_control(
			'od_cta_bg_shap_img_4',
			[
				'label' => esc_html__( 'Shap 4', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/video/shape-1-5.png',
				],
			]
		);



        $this->end_controls_section();

          // Thumbnail
        $this->start_controls_section(
            'tv_thumbnail_4',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
            ]
        );

        $this->add_control(
            'tv_video_thumb_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/video/bg-4-2.jpg',
                ],
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5'],
                ],
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

      
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Join Our New Session', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => tp_kses('Call To Enroll Your Child <br> <a href="tel:+91958423452">(+91)958423452</a>', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'od_description',
            [
                
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => tp_kses('Description', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

            // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'odcore'),

                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5'  ],
                ],
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Join With Us', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();
            // button Two
        $this->start_controls_section(
            'tp_btn_button_group2',
            [
                'label' => esc_html__('Button Two', 'odcore'),

                'condition' => [
                    'od_design_style' => [ 'layout-3' ],
                ],
            ]
        );

        $this->add_control(
            'tp_btn_button_show2',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text2',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type2',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show2' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link2',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type2' => '1',
                    'tp_btn_button_show2' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link2',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type2' => '2',
                    'tp_btn_button_show2' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();


        // tp_video
        $this->start_controls_section(
            'tp_video',
            [
                'label' => esc_html__('Video', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-5'],
                ],
            ]
        );

        $this->add_control(
            'tp_video_url',
            [
                'label' => esc_html__('Video', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => 'https://www.youtube.com/watch?v=DjQ_ZMKUxuE',
                'title' => esc_html__('Video url', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'video_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Watch Now', 'odcore'),
                'placeholder' => esc_html__('Type  Text Here', 'odcore'),
                'label_block' => true,
            ]
        ); 

        $this->end_controls_section();

        // video for style 3
        $this->start_controls_section(
            'tp_video3',
            [
                'label' => esc_html__('Video', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-4'],
                ],
            ]
        );

        $this->add_control(
            'tp_video_url3',
            [
                'label' => esc_html__('Video', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => 'https://www.youtube.com/watch?v=DjQ_ZMKUxuE',
                'title' => esc_html__('Video url', 'odcore'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();
       

  



		// TAB_STYLE
		$this->start_controls_section(
			'od_cta_video_area',
			[
				'label' => __( 'CTA Video Area', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_cta_video_area_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-bg::after' => 'background-color: {{VALUE}}',
				],
			]
		);



		$this->end_controls_section();
		// TAB_STYLE
		$this->start_controls_section(
			'od_cta_video_area_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_cta_video_area_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-title' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cta_video_area_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-video-title',
                ],
			]
		);

        $this->add_control(
			'od_cta_video_area_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-content.yellow > span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-video-content > span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cta_video_area_content_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-video-content.yellow > span',
                    '{{WRAPPER}} .it-video-content > span',
                ],
			]
		);
        $this->add_control(
			'od_cta_video_area_content_description_color',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-style-4 .it-video-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'name' => 'od_cta_video_area_content_description_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-video-style-4 .it-video-content p',
                ],
			]
		);



		$this->end_controls_section();

        	// TAB_STYLE
		$this->start_controls_section(
			'od_cta_video_area_button',
			[
				'label' => __( 'Button', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_cta_video_area_button_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_cta_video_area_button_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_cta_video_area_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-yellow i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.theme' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2 ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.theme ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange ' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_normal_icon_bg_color',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2'],
                ],
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow i ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2 i ' => 'background-color: {{VALUE}}',
				],
			]
		);



        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_cta_video_area_button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_cta_video_area_button__hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow:hover ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-yellow:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.theme:hover ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange:hover ' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow:hover ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.theme:hover ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange:hover ' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_hover_icon_bg_color',
			[
                 'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2'],
                ],
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-yellow:hover i ' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i ' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cta_video_area_button_hover_text_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-btn-yellow',
                    '{{WRAPPER}} .ed-btn-theme.theme-2',
                    '{{WRAPPER}} .ed-btn-square.theme',
                    '{{WRAPPER}} .ed-btn-square.orange',
                ],
			]
		);

        $this->end_controls_section();

            	// TAB_STYLE
		$this->start_controls_section(
			'od_cta_video_area_button_2',
			[
                
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'label' => __( 'Button 2', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs(
            'od_cta_video_area_button_2_tabs'
        );

        // Normal

        $this->start_controls_tab(
            'od_cta_video_area_button_2_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_cta_video_area_button_2_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-3' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_cta_video_area_button_2_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-3' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        // Hover

        $this->start_controls_tab(
            'od_cta_video_area_button_2_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'odcore' ),
            ]
        );

        $this->add_control(
			'od_cta_video_area_button_2_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-3:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_cta_video_area_button_2_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-3:hover' => 'background-color: {{VALUE}}',
				],
			]
		);



        $this->end_controls_tab();

        $this->end_controls_tabs();




        $this->end_controls_section();

          	// TAB_STYLE
		$this->start_controls_section(
			'od_cta_video_area_button_video',
			[
				'label' => __( 'Video Button', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_cta_video_area_button_video_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-play a.play ' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-video-style-2 .it-video-play a.play i ' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_video_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-play a.play ' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_cta_video_area_button_video_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-video-play a.text ' => 'color: {{VALUE}}',
				],
			]
		);

        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_cta_video_area_button_video_text_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-video-play a.text',
                ],
			]
		);



        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$tv_video_bg_img = $settings['tv_video_bg_img'];
		$tp_video_url = $settings['tp_video_url'];
		$video_btn_text = $settings['video_btn_text'];
		$tp_sub_title = $settings['tp_sub_title'];
		$tp_title = $settings['tp_title'];
		$tp_btn_text = $settings['tp_btn_text'];
		$tp_btn_button_show = $settings['tp_btn_button_show'];

        $od_cta_bg_shap_img_1 = $settings['od_cta_bg_shap_img_1'];
        $od_cta_bg_shap_img_2 = $settings['od_cta_bg_shap_img_2'];
        $od_cta_bg_shap_img_3 = $settings['od_cta_bg_shap_img_3'];
        $od_cta_bg_shap_img_4 = $settings['od_cta_bg_shap_img_4'];

		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ):


			 // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
                }
            }


        ?>



        <!-- video-area-start -->
      <div class="it-video-area it-video-bg it-video-color p-relative fix pt-100 pb-95" style="background-image:url(<?php echo esc_url($tv_video_bg_img['url'], 'odcore');?>)">
         <div class="it-video-shape-1 d-none d-lg-block">
            <img src="<?php echo get_template_directory_uri();?>/assets/img/video/shape-1-1.png" alt="">
         </div>
         <div class="it-video-shape-2 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-3 d-none d-xl-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-4 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-5 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <div class="it-video-content">
                     <span><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                     <h3 class="it-video-title"><?php echo tp_kses($tp_title, 'odcore');?></h3>
                     <div class="it-video-button">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            	<?php echo $tp_btn_text; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-lg-5 col-md-3 col-sm-3">
                  <div
                     class="it-video-play-wrap d-flex justify-content-start justify-content-md-end align-items-center">
                     <div class="it-video-play text-center">
                        <a class="popup-video play" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><i
                              class="fas fa-play"></i></a>
                        <a class="text" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><?php echo esc_html($video_btn_text, 'odcore');?></a>
                     </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- video-area-end -->


    <?php elseif ( $settings['od_design_style']  == 'layout-3' ):


			$tp_btn_button_show2 = $settings['tp_btn_button_show2'];
			$tp_btn_text2 = $settings['tp_btn_text2'];
			$tp_video_url3 = $settings['tp_video_url3'];
            $od_description = $settings['od_description'];


    		 // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square theme mr-25');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square theme mr-25');
                }
            }
    		 // Link
            if ('2' == $settings['tp_btn_link_type2']) {
                $this->add_render_attribute('tp-button-arg2', 'href', get_permalink($settings['tp_btn_page_link2']));
                $this->add_render_attribute('tp-button-arg2', 'target', '_self');
                $this->add_render_attribute('tp-button-arg2', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg2', 'class', 'ed-btn-square purple-3');
            } else {
                if ( ! empty( $settings['tp_btn_link2']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg2', $settings['tp_btn_link2'] );
                    $this->add_render_attribute('tp-button-arg2', 'class', 'ed-btn-square purple-3');
                }
            }




     ?>


      <!-- video-area-start -->
      <div class="it-video-area it-video-style-4 it-video-bg ed-video-style-2 p-relative fix" style="background-image:url(<?php echo esc_url($tv_video_bg_img['url'], 'odcore');?>)">
         <div class="it-video-shape-2 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-5 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-6 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <div class="it-video-content">
                     <span class="it-section-subtitle-5 sky">
                        <img src="<?php echo esc_url($od_cta_bg_shap_img_1['url'], 'odcore');?>" alt="">
                       <?php echo esc_html($tp_sub_title, 'odcore');?></span>
                     <h3 class="it-video-title"><?php echo tp_kses($tp_title, 'odcore');?></h3>
                     <p><?php echo tp_kses($od_description, 'odcore');?></p>
                     <div class="it-video-button">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                       		<span>
                            	<?php echo $tp_btn_text; ?>
                           </span>
                        </a>
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg2' ); ?>>
                       		<span>
                            	<?php echo $tp_btn_text2; ?>
                           </span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-lg-5 col-md-3 col-sm-3">
                  <div
                     class="it-video-play-wrap d-flex justify-content-center align-items-center">
                     <div class="it-video-play text-center">
                        <a class="popup-video play" href="<?php echo esc_url($tp_video_url3, 'odcore');?>"><i
                              class="fas fa-play"></i></a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- video-area-end -->



    <?php elseif ( $settings['od_design_style']  == 'layout-4' ):

    	$tv_video_thumb_img = $settings['tv_video_thumb_img'];
    	$tp_video_url3 = $settings['tp_video_url3'];


     ?>



      <!-- video-area-start --> 
      <div class="ed-video-area fix ed-video-bg p-relative pt-160 pb-120" style="background-image:url(<?php echo esc_url($tv_video_bg_img['url'], 'odcore');?>)">
         <div class="ed-video-shape-1">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-video-shape-2">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <div class="row">
               <div class="col-xl-12">
               	<?php if(!empty($tv_video_thumb_img['url'])):?>
                  <div class="ed-video-wrap" style="background-image:url(<?php echo esc_url($tv_video_thumb_img['url'], 'odcore');?>)">
                     <div
                     class="it-video-play-wrap">
                     <div class="it-video-play">
                        <a class="popup-video play" href="<?php echo esc_url($tp_video_url3, 'odcore');?>"><i
                              class="fas fa-play"></i></a>
                     </div>
                  </div>
                  </div>
              <?php endif;?>
               </div>
            </div>
         </div>
      </div>
      <!-- video-area-end --> 

 	 <?php elseif ( $settings['od_design_style']  == 'layout-5' ):



			 // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
                }
            }
           



     ?>

         <!-- video-area-start -->
       <div class="it-video-area it-video-bg it-video-color p-relative fix pt-100 pb-95" style="background-image:url(<?php echo esc_url($tv_video_bg_img['url'], 'odcore');?>)">
       <div class="it-video-shape-1 d-none d-lg-block">
          <img src="<?php echo get_template_directory_uri();?>/assets/img/video/shape-1-1.png" alt="">
       </div>
       <div class="it-video-shape-2 d-none d-lg-block">
          <img src="<?php echo esc_url($od_cta_bg_shap_img_2['url'], 'odcore');?>" alt="">
       </div>
       <div class="it-video-shape-3 d-none d-xl-block">
          <img src="<?php echo esc_url($od_cta_bg_shap_img_1['url'], 'odcore');?>" alt="">
       </div>
       <div class="it-video-shape-4 d-none d-lg-block">
          <img src="<?php echo esc_url($od_cta_bg_shap_img_3['url'], 'odcore');?>" alt="">
       </div>
       <div class="it-video-shape-5 d-none d-lg-block">
          <img src="<?php echo esc_url($od_cta_bg_shap_img_4['url'], 'odcore');?>" alt="">
       </div>
       <div class="container">
          <div class="row align-items-center">
             <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                <div class="it-video-content">
                   <span><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                   <h3 class="it-video-title"><?php echo tp_kses($tp_title, 'odcore');?></h3>
                   <div class="it-video-button">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                       	 	<span>
                            	<?php echo $tp_btn_text; ?>
                            <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                               xmlns="http://www.w3.org/2000/svg">
                               <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                  stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                               <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                  stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                         </i>
                      </a>
                   </div>
                </div>
             </div>
             <div class="col-xl-5 col-lg-5 col-md-3 col-sm-3">
                <div
                   class="it-video-play-wrap d-flex justify-content-start justify-content-md-end align-items-center">
                   <div class="it-video-play text-center">
                        <a class="popup-video play" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><i
                              class="fas fa-play"></i></a>
                        <a class="text" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><?php echo esc_html($video_btn_text, 'odcore');?></a>
                   </div>
                </div>
             </div>
          </div>
       </div>
       </div>
      <!-- video-area-end -->

		<?php else:


			 // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-yellow');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-yellow');
                }
            }
           

            

		?>	
       <!-- video-area-start -->
      <div class="it-video-area it-video-bg p-relative fix pt-100 pb-95" style="background-image:url(<?php echo esc_url($tv_video_bg_img['url'], 'odcore');?>)">
         <div class="it-video-shape-2 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-3 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-4 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-video-shape-5 d-none d-lg-block">
            <img src="<?php echo esc_url($od_cta_bg_shap_img_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <div class="it-video-content yellow">
                     <span><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                     <h3 class="it-video-title"><?php echo tp_kses($tp_title, 'odcore');?></h3>
                     <div class="it-video-button">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                       	 	<span>
                            	<?php echo $tp_btn_text; ?>
                              <i>
                                 <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                       stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                       stroke-linecap="round" stroke-linejoin="round" />
                                 </svg>
                              </i>
                           </span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-lg-5 col-md-3 col-sm-3">
                  <div
                     class="it-video-play-wrap d-flex justify-content-start justify-content-md-end align-items-center">
                     <div class="it-video-play text-center">
                        <a class="popup-video play" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><i
                              class="fas fa-play"></i></a>
                        <a class="text" href="<?php echo esc_url($tp_video_url, 'odcore');?>"><?php echo esc_html($video_btn_text, 'odcore');?></a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- video-area-end -->
        <?php endif; ?>

        <?php 
		
	}

}

$widgets_manager->register( new TP_Video_Popup() );