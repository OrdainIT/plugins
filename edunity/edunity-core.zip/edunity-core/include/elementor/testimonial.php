<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Testimonial extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'testimonial';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                    'layout-5' => esc_html__('Layout 5', 'odcore'),
                    'layout-6' => esc_html__('Layout 6', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

          // layout Panel
        $this->start_controls_section(
            'od_testimonial_settings',
            [
                'label' => esc_html__('Settings', 'odcore'),
            ]
        );

        $this->add_control(
			'od_testimonial_autoplay_switcher',
			[
				'label' => esc_html__( 'Autoplay On/Off', 'odcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'odcore' ),
				'label_off' => esc_html__( 'Off', 'odcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();

            // layout Panel
        $this->start_controls_section(
            'od_testimonial_section_shap',
            [
                'label' => esc_html__('shap', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-4'],
                ],
            ]
        );

        $this->add_control(
			'od_testimonial_section_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/testimonial/shape-4-1.png',
				],
			]
		);
        $this->add_control(
			'od_testimonial_section_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/testimonial/shape-5-3.png',
				],
			]
		);


        $this->end_controls_section();

          // layout Panel
        $this->start_controls_section(
            'tv_background',
            [
                'label' => esc_html__('Background', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
            ]
        );

        $this->add_control(
            'tv_bg_img',
            [
                'label' => esc_html__('Upload Image', 'odcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/testimonial/testimonial-bg.jpg'
                ],
                'placeholder' => esc_html__('Upload Image', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
			'od_testimonial_area_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-ptb' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-testimonial-3-area' => 'background-color: {{VALUE}}',
				],
			]
		);






        $this->end_controls_section();
        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-4', 'layout-5'],
                ],
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Testimonial', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Creating A Community Of Life Long Learners.', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );      

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Description here', 'odcore'),
                'placeholder' => esc_html__('Type section description here', 'odcore'),
            ]
        );

  


        $this->end_controls_section();


    

        // Review group
        $this->start_controls_section(
            'testimonial_items_section',
            [
                'label' => esc_html__( 'Testimonail List', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'testimonial_items',
            [
                'label' => esc_html__( 'Testimonail', 'odcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'testi_name',
                        'label' => esc_html__( 'Name', 'odcoreodcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Kathy Sullivan' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'testi_designation',
                        'label' => esc_html__( 'Designation', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Marketing Manager' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'testi_description',
                        'label' => esc_html__( 'Description', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => esc_html__( '“Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Orci nulla pellentesque dignissim enim. Amet consectetur adipiscing”' , 'odcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'testi_avatar',
                        'label' => esc_html__( 'Avatar Image', 'odcore' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'testi_name' => esc_html__( 'Kathy Sullivan', 'odcore' ),
                    ],
                    [
                        'testi_name' => esc_html__( 'Kathy Sullivan', 'odcore' ),
                    ],
                    [
                        'testi_name' => esc_html__( 'Kathy Sullivan', 'odcore' ),
                    ],
                    [
                        'testi_name' => esc_html__( 'Kathy Sullivan', 'odcore' ),
                    ],
                ],
                'title_field' => '{{{ testi_name }}}',
            ]
        );
       
       

       

        $this->end_controls_section();

		  // Rating
        $this->start_controls_section(
            'testimonail_rating',
            [
                'label' => __('Rating', 'odcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-7']
                ],
            ]
        );


        $this->add_control(
            'show_rating',
            [
                'label' => esc_html__( 'Show Rating', 'odcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_control(
            'rating_title',
            [
                'label' => esc_html__( 'Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'AVG RATING 4.9K', 'odcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
            ]
        );

         $this->end_controls_section();

           // Reveiws
        $this->start_controls_section(
            'testimonail_reveiws',
            [
                'label' => __('Review', 'odcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-7']
                ],
            ]
        );
         $this->add_control(
            'show_reveiw',
            [
                'label' => esc_html__( 'Show Review', 'odcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
         $this->add_control(
            'review_title',
            [
                'label' => esc_html__( 'Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'GOOGLE REVIEW', 'odcore' ),
                'placeholder' => esc_html__( 'Type your title here', 'odcore' ),
            ]
        );

         $this->end_controls_section();



        // _section_logo_list
        $this->start_controls_section(
            'testimonail_thumbnail',
            [
                'label' => __('Thumbnail', 'odcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' =>['layout-2', 'layout-3'],
                ],
            ]
        );

        $this->add_control(
            'testi_image',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/testimonial/thumb-2.png',
                ],
            ]
        );
  


        $this->end_controls_section();

        // TAB_STYLE
		$this->start_controls_section(
			'od_testimonial_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4', 'layout-5'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      
		$this->add_control(
			'od_testimonial_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_testimonial_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-title',
                ],
			]
		);


          
		$this->add_control(
			'od_testimonial_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_testimonial_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5.orange' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_testimonial_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-subtitle',
                    '{{WRAPPER}} .it-section-subtitle-5.orange',
                ],
			]
		);

	

		$this->end_controls_section();
        // TAB_STYLE
		$this->start_controls_section(
			'od_testimonial_content',
			[
				'label' => __( 'Testimonial Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        
		$this->add_control(
			'od_testimonial_content_shap_img_1',
			[
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-2'],
                ],
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/testimonial/bg-3.png',
				],
			]
		);
		$this->add_control(
			'od_testimonial_content_shap_img_2',
			[
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-2'],
                ],
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/testimonial/shape-3-1.png',
				],
			]
		);



        $this->add_control(
			'od_testimonial_content_area_bg',
			[
				'label' => esc_html__( 'Content BG Color', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-item' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_testimonial_content_area_border',
			[
				'label' => esc_html__( 'Content Border Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-item' => 'border-color: {{VALUE}}',
				],
			]
		);


        $this->add_control(
			'od_testimonial_content_title_color',
			[
				'label' => esc_html__( 'Title  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-author-box h5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-testimonial-3-author-info h5' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_testimonial_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-testimonial-author-box h5',
                    '{{WRAPPER}} .it-testimonial-3-author-info h5',
                ],
			]
		);

        $this->add_control(
			'od_testimonial_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-author-box span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-testimonial-3-author-info span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_testimonial_content_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-testimonial-author-box span',
                    '{{WRAPPER}} .it-testimonial-3-author-info span',
                ],
			]
		);
        $this->add_control(
			'od_testimonial_content_description_color',
			[
				'label' => esc_html__( 'Description  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-testimonial-3-content p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_testimonial_content_description_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-testimonial-text p',
                    '{{WRAPPER}} .it-testimonial-3-content p',
                ],
			]
		);

         $this->add_control(
			'od_testimonial_content_star_color',
			[
				'label' => esc_html__( 'Star  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-testimonial-style-3 .ed-testimonial-ratting i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-testimonial-style-3 .ed-testimonial-item' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-testimonial-style-2 .ed-testimonial-item' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-testimonial-ratting i' => 'color: {{VALUE}}',
				],
			]
		);

	

		$this->end_controls_section();
        // TAB_STYLE
		$this->start_controls_section(
			'od_testimonial_dots_content',
			[
				'label' => __( 'Dots', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_testimonial_dots_switcher',
			[
				'label' => esc_html__( 'Dots Show/Hide', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'od_testimonial_dots_color',
			[
				'label' => esc_html__( 'Dots  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .test-slider-dots .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .test-slider-dots .swiper-pagination-bullet::after' => 'border-color: {{VALUE}}',
				],
			]
		);



	

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


        $tp_section_title_show = $settings['tp_section_title_show'];
        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $tp_desctiption = $settings['tp_desctiption'];

        $od_testimonial_content_shap_img_1 = $settings['od_testimonial_content_shap_img_1'];
        $od_testimonial_content_shap_img_2 = $settings['od_testimonial_content_shap_img_2'];
        $od_testimonial_dots_switcher = $settings['od_testimonial_dots_switcher'];

		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ):


        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];
        $testi_image_thumb = $settings['testi_image'];
        ?>
         

      <!-- testimonial-area-start -->
      <div class="it-testimonial-3-area fix" style="background-image: url(<?php echo esc_url($tv_bg_img['url'], 'odcore');?>);" >
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-5 col-lg-4 d-none d-lg-block">
                  <div class="it-testimonial-3-thumb">
                     <img src="<?php echo esc_url($testi_image_thumb['url'], 'odcore');?>" alt="">
                  </div>
               </div>
               <div class="col-xl-7 col-lg-8">
                  <div class="it-testimonial-3-box z-index p-relative">
                     <div class="it-testimonial-3-shape-1">
                        <img src="<?php echo esc_url($od_testimonial_content_shap_img_2['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="it-testimonial-3-wrapper p-relative" style="background-image:url(<?php echo esc_url($od_testimonial_content_shap_img_1['url'], 'odcore');?>)">
                        <div class="it-testimonial-3-quote d-none d-md-block">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/testimonial/quot.png" alt="">
                        </div>
                        <div class="swiper-container it-testimonial-3-active">
                           <div class="swiper-wrapper">

                            <?php foreach($testimonial_items as $single_item):
                                $testi_avatar_url = $single_item['testi_avatar'];
                            ?>
                              <div class="swiper-slide">
                                 <div class="it-testimonial-3-item">
                                    <div class="it-testimonial-3-content">
                                       <p><?php echo tp_kses($single_item['testi_description']);?></p>
                                       <div class="it-testimonial-3-author-box d-flex align-items-center">
                                          <div class="it-testimonial-3-avata">
                                             <img src="<?php echo esc_url($testi_avatar_url['url']);?>" alt="">
                                          </div>
                                          <div class="it-testimonial-3-author-info">
                                             <h5><?php echo esc_html($single_item['testi_name']);?></h5>
                                             <span><?php echo esc_html($single_item['testi_designation']);?></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                          <?php endforeach;?>
                           </div>
                        </div>
                        <?php if(!empty($od_testimonial_dots_switcher)): ?>
                        <div class="test-slider-dots d-none d-sm-block"></div>
                        <?php endif;?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->

    <?php elseif ( $settings['od_design_style']  == 'layout-3' ):

        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];
        $testi_image_thumb = $settings['testi_image'];
    ?>


      <!-- testimonial-area-start -->
      <div class="it-testimonial-3-area fix" style="background-image: url(<?php echo esc_url($tv_bg_img['url'], 'odcore');?>);" >
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-5 col-lg-4 d-none d-lg-block">
                  <div class="it-testimonial-3-thumb">
                     <img src="<?php echo esc_url($testi_image_thumb['url'], 'odcore');?>" alt="">
                  </div>
               </div>
               <div class="col-xl-7 col-lg-8">
                  <div class="it-testimonial-3-box z-index p-relative">
                     <div class="it-testimonial-3-shape-1">
                        <img src="<?php echo esc_url($od_testimonial_content_shap_img_2['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="it-testimonial-3-wrapper p-relative" style="background-image:url(<?php echo esc_url($od_testimonial_content_shap_img_1['url'], 'odcore');?>)">
                        <div class="it-testimonial-3-quote d-none d-md-block">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/testimonial/quot.png" alt="">
                        </div>
                        <div class="swiper-container it-testimonial-3-active">
                           <div class="swiper-wrapper">

                            <?php foreach($testimonial_items as $single_item):
                                $testi_avatar_url = $single_item['testi_avatar'];
                            ?>

                              <div class="swiper-slide">
                                 <div class="it-testimonial-3-item">
                                    <div class="it-testimonial-3-content">
                                       <p><?php echo tp_kses($single_item['testi_description']);?></p>
                                       <div class="it-testimonial-3-author-box d-flex align-items-center">
                                          <div class="it-testimonial-3-avata">
                                             <img src="<?php echo esc_url($testi_avatar_url['url'], 'odcore');?>" alt="">
                                          </div>
                                          <div class="it-testimonial-3-author-info">
                                             <h5><?php echo esc_html($single_item['testi_name']);?></h5>
                                             <span><?php echo esc_html($single_item['testi_designation']);?></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                          <?php endforeach;?>
                           </div>
                        </div>
                        <div class="test-slider-dots d-none d-sm-block"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->
        

    <?php elseif ( $settings['od_design_style']  == 'layout-4' ):


        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];
        $testi_image_thumb = $settings['testi_image'];
        $od_testimonial_section_shap_img_1 = $settings['od_testimonial_section_shap_img_1'];
        $od_testimonial_section_shap_img_2 = $settings['od_testimonial_section_shap_img_2'];

    ?>


     <!-- testimonial-area-start -->
      <div class="it-testimonial-area ed-testimonial-style-2 ed-testimonial-style-3 pt-120 pb-120 fix p-relative">
         <div class="ed-testimonial-shape-1">
            <img src="<?php echo esc_url($od_testimonial_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-testimonial-shape-2 d-none d-xxl-block">
            <img src="<?php echo esc_url($od_testimonial_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="it-testimonial-title-wrap mb-55">
               <div class="row justify-content-center">
                  <div class="col-xl-6">
                     <div class="it-testimonial-title-box text-center">
                        <span class="it-section-subtitle-5 orange"><i class="fa-light fa-book"></i><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
               <div class="col-xl-12">
                  <div class="ed-testimonial-wrapper">
                     <div class="swiper-container ed-testimonial-active">
                        <div class="swiper-wrapper">
                            <?php foreach($testimonial_items as $single_item):
                                 $testi_avatar_url = $single_item['testi_avatar'];
                                ?>
                           <div class="swiper-slide">
                              <div class="ed-testimonial-item p-relative">
                                 <div class="ed-testimonial-ratting">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                 </div>
                                 <div class="ed-testimonial-text">
                                    <p><?php echo tp_kses($single_item['testi_description']);?></p>
                                 </div>
                                 <div class="ed-testimonial-author-box d-flex align-items-center">
                                    <div class="ed-testimonial-author mr-15">
                                       <img src="<?php echo esc_url($testi_avatar_url['url'], 'odcore')?>" alt="">
                                    </div>
                                    <div>
                                       <h5><?php echo esc_html($single_item['testi_name']);?></h5>
                                       <span><?php echo esc_html($single_item['testi_designation']);?></span>
                                    </div>                                       
                                 </div>
                              </div>
                           </div>
                       <?php endforeach;?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->



        <?php elseif ( $settings['od_design_style']  == 'layout-5' ):


        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];
        $testi_image_thumb = $settings['testi_image'];

    ?>


     <!-- testimonial-area-start -->
      <div class="it-testimonial-area ed-testimonial-style-2 pt-120 pb-120 fix p-relative">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="it-testimonial-title-wrap mb-65">
               <div class="row justify-content-center">
                  <div class="col-xl-6">
                     <div class="it-testimonial-title-box text-center">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
               <div class="col-xl-12">
                  <div class="ed-testimonial-wrapper">
                     <div class="swiper-container ed-testimonial-active">
                        <div class="swiper-wrapper">
                            <?php foreach($testimonial_items as $single_item):
                                 $testi_avatar_url = $single_item['testi_avatar'];
                                ?>
                           <div class="swiper-slide">
                              <div class="ed-testimonial-item p-relative">
                                 <div class="ed-testimonial-ratting">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                 </div>
                                 <div class="ed-testimonial-text">
                                    <p><?php echo tp_kses($single_item['testi_description']);?></p>
                                 </div>
                                 <div class="ed-testimonial-author-box d-flex align-items-center">
                                    <div class="ed-testimonial-author mr-15">
                                       <img src="<?php echo esc_url($testi_avatar_url['url'], 'odcore')?>" alt="">
                                    </div>
                                    <div>
                                       <h5><?php echo esc_html($single_item['testi_name']);?></h5>
                                       <span><?php echo esc_html($single_item['testi_designation']);?></span>
                                    </div>                                       
                                 </div>
                              </div>
                           </div>
                       <?php endforeach;?>

                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->




        <?php elseif ( $settings['od_design_style']  == 'layout-6' ):


        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];
        $testi_image_thumb = $settings['testi_image'];


        ?>



        <!-- testimonial-area-start -->
      <div class="it-testimonial-area ed-testimonial-style-2 pt-120 pb-120 fix p-relative">
         <div class="container">
            <div class="row">

            <?php foreach($testimonial_items as $single_item):
                 $testi_avatar_url = $single_item['testi_avatar'];
                ?>
               <div class="col-xl-4 col-lg-6 mb-30">
                  <div class="ed-testimonial-item p-relative">
                     <div class="ed-testimonial-ratting">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                     </div>
                     <div class="ed-testimonial-text">
                        <p><?php echo tp_kses($single_item['testi_description']);?></p>
                     </div>
                     <div class="ed-testimonial-author-box d-flex align-items-center">
                        <div class="ed-testimonial-author mr-15">
                           <img src="<?php echo esc_url($testi_avatar_url['url'], 'odcore')?>" alt="">
                        </div>
                        <div>
                           <h5><?php echo esc_html($single_item['testi_name']);?></h5>
                           <span><?php echo esc_html($single_item['testi_designation']);?></span>
                        </div>                                       
                     </div>
                  </div>
               </div>
            <?php endforeach;?>

            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->


      




	<?php else:

        $tv_bg_img = $settings['tv_bg_img'];
        $testimonial_items = $settings['testimonial_items'];


    ?>


         
     <!-- testimonial-area-start -->
      <div class="it-testimonial-area ed-testimonial-ptb fix p-relative" style="background-image: url(<?php echo esc_url($tv_bg_img['url'], 'odcore');?>);">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="it-testimonial-title-wrap mb-90">
               <div class="row justify-content-center">
                  <div class="col-xl-6">
                     <div class="it-testimonial-title-box text-center">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
               <div class="col-xl-12">
                  <div class="ed-testimonial-wrapper">
                     <div class="swiper-container ed-testimonial-active">
                        <div class="swiper-wrapper">
                            <?php foreach($testimonial_items as $single_item):?>
                           <div class="swiper-slide">
                              <div class="ed-testimonial-item p-relative">
                                 <div class="ed-testimonial-quote">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/img/testimonial/ed-quot.png" alt="">
                                 </div>
                                 <div class="ed-testimonial-text">
                                    <p><?php echo tp_kses($single_item['testi_description'], 'odcore');?></p>
                                 </div>
                                 <div class="ed-testimonial-author-box">
                                    <h5><?php echo esc_html($single_item['testi_name'], 'odcore');?></h5>
                                    <span><?php echo esc_html($single_item['testi_designation'], 'odcore');?></span>
                                 </div>
                              </div>
                           </div>
                       <?php endforeach;?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- testimonial-area-end -->


        <?php endif; 
            $od_testimonial_autoplay_switcher = $settings['od_testimonial_autoplay_switcher'];

            
        ?>
            <script>
                "use strict";
                jQuery(document).ready(function($) {
                    // 13. Swiper Js    
                    const sliderAutoplay1 = <?php echo $od_testimonial_autoplay_switcher ? 'true' : 'false'; ?>;
                    const testi1swiper = new Swiper('.ed-testimonial-active', {
                        // Optional parameters
                        speed:1500,
                        loop: true,
                        slidesPerView: 3,
                        spaceBetween: 50,
                        autoplay: sliderAutoplay1 ? { delay: 3000 } : false,
                        breakpoints: {
                            '1400': {
                                slidesPerView: 3,
                            },
                            '1200': {
                                slidesPerView: 3,
                            },
                            '992': {
                                slidesPerView: 2,
                            },
                            '768': {
                                slidesPerView: 1,
                            },
                            '576': {
                                slidesPerView: 1,
                            },
                            '0': {
                                slidesPerView: 1,
                            },
                        },
                    });



                  const sliderAutoplay2 = <?php echo $od_testimonial_autoplay_switcher ? 'true' : 'false'; ?>;
                      
                   // 13. Swiper Js 
                    const testi3swiper = new Swiper('.it-testimonial-3-active', {
                        // Optional parameters
                        speed:500,
                        loop: true,
                        slidesPerView: 1,
                        spaceBetween: 30,
                        autoplay: sliderAutoplay2 ? { delay: 3000 } : false,
                        centeredSlides: true,
                        roundLengths: true,
                        breakpoints: {
                            '1400': {
                                slidesPerView: 1,
                            },
                            '1200': {
                                slidesPerView: 1,
                            },
                            '992': {
                                slidesPerView: 1,
                            },
                            '768': {
                                slidesPerView: 1,
                            },
                            '576': {
                                slidesPerView: 1,
                            },
                            '0': {
                                slidesPerView: 1,
                            },
                        },
                        pagination: {
                            el: ".test-slider-dots",
                            clickable:true,
                          },
                      });

                    
                       const sliderAutoplay3 = <?php echo $od_testimonial_autoplay_switcher ? 'true' : 'false'; ?>;

                    const testi2swiper = new Swiper('.it-testimonial-2-active', {
                        // Optional parameters
                        speed:1000,
                        loop: true,
                        slidesPerView: 1,
                        spaceBetween: 30,
                        autoplay: sliderAutoplay3 ? { delay: 3000 } : false,
                        centeredSlides: true,
                        roundLengths: true,
                        breakpoints: {
                            '1400': {
                                slidesPerView: 1,
                            },
                            '1200': {
                                slidesPerView: 1,
                            },
                            '992': {
                                slidesPerView: 1,
                            },
                            '768': {
                                slidesPerView: 1,
                            },
                            '576': {
                                slidesPerView: 1,
                            },
                            '0': {
                                slidesPerView: 1,
                            },
                        },
                        pagination: {
                            el: ".it-service-3-dots",
                            clickable:true,
                          },
                      });

                    const sliderAutoplay4 = <?php echo $od_testimonial_autoplay_switcher ? 'true' : 'false'; ?>;
                    const testi4Swiper = new Swiper('.it-testi-4-active', {
                        // Optional parameters
                        speed:1000,
                        loop: true,
                        slidesPerView: 3,
                        spaceBetween: 30,
                        autoplay: sliderAutoplay4 ? { delay: 3000 } : false,
                        breakpoints: {
                            '1400': {
                                slidesPerView: 3,
                            },
                            '1200': {
                                slidesPerView: 3,
                            },
                            '992': {
                                slidesPerView: 3,
                            },
                            '768': {
                                slidesPerView: 2,
                            },
                            '576': {
                                slidesPerView: 1,
                            },
                            '0': {
                                slidesPerView: 1,
                            },
                        },
                        navigation: {
                            prevEl: '.testi-prev',
                            nextEl: '.testi-next',
                        },
                      });

                });
            </script>
        <?php 
	}
}

$widgets_manager->register( new TP_Testimonial() );