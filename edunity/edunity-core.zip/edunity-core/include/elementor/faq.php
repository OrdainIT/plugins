<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_FAQ extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {


		 // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),

                ],
                'default' => 'layout-1',
            ]
        );


        $this->end_controls_section();


		 // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' => [
                    'od_design_style' => [ 'layout-1'  ],
                ],
            ]
        );

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('FAQ', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Frequently asked some questions?', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );

      

        $this->end_controls_section();

		$this->start_controls_section(
            '_accordions_area',
            [
                'label' => esc_html__( 'Accordion', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

			$this->add_control(
			'_accordion_list_section',
			[
				'label' => esc_html__( 'Accordion List', 'odcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'accordion_title',
						'label' => esc_html__( 'Title', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Why do students prefer online learning?' , 'odcore' ),
						'label_block' => true,
					],
					[
						'name' => 'accordion_description',
						'label' => esc_html__( 'Content', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur elit, sed doeiusmod tempor
                                       incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                       nostrud exercitation.' , 'odcore' ),
					],
					[
						'name' => 'accordion_img',
						'label' => esc_html__( 'Content', 'odcore' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => get_template_directory_uri().'/assets/img/faq/thumb-2.jpg',
						],
					],

				],
				'default' => [
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
					[
						'accordion_title' => esc_html__( 'Why do students prefer online learning?', 'odcore' ),
					],
				],
				'title_field' => '{{{ accordion_title }}}',
			]
		);

       $this->end_controls_section();

        $this->start_controls_section(
            '_accordion_thumbnail',
            [
                'label' => esc_html__( 'Accordion Thumbnail', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => [ 'layout-1'  ],
                ],
            ]
        );

        $this->add_control(
			'accordian_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri().'/assets/img/faq/faq-2.jpg',
				],
			]
		);


         $this->end_controls_section();



		$this->start_controls_section(
			'od_faq_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
				  'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'od_faq_title_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-5' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_title_content_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-5',
			]
		);
		$this->add_control(
			'od_faq_title_content_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_faq_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_title_content_subtitle_typography',
				'selector' => '{{WRAPPER}} .ed-section-subtitle',
			]
		);


		

		

		$this->end_controls_section();
		$this->start_controls_section(
			'od_faq_content',
			[
				'label' => __( 'Faq Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
            'od_faq_content_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_faq_content_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

		 $this->add_control(
			'od_faq_content_normal_accordain_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-buttons' => 'background-color: {{VALUE}}',
				],
			]
		);
		 $this->add_control(
			'od_faq_content_normal_accordain_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-buttons' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-custom-accordion .accordion-buttons::after' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_faq_content_hover_tab',
            [
               'label' => esc_html__( 'Active', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_faq_content_hover_accordain_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .accordion-buttons:not(.collapsed)' => 'background-color: {{VALUE}}',
				],
			]
		);
		 $this->add_control(
			'od_faq_content_hover_accordain_bg_active',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .accordion-buttons:not(.collapsed)' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-custom-accordion .accordion-buttons:not(.collapsed)::after' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_content_hover_accordain_title_typography',
				'selector' => '{{WRAPPER}} .it-custom-accordion .accordion-buttons',
			]
		);

		$this->add_control(
			'od_faq_content_hover_accordain_area_border_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion .accordion-items' => 'border-color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'od_faq_content_hover_accordain_area_description_color',
			[
				'label' => esc_html__( 'Description Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion-style-2 .accordion-body p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-custom-accordion .accordion-body p' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_faq_content_hover_accordain_area_description_typography',
				'selectors' => [
					'{{WRAPPER}} .it-custom-accordion-style-2 .accordion-body p',
					'{{WRAPPER}} .it-custom-accordion .accordion-body p',
				],
			]
		);





		

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$tp_sub_title = $settings['tp_sub_title'];
		$tp_title = $settings['tp_title'];
		$accordian_items = $settings['_accordion_list_section'];
		$accordian_thumb = $settings['accordian_thumb'];

		?>


		<?php if ( $settings['od_design_style']  == 'layout-2' ):?>

                  <div class="it-faq-wrap">
                     <div class="it-custom-accordion it-custom-accordion-style-3 inner-style">
                        <div class="accordion" id="accordionExample">

                        <?php 
                        	$i=0;
                        	foreach($accordian_items as $single_item):
                        		$single_item_img = $single_item['accordion_img'];
                        	$i++;
                        ?>
                           <div class="accordion-items tp-faq-active">
                              <h2 class="accordion-header" id="heading<?php echo esc_attr($i, 'odcore');?>">
                                 <button class="accordion-buttons <?php echo ($i === 1) ? '' : 'collapsed'; ?> " type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse<?php echo esc_attr($i, 'odcore');?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i, 'odcore');?>">
                                    <?php echo esc_html($single_item['accordion_title']);?>
                                 </button>
                              </h2>
                              <div id="collapse<?php echo esc_attr($i, 'odcore');?>" class="accordion-collapse collapse "
                                 aria-labelledby="heading<?php echo esc_attr($i, 'odcore');?>" data-bs-parent="#accordionExample">
                                 <div class="accordion-body d-flex align-items-center">
                                    <p class="mb-0"><?php echo tp_kses($single_item['accordion_description']);?></p>
                                    <img class="d-none d-xl-block" src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt="">
                                 </div>
                              </div>
                           </div>

                       <?php endforeach;?>

                        </div>
                     </div>
                  </div>


        <?php else: 

	?>	

		
      <!-- faq-area-start -->
      <div class="it-faq-area p-relative pt-120 pb-120">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-6 col-lg-6 wow itfadeLeft" data-wow-duration=".9s"
               data-wow-delay=".5s">
                  <div class="it-faq-thumb text-center text-lg-start">
                     <img src="<?php echo esc_url($accordian_thumb['url'], 'odcore');?>" alt="">
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow itfadeRight" data-wow-duration=".9s"
               data-wow-delay=".7s">
                  <div class="it-faq-wrap">
                     <div class="it-faq-title-box mb-20">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="it-section-title-5"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                     <div class="it-custom-accordion it-custom-accordion-style-2">
                        <div class="accordion" id="accordionExample">
                        <?php 
                        	$i=0;
                        	foreach($accordian_items as $single_item):
                        		$single_item_img = $single_item['accordion_img'];
                        	$i++;
                        ?>
                           <div class="accordion-items">
                              <h2 class="accordion-header" id="heading<?php echo esc_attr($i, 'odcore');?>">
                                 <button class="accordion-buttons <?php echo ($i === 1) ? '' : 'collapsed'; ?>" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse<?php echo esc_attr($i, 'odcore');?>" aria-expanded="<?php if($i==1){ echo "true";}else{ echo "false";}?>" aria-controls="collapse<?php echo esc_attr($i, 'odcore');?>">
                                    <?php echo esc_html($single_item['accordion_title']);?>
                                 </button>
                              </h2>
                              <div id="collapse<?php echo esc_attr($i, 'odcore');?>" class="accordion-collapse collapse <?php if($i==1){echo "show";}else{echo "";}?>" aria-labelledby="heading<?php echo esc_attr($i, 'odcore');?>" data-bs-parent="#accordionExample">
                                 <div class="accordion-body d-flex align-items-center">
                                    <p class="mb-0"><?php echo tp_kses($single_item['accordion_description']);?></p>
                                    <img class="d-none d-xl-block" src="<?php echo esc_url($single_item_img['url'], 'odcore');?>" alt="">
                                 </div>
                              </div>
                           </div>
                       <?php endforeach;?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- faq-area-end -->

      <?php endif;?>

		<?php
	}

}

$widgets_manager->register( new TP_FAQ() );