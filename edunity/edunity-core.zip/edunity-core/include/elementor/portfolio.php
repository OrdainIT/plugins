<?php
namespace tvcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Portfolio extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'portfolio-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio', 'tvcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tvcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tvcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tvcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tvcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tvcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'tp_portfolio',
            [
                'label' => esc_html__('Portfolio List', 'tvcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tvcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            '_portfolio_list_section',
            [
                'label' => esc_html__( 'Portfolio List', 'tvcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'portfolio_title',
                        'label' => esc_html__( 'Title', 'tvcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Solar Pannel Repair' , 'tvcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'portfolio_sub_title',
                        'label' => esc_html__( 'Sub Title', 'tvcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( 'Repairing' , 'tvcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'portfolio_url',
                        'label' => esc_html__( 'URL', 'tvcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( '#' , 'tvcore' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'portfolio_thumbnail',
                        'label' => esc_html__( 'Choose Image', 'tvcore' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
                'default' => [
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                    [
                        'portfolio_title' => esc_html__( 'Solar Pannel Repair', 'tvcore' ),
                        'portfolio_sub_title' => esc_html__( 'Repairing', 'tvcore' ),
                    ],
                ],
                'title_field' => '{{{ portfolio_title }}}',
            ]
        );



        
        $this->end_controls_section();

        

        // TAB_STYLE
		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'tvcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'tvcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'tvcore' ),
					'uppercase' => __( 'UPPERCASE', 'tvcore' ),
					'lowercase' => __( 'lowercase', 'tvcore' ),
					'capitalize' => __( 'Capitalize', 'tvcore' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<?php if ( $settings['tp_design_style']  == 'layout-2' ): ?>
        
		<?php else: 
			$this->add_render_attribute('title_args', 'class', 'title');
		?>	

         <!-- service-3 area start -->
      <div class="it-service-3-area portfolio-inner p-relative pt-115 pb-100">
         <div class="container">
            <div class="row">
                <?php foreach($settings['_portfolio_list_section'] as $single_portfolio_item):?>
               <div class="col-xl-4 col-lg-4 col-md-6">
                  <div class="it-service-3-item p-relative fix">
                     <div class="it-service-3-thumb">
                        <img src="<?php echo esc_url($single_portfolio_item['portfolio_thumbnail']['url']);?>" alt="">
                     </div>
                     <div class="it-service-3-content">
                        <span class="it-service-3-categories"><?php echo esc_html($single_portfolio_item['portfolio_sub_title']);?></span>
                        <h3 class="it-service-3-item-title">
                           <a href="<?php echo esc_url($single_portfolio_item['portfolio_url']);?>"><?php echo esc_html($single_portfolio_item['portfolio_title']);?></a>
                        </h3>
                     </div>
                  </div>
               </div>
           <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- service-3 area end -->

        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new TP_Portfolio() );