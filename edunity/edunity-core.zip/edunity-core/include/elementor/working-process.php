<?php
namespace tvcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Working_Process extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'working-process';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Working Process', 'tvcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tvcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tvcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Design Layout', 'tvcore' ),
			]
		);

		
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tvcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tvcore'),
                    'layout-2' => esc_html__('Layout 2', 'tvcore'),
                ],
                'default' => 'layout-1',
            ]
        );
		$this->end_controls_section();

		// tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'tvcore'),
            ]
        );

         $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Sub Title', 'tvcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'tvcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Title Here', 'tvcore'),
                'placeholder' => esc_html__('Type Heading Text', 'tvcore'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        //Working List Item
        $this->start_controls_section(
            'working_list_section',
            [
                'label' => esc_html__('List Item', 'tvcore'),
            ]
        );

        	$this->add_control(
			'working_list_items_2',
			[
				'label' => esc_html__( 'List Item', 'tvcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'condition' => [
					'tp_design_style' => 'layout-2'
				],
				'fields' => [
					[
						'name' => 'list_sub_title2',
						'label' => esc_html__( 'Sub Title', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Sub Title' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_title2',
						'label' => esc_html__( 'Title', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Project Planning' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_title_URL2',
						'label' => esc_html__( 'URL', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_content2',
						'label' => esc_html__( 'Description', 'tvcore' ),
						'label' => esc_html__( 'Content', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'List Content' , 'tvcore' ),
						'show_label' => true,
					],
					[
						'name' => 'list_item_number2',
						'label' => esc_html__( 'Number', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( '01' , 'tvcore' ),
						'show_label' => true,
					],
				],
				'default' => [
					[
						'list_title' => esc_html__( 'Project Planning', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Project Planning', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Project Planning', 'textdomain' ),
					],
				],
				'title_field' => '{{{ list_title2 }}}',
			]
		);

        	$this->add_control(
			'working_list_items',
			[
				'label' => esc_html__( 'List Item', 'tvcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'condition' => [
					'tp_design_style' => 'layout-1'
				],
				'fields' => [
					[
						'name' => 'list_sub_title',
						'label' => esc_html__( 'Sub Title', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Sub Title' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_title',
						'label' => esc_html__( 'Title', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'Title' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_title_URL',
						'label' => esc_html__( 'URL', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( '#' , 'tvcore' ),
						'label_block' => true,
					],
					[
						'name' => 'list_content',
						'label' => esc_html__( 'Content', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'List Content' , 'tvcore' ),
						'show_label' => false,
					],
					[
						'name' => 'list_item_image',
						'label' => esc_html__( 'Choose Image', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => \Elementor\Utils::get_placeholder_image_src(),
						],
					],
					[
						'name' => 'list_item_number',
						'label' => esc_html__( 'Number', 'tvcore' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( '2024' , 'tvcore' ),
						'show_label' => false,
					],
				],
				'default' => [
					[
						'list_title' => esc_html__( 'Working Process', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Working Process', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Working Process', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Working Process', 'textdomain' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);





        $this->end_controls_section();




		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'tvcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'tvcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'tvcore' ),
					'uppercase' => __( 'UPPERCASE', 'tvcore' ),
					'lowercase' => __( 'lowercase', 'tvcore' ),
					'capitalize' => __( 'Capitalize', 'tvcore' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

	?>

	<?php if ( $settings['tp_design_style']  == 'layout-2' ):?>

	 <!-- work area start  -->
      <div class="it-work-area pt-110 pb-90">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-xl-6">
                  <div class="it-work-title-box text-center mb-70">
                     <span class="it-subtitle mb-30"><?php echo esc_html($settings['tp_sub_title']);?></span>
                     <h3 class="it-section-title"><?php echo esc_html($settings['tp_title']);?></h3>
                  </div>
               </div>
            </div>
            <div class="it-work-wrapper p-relative">
               <div class="row">
               	<?php foreach($settings['working_list_items_2'] as $single_work_list2):?>
                  <div class="col-lg-4 col-md-4 col-sm-6 mb-30">
                     <div class="it-work-item text-center">
                        <div class="it-wor-icon-box">
                           <span class="it-work-main-number"><?php echo esc_html($single_work_list2['list_item_number2']);?></span>
                           <div class="it-work-sub-icon">
                              <span class="download-icon">
                                 <svg width="8" height="39" viewBox="0 0 8 39" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M3.64645 38.3536C3.84171 38.5488 4.15829 38.5488 4.35355 38.3536L7.53553 35.1716C7.7308 34.9763 7.7308 34.6597 7.53553 34.4645C7.34027 34.2692 7.02369 34.2692 6.82843 34.4645L4 37.2929L1.17157 34.4645C0.976311 34.2692 0.659728 34.2692 0.464466 34.4645C0.269204 34.6597 0.269204 34.9763 0.464466 35.1716L3.64645 38.3536ZM3.5 0V0.95H4.5V0H3.5ZM3.5 2.85V4.75H4.5V2.85H3.5ZM3.5 6.65V8.55H4.5V6.65H3.5ZM3.5 10.45V12.35H4.5V10.45H3.5ZM3.5 14.25V16.15H4.5V14.25H3.5ZM3.5 18.05V19.95H4.5V18.05H3.5ZM3.5 21.85V23.75H4.5V21.85H3.5ZM3.5 25.65V27.55H4.5V25.65H3.5ZM3.5 29.45V31.35H4.5V29.45H3.5ZM3.5 33.25V35.15H4.5V33.25H3.5ZM3.5 37.05V38H4.5V37.05H3.5Z"
                                       fill="currentColor"></path>
                                 </svg>
                              </span>
                           </div>
                        </div>
                        <div class="it-work-content">
                           <h3 class="it-section-title-sm"><?php echo esc_html($single_work_list2['list_sub_title2']);?></h3>
                           <p><?php echo tp_kses($single_work_list2['list_content2']);?></p>
                        </div>
                     </div>
                  </div>
              <?php endforeach;?>
               </div>
            </div>
         </div>
      </div>
      <!-- work area end  -->


  <?php else:?>

  	 <!-- work area start  -->
      <div class="it-work-2-area grey-bg pt-115 pb-70">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-xl-6">
                  <div class="it-work-title-box text-center mb-70">
                     <span class="it-subtitle mb-30"><?php echo esc_html($settings['tp_sub_title']);?></span>
                     <h3 class="it-section-title"><?php echo esc_html($settings['tp_title']);?></h3>
                  </div>
               </div>
            </div>
            <div class="it-work-wrapper work-border-2 p-relative">
               <div class="row">
               	<?php $i = 3;  foreach($settings['working_list_items'] as $single_work_list): $i = $i+2;?>
                  <div class="col-lg-3 col-md-3 col-sm-6 mb-30">
                     <div class="it-work-item z-index-5 text-center"
                        data-wow-delay=".<?php echo esc_attr($i);?>s">
                        <div class="it-wor-icon-box">
                           <span class="it-work-main-number work-number-2"><?php echo esc_html($single_work_list['list_item_number']);?></span>
                           <div class="it-work-sub-icon">
                              <span class="download-icon">
                                 <svg width="8" height="45" viewBox="0 0 8 45" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M1.33333 3C1.33333 4.47276 2.52724 5.66667 4 5.66667C5.47276 5.66667 6.66667 4.47276 6.66667 3C6.66667 1.52724 5.47276 0.333333 4 0.333333C2.52724 0.333333 1.33333 1.52724 1.33333 3ZM3.64645 44.8536C3.84171 45.0488 4.15829 45.0488 4.35355 44.8536L7.53553 41.6716C7.7308 41.4763 7.7308 41.1597 7.53553 40.9645C7.34027 40.7692 7.02369 40.7692 6.82843 40.9645L4 43.7929L1.17157 40.9645C0.976311 40.7692 0.659728 40.7692 0.464466 40.9645C0.269204 41.1597 0.269204 41.4763 0.464466 41.6716L3.64645 44.8536ZM3.5 3V4.0375H4.5V3H3.5ZM3.5 6.1125V8.1875H4.5V6.1125H3.5ZM3.5 10.2625V12.3375H4.5V10.2625H3.5ZM3.5 14.4125V16.4875H4.5V14.4125H3.5ZM3.5 18.5625V20.6375H4.5V18.5625H3.5ZM3.5 22.7125V24.7875H4.5V22.7125H3.5ZM3.5 26.8625V28.9375H4.5V26.8625H3.5ZM3.5 31.0125V33.0875H4.5V31.0125H3.5ZM3.5 35.1625V37.2375H4.5V35.1625H3.5ZM3.5 39.3125V41.3875H4.5V39.3125H3.5ZM3.5 43.4625V44.5H4.5V43.4625H3.5Z"
                                       fill="currentColor" />
                                 </svg>
                              </span>
                           </div>
                        </div>
                        <div class="it-work-2-item">
                           <div class="it-work-2-content">
                              <div class="it-work-2-thumb">
                                 <img src="<?php echo esc_url($single_work_list['list_item_image']['url']);?>" alt="">
                              </div>
                              <h3 class="it-work-2-title">
                                 <a href="<?php echo esc_url($single_work_list['list_title_URL']);?>"><?php echo esc_html($single_work_list['list_title']);?></a>
                              </h3>
                              <p><?php echo tp_kses($single_work_list['list_content']);?></p>
                           </div>
                        </div>
                     </div>
                  </div>

              <?php endforeach;?>
               </div>
            </div>
         </div>
      </div>
      <!-- work area end  -->


  <?php endif;?>

  <?php

		
	}

}

$widgets_manager->register( new Working_Process() );