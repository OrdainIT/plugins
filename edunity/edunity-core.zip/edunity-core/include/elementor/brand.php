<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Brand extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'brand';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

		 // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'tp_brand_section_2',
            [
                'label' => __( 'Brand Item', 'odcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' =>[
                	'od_design_style' => ['layout-1'],
                ],
            ]
        );

        	$this->add_control(
			'brad_text_2',
			[
				'label' => esc_html__( 'Marque Text', 'odcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'marque_title_img',
						'label' => esc_html__( 'Image', 'odcore' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' =>  get_template_directory_uri(). '/assets/img/career/ed-text.png',
						],
						'label_block' => true,
					],
					[
						'name' => 'marque_title',
						'label' => esc_html__( 'Marque Title', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('solar energy ', 'odcore'),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
					[
						'marque_title' => esc_html__( 'Online School', 'odcore' ),
					],
				],
				'title_field' => '{{{ marque_title }}}',
			]
		);





        $this->end_controls_section();


		$this->start_controls_section(
            'tp_brand_section',
            [
                'label' => __( 'Brand Item', 'odcore' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' =>[
                	'od_design_style' => ['layout-2'],
                ],
            ]
        );

		$this->add_control(
			'brad_img',
			[
				'label' => esc_html__( 'Brand List', 'odcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'list_imge',
						'label' => esc_html__( 'Title', 'odcore' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
							'url' => \Elementor\Utils::get_placeholder_image_src(),
						],
						'label_block' => true,
					],
					[
						'name' => 'list_url',
						'label' => esc_html__( 'URL', 'odcore' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__('#', 'odcore'),
						'label_block' => true,
					],
				],
				'default' => [
					[
						'list_imge' => esc_html__( 'Brand Item', 'odcore' ),
					],
					[
						'list_imge' => esc_html__( 'Brand Item', 'odcore' ),
					],
					[
						'list_imge' => esc_html__( 'Brand Item', 'odcore' ),
					],
					[
						'list_imge' => esc_html__( 'Brand Item', 'odcore' ),
					],
					[
						'list_imge' => esc_html__( 'Brand Item', 'odcore' ),
					],
				],
				'title_field' => esc_html__('Brand Item'),
			]
		);


        $this->end_controls_section();


		$this->start_controls_section(
			'od_brand_area',
			[
				'label' => __( 'Brand Area', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_brand_area_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-text-slider-height' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_brand_area_title_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-text-slider-content span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_brand_area_title_typography',
				'selector' => '{{WRAPPER}} .ed-text-slider-content span',
			]
		);

		

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
	<?php if ( $settings['od_design_style']  == 'layout-2' ): ?>

		<!-- text-slider-4 start  -->
      <div class="it-header-2-top text-slider-4 pt-10 pb-10 fix theme-bg">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-12">
                  <div class="it-header-2-top-info">
                     <div class="it-header-2-top-marque d-flex align-items-center justify-content-center">
                     	<?php foreach($settings['brad_text_2'] as $single_marque_text):?>
                        <div class="it-header-2-top-content d-flex align-items-center">
                           <p><?php echo esc_html($single_marque_text['marque_title']);?> </p>
                           <span>
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path
                                    d="M11.4821 0.18297L10.5151 0.166092L10.1661 20.163L11.1331 20.1799L11.4821 0.18297Z"
                                    fill="currentColor" />
                                 <path
                                    d="M20.8309 9.86495L0.833984 9.5159L0.817106 10.4829L20.8141 10.8319L20.8309 9.86495Z"
                                    fill="currentColor" />
                                 <path
                                    d="M4.22109 2.64359L3.52542 3.3154L17.4185 17.7021L18.1141 17.0302L4.22109 2.64359Z"
                                    fill="currentColor" />
                                 <path
                                    d="M17.6772 2.87847L3.29054 16.7715L3.96234 17.4671L18.349 3.57415L17.6772 2.87847Z"
                                    fill="currentColor" />
                                 <path
                                    d="M1.82163 5.79848L1.44116 6.68762L19.8286 14.5558L20.2091 13.6666L1.82163 5.79848Z"
                                    fill="currentColor" />
                                 <path
                                    d="M14.3183 0.793775L6.45018 19.1812L7.33933 19.5617L15.2074 1.17424L14.3183 0.793775Z"
                                    fill="currentColor" />
                                 <path
                                    d="M19.9999 6.14882L1.3184 13.2919L1.6638 14.1952L20.3453 7.05219L19.9999 6.14882Z"
                                    fill="currentColor" />
                                 <path
                                    d="M7.70126 0.667453L6.7979 1.01277L13.9389 19.6942L14.8423 19.349L7.70126 0.667453Z"
                                    fill="currentColor" />
                              </svg>
                           </span>
                        </div>
                    <?php endforeach;?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- text-slider-4 end  -->

    <?php else:?>


    	<!-- text-slider-area-start -->
      <div class="ed-text-slider-area ed-text-slider-height fix">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-12">
                  <div class="ed-text-slider-wrap d-flex align-content-center">
                  	<?php foreach($settings['brad_text_2'] as $single_marque_text):
						
						$marque_img_url = $single_marque_text['marque_title_img'];
					
					?>
                     <div class="ed-text-slider-content d-flex align-items-center">
                        <span><?php echo esc_html($single_marque_text['marque_title']);?></span>
                        <img src="<?php echo esc_url($marque_img_url['url'], 'odcore');?>" alt="">
                     </div>
                  <?php endforeach;?>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- text-slider-area-end -->



    <?php endif;?>

    <script>
    	"use strict";
			jQuery(document).ready(function($) {
				const brandswiper = new Swiper('.it-brand-active', {
					// Optional parameters
					speed:1000,
					loop: true,
					slidesPerView: 5,
			        spaceBetween: 30,
					centeredSlides: true,
					autoplay: false,
					breakpoints: {
						'1400': {
							slidesPerView: 5,
						},
						'1200': {
							slidesPerView: 5,
						},
						'992': {
							slidesPerView: 4,
						},
						'768': {
							slidesPerView: 3,
						},
						'576': {
							slidesPerView: 2,
						},
						'0': {
							slidesPerView: 1,
						},
					},
					
				  });
				

			});
	</script>

		<?php
	}


}

$widgets_manager->register( new TP_Brand() );