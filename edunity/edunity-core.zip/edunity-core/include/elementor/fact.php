<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Fact extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-fact';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Fun Fact', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

              // Service group
        $this->start_controls_section(
            'od_fact_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
            ]
        );

        $this->add_control(
			'od_fact_section_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  get_template_directory_uri(). '/assets/img/about/funfact-shape-2.png',
				],
			]
		);
        $this->add_control(
			'od_fact_section_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  get_template_directory_uri(). '/assets/img/about/funfact-shape.png',
				],
			]
		);

        $this->end_controls_section();

          // Service group
        $this->start_controls_section(
            'tv_bg_img',
            [
                'label' => esc_html__('Background', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
            ]
        );

         $this->add_control(
            'tv_fact_bg_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/funfact/funfact-bg.png',
                ],
            ]
        );

         $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'tp_fact',
            [
                'label' => esc_html__('Fact List', 'odcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'odcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();


         $repeater->add_control(
            'tp_fact_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('YEARS OF EXPERIENCE', 'odcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tp_fact_number', [
                'label' => esc_html__('Number', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('20', 'odcore'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'tp_fact_number_symbol', [
                'label' => esc_html__('Symbol', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('k+', 'odcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tp_fact_number_icon', [
                'label' => esc_html__('Icon', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('flaticon-teacher', 'odcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_fact_list',
            [
                'label' => esc_html__('Fact - List', 'odcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_fact_title' => esc_html__('YEARS OF EXPERIENCE', 'odcore'),
                        'tp_fact_number' => esc_html__('20', 'odcore'),
                        'tp_fact_number_symbol' => esc_html__('+', 'odcore'),
                        'tp_fact_number_icon' => esc_html__('flaticon-teacher', 'odcore'),
                    ],
                    [
                        'tp_fact_title' => esc_html__('PROJECT TAKEN', 'odcore'),
                        'tp_fact_number' => esc_html__('400', 'odcore'),
                        'tp_fact_number_symbol' => esc_html__('K', 'odcore'),
                        'tp_fact_number_icon' => esc_html__('flaticon-completed-task', 'odcore'),
                    ],
                    [
                        'tp_fact_title' => esc_html__('PROJECT TAKEN', 'odcore'),
                        'tp_fact_number' => esc_html__('300', 'odcore'),
                        'tp_fact_number_symbol' => esc_html__('+', 'odcore'),
                        'tp_fact_number_icon' => esc_html__('flaticon-customer-review', 'odcore'),
                    ],
                    [
                        'tp_fact_title' => esc_html__('AWARDS WON', 'odcore'),
                        'tp_fact_number' => esc_html__('200', 'odcore'),
                        'tp_fact_number_symbol' => esc_html__('+', 'odcore'),
                        'tp_fact_number_icon' => esc_html__('flaticon-class', 'odcore'),
                    ]
                ],
                'title_field' => '{{{ tp_fact_title }}}',
            ]
        );
        $this->end_controls_section();

        // tp_fact_columns_section
        $this->start_controls_section(
            'tp_fact_columns_section',
            [
                'label' => esc_html__('Blank', 'odcore'),
            ]
        );

       

        $this->end_controls_section();



// TAB_STYLE
        $this->start_controls_section(
            'od_fun_fact_bg',
            [
                'label' => __( 'Fun Fact Area', 'odcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
			'od_fun_fact_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-bg-wrap' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-funfact-4-area' => 'background-color: {{VALUE}}',
				],
			]
		);
      

        $this->end_controls_section();
// TAB_STYLE
        $this->start_controls_section(
            'od_fun_fact_content',
            [
                'label' => __( 'Fun Fact Content', 'odcore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
			'od_fun_fact_content_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-content h6' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-funfact-4-item h4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-funfact-4-wrap' => 'border-color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_fun_fact_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-funfact-content h6',
                    '{{WRAPPER}} .it-funfact-4-item h4',
                ],
			]
		);

        $this->add_control(
			'od_fun_fact_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-content span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-funfact-4-item p' => 'color: {{VALUE}}',
				],
			]
		);

        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_fun_fact_content_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-funfact-content span',
                    '{{WRAPPER}} .it-funfact-4-item p',
                ],
			]
		);

        $this->add_control(
			'od_fun_fact_content_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-icon span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-funfact-wrap .it-funfact-icon span::after' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ed-funfact-wrap .it-funfact-item.border-style-1::after' => 'border-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_fun_fact_content_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-funfact-icon span' => 'background-color: {{VALUE}}',
				],
			]
		);

 
      

        $this->end_controls_section();

        
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


        $tv_fact_bg_img = $settings['tv_fact_bg_img'];
        $tp_fact_list = $settings['tp_fact_list'];


		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ): 
         $od_fact_section_shap_img_1 = $settings['od_fact_section_shap_img_1'];
         $od_fact_section_shap_img_2 = $settings['od_fact_section_shap_img_2'];
        ?>
           <!-- funfact-area-start -->
      <div class="it-funfact-4-area fix p-relative pt-75 pb-45">
         <div class="it-funfact-4-shape-1">
            <img src="<?php echo esc_url($od_fact_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-funfact-4-shape-2">
            <img src="<?php echo esc_url($od_fact_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row">

                <?php foreach($tp_fact_list as $single_fact):?>

               <div class="col-xl-3 col-lg-3 col-md-6 mb-30 d-flex justify-content-center">
                  <div class="it-funfact-4-wrap d-flex align-items-center justify-content-center">
                     <div class="it-funfact-4-item">
                        <h4><span data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($single_fact['tp_fact_number']);?>"
                              class="purecounter"><?php echo esc_html($single_fact['tp_fact_number']);?></span><?php echo esc_html($single_fact['tp_fact_number_symbol']);?></h4>
                        <p><?php echo esc_html($single_fact['tp_fact_title']);?></p>
                     </div>
                  </div>
               </div>
           <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- funfact-area-end -->

    <?php elseif ( $settings['od_design_style']  == 'layout-3' ):
        $od_fact_section_shap_img_1 = $settings['od_fact_section_shap_img_1'];
        ?>
        <!-- funfact-area-start -->
      <div class="ed-funfact-area ed-funfact-wrap p-relative pb-90">
         <div class="ed-funfact-shape-1 d-none d-xl-block">
            <img src="<?php echo esc_url($od_fact_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <div class="row">
                <?php foreach($tp_fact_list as $single_fact):?>
               <div class="col-xl-3 col-lg-3 col-md-6 mb-30">
                  <div class="it-funfact-item text-center border-style-1">
                     <div class="it-funfact-icon mb-30">
                        <span><i class="<?php echo esc_attr($single_fact['tp_fact_number_icon']);?>"></i></span>
                     </div>
                     <div class="it-funfact-content">
                        <h6><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($single_fact['tp_fact_number']);?>">0</i>
                        </h6>
                        <span><?php echo esc_html($single_fact['tp_fact_title']);?></span>
                     </div>
                  </div>
               </div>
           <?php endforeach;?>
            </div>
         </div>
      </div>
      <!-- funfact-area-end -->
  <?php elseif ( $settings['od_design_style']  == 'layout-4' ): ?>

      <!-- funfact-area-start -->
      <div class="it-funfact-area z-index-5">
         <div class="container">
            <div class="it-funfact-bg-wrap orange-bg" style="background-image:url(<?php echo esc_url($tv_fact_bg_img['url'], 'odcore');?>);">
               <div class="row gx-0">
                <?php foreach($tp_fact_list as $single_fact):?>
                  <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                     <div class="it-funfact-item d-flex align-items-center">
                        <div class="it-funfact-icon">
                           <span><i class="<?php echo esc_attr($single_fact['tp_fact_number_icon']);?>"></i></span>
                        </div>
                        <div class="it-funfact-content">
                           <h6 class=""><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($single_fact['tp_fact_number']);?>">0</i><?php echo esc_html($single_fact['tp_fact_number_symbol']);?>
                           </h6>
                           <span><?php echo esc_html($single_fact['tp_fact_title']);?></span>
                        </div>
                     </div>
                  </div>
              <?php endforeach;?>
               </div>
            </div>
         </div>
      </div>
      <!-- funfact-area-end -->

    <?php else: ?>

            <!-- funfact-area-start -->
      <div class="it-funfact-area z-index-5">
         <div class="container">
            <div class="it-funfact-bg-wrap yellow-bg" style="background-image:url(<?php echo esc_url($tv_fact_bg_img['url'], 'odcore');?>);" >
               <div class="row gx-0">
                <?php foreach($tp_fact_list as $single_fact):?>
                  <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                     <div class="it-funfact-item d-flex align-items-center">
                        <div class="it-funfact-icon">
                           <span><i class="<?php echo esc_attr($single_fact['tp_fact_number_icon']);?>"></i></span>
                        </div>
                        <div class="it-funfact-content">
                           <h6><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo esc_attr($single_fact['tp_fact_number']);?>">0</i><?php echo esc_html($single_fact['tp_fact_number_symbol']);?>
                           </h6>
                           <span><?php echo esc_html($single_fact['tp_fact_title']);?></span>
                        </div>
                     </div>
                  </div>
              <?php endforeach;?>
               </div>
            </div>
         </div>
      </div>
      <!-- funfact-area-end -->

         

      

        <?php endif; ?>
        <script>
            "use strict";
        jQuery(document).ready(function($) {

                // 12. Counter Js
            if ($(".purecounter").length) {
                new PureCounter({
                    filesizing: true,
                    selector: ".filesizecount",
                    pulse: 2,
                });
                new PureCounter();
            }


        });
        </script>

        <?php 

	}
}



$widgets_manager->register( new TP_Fact() );