<?php
namespace tvcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Course_Category extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'course-category';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Course Category', 'tvcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tvcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tvcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Title & Content', 'tvcore' ),
			]
		);

		$this->add_control(
			'tv_sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'tvcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'category', 'tvcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tvcore' ),
			]
		);


		$this->add_control(
			'tv_title',
			[
				'label' => esc_html__( 'Title', 'tvcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Favorite topics to learn', 'tvcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tvcore' ),
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'od_category_course_section_shap',
			[
				'label' => __( 'Shap', 'tvcore' ),
			]
		);

		$this->add_control(
			'od_category_course_section_shap_img_1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/category/title.svg',
				],
			]
		);
		$this->add_control(
			'od_category_course_section_shap_img_2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri(). '/assets/img/category/shape-1-1.png',
				],
			]
		);

		$this->end_controls_section();




		$this->start_controls_section(
			'tv_section_button',
			[
				'label' => __( 'Button', 'tvcore' ),
			]
		);



		$this->add_control(
            'tv_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tvcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tv_btn_text',
            [
                'label' => esc_html__('Button Text', 'tvcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Browse Edunity Courses', 'tvcore'),
                'title' => esc_html__('Enter button text', 'tvcore'),
                'label_block' => true,
                'condition' => [
                    'tv_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tv_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tvcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tv_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tv_btn_link',
            [
                'label' => esc_html__('Button link', 'tvcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tvcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tv_btn_link_type' => '1',
                    'tv_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tv_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tvcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tv_btn_link_type' => '2',
                    'tv_btn_button_show' => 'yes'
                ]
            ]
        );



		$this->end_controls_section();





		$this->start_controls_section(
			'tv_course_category_section',
			[
				'label' => __( 'Category Query', 'tvcore' ),
			]
		);

		$this->add_control(
			'category_number',
			[
				'label' => esc_html__( 'Post Per Page', 'tvcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '5', 'tvcore' ),
				'placeholder' => esc_html__( 'Type your title here', 'tvcore' ),
			]
		);

		// $service_cats = get_terms('project-categories', array('order' => 'DESC'));
		// $cat_array = array( '' => 'Select One' );
		// foreach($service_cats as $cat) {
		//     $cat_array[$cat->slug] = $cat->name;
		// }

		/**
		 * Get Post Categories
		 */
		// function tp_get_categories($taxonomy)
		// {
		//     $terms = get_terms(array(
		//         'taxonomy' => $taxonomy,
		//         'hide_empty' => true,
		//     ));
		//     $options = array();
		//     if (!empty($terms) && !is_wp_error($terms)) {
		//         foreach ($terms as $term) {
		//             $options[$term->slug] = $term->name;
		//         }
		//     }
		//     return $options;
		// }


        // $this->add_control(
        //     'category',
        //     [
        //         'label' => esc_html__('Include Categories', 'tvcore'),
        //         'description' => esc_html__('Select a category to include or leave blank for all.', 'tvcore'),
        //         'type' => Controls_Manager::SELECT2,
        //         'multiple' => true,
        //         'options' => tp_get_categories('project-categories'),
        //         'label_block' => true,
        //     ]
        // );

		$this->end_controls_section();

		$this->start_controls_section(
			'od_category_course',
			[
				'label' => __( 'Title & Content', 'tvcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_category_course_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_category_course_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-3',
			]
		);

		$this->add_control(
			'od_category_course_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-5.purple-2' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_category_course_subtitle_typography',
				'selector' => '{{WRAPPER}} .it-section-subtitle-5.purple-2',
			]
		);

		$this->add_control(
			'od_category_course_button_heading',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
            'od_category_course_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_category_course_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_category_course_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-2' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_category_course_button_normal__color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-2' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_category_course_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

		$this->add_control(
			'od_category_course_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-2:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_category_course_button_hover__color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-square.purple-2:hover' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();
	
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_category_course_button_typography',
				'selector' => '{{WRAPPER}} .ed-btn-square.purple-2',
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'od_category_course_cotent',
			[
				'label' => __( 'Category Content', 'tvcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'od_category_course_cotent_title',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-category-4-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_category_course_cotent_title_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-category-4-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_category_course_cotent_title_typography',
				'selector' => '{{WRAPPER}} .it-category-4-title',
			]
		);

		$this->add_control(
			'od_category_course_cotent_titlesub_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-category-4-content span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_category_course_cotent_titlesub_typography',
				'selector' => '{{WRAPPER}} .it-category-4-content span',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


		$tv_btn_text = $settings['tv_btn_text'];
		$tv_sub_title = $settings['tv_sub_title'];
		$tv_title = $settings['tv_title'];
		$tv_btn_button_show = $settings['tv_btn_button_show'];
		$category_number = $settings['category_number'];

		$od_category_course_section_shap_img_1 = $settings['od_category_course_section_shap_img_1'];
		$od_category_course_section_shap_img_2 = $settings['od_category_course_section_shap_img_2'];




               // Link
            if ('2' == $settings['tv_btn_link_type']) {
                $this->add_render_attribute('tv-button-arg', 'href', get_permalink($settings['tv_btn_page_link']));
                $this->add_render_attribute('tv-button-arg', 'target', '_self');
                $this->add_render_attribute('tv-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tv-button-arg', 'class', 'ed-btn-square purple-2');
            } else {
                if ( ! empty( $settings['tv_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tv-button-arg', $settings['tv_btn_link'] );
                    $this->add_render_attribute('tv-button-arg', 'class', 'ed-btn-square purple-2');
                }
            }






		?>


		 <!-- category-area-start -->
      <div class="it-category-4-area p-relative pt-120 pb-90">
         <div class="it-category-4-shape-1 d-none d-lg-block">
            <img src="<?php echo esc_url($od_category_course_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="it-category-4-title-wrap mb-60">
               <div class="row align-items-end">
                  <div class="col-xl-6 col-lg-6 col-md-6">
                     <div class="it-category-4-title-box">
                        <span class="it-section-subtitle-5 purple-2">
                           <img src="<?php echo esc_url($od_category_course_section_shap_img_1['url'], 'odcore');?>" alt="">
                           <?php echo esc_html($tv_sub_title, 'tvcore');?>
                        </span>
                        <h4 class="it-section-title-3"><?php echo tp_kses($tv_title, 'tvcore');?></h4>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-6 col-md-6">
                     <div class="it-category-4-btn-box text-start text-md-end pt-25">
                       <a <?php echo $this->get_render_attribute_string( 'tv-button-arg' ); ?>>
                                <?php echo $tv_btn_text; ?>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row row-cols-xl-5 row-cols-lg-3 row-cols-md-3 row-cols-sm-2 row-cols-1">
            	<?php
					$categories = get_terms(array(
						'taxonomy' => 'course-category',
						'hide_empty' => false,
						'number' => $category_number,
					));

					$i = 0;

					foreach ($categories as $single_item):
						$i++;
						$icon_index = $i % 5 + 1; // Cycles through 1 to 5


						// Fetch the Tutor LMS category thumbnail (stored as term meta)
						$thumbnail_id = get_term_meta($single_item->term_id, 'thumbnail_id', true);
						$thumbnail_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : ''; // Get image URL if available

						// Fallback to default image if no custom thumbnail is set
						$default_image = get_template_directory_uri() . '/assets/img/category/category-4-' . $icon_index . '.png';
						$category_image = $thumbnail_url ? $thumbnail_url : $default_image;
						?>
						<div class="col mb-30 wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
							<div class="it-category-4-item text-center">
								<div class="it-category-4-icon">
									<span>
										<img src="<?php echo esc_url($category_image); ?>" alt="<?php echo esc_attr($single_item->name); ?>">
									</span>
								</div>
								<div class="it-category-4-content">
									<h4 class="it-category-4-title">
										<a href="<?php echo esc_url(get_term_link($single_item)); ?>"><?php echo esc_html($single_item->name); ?></a>
									</h4>
									<span><?php echo $single_item->count; ?> <?php echo esc_html__('Courses', 'tvcore'); ?></span>
								</div>
							</div>
						</div>
					<?php endforeach; ?>

            </div>
         </div>
      </div>
      <!-- category-area-end -->




		<?php
	}

	
}

$widgets_manager->register( new Course_Category() );