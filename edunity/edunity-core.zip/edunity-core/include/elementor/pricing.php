<?php
namespace tvcore\Widgets;

use Elementor\Widget_Base;
use \Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Pricing extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-pricing';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Pricing', 'tvcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tvcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tvcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {


       
        
        
          // tp_section_title
        $this->start_controls_section(
            'tv_pricing_heading',
            [
                'label' => esc_html__('Heading', 'tvcore'),
            ]
        );

        $this->add_control(
            'hightlights_box',
            [
                'label' => esc_html__( 'High Lights Box', 'tvcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'price_title',
            [
                'label' => esc_html__('Title', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('SOLAR ENERGY', 'tvcore'),
                'placeholder' => esc_html__('Type Heading Text', 'tvcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'price_description',
            [
                'label' => esc_html__('Description', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Advanced features for pros who need more customization.', 'tvcore'),
                'placeholder' => esc_html__('Type Text Here', 'tvcore'),
                'label_block' => true,
            ]
        );   
        $this->add_control(
            'price_prcing',
            [
                'label' => esc_html__('Price', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('20', 'tvcore'),
                'placeholder' => esc_html__('Type Your Price', 'tvcore'),
                'label_block' => true,
            ]
        );     
        $this->add_control(
            'price_per_mont',
            [
                'label' => esc_html__('Per Month/Year', 'tvcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Month', 'tvcore'),
                'placeholder' => esc_html__('Type Package Length', 'tvcore'),
                'label_block' => true,
            ]
        );     

        
  

        

        $this->end_controls_section();

         // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'tvcore'),
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tvcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tvcore' ),
                'label_off' => esc_html__( 'Hide', 'tvcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'tvcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Purchase Now', 'tvcore'),
                'title' => esc_html__('Enter button text', 'tvcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tvcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'tvcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tvcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tvcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();
          // tp_btn_button_group
        $this->start_controls_section(
            'pricing_repeater_list_seciton',
            [
                'label' => esc_html__('List Item', 'tvcore'),
            ]
        );

       
        $this->add_control(
            'pricing_repeater_list',
            [
                'label' => esc_html__( 'List Item', 'tvcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'list_title',
                        'label' => esc_html__( 'Title', 'tvcore' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__( '7-Days Shipping World Wide' , 'tvcore' ),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'list_title' => esc_html__( '7-Days Shipping World Wide', 'tvcore' ),
                    ],
                    [
                        'list_title' => esc_html__( '3 Kg Weight Max /Package', 'tvcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Free Wood Crate', 'tvcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Get in touch to discuss', 'tvcore' ),
                    ],
                    [
                        'list_title' => esc_html__( 'Use Personal And Commercial', 'tvcore' ),
                    ],
                    [
                        'list_title' => esc_html__( '24/7 Support', 'tvcore' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );


        $this->end_controls_section();
      

        

        

    }

   


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $hightlights_box = $settings['hightlights_box'];
        $price_title = $settings['price_title'];
        $price_description = $settings['price_description'];
        $price_prcing = $settings['price_prcing'];
        $price_per_mont = $settings['price_per_mont'];
        $pricing_repeater_list = $settings['pricing_repeater_list'];
        $tp_btn_text = $settings['tp_btn_text'];
        $tp_btn_button_show = $settings['tp_btn_button_show'];

         // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square purple-4 radius w-100 text-center');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square purple-4 radius w-100 text-center');
                }
            }

           

            $this->add_render_attribute('title_args', 'class', 'it-price-title');
            
            if($settings['hightlights_box'] =='yes'){
                $active_class = "active ";
                
            }else{
                $active_class = "";
                
            }

            

        ?>


             <div class="it-price-item-wrap p-relative z-index <?php echo esc_attr($active_class, 'tvcore');?>">
                     <div class="it-price-shape-1">
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/price/shape-1.png" alt="">
                     </div>
                     <div class="it-price-category text-center">
                        <span><?php echo esc_html($price_title, 'tvcore');?></span>
                     </div>
                     <div class="it-price-item">
                        <div class="it-price-category-wrap">
                           <div class="it-price-month text-center">
                              <span><?php echo esc_html($price_prcing, 'tvcore');?><i><?php echo esc_html($price_per_mont, 'tvcore');?></i></span>
                           </div>
                        </div>
                        <div class="it-price-list text-center">
                           <p><?php echo tp_kses($price_description, 'tvcore');?></p>
                           <ul>
                            <?php foreach($pricing_repeater_list as $single_item):?>
                              <li>
                                 <i class="fa-light fa-check"></i>
                                 <?php echo esc_html($single_item['list_title'], 'tvcore');?>
                              </li>
                          <?php endforeach;?>
                           </ul>
                        </div>
                   <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                        <span>
                        <?php echo $settings['tp_btn_text']; ?>
                           </span>
                        </a>
                     </div>
                  </div>


        <?php
    }

}

$widgets_manager->register( new TP_Pricing() );