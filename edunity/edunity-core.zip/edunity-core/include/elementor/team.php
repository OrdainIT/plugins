<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Team extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-team';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                    'layout-4' => esc_html__('Layout 4', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        
           // tp_section_title
        $this->start_controls_section(
            'od_testi_section_team_settings',
            [
                'label' => esc_html__('Settings', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-3'],
                ],
            ]
        );
        $this->add_control(
			'od_testi_section_team_autoplay_switcher',
			[
				'label' => esc_html__( 'Autoplay On/Off', 'odcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'odcore' ),
				'label_off' => esc_html__( 'Off', 'odcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();

           // tp_section_title
        $this->start_controls_section(
            'od_testi_section_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
            ]
        );

        $this->add_control(
            'od_testi_section_shap_img_1',
            [
               'label' => esc_html__( 'Shap 1', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>  get_template_directory_uri(). '/assets/img/team/shape-1-2.png',
               ],
            ]
         );

        $this->add_control(
            'od_testi_section_shap_img_2',
            [
               'label' => esc_html__( 'Shap 2', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>  get_template_directory_uri(). '/assets/img/team/shape-1-1.png',
               ],
            ]
         );
        $this->add_control(
            'od_testi_section_shap_img_3',
            [
               'label' => esc_html__( 'Shap 3', 'odcore' ),
               'type' => \Elementor\Controls_Manager::MEDIA,
               'default' => [
                  'url' =>  get_template_directory_uri(). '/assets/img/team/shape-1-3.png',
               ],
            ]
         );


      $this->end_controls_section();



        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-1', 'layout-2','layout-3', 'layout-4'],
                ],
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('OUR INSTRUCTOR', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Meet Our Expert Instructor', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );      
        $this->add_control(
            'tp_description',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__(' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris..', 'odcore'),
                'placeholder' => esc_html__('Type Description Text', 'odcore'),
                'label_block' => true,
                'condition' =>[
                    'od_design_style' => ['layout-1'],
                ],
            ]
        );      

        

        $this->end_controls_section();

        // Thumbnail
        $this->start_controls_section(
            'section_thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
                'condition' =>[
                    'od_design_style' => ['layout-2'],
                ],
            ]
        );

        $this->add_control(
            'team_thumbnail',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/team/bg-3.png',
                ],
            ]
        );



        $this->end_controls_section();

           // Blog Query
        $this->start_controls_section(
            'tp_post_query',
            [
                'label' => esc_html__('Team Query', 'odcore'),
            ]
        );

        $post_type = 'team';
        $taxonomy = 'team-cat';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'odcore'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '5',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'odcore'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true,
            ]
        );




        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
                    'ID' => 'Post ID',
                    'author' => 'Post Author',
                    'title' => 'Title',
                    'date' => 'Date',
                    'modified' => 'Last Modified Date',
                    'parent' => 'Parent Id',
                    'rand' => 'Random',
                    'comment_count' => 'Comment Count',
                    'menu_order' => 'Menu Order',
                ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc'   => esc_html__( 'Ascending', 'odcore' ),
                    'desc'  => esc_html__( 'Descending', 'odcore' )
                ],
                'default' => 'desc',

            ]
        );

        $this->end_controls_section();

        // Button
        $this->start_controls_section(
            'tp_button_style_2',
            [
                'label' => esc_html__('Button', 'odcore'),
                'condition' => [
                    'od_design_style'=> ['layout-1', 'layout-3'],
                ],
            ]
        );

        $this->add_control(
            'button_swticher',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => esc_html__( 'Button Text', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Contact Us', 'odcore' ),
                'placeholder' => esc_html__( 'Button Text', 'odcore' ),
                'condition' => [
                    'button_swticher'=> 'yes',
                ],
            ]
        );
        $this->add_control(
            'button_url',
            [
                'label' => esc_html__( 'Button URL', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'odcore' ),
                'placeholder' => esc_html__( 'Button URL', 'odcore' ),
                'condition' => [
                    'button_swticher'=> 'yes',
                ],
            ]
        ); 
        $this->add_control(
            'button_swticher2',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'button_text2',
            [
                'label' => esc_html__( 'Button Text', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Find Courses', 'odcore' ),
                'placeholder' => esc_html__( 'Button Text', 'odcore' ),
                'condition' => [
                    'button_swticher'=> 'yes',
                ],
            ]
        );
        $this->add_control(
            'button_url2',
            [
                'label' => esc_html__( 'Button URL', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'odcore' ),
                'placeholder' => esc_html__( 'Button URL', 'odcore' ),
                'condition' => [
                    'button_swticher'=> 'yes',
                ],
            ]
        );

        $this->end_controls_section();



		$this->start_controls_section(
			'od_team_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_team_title_content_section_bg_color',
			[
				'label' => esc_html__( 'Section BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-area.grey-bg-5' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-area' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_title_content_title_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_title_content_title_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-title',
                    '{{WRAPPER}} .it-section-title-3',
                ],
			]
		);
      $this->add_control(
			'od_team_title_content_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title  Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5.orange' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_title_content_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-section-subtitle',
                    '{{WRAPPER}} .it-section-subtitle-3',
                    '{{WRAPPER}} .it-section-subtitle-5.orange',
                ],
			]
		);

      $this->add_control(
			'od_team_title_content_description_color',
			[
				'label' => esc_html__( 'Description  Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-text p' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_title_content_description_description',
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'selectors' => [
                    '{{WRAPPER}} .it-team-text p',
                ],
			]
		);



	

		$this->end_controls_section();

		$this->start_controls_section(
			'od_team_team_content',
			[
				'label' => __( 'Team Content', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->add_control(
			'od_team_team_content_primary_color',
			[
				'label' => esc_html__( 'Team Primary Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-thumb-box' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-author-info span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-social-box button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-social a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-link a svg' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_team_content_secoundary_color',
			[
				'label' => esc_html__( 'Team Secondary  Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-author-box' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-social-box button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-team-social' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-social::after' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_team_content_title_color',
			[
				'label' => esc_html__( 'Title  Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-author-name' => 'color: {{VALUE}}',
				],
			]
		);

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_team_content_title_typography',
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'selectors' => [
                    '{{WRAPPER}} .it-team-author-name',
                ],
			]
		);


      // Team Style 2 & 3

      $this->add_control(
			'od_team_team_style2_content_area',
			[
				'label' => esc_html__( 'Content Area', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_team_team_style2_content_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-item' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_team_style2_content_bg_hover_color',
			[
				'label' => esc_html__( 'BG Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-item:hover .it-team-3-content' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_team_style2_content_bg_hover_overylay_color',
			[
				'label' => esc_html__( 'Hover Overlay Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-thumb::after' => 'background: {{VALUE}}',
				],
			]
		);


      
      $this->add_control(
			'od_team_team_style2_title_heading',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
         'od_team_team_style2_title_tabs',
         [
            
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' , 'layout-4' ],
                ],
         ]
      );

      // normal

      $this->start_controls_tab(
         'od_team_team_style2_title_normal_tab',
         [
            'label' => esc_html__( 'Normal', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_team_style2_title_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-title' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      // Hover

      $this->start_controls_tab(
         'od_team_team_style2_title_hover_tab',
         [
            'label' => esc_html__( 'Hover', 'odcore' ),
         ]
      );

      
      $this->add_control(
			'od_team_team_style2_title_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-item:hover .it-team-3-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();
      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_team_style2_title_typography', 
            'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'selectors' => [
                    '{{WRAPPER}} .it-team-3-title',
                    '{{WRAPPER}} .ed-team-title',
                ],
			]
		);
      
      $this->add_control(
			'od_team_team_style2_subtitle_heading',
			[
				'label' => esc_html__( 'Sub Title', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' ,'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
         'od_team_team_style2_subtitle_tabs',
         [
            
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' , 'layout-4'],
                ],
         ]
      );

      // normal

      $this->start_controls_tab(
         'od_team_team_style2_subtitle_normal_tab',
         [
            'label' => esc_html__( 'Normal', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_team_style2_subtitle_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-content span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-author-box span' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      // Hover

      $this->start_controls_tab(
         'od_team_team_style2_subtitle_hover_tab',
         [
            'label' => esc_html__( 'Hover', 'odcore' ),
         ]
      );

      
      $this->add_control(
			'od_team_team_style2_subtitle_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-item:hover .it-team-3-content span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-author-box span:hover' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();
      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_team_style2_subtitle_typography', 
            'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' ,'layout-4'],
                ],
				'selectors' => [
                    '{{WRAPPER}} .it-team-3-content span',
                    '{{WRAPPER}} .ed-team-author-box span',
                ],
			]
		);


      $this->add_control(
			'od_team_team_style2_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' ,'layout-3'],
                ],
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
            'od_team_team_style2_icon_heading_tabs',
            [
               
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],
            ]
         );

         // Normal

      $this->start_controls_tab(
            'od_team_team_style2_icon_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
      );

      $this->add_control(
			'od_team_team_style2_icon_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-box button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-box button' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_team_style2_icon_normal_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-box button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-box button' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();


         // Hover

      $this->start_controls_tab(
            'od_team_team_style2_icon_hover_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
      );

       $this->add_control(
			'od_team_team_style2_icon_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-box:hover button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-box:hover button' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_team_style2_icon_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-box:hover button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-box:hover button' => 'color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();



      $this->add_control(
			'od_team_team_style2_social_icon_heading',
			[
				'label' => esc_html__( 'Social Icon', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' , 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->add_control(
			'od_team_team_style2_social_icon_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' , 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-wrap' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-team-3-social-wrap::after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-wrap > a' => 'background-color: {{VALUE}}',
				],
			]
		);

      
      $this->add_control(
			'od_team_team_style2_social_icon_hover_bg_color',
			[
				'label' => esc_html__( 'BG Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-social-wrap > a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_team_style2_social_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3' , 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-wrap > a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-wrap > a' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_team_style2_social_icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3', 'layout-4'],
                ],
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-team-3-social-wrap > a:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-social-wrap > a:hover' => 'color: {{VALUE}}',
				],
			]
		);

      

      




	

		$this->end_controls_section();

		$this->start_controls_section(
			'od_team_button_content',
			[
				'label' => __( 'Button 1', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->start_controls_tabs(
         'od_team_button_content_tabs'
      );

      // Normal

      $this->start_controls_tab(
         'od_team_button_content_normal_tab',
         [
            'label' => esc_html__( 'Normal', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_button_content_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme i' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button_content_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button_content_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme i' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      // Hover

      $this->start_controls_tab(
         'od_team_button_content_hover_tab',
         [
            'label' => esc_html__( 'Hover', 'odcore' ),
         ]
      );


      $this->add_control(
			'od_team_button_content_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button_content_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button_content_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();
      
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_button_content_typography',
				'selectors' => [
                    '{{WRAPPER}}  .ed-btn-theme',
                ],
			]
		);
	

		$this->end_controls_section();

		$this->start_controls_section(
			'od_team_button2_content',
			[
				'label' => __( 'Button 2', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->start_controls_tabs(
         'od_team_button2_content_tabs'
      );

      // Normal

      $this->start_controls_tab(
         'od_team_button2_content_normal_tab',
         [
            'label' => esc_html__( 'Normal', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_button2_content_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-dark i' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_button2_content_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button2_content_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark i' => 'background-color: {{VALUE}}',
				],
			]
		);



      $this->end_controls_tab();

      // Hover

      $this->start_controls_tab(
         'od_team_button2_content_hover_tab',
         [
            'label' => esc_html__( 'Hover', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_button2_content_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-dark:hover i' => 'color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_button2_content_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'od_team_button2_content_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-dark:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();

      
      $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_team_button2_content_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark',
                ],
			]
		);

	

		$this->end_controls_section();

      $this->start_controls_section(
			'od_team_arrow2_content',
			[
				'label' => __( 'Arrow', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

      $this->start_controls_tabs(
         'od_team_arrow2_content_tabs'
      );

      // Normal

      $this->start_controls_tab(
         'od_team_arrow2_content_normal_tab',
         [
            'label' => esc_html__( 'Normal', 'odcore' ),
         ]
      );

      $this->add_control(
			'od_team_arrow2_content_normal_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-arrow-box button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-arrow-box button' => 'border-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_arrow2_content_normal_icon_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-arrow-box button' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      // Hover

      $this->start_controls_tab(
         'od_team_arrow2_content_hover_tab',
         [
            'label' => esc_html__( 'Hover', 'odcore' ),
         ]
      );

      
      $this->add_control(
			'od_team_arrow2_content_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-arrow-box button:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-team-arrow-box button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'od_team_arrow2_content_hover_icon_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team-arrow-box button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->end_controls_tab();

      $this->end_controls_tabs();


      $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $tp_section_title_show = $settings['tp_section_title_show'];
        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $tp_description = $settings['tp_description'];
        $button_swticher = $settings['button_swticher'];
        $button_swticher2 = $settings['button_swticher2'];
        $button_text = $settings['button_text'];
        $button_text2 = $settings['button_text2'];
        $button_url = $settings['button_url'];
        $button_url2 = $settings['button_url2'];
        $category = $settings['category'];

        $od_testi_section_shap_img_1 = $settings['od_testi_section_shap_img_1'];
        $od_testi_section_shap_img_2 = $settings['od_testi_section_shap_img_2'];
        $od_testi_section_shap_img_3 = $settings['od_testi_section_shap_img_3'];

   

      
        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';



       
    $args = array(
        'post_type' => 'team',
        'post_status' => 'publish',
        'posts_per_page' => $posts_per_page,
        'orderby' => $orderby,
        'order' => $order,
        'tax_query' => array(
            array(
                'taxonomy' => 'team-cat', // Replace with your custom taxonomy name
                'field' => 'slug', // Can be 'slug' or 'term_id' or 'name'
                'terms' => $category, // Replace $category with the term slug or ID
            ),
        ),
    );



        // The Query
        $query = new \WP_Query($args);


		?>

	    <!-- style 2 -->
	    <?php if ( $settings['od_design_style'] === 'layout-2' ):
            $team_thumbnail = $settings['team_thumbnail'];


        ?>
        

         <!-- team-area-start -->
      <div class="it-team-3-area p-relative z-index pt-110 pb-90">
         <div class="it-team-3-bg" style="background-image:url(<?php echo esc_url($team_thumbnail['url'], 'odcore');?>)"></div>
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="row">
               <div class="col-xl-12">
                  <div class="it-event-title-box text-center pb-40">
                     <span class="it-section-subtitle-3">
                        <img src="<?php echo esc_url($od_testi_section_shap_img_1['url'], 'odcore');?>" alt="">
                        <?php echo esc_html($tp_sub_title, 'odcore');?>
                        <img src="<?php echo esc_url($od_testi_section_shap_img_2['url'], 'odcore');?>" alt="">
                     </span>
                     <h2 class="it-section-title-3"><?php echo tp_kses($tp_title, 'odcore');?></h2>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">

               <?php if ($query->have_posts()) : ?>
                    <?php while ($query->have_posts()) : 
                        $query->the_post();
                        global $post;
                        $categories = get_the_category($post->ID);
                        $thumbnail_id = get_post_thumbnail_id(get_the_ID());

                        // Get the alt text for the post thumbnail
                        $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                        $instructor_designation = function_exists('get_field') ? get_field('instructor_designation') : '';
                        $facebook = function_exists('get_field') ? get_field('facebook') : '';
                        $twitter = function_exists('get_field') ? get_field('twitter') : '';
                        $skype = function_exists('get_field') ? get_field('skype') : '';
                        $linkedin = function_exists('get_field') ? get_field('linkedin') : '';
                ?>
               <div class="col-xl-3 col-lg-4 col-md-6 mb-30">
                  <div class="it-team-3-item text-center">
                     <div class="it-team-3-thumb fix">
                        <img src="<?php the_post_thumbnail_url();?>" alt="<?php echo esc_attr($alt_text, 'odcore');?>">
                     </div>
                     <div class="it-team-3-content">
                        <div class="it-team-3-social-box p-relative">
                           <button>
                              <i class="fa-light fa-share-nodes"></i>
                           </button>
                           <div class="it-team-3-social-wrap">
                            <?php if(!empty($facebook)):?>
                               <a href="<?php echo esc_url($facebook, 'odcore');?>"><i class="fab fa-facebook-f"></i></a>
                            <?php endif;?>
                            <?php if(!empty($twitter)):?>
                               <a href="<?php echo esc_url($twitter, 'odcore');?>"><i class="fab fa-twitter"></i></a>
                            <?php endif;?>
                            <?php if(!empty($skype)):?>
                               <a href="<?php echo esc_url($skype, 'odcore');?>"><i class="fab fa-skype"></i></a>
                            <?php endif;?>
                            <?php if(!empty($linkedin)):?>
                               <a href="<?php echo esc_url($linkedin, 'odcore');?>"><i class="fab fa-linkedin-in"></i></a>
                            <?php endif;?>
                           </div>
                        </div>
                        <div class="it-team-3-author-box">
                           <h4 class="it-team-3-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                           <span><?php echo esc_html($instructor_designation, 'odcore');?></span>
                        </div>
                     </div>
                  </div>
               </div>
            <?php endwhile; wp_reset_query(); ?>
            <?php endif; ?>


            </div>
         </div>
      </div>
      <!-- team-area-end -->


           <!-- style 2 -->
        <?php elseif ( $settings['od_design_style'] === 'layout-3' ):

        ?>
           <!-- team-area-start -->
      <div class="ed-team-area grey-bg-5 p-relative fix z-index pt-110 pb-90">
         <div class="ed-team-shape-1 d-none d-md-block">
            <img src="<?php echo esc_url($od_testi_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="it-team-title-wrap mb-40">
               <div class="row align-items-center">
                  <div class="col-xl-6">
                <?php if(!empty($tp_section_title_show)):?>
                     <div class="it-team-title-box">
                        <span class="it-section-subtitle-5 orange"><i class="fa-light fa-book"></i><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
              <?php endif;?>
                  </div>
                  <div class="col-xl-6">
                     <div class="ed-team-arrow-box text-end">
                        <button class="slider-prev">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M9.57031 5.92969L3.50031 11.9997L9.57031 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              <path d="M20.5 12H3.67" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>
                        <button class="slider-next">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M14.4297 5.92969L20.4997 11.9997L14.4297 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              <path d="M3.5 12H20.33" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>          
                     </div>
                  </div>
               </div>
            </div>
            <div class="ed-team-wrapper">
               <div class="swiper-container ed-team-active">
                  <div class="swiper-wrapper">
                        <?php if ($query->have_posts()) : ?>
                            <?php while ($query->have_posts()) : 
                                $query->the_post();
                                global $post;
                                $categories = get_the_category($post->ID);
                                $thumbnail_id = get_post_thumbnail_id(get_the_ID());
        
                                // Get the alt text for the post thumbnail
                                $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                                $instructor_designation = function_exists('get_field') ? get_field('instructor_designation') : '';
                                $facebook = function_exists('get_field') ? get_field('facebook') : '';
                                $twitter = function_exists('get_field') ? get_field('twitter') : '';
                                $skype = function_exists('get_field') ? get_field('skype') : '';
                                $linkedin = function_exists('get_field') ? get_field('linkedin') : '';
                        ?>
                     <div class="swiper-slide">
                        <div class="ed-team-item">
                           <div class="ed-team-thumb fix">
                              <img src="<?php the_post_thumbnail_url();?>" alt="<?php echo esc_attr($alt_text, 'odcore');?>">
                           </div>
                           <div class="ed-team-content p-relative">
                              <div class="ed-team-social-box p-relative">
                                 <button>
                                    <i class="fa-light fa-share-nodes"></i>
                                 </button>
                                 <div class="ed-team-social-wrap">
                                        <?php if(!empty($facebook)):?>
                                           <a href="<?php echo esc_url($facebook, 'odcore');?>"><i class="fab fa-facebook-f"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($twitter)):?>
                                           <a href="<?php echo esc_url($twitter, 'odcore');?>"><i class="fab fa-twitter"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($skype)):?>
                                           <a href="<?php echo esc_url($skype, 'odcore');?>"><i class="fab fa-skype"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($linkedin)):?>
                                           <a href="<?php echo esc_url($linkedin, 'odcore');?>"><i class="fab fa-linkedin-in"></i></a>
                                        <?php endif;?>
                                 </div>
                              </div>
                              <div class="ed-team-author-box">
                                 <h4 class="ed-team-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                 <span><?php echo esc_html($instructor_designation, 'odcore');?></span>
                              </div>
                           </div>
                        </div>
                     </div>
                    <?php endwhile; wp_reset_query(); ?>
                    <?php endif; ?>

                </div>
               </div>
            </div>
         </div>
      </div>
      <!-- team-area-end -->

          <!-- style 2 -->
        <?php elseif ( $settings['od_design_style'] === 'layout-4' ):

        ?>

        <!-- team-area-start -->
      <div class="ed-team-area p-relative inner-style fix z-index pt-110 pb-90">
         <div class="container">
        <?php if(!empty($tp_section_title_show)):?>
            <div class="it-team-title-wrap mb-40">
               <div class="row align-items-center justify-content-center">
                  <div class="col-xl-6">
                     <div class="it-team-title-box text-center">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">

                <?php if ($query->have_posts()) : ?>
                    <?php while ($query->have_posts()) : 
                        $query->the_post();
                        global $post;
                        $categories = get_the_category($post->ID);
                        $thumbnail_id = get_post_thumbnail_id(get_the_ID());

                        // Get the alt text for the post thumbnail
                        $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                        $instructor_designation = function_exists('get_field') ? get_field('instructor_designation') : '';
                        $facebook = function_exists('get_field') ? get_field('facebook') : '';
                        $twitter = function_exists('get_field') ? get_field('twitter') : '';
                        $skype = function_exists('get_field') ? get_field('skype') : '';
                        $linkedin = function_exists('get_field') ? get_field('linkedin') : '';
                ?>
               <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-30">
                  <div class="ed-team-item">
                     <div class="ed-team-thumb fix">
                        <img src="<?php the_post_thumbnail_url();?>" alt="<?php echo esc_attr($alt_text, 'odcore');?>">
                     </div>
                     <div class="ed-team-content p-relative">
                        <div class="ed-team-social-box p-relative">
                           <button>
                              <i class="fa-light fa-share-nodes"></i>
                           </button>
                           <div class="ed-team-social-wrap">
                                        <?php if(!empty($facebook)):?>
                                           <a href="<?php echo esc_url($facebook, 'odcore');?>"><i class="fab fa-facebook-f"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($twitter)):?>
                                           <a href="<?php echo esc_url($twitter, 'odcore');?>"><i class="fab fa-twitter"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($skype)):?>
                                           <a href="<?php echo esc_url($skype, 'odcore');?>"><i class="fab fa-skype"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($linkedin)):?>
                                           <a href="<?php echo esc_url($linkedin, 'odcore');?>"><i class="fab fa-linkedin-in"></i></a>
                                        <?php endif;?>
                           </div>
                        </div>
                        <div class="ed-team-author-box">
                           <h4 class="ed-team-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                           <span><?php echo esc_html($instructor_designation, 'odcore');?></span>
                        </div>
                     </div>
                  </div>
               </div>

                <?php endwhile; wp_reset_query(); ?>
                <?php endif; ?>
            </div>
         </div>
      </div>
      <!-- team-area-end -->   

	    <!-- style default -->
	    <?php else : 
	    ?>

            <!-- team-area-start -->
      <div class="it-team-area p-relative pt-120 pb-120">
         <div class="it-team-shape-1 d-none d-xl-block">
            <img src="<?php echo esc_url($od_testi_section_shap_img_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-team-shape-2 d-none d-xxl-block">
            <img src="<?php echo esc_url($od_testi_section_shap_img_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="it-team-shape-3 d-none d-xl-block">
            <img src="<?php echo esc_url($od_testi_section_shap_img_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-xl-5 col-lg-5">
                  <div class="it-team-left">
                    <?php if(!empty($tp_section_title_show)):?>
                     <div class="it-team-title-box pb-15">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                 <?php endif;?>
                     <div class="it-team-text">
                        <p><?php echo tp_kses($tp_description, 'odcore');?></p>
                     </div>
                     <div class="it-team-button">
                        <?php if(!empty($button_swticher)):?>
                        <a class="ed-btn-theme mr-15" href="<?php echo esc_url($button_url, 'odcore');?>">
                           <?php echo esc_html($button_text, 'odcore');?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                    <?php endif;?>
                     <?php if(!empty($button_swticher2)):?>
                        <a class="ed-btn-dark" href="<?php echo esc_url($button_url2, 'odcore');?>">
                           <?php echo esc_html($button_text2, 'odcore');?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                        <?php endif;?>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7">
                  <div class="it-team-right-box">
                     <div class="row">

                        <?php if ($query->have_posts()) : ?>
                            <?php while ($query->have_posts()) : 
                                $query->the_post();
                                global $post;
                                $categories = get_the_category($post->ID);
                                $thumbnail_id = get_post_thumbnail_id(get_the_ID());
        
                                // Get the alt text for the post thumbnail
                                $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                                $instructor_designation = function_exists('get_field') ? get_field('instructor_designation') : '';
                                $facebook = function_exists('get_field') ? get_field('facebook') : '';
                                $twitter = function_exists('get_field') ? get_field('twitter') : '';
                                $skype = function_exists('get_field') ? get_field('skype') : '';
                                $linkedin = function_exists('get_field') ? get_field('linkedin') : '';
                        ?>
                        <div class="col-xl-6 col-lg-6 col-md-6 mb-30">
                           <div class="it-team-item">
                              <div class="it-team-thumb-box p-relative">
                                 <div class="it-team-thumb">
                                    <img src="<?php the_post_thumbnail_url();?>" alt="<?php echo esc_attr($alt_text, 'odcore');?>">
                                 </div>
                                 <div class="it-team-social-box">
                                    <button><i class="fa-sharp fa-light fa-share-nodes"></i></button>
                                    <div class="it-team-social">
                                        <?php if(!empty($facebook)):?>
                                           <a href="<?php echo esc_url($facebook, 'odcore');?>"><i class="fab fa-facebook-f"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($twitter)):?>
                                           <a href="<?php echo esc_url($twitter, 'odcore');?>"><i class="fab fa-twitter"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($skype)):?>
                                           <a href="<?php echo esc_url($skype, 'odcore');?>"><i class="fab fa-skype"></i></a>
                                        <?php endif;?>
                                        <?php if(!empty($linkedin)):?>
                                           <a href="<?php echo esc_url($linkedin, 'odcore');?>"><i class="fab fa-linkedin-in"></i></a>
                                        <?php endif;?>
                                    </div>
                                 </div>
                                 <div class="it-team-author-box d-flex align-items-center justify-content-between">
                                    <div class="it-team-author-info">
                                       <h5 class="it-team-author-name"><a href="<?php the_permalink();?>"><?php the_title();?></a>
                                       </h5>
                                       <span><?php echo esc_html($instructor_designation, 'odcore');?></span>
                                    </div>
                                    <div class="it-team-link">
                                       <a href="teacher-details.html">
                                          <svg width="21" height="8" viewBox="0 0 21 8" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                             <path
                                                d="M20.3536 4.35355C20.5488 4.15829 20.5488 3.84171 20.3536 3.64645L17.1716 0.464466C16.9763 0.269204 16.6597 0.269204 16.4645 0.464466C16.2692 0.659728 16.2692 0.976311 16.4645 1.17157L19.2929 4L16.4645 6.82843C16.2692 7.02369 16.2692 7.34027 16.4645 7.53553C16.6597 7.7308 16.9763 7.7308 17.1716 7.53553L20.3536 4.35355ZM0 4.5H20V3.5H0V4.5Z"
                                                fill="currentcolor" />
                                          </svg>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                    <?php endwhile; wp_reset_query(); ?>
                    <?php endif; ?>

                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- team-area-end -->


    	<?php endif;
         $od_testi_section_team_autoplay_switcher = $settings['od_testi_section_team_autoplay_switcher'];
      ?> 

        <script>
            "use strict";
            jQuery(document).ready(function($) {
                // 13. Swiper Js   
                  const sliderAutoplay = <?php echo $od_testi_section_team_autoplay_switcher ? 'true' : 'false'; ?>;
            const teamswiper = new Swiper('.ed-team-active', {
                // Optional parameters
                speed:1500,
                loop: true,
                slidesPerView: 4,
                spaceBetween: 50,
                autoplay: sliderAutoplay ? { delay: 3000 } : false,
                breakpoints: {
                    '1400': {
                        slidesPerView: 4,
                    },
                    '1200': {
                        slidesPerView: 4,
                        spaceBetween: 30,
                    },
                    '992': {
                        slidesPerView: 3,
                        spaceBetween: 30,
                    },
                    '768': {
                        slidesPerView: 2,
                        spaceBetween: 30,
                    },
                    '576': {
                        slidesPerView: 2,
                        spaceBetween: 30,
                    },
                    '0': {
                        slidesPerView: 1,
                    },
                },
                navigation: {
                    prevEl: '.slider-prev',
                    nextEl: '.slider-next',
                },
            });
      
            

                

            });
        </script> 

		<?php
	}
}

$widgets_manager->register( new TP_Team() );