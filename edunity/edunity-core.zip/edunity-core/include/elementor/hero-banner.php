<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Hero_Banner extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'hero-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Banner', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'odcore'),
                    'layout-2' => esc_html__('Layout 2', 'odcore'),
                    'layout-3' => esc_html__('Layout 3', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

         // tp_section_title
        $this->start_controls_section(
            'hero_1_bg',
            [
                'label' => esc_html__('Background', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1']
                ],
            ]
        );

        $this->add_control(
            'hero_1_bg_img',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/slider/slider-bg.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1']
                ],
            ]
        );
        $this->add_control(
            'hero_bg_1_color',
            [
                'label' => esc_html__( 'Background Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#F3FBF5',
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-bg' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1']
                ],
            ]
        );


         $this->end_controls_section();

         
         // Shap For Style 2
        $this->start_controls_section(
            'od_banner2_shap',
            [
                'label' => esc_html__('Shap', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-2']
                ],
            ]
        );

        $this->add_control(
			'od_banner2_shap1',
			[
				'label' => esc_html__( 'Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/shape-1-1.png',
				],
			]
		);
        $this->add_control(
			'od_banner2_shap2',
			[
				'label' => esc_html__( 'Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/shape-1-2.png',
				],
			]
		);
        $this->add_control(
			'od_banner2_shap3',
			[
				'label' => esc_html__( 'Shap 3', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/shape-1-3.png',
				],
			]
		);
        $this->add_control(
			'od_banner2_image_bgshap1',
			[
				'label' => esc_html__( 'Thumb BG Shap 1', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/thumb-shape-1-2.png',
				],
			]
		);

        $this->add_control(
			'od_banner2_image_bgshap2',
			[
				'label' => esc_html__( 'Thumb BG Shap 2', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/hero/thumb-shape-1-1.png',
				],
			]
		);


        $this->end_controls_section();


        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sub Title', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1']
                ],
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-1', 'layout-3']
                ],
            ]
        );

        

   

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('section description here', 'odcore'),
                'placeholder' => esc_html__('Type section description here', 'odcore'),
            ]
        );

   
        $this->end_controls_section();


         // tp_btn_button_group
        $this->start_controls_section(
            'hero_one_tooltip_area',
            [
                'label' => esc_html__('Tooltip', 'odcore'),
            ]
        );
         $this->add_control(
            'tool_tooltip_content',
            [
                'label' => esc_html__('Content', 'odcore'),
                'type' => Controls_Manager::TEXTAREA,
                'default' =>tp_kses('<span><i>200+</i> Instructor</span>', 'odcore'),
                'title' => esc_html__('Type Text Here', 'odcore'),
                'label_block' => true,
            ]
        );
         $this->add_control(
            'tool_tooltip_img',
            [
                'label' => esc_html__('Image', 'odcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/slider/instructor.png',
                ],
                'title' => esc_html__('Upload Image Here', 'odcore'),
                'label_block' => true,
            ]
        );


         $this->add_control(
            'tool_tooltip_content2',
            [
                'label' => esc_html__('Content', 'odcore'),
                'type' => Controls_Manager::TEXTAREA,
                'default' =>tp_kses('<i>5.8k</i><span>Success Courses</span>', 'odcore'),
                'title' => esc_html__('Type Text Here', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
            ]
        );

        $this->end_controls_section();

        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'odcore'),
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-1']
                ],
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => true,
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );

  
    

        $this->end_controls_section();
         // _tp_image
        $this->start_controls_section(
            'video_button_section',
            [
                'label' => esc_html__('Button Video', 'odcore'),

                'condition' => [
                    'od_design_style' => 'layout-3'
                ],
            ]
        );

     
        $this->add_control(
            'video_button_text',
            [
                'label' => esc_html__( 'Video Button URL', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Watch Now', 'odcore' ),
                'placeholder' => esc_html__( 'Type URL Here', 'odcore' ),
            ]
        );
        $this->add_control(
            'video_button_url',
            [
                'label' => esc_html__( 'Video Button URL', 'odcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'odcore' ),
                'placeholder' => esc_html__( 'Type URL Here', 'odcore' ),
            ]
        );

        $this->end_controls_section();

        // _tp_image
        $this->start_controls_section(
            '_tp_image_section',
            [
                'label' => esc_html__('Thumbnail', 'odcore'),
            ]
        );
        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/slider/thumb-1-1.jpg',
                ],
                'condition' => [
                    'od_design_style' => 'layout-1'
                ],
            ]
        );
        $this->add_control(
            'tp_image2',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/hero/thumb-1-1.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-2'],
                ],
            ]
        );

        $this->add_control(
            'tp_image3',
            [
                'label' => esc_html__( 'Choose Image', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/assets/img/hero/thumb-1-2.png',
                ],
                'condition' => [
                    'od_design_style' => ['layout-3', 'layout-2'],
                ],
            ]
        );



      
        $this->end_controls_section();

        // _tp_image
        $this->start_controls_section(
            'od_shape_image_section',
            [
                'label' => esc_html__('Shape Image', 'odcore'),
                'condition' => array(
                    'od_design_style' => [ 'layout-3'],
                ),
            ]
        );
        $this->add_control(
            'od_shape_image_1',
            [
                'label' => esc_html__( 'Shap 1', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-1.png',
                ],
            ]
        );

        $this->add_control(
            'od_shape_image_2',
            [
                'label' => esc_html__( 'Shap 2', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-2.png',
                ],
            ]
        );        
        $this->add_control(
            'od_shape_image_3',
            [
                'label' => esc_html__( 'Shap 3', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-4.png',
                ],
            ]
        );        
        $this->add_control(
            'od_shape_image_4',
            [
                'label' => esc_html__( 'Shap 4', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-3.png',
                ],
            ]
        );        
        $this->add_control(
            'od_shape_image_5',
            [
                'label' => esc_html__( 'Shap 5', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-5.png',
                ],
            ]
        );        
        $this->add_control(
            'od_shape_image_6',
            [
                'label' => esc_html__( 'Shap 6', 'odcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri() . '/assets/img/hero/shape-2-3.png',
                ],
            ]
        );        

     

        $this->end_controls_section();


		// TAB_STYLE
		$this->start_controls_section(
			'hero_bg_1_title',
			[
				'label' => __( 'Title & Contnet', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'hero_1_sub_title_heading',
            [
                'label' => esc_html__( 'Subtitle', 'odcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'hero_1_sub_title_bg',
            [
                'label' => esc_html__( 'BG Color', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-hero-subtitle' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_1_sub_title',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-subtitle' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-hero-subtitle' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'hero_1_sub_title_typography',
                'selectors' =>[
                     '{{WRAPPER}} .ed-slider-subtitle',
                     '{{WRAPPER}} .ed-hero-subtitle',
                ],
            ]
        );
         $this->add_control(
            'hero_1_title_heading',
            [
                'label' => esc_html__( 'Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'hero_1_title',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-title' => 'color: {{VALUE}}',
                ],
            ]
        );


         $this->add_control(
            'hero_1__color_title_heading',
            [
                'label' => esc_html__( 'Color Title', 'odcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'hero_1_color_title',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-title span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'hero_1_title_typography',
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-title',
                ],
            ]
        );
        $this->add_control(
            'hero_1_desc',
            [
                'label' => esc_html__( 'Description', 'odcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'hero_1_desc_color',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-hero-content > span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-hero-2-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'hero_1_desc_typography',
                'selectors' => [
                    '{{WRAPPER}} .ed-slider-content p',
                    '{{WRAPPER}} .ed-hero-content > span',
                    '{{WRAPPER}} .ed-hero-2-content p',
                ],
            ]
        );
        $this->add_control(
            'hero_1_button',
            [
                'label' => esc_html__( 'Button', 'odcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3'],
                ],
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs(
            'hero_1_btn_styles',
            [
                
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-3'],
                ],
            ]
        );
        $this->start_controls_tab(
            'hero_1_btn_normal_section',
            [
                'label' => esc_html__( 'Normal', 'odcore' ),
            ]
        );

        $this->add_control(
            'hero_1_button_normal_color',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-btn-dark i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-hero-2-button .ed-btn-radius' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_1_button_normal_bg_color',
            [
                'label' => esc_html__( 'Background Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .ed-hero-2-button .ed-btn-radius' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_1_button_normal_icon_bg_color',
            [
                  'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
                'label' => esc_html__( 'Icon BG Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark i' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'hero_1_btn_hover_section',
            [
                'label' => esc_html__( 'Hover', 'odcore' ),
            ]
        );

        $this->add_control(
            'hero_1_button_hover_color',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-btn-dark:hover i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ed-btn-radius:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_1_button_bg_hover_color',
            [
                'label' => esc_html__( 'Background Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark:hover' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .ed-btn-radius:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_1_button_bg_icon_hover_color',
            [
                  'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
                'label' => esc_html__( 'Icon BG Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-btn-dark:hover i' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs()
        ;
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'condition' => [
                    'od_design_style' => ['layout-1'],
                ],
                'name' => 'hero_1_btn_typography',
                'selectors' =>[
                     '{{WRAPPER}} .ed-btn-dark',
                     '{{WRAPPER}} .ed-btn-radius',
                ],
            ]
        );

       

		$this->end_controls_section();

          	// TAB_STYLE
		$this->start_controls_section(
			'od_banner2_video_button_area',
			[
				'label' => __( 'Video Button', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'od_banner2_video_button__icon_bg_color',
            [
                'label' => esc_html__( 'BG Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-hero-2-content .ed-slider-3-video span' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'od_banner2_video_button__icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-hero-2-content .ed-slider-3-video span i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'od_banner2_video_button_text_color',
            [
                'label' => esc_html__( 'Text Color', 'odcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ed-hero-2-content .ed-slider-3-video a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_banner2_video_button_text_typography',
				'selector' => '{{WRAPPER}} .ed-hero-2-content .ed-slider-3-video a',
			]
		);





        $this->end_controls_section();


          	// TAB_STYLE
		$this->start_controls_section(
			'od_banner2_search_area',
			[
				'label' => __( 'Search Box', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        
		$this->add_control(
			'od_banner2_search_area_bg',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-search input' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'od_banner2_search_area_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-search span' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_banner2_search_area_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-search span svg path' => 'fill: {{VALUE}}',
				],
			]
		);


        $this->end_controls_section();
    
        	// TAB_STYLE
		$this->start_controls_section(
			'od_banner_tooltip_area',
			[
				'label' => __( 'Tooltip', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-2', 'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_banner_tooltip_area_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-instructor-box' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-hero-thumb-student' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_banner_tooltip_area_title1_color',
			[
				'label' => esc_html__( 'Title 1 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-instructor-box span i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-hero-thumb-student > span i' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_banner_tooltip_area_title2_color',
			[
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-slider-instructor-box span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-hero-thumb-student > span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_banner_tooltip_area_title_typography',
				'selectors' =>[
                     '{{WRAPPER}} .ed-slider-instructor-box span',
                     '{{WRAPPER}} .ed-hero-thumb-student > span',
                ],
			]
		);

        $this->end_controls_section();

         	// TAB_STYLE
		$this->start_controls_section(
			'od_banner_tooltip_area2',
			[
				'label' => __( 'Tooltip 2', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        
        $this->add_control(
			'od_banner_tooltip2_area_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-thumb-courses' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_banner_tooltip2_area_title1_color',
			[
				'label' => esc_html__( 'Title 1 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-thumb-courses i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_banner_tooltip2_area_title1_typography',
				'selectors' =>[
                     '{{WRAPPER}} .ed-hero-thumb-courses i',
                ],
			]
		);

        $this->add_control(
			'od_banner_tooltip2_area_title2_color',
			[
				'label' => esc_html__( 'Title 2 Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-hero-thumb-courses span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_banner_tooltip2_area_title2_typography',
				'selectors' =>[
                     '{{WRAPPER}} .ed-hero-thumb-courses span',
                ],
			]
		);


         $this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

      


        $tp_section_title_show = $settings['tp_section_title_show'];
        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $tp_desctiption = $settings['tp_desctiption'];
        $tp_btn_button_show = $settings['tp_btn_button_show'];
        $tp_btn_text = $settings['tp_btn_text'];
        $tool_tooltip_content2 = $settings['tool_tooltip_content2'];
        $tool_tooltip_content = $settings['tool_tooltip_content'];
        $hero_1_bg_img = $settings['hero_1_bg_img'];
        $tool_tooltip_img = $settings['tool_tooltip_img'];
        $tp_image3 = $settings['tp_image3'];
        $tp_image2 = $settings['tp_image2'];

        $od_banner2_shap1 = $settings['od_banner2_shap1'];
        $od_banner2_shap2 = $settings['od_banner2_shap2'];
        $od_banner2_shap3 = $settings['od_banner2_shap3'];
        $od_banner2_image_bgshap1 = $settings['od_banner2_image_bgshap1'];
        $od_banner2_image_bgshap2 = $settings['od_banner2_image_bgshap2'];

		?>

		<?php if ( $settings['od_design_style']  == 'layout-2' ): 
          
            $tp_image3 = $settings['tp_image3'];
            $tp_image2 = $settings['tp_image2'];

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                    $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                    $this->add_render_attribute('tp-button-arg', 'target', '_self');
                    $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                    $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-green mr-30');
                } else {
                    if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                        $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                        $this->add_render_attribute('tp-button-arg', 'class', 'it-btn-green mr-30');
                    }
            }

            
             $this->add_render_attribute('title_args', 'class', 'it-hero-title mt-5 wow itfadeUp');
            $this->add_render_attribute('title_args', 'data-wow-duration', '.9s');
            $this->add_render_attribute('title_args', 'data-wow-delay', '.5s');

            $this->add_render_attribute('tp-button-arg', 'class', 'it-btn-green');
        ?>
        
             <!-- hero-area-start -->
      <div class="ed-hero-area  p-relative fix">
         <div class="ed-hero-bg p-relative z-index" style="background-image: url(<?php echo esc_url($hero_1_bg_img['url'], 'odcore');?>);">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-xl-6 col-lg-6">
                     <div class="ed-hero-content">
                        <div class="ed-hero-title-box">
                           <span class="ed-hero-subtitle  wow itfadeUp" data-wow-duration=".9s"
                           data-wow-delay=".3s"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                           <h1 class="ed-slider-title  wow itfadeUp" data-wow-duration=".9s"
                           data-wow-delay=".5s"><?php echo tp_kses($tp_title, 'odcore');?></h1>
                        </div>
                        <span class="pb-25  wow itfadeUp" data-wow-duration=".9s"
                        data-wow-delay=".7s"><?php echo tp_kses($tp_desctiption, 'odcore');?></span>
                        <div class="ed-hero-search p-relative  wow itfadeUp" data-wow-duration=".9s"
                        data-wow-delay=".9s">
                           <form method="get" action="<?php echo home_url('/'); ?>">
                                <input type="text" name="s" placeholder="What do you want to learn today? Type and Hit Enter">
                                <input type="hidden" name="post_type" value="courses">
                                <span>
                                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.858 14.1839L10.9851 10.3731C11.9993 9.27123 12.6225 7.81402 12.6225 6.21052C12.622 2.78032 9.79656 0 6.31098 0C2.8254 0 0 2.78032 0 6.21052C0 9.64071 2.8254 12.421 6.31098 12.421C7.81699 12.421 9.19827 11.9001 10.2833 11.0341L14.1711 14.86C14.3605 15.0467 14.6681 15.0467 14.8575 14.86C15.0474 14.6734 15.0474 14.3706 14.858 14.1839ZM6.31098 11.4655C3.3618 11.4655 0.971033 9.11277 0.971033 6.21052C0.971033 3.30826 3.3618 0.955524 6.31098 0.955524C9.26019 0.955524 11.6509 3.30826 11.6509 6.21052C11.6509 9.11277 9.26019 11.4655 6.31098 11.4655Z" fill="white" />
                                    </svg>
                                </span>
                            </form>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-6">
                     <div class="ed-hero-thumb-wrap text-center text-md-end  p-relative">
                        <div class="ed-hero-thumb-main  p-relative">
                           <img src="<?php echo esc_url($tp_image2['url'], 'odcore');?>" alt="">
                           <div class="ed-hero-thumb-shape-1">
                              <img src="<?php echo esc_url($od_banner2_image_bgshap2['url'], 'odcore');?>" alt="">
                           </div>
                        </div>
                        <div class="ed-hero-thumb-sm p-relative">
                           <img src="<?php echo esc_url($tp_image3['url'], 'odcore');?>" alt="">
                           <div class="ed-hero-thumb-shape-1">
                              <img src="<?php echo esc_url($od_banner2_image_bgshap1['url'], 'odcore');?>" alt="">
                           </div>
                        </div>
                        <div class="ed-hero-thumb-shape-2">
                           <img src="<?php echo esc_url($od_banner2_shap1['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="ed-hero-thumb-shape-3">
                           <img src="<?php echo esc_url($od_banner2_shap2['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="ed-hero-thumb-shape-4">
                           <img src="<?php echo esc_url($od_banner2_shap3['url'], 'odcore');?>" alt="">
                        </div>
                        <div class="ed-hero-thumb-student d-none d-md-flex align-items-center">
                            <?php echo tp_kses($tool_tooltip_content, 'odcore');?>
                           <div><img src="<?php echo esc_url($tool_tooltip_img['url']);?>" alt=""></div>
                        </div>
                        <div class="ed-hero-thumb-courses d-none d-md-block">
                           <?php echo tp_kses($tool_tooltip_content2, 'odcore');?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- hero-area-end -->
       

        <?php elseif ( $settings['od_design_style']  == 'layout-3' ):

            $video_button_url = $settings['video_button_url'];
            $video_button_text = $settings['video_button_text'];
            $od_shape_image_1 = $settings['od_shape_image_1'];
            $od_shape_image_2 = $settings['od_shape_image_2'];
            $od_shape_image_3 = $settings['od_shape_image_3'];
            $od_shape_image_4 = $settings['od_shape_image_4' ];
            $od_shape_image_5 = $settings['od_shape_image_5'];
            $od_shape_image_6 = $settings['od_shape_image_6'];

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                    $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                    $this->add_render_attribute('tp-button-arg', 'target', '_self');
                    $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius');
                } else {
                    if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                        $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                        $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-radius');
                    }
            } 
           

        ?>

          <!-- hero-area-start -->
      <div class="ed-hero-2-area ed-hero-2-bg fix z-index p-relative">
         <div class="ed-hero-2-shape-1">
            <img src="<?php echo esc_url($od_shape_image_1['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-hero-2-shape-2 d-none d-md-block">
            <img src="<?php echo esc_url($od_shape_image_2['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-hero-2-shape-3">
            <img src="<?php echo esc_url($od_shape_image_3['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-hero-2-shape-4">
            <img src="<?php echo esc_url($od_shape_image_6['url'], 'odcore');?>" alt="">
         </div>
         <div class="ed-hero-2-shape-5">
            <img src="<?php echo esc_url($od_shape_image_4['url'], 'odcore');?>" alt="">
         </div>
         <div class="container container-3">
            <div class="row align-items-center">
               <div class="col-xxl-6 col-xl-5 col-lg-6">
                  <div class="ed-hero-2-content">
                     <h1 class="ed-slider-title pb-5 wow itfadeUp" data-wow-duration=".9s"
                     data-wow-delay=".3s">
                     <?php echo tp_kses($tp_title, 'odcore');?>
                     </h1>
                     <div class="ed-hero-2-text mb-30 wow itfadeUp" data-wow-duration=".9s"
                     data-wow-delay=".5s">                                       
                        <p><?php echo tp_kses($tp_desctiption, 'odcore');?></p>
                     </div>
                     <div class="ed-hero-2-button-wrapper wow itfadeUp" data-wow-duration=".9s"
                     data-wow-delay=".7s">
                        <div class="ed-hero-2-button d-flex align-content-center">
                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                                <?php echo $settings['tp_btn_text']; ?>
                           </a>
                           <div class="ed-slider-3-video">
                              <span><i class="fa-sharp fa-solid fa-play"></i></span>
                              <a class="popup-video" href="<?php echo esc_url($video_button_url, 'odcore');?>"><?php echo esc_html($video_button_text, 'odcore');?></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xxl-6 col-xl-7 col-lg-6">
                  <div class="ed-hero-2-right p-relative">
                    <?php if(!empty($tp_image2['url'])):?>
                     <div class="ed-hero-2-thumb style-1">
                        <img src="<?php echo esc_url($tp_image2['url'], 'odcore');?>" alt="">
                     </div>
                    <?php endif;?>
                     <?php if(!empty($tp_image3['url'])):?>
                     <div class="ed-hero-2-thumb style-2">
                        <img src="<?php echo esc_url($tp_image3['url'], 'odcore');?>" alt="">
                     </div>
                    <?php endif;?>
                     <div class="ed-hero-thumb-student d-md-flex align-items-center d-none">
                        <?php echo tp_kses($tool_tooltip_content, 'odcore');?>
                        <img src="<?php echo esc_url($tool_tooltip_img['url'], 'odcore');?>" alt="">
                     </div>
                     <div class="ed-hero-thumb-courses d-none d-md-block">
                       <?php echo tp_kses($tool_tooltip_content2, 'odcore');?>
                     </div>
                     <div class="ed-hero-2-shape-6">
                        <img src="<?php echo esc_url($od_shape_image_5['url'], 'odcore');?>" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div> 
      </div>
      <!-- hero-area-end -->



		<?php else:




            $hero_1_bg_img = $settings['hero_1_bg_img'];
            $tool_tooltip_content = $settings['tool_tooltip_content'];
            $tool_tooltip_img = $settings['tool_tooltip_img'];
            $tp_image = $settings['tp_image'];


                  // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-dark wow itfadeUp');
                $this->add_render_attribute('tp-button-arg', 'data-wow-duration', '.9s');
                $this->add_render_attribute('tp-button-arg', 'data-wow-delay', '.7s');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-dark wow itfadeUp');
                    $this->add_render_attribute('tp-button-arg', 'data-wow-duration', '.9s');
                    $this->add_render_attribute('tp-button-arg', 'data-wow-delay', '.7s');
                }
            }


		?>

           <!-- slider-area-start -->
      <div class="ed-slider-area p-relative">
         <div class="ed-slider-bg p-relative" style="background-image:url(<?php echo esc_url($hero_1_bg_img['url'], 'odcore');?>);">
            <div class="ed-slider-instructor-box d-none d-lg-block">
               <div>
                <?php echo tp_kses($tool_tooltip_content, 'odcore');?>
                  <img src="<?php echo esc_url($tool_tooltip_img['url'],  'odcore');?>" alt="">
               </div>
            </div>
            <div class="container ">
               <div class="row p-relative">
                  <div class="col-xl-8 col-lg-6">
                     <div class="ed-slider-content">
                        <span class="ed-slider-subtitle pb-10 wow itfadeUp" data-wow-duration=".9s"
                        data-wow-delay=".3s"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h1 class="ed-slider-title wow itfadeUp" data-wow-duration=".9s"
                        data-wow-delay=".4s"><?php echo tp_kses($tp_title, 'odcore');?></h1>
                        <p class="pb-25 wow itfadeUp" data-wow-duration=".9s"
                        data-wow-delay=".5s"><?php echo tp_kses($tp_desctiption, 'odcore');?></p>

                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                                <?php echo $settings['tp_btn_text']; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
                <div class="ed-slider-shape-2 d-none d-xl-block">
                   <img src="<?php echo get_template_directory_uri();?>/assets/img/slider/shape-1-2.png" alt="">
                </div>
               </div>
                <div class="ed-slider-thumb">
                   <img src="<?php echo esc_url($tp_image['url'], 'odcore');?>" alt="">
                   <div class="ed-slider-shape-1 d-none d-xl-block">
                      <img src="<?php echo get_template_directory_uri();?>/assets/img/slider/shape-1-1.png" alt="">
                   </div>
                </div>
            </div>
         </div>
      </div>
      <!-- slider-area-end -->
                           
                           
       
         

        <?php endif; ?>

        <?php 
		
	}

}

$widgets_manager->register( new TP_Hero_Banner() );