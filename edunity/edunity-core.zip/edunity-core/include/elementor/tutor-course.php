<?php
namespace odcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Tutor_Course extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-tutor';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Tutor Course', 'odcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'odcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'odcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {



    
        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Sub Title', 'odcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );   
        $this->add_control(
            'tp_title2',
            [
                'label' => esc_html__('Title 2', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title 2 Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );   
        $this->add_control(
            'tp_title3',
            [
                'label' => esc_html__('Title 3', 'odcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Title 3 Here', 'odcore'),
                'placeholder' => esc_html__('Type Heading Text', 'odcore'),
                'label_block' => true,
            ]
        );       


        $this->end_controls_section();

        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Load More Courses', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'odcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'odcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();



		$this->start_controls_section(
            'tp_tutor_query',
            [
                'label' => esc_html__('Tutor Query', 'odcore'),
            ]
        );

        $post_type = 'courses';
        $taxonomy = 'course-category';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'odcore'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'odcore'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_category',
            [
                'label' => esc_html__('Exclude Categories', 'odcore'),
                'description' => esc_html__('Select a category to exclude', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => tp_get_categories($taxonomy),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post__not_in',
            [
                'label' => esc_html__('Exclude Item', 'odcore'),
                'type' => Controls_Manager::SELECT2,
                'options' => tp_get_all_types_post($post_type),
                'multiple' => true,
                'label_block' => true
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => esc_html__('Offset', 'odcore'),
                'type' => Controls_Manager::NUMBER,
                'default' => '0',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
			        'ID' => 'Post ID',
			        'author' => 'Post Author',
			        'title' => 'Title',
			        'date' => 'Date',
			        'modified' => 'Last Modified Date',
			        'parent' => 'Parent Id',
			        'rand' => 'Random',
			        'comment_count' => 'Comment Count',
			        'menu_order' => 'Menu Order',
			    ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' 	=> esc_html__( 'Ascending', 'odcore' ),
                    'desc' 	=> esc_html__( 'Descending', 'odcore' )
                ],
                'default' => 'desc',

            ]
        );
        $this->add_control(
            'ignore_sticky_posts',
            [
                'label' => esc_html__( 'Ignore Sticky Posts', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'odcore' ),
                'label_off' => esc_html__( 'No', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => __('Content', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'odcore'),
                'label_off' => __('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'content_limit',
            [
                'label' => __('Content Limit', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '14',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'content' => 'yes'
                ]
            ]
        );


        $this->end_controls_section();


        // layout Panel
        $this->start_controls_section(
            'tp_campaign',
            [
                'label' => esc_html__('Tutor - Layout', 'odcore'),
            ]
        );
        $this->add_control(
            'od_design_style',
            [
                'label' => esc_html__('Select Layout', 'odcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Grid Style 1', 'odcore'),
                    'layout-2' => esc_html__('Grid Style 2', 'odcore'),
                    'layout-3' => esc_html__('Grid Style 3', 'odcore'),
                    'layout-4' => esc_html__('Grid Style 4', 'odcore'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'tp_tutor_height',
            [
                'label' => esc_html__( 'Height', 'odcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tp-project-img img' => 'height: {{SIZE}}{{UNIT}};object-fit: cover;',
                ],
            ]
        );
        $this->add_control(
            'tp_tutor_dots',
            [
                'label' => esc_html__('Dots?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'odcore'),
                'label_off' => esc_html__('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_tutor_arrow',
            [
                'label' => esc_html__('Arrow Icons?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'odcore'),
                'label_off' => esc_html__('Hide', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_tutor_infinite',
            [
                'label' => esc_html__('Infinite?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_tutor_autoplay',
            [
                'label' => esc_html__('Autoplay?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-2',
                ),
            ]
        );        
        $this->add_control(
            'tp_tutor_autoplay_speed',
            [
                'label' => esc_html__('Autoplay Speed', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => '2500',
                'title' => esc_html__('Enter autoplay speed', 'odcore'),
                'label_block' => true,
                'condition' => array(
                    'tp_tutor_autoplay' => 'yes',
                    'od_design_style' => 'layout-2',
                ),
            ]
        );
        $this->add_control(
            'tp_tutor_filter',
            [
                'label' => esc_html__('Filter?', 'odcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'odcore'),
                'label_off' => esc_html__('No', 'odcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-3',
                ),
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'tp-campaign-thumb',
            ]
        );
        $this->add_control(
            'tp_tutor_pagination',
            [
                'label' => esc_html__( 'Pagination', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'no',
                // 'condition' => array(
                //     'od_design_style' => 'layout-1',
                // ),
            ]
        );
        
        $this->add_control(
            'tp_btn_button_show1',
            [
                'label' => esc_html__( 'Show Button', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'od_design_style' => 'layout-3',
                ),
            ]
        );

        $this->add_control(
            'tp_btn_text1',
            [
                'label' => esc_html__('Button Text', 'odcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'odcore'),
                'title' => esc_html__('Enter button text', 'odcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );


        $this->add_control(
            'tp_image_show',
            [
                'label' => esc_html__( 'Show Image', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        

        $this->add_control(
            'tp_prcie_show',
            [
                'label' => esc_html__( 'Show Price', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_cat_show',
            [
                'label' => esc_html__( 'Show Category', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        

        $this->add_control(
            'tp_author_show',
            [
                'label' => esc_html__( 'Show Author', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'tp_lessons_show',
            [
                'label' => esc_html__( 'Show Lessons', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );            

        $this->add_control(
            'tp_duration_show',
            [
                'label' => esc_html__( 'Show Duration', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        

        $this->add_control(
            'tp_rating_show',
            [
                'label' => esc_html__( 'Show Rating', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );               

        $this->add_control(
            'tp_students_show',
            [
                'label' => esc_html__( 'Show Students', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        

        $this->add_control(
            'course_list_difficulty_settings',
            [
                'label' => esc_html__( 'Show difficulty', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        

        $this->add_control(
            'course_list_wishlist_settings',
            [
                'label' => esc_html__( 'Show wishlist', 'odcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'odcore' ),
                'label_off' => esc_html__( 'Hide', 'odcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // tp_tutor_columns_section
        $this->start_controls_section(
            'tp_tutor_columns_section',
            [
                'label' => esc_html__('Tutor - Columns', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_tutor__for_desktop',
            [
                'label' => esc_html__( 'Columns for Desktop', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 992px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'odcore' ),
                    6 => esc_html__( '2 Columns', 'odcore' ),
                    4 => esc_html__( '3 Columns', 'odcore' ),
                    3 => esc_html__( '4 Columns', 'odcore' ),
                    2 => esc_html__( '6 Columns', 'odcore' ),
                    1 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '4',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor__for_laptop',
            [
                'label' => esc_html__( 'Columns for Laptop', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 768px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'odcore' ),
                    6 => esc_html__( '2 Columns', 'odcore' ),
                    4 => esc_html__( '3 Columns', 'odcore' ),
                    3 => esc_html__( '4 Columns', 'odcore' ),
                    2 => esc_html__( '6 Columns', 'odcore' ),
                    1 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '4',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor__for_tablet',
            [
                'label' => esc_html__( 'Columns for Tablet', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 576px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'odcore' ),
                    6 => esc_html__( '2 Columns', 'odcore' ),
                    4 => esc_html__( '3 Columns', 'odcore' ),
                    3 => esc_html__( '4 Columns', 'odcore' ),
                    2 => esc_html__( '6 Columns', 'odcore' ),
                    1 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '6',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            '
            ',
            [
                'label' => esc_html__( 'Columns for Mobile', 'odcore' ),
                'description' => esc_html__( 'Screen width less than 576px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'odcore' ),
                    6 => esc_html__( '2 Columns', 'odcore' ),
                    4 => esc_html__( '3 Columns', 'odcore' ),
                    3 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns (For Carousel Item)', 'odcore' ),
                    2 => esc_html__( '6 Columns', 'odcore' ),
                    1 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '12',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

        // tp_tutor_slider_columns_section
		$this->start_controls_section(
            'tp_tutor_slider_columns_section',
            [
                'label' => esc_html__('Tutor - Columns for Carousel', 'odcore'),
            ]
        );

        $this->add_control(
            'tp_tutor_slider_for_xl_desktop',
            [
                'label' => esc_html__( 'Columns for Extra Large Desktop', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 1920px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '3',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor_slider_for_desktop',
            [
                'label' => esc_html__( 'Columns for Desktop', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 1200px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '3',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor_slider_for_laptop',
            [
                'label' => esc_html__( 'Columns for Laptop', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 992px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '3',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor_slider_for_tablet',
            [
                'label' => esc_html__( 'Columns for Tablet', 'odcore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 768px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '2',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor_slider_for_mobile',
            [
                'label' => esc_html__( 'Columns for Mobile', 'odcore' ),
                'description' => esc_html__( 'Screen width less than 767', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '1',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'tp_tutor_slider_for_xs_mobile',
            [
                'label' => esc_html__( 'Columns for Extra Small Mobile', 'odcore' ),
                'description' => esc_html__( 'Screen width less than 575px', 'odcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1 => esc_html__( '1 Columns', 'odcore' ),
                    2 => esc_html__( '2 Columns', 'odcore' ),
                    3 => esc_html__( '3 Columns', 'odcore' ),
                    4 => esc_html__( '4 Columns', 'odcore' ),
                    5 => esc_html__( '5 Columns', 'odcore' ),
                    6 => esc_html__( '6 Columns', 'odcore' ),
                    7 => esc_html__( '7 Columns', 'odcore' ),
                    8 => esc_html__( '8 Columns', 'odcore' ),
                    9 => esc_html__( '9 Columns', 'odcore' ),
                    10 => esc_html__( '10 Columns', 'odcore' ),
                    11 => esc_html__( '10 Columns', 'odcore' ),
                    12 => esc_html__( '12 Columns', 'odcore' ),
                ],
                'separator' => 'before',
                'default' => '1',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();


        // style control

        
		$this->start_controls_section(
			'od_tutor_course_title_content_bg',
			[
				'label' => __( 'Section BG', 'odcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
		$this->add_control(
			'od_tutor_course_title_content_bg_img',
			[
				'label' => esc_html__( 'BG Image', 'odcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  get_template_directory_uri(). '/assets/img/course/ed-bg-1.jpg',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_bg_img2',
			[
				'label' => esc_html__( 'BG Image', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' =>  get_template_directory_uri(). '/assets/img/about/t-shape.png',
				],
			]
		);

        $this->add_control(
			'od_tutor_course_title_content_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-area.ed-course-bg.ed-course-style-3' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .it-course-style-3.it-course-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();

        

		$this->start_controls_section(
			'od_tutor_course_title_content2',
			[
				'label' => __( 'Title & Content', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_tutor_course_title2_content_title2',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-title-3' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title2_content_title_typography',
				'selector' => '{{WRAPPER}} .it-section-title-3',
			]
		);
        $this->add_control(
			'od_tutor_course_title2_content_subtitle2',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-section-subtitle-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-section-subtitle-5.purple-2' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title_content2_subtitle_typography',
				'selectors' => [
                    '{{WRAPPER}} .it-section-subtitle-4',
                    '{{WRAPPER}} .it-section-subtitle-5.purple-2',
                ],
			]
		);

        $this->add_control(
			'od_tutor_course_title_content2_button',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->start_controls_tabs(
            'od_tutor_course_title_content2_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course_title_content2_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         $this->add_control(
			'od_tutor_course_title_content2_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_title_content2_button_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_title_content2_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2 i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course_title_content2_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course_title_content2_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_title_content2_button_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_title_content2_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme.theme-2:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square:hover' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title_content2_button_typography',
				'selectors' => [
                    '{{WRAPPER}} .ed-btn-theme.theme-2',
                    '{{WRAPPER}} .ed-btn-square',
                ],
			]
		);


        
        $this->end_controls_section();


        $this->start_controls_section(
			'od_tutor_course_content_2',
			[
				'label' => __( 'Course Content', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-2', 'layout-3'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_heading',
			[
				'label' => esc_html__( 'Content Area', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-item' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-2-item' => 'background-color: {{VALUE}}',
				],
			]
		);


        $this->add_control(
			'od_tutor_course_content_2_title',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_title_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-title' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_title_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-style-3 .it-course-title:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_title_typography',
				'selector' => '{{WRAPPER}} .it-course-title',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_coursemeta',
			[
				'label' => esc_html__( 'Course Meta', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_coursemeta_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-2-item .it-course-info' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_coursemeta_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-info > span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_coursemeta_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-info > span i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_coursemeta_typography',
				'selector' => '{{WRAPPER}} .it-course-info > span',
			]
		);

        
        $this->add_control(
			'od_tutor_course_content_2_author',
			[
				'label' => esc_html__( 'Author', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_author_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-author > span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-course-author > span > i' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_author_text_typography',
				'selectors' =>[
                     '{{WRAPPER}} .it-course-author > span',
                     '{{WRAPPER}} .it-course-author > span > i',
                ],
			]
		);
        
        $this->add_control(
			'od_tutor_course_content_2_price',
			[
				'label' => esc_html__( 'Price', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_price_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-price-box span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_price_typogrpahy',
				'selector' => '{{WRAPPER}} .it-course-price-box span',
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_button',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_button_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-price-box a' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_button_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-price-box a:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_button_typography',
				'selector' => '{{WRAPPER}} .it-course-price-box a',
			]
		);
        $this->add_control(
			'od_tutor_course_content_2_star',
			[
				'label' => esc_html__( 'Star', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_star_color',
			[
				'label' => esc_html__( 'Icon Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-style-3 .it-course-content span.tutor-icon-star-line' => 'color: {{VALUE}}',
					'{{WRAPPER}} .it-course-style-3 .it-course-content span.tutor-icon-star-bold' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_star_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-style-3 .it-course-content span' => 'color: {{VALUE}}',
				],
			]
		);
      
        $this->add_control(
			'od_tutor_course_content_2_category',
			[
				'label' => esc_html__( 'Category', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_category_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-style-3 .it-course-thumb-text span' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course_content_2_category_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-style-3 .it-course-thumb-text span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_content_2_category_text_typography',
				'selector' => '{{WRAPPER}} .it-course-style-3 .it-course-thumb-text span',
			]
		);

        

        






        $this->end_controls_section();



		$this->start_controls_section(
			'od_tutor_course_title_content',
			[
				'label' => __( 'Title & Content', 'odcore' ),  
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4' ],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        
		$this->add_control(
			'od_tutor_course_title_content_title',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_title_shap_color',
			[
				'label' => esc_html__( 'Title Shap Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-title svg path' => 'stroke: {{VALUE}}',
				],
			]
		);

        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title_content_title_typography',
				'selector' => '{{WRAPPER}} .ed-section-title',
			]
		);

        $this->add_control(
			'od_tutor_course_title_content_subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course_title_content_subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-section-subtitle' => 'color: {{VALUE}}',
				],
			]
		);

        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title_content_subtitle_typography',
				'selector' => '{{WRAPPER}} .ed-section-subtitle',
			]
		);

        $this->add_control(
			'od_tutor_course_title_content_button_heading',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_tutor_course_title_content_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course_title_content_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
		$this->add_control(
			'od_tutor_course_title_content_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_button_normal_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme i' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course_title_content_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

           
		$this->add_control(
			'od_tutor_course_title_content_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_button_hover_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'od_tutor_course_title_content_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-btn-theme:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-theme:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-btn-square.orange:hover' => 'color: {{VALUE}}',
				],
			]
		);
         

         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course_title_content_button_typography',
				'selector' => '{{WRAPPER}} .ed-btn-theme',
			]
		);


		

		$this->end_controls_section();

		$this->start_controls_section(
			'od_tutor_course__content',
			[
				'label' => __( 'Course Content', 'odcore' ),
                'condition' => [
                    'od_design_style' => ['layout-1', 'layout-4'],
                ],
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'od_tutor_course__content_area',
			[
				'label' => esc_html__( 'Content Area', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_tutor_course__content_area_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course__content_area_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         $this->add_control(
			'od_tutor_course__content_area_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->add_control(
			'od_tutor_course__content_area_normal_bg_border_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2' => 'border-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course__content_area_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course__content_area_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_hover_bg_border_color',
			[
				'label' => esc_html__( 'Border Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();


         
        $this->add_control(
			'od_tutor_course__content_area_title',
			[
				'label' => esc_html__( 'Title', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_tutor_course__content_area_title_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course__content_area_title_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course__content_area_title_normal_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-title' => 'color: {{VALUE}}',
				],
			]
		);


         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course__content_area_title_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );
        $this->add_control(
			'od_tutor_course__content_area_title_hover_color',
			[
				'label' => esc_html__( 'Title Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .it-course-title' => 'color: {{VALUE}}',
				],
			]
		);
         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_title_typography',
				'selector' => '{{WRAPPER}} .it-course-title',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_metabox',
			[
				'label' => esc_html__( 'Course Metabox', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->add_control(
			'od_tutor_course__content_area_metabox_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-info' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_metabox_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-info span' => 'color: {{VALUE}}',
				],
			]
		);

        
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_metabox_text_typography',
				'selector' => '{{WRAPPER}} .ed-course-style-2 .it-course-info span',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_metabox_icon_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .it-course-info > span i' => 'color: {{VALUE}}',
				],
			]
		);


        
        $this->add_control(
			'od_tutor_course__content_area_author',
			[
				'label' => esc_html__( 'Author', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


        $this->start_controls_tabs(
            'od_tutor_course__content_area_author_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course__content_area_author_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course__content_area_author_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-author span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-2 .it-course-author img' => 'border-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course__content_area_author_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_tutor_course__content_area_author_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .it-course-author span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .it-course-author img' => 'border-color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_author_text_typography',
				'selector' => '{{WRAPPER}} .it-course-author span',
			]
		);

               
        $this->add_control(
			'od_tutor_course__content_area_button',
			[
				'label' => esc_html__( 'Button', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->start_controls_tabs(
            'od_tutor_course__content_area_button_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course__content_area_button_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );
         
        $this->add_control(
			'od_tutor_course__content_area_button_normal_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course__content_area_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-btn span' => 'color: {{VALUE}}',
				],
			]
		);


         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course__content_area_button_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course__content_area_button_hover_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .ed-course-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course__content_area_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .ed-course-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .ed-course-btn span' => 'color: {{VALUE}}',
				],
			]
		);

         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_button_typography',
				'selector' => '{{WRAPPER}} .ed-course-btn',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_star',
			[
				'label' => esc_html__( 'Star', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_star_color',
			[
				'label' => esc_html__( 'Star Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-rating .star_show span.tutor-icon-star-bold' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-3 .it-course-rating .star_show span.tutor-icon-star-line' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'od_tutor_course__content_area_price',
			[
				'label' => esc_html__( 'Price', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

      $this->start_controls_tabs(
            'od_tutor_course__content_area_price_tabs'
         );

         // Normal

         $this->start_controls_tab(
            'od_tutor_course__content_area_price_normal_tab',
            [
               'label' => esc_html__( 'Normal', 'odcore' ),
            ]
         );

         
        $this->add_control(
			'od_tutor_course__content_area_price_normal_color',
			[
				'label' => esc_html__( 'price Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-price-box span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-3 .it-course-rating span' => 'color: {{VALUE}}',
				],
			]
		);



         $this->end_controls_tab();

         // Hover

         $this->start_controls_tab(
            'od_tutor_course__content_area_price_hover_tab',
            [
               'label' => esc_html__( 'Hover', 'odcore' ),
            ]
         );

        $this->add_control(
			'od_tutor_course__content_area_price_hover_color',
			[
				'label' => esc_html__( 'price Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .it-course-price-box span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ed-course-style-3 .it-course-item:hover .it-course-rating span' => 'color: {{VALUE}}',
				],
			]
		);


         $this->end_controls_tab();

         $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_price_typography',
				'selector' => '{{WRAPPER}} .it-course-price-box span',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_category',
			[
				'label' => esc_html__( 'Category', 'odcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_category_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-thumb-text span' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'od_tutor_course__content_area_category_color',
			[
				'label' => esc_html__( 'Text Color', 'odcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-course-style-2 .it-course-thumb-text span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'od_tutor_course__content_area_category_typography',
				'selector' => '{{WRAPPER}} .ed-course-style-2 .it-course-thumb-text span',
			]
		);



		

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } else if (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        // include_categories
        $category_list = '';
        if (!empty($settings['category'])) {
            $category_list = implode(", ", $settings['category']);
        }
        $category_list_value = explode(" ", $category_list);

        // exclude_categories
        $exclude_categories = '';
        if(!empty($settings['exclude_category'])){
            $exclude_categories = implode(", ", $settings['exclude_category']);
        }
        $exclude_category_list_value = explode(" ", $exclude_categories);

        $post__not_in = '';
        if (!empty($settings['post__not_in'])) {
            $post__not_in = $settings['post__not_in'];
            $args['post__not_in'] = $post__not_in;
        }
        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';
        $offset_value = (!empty($settings['offset'])) ? $settings['offset'] : '0';
        $ignore_sticky_posts = (! empty( $settings['ignore_sticky_posts'] ) && 'yes' == $settings['ignore_sticky_posts']) ? true : false ;


        // number
        $off = (!empty($offset_value)) ? $offset_value : 0;
        $offset = $off + (($paged - 1) * $posts_per_page);
        $p_ids = array();

        // build up the array
        if (!empty($settings['post__not_in'])) {
            foreach ($settings['post__not_in'] as $p_idsn) {
                $p_ids[] = $p_idsn;
            }
        }

        $args = array(
            'post_type' => 'courses',
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'offset' => $offset,
            'paged' => $paged,
            'post__not_in' => $p_ids,
            'ignore_sticky_posts' => $ignore_sticky_posts
        );

        // exclude_categories
        if ( !empty($settings['exclude_category'])) {

            // Exclude the correct cats from tax_query
            $args['tax_query'] = array(
                array(
                    'taxonomy'	=> 'course-category',
                    'field'	 	=> 'slug',
                    'terms'		=> $exclude_category_list_value,
                    'operator'	=> 'NOT IN'
                )
            );

            // Include the correct cats in tax_query
            if ( !empty($settings['category'])) {
                $args['tax_query']['relation'] = 'AND';
                $args['tax_query'][] = array(
                    'taxonomy'	=> 'course-category',
                    'field'		=> 'slug',
                    'terms'		=> $category_list_value,
                    'operator'	=> 'IN'
                );
            }

        } else {
            // Include the cats from $cat_slugs in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query'][] = [
                    'taxonomy' => 'course-category',
                    'field' => 'slug',
                    'terms' => $category_list_value,
                ];
            }
        }

        $filter_list = $settings['category'];

        // The Query
        $query = new \WP_Query($args);

        // var_dump($query);

        $carousel_args = [
            'arrows' => ('yes' === $settings['tp_tutor_arrow']),
            'dots' => ('yes' === $settings['tp_tutor_dots']),
            'autoplay' => ('yes' === $settings['tp_tutor_autoplay']),
            'autoplay_speed' => absint($settings['tp_tutor_autoplay_speed']),
            'infinite' => ('yes' === $settings['tp_tutor_infinite']),
            'for_xl_desktop' => absint($settings['tp_tutor_slider_for_xl_desktop']),
            'slidesToShow' => absint($settings['tp_tutor_slider_for_desktop']),
            'for_laptop' => absint($settings['tp_tutor_slider_for_laptop']),
            'for_tablet' => absint($settings['tp_tutor_slider_for_tablet']),
            'for_mobile' => absint($settings['tp_tutor_slider_for_mobile']),
            'for_xs_mobile' => absint($settings['tp_tutor_slider_for_xs_mobile']),
        ];
        $this->add_render_attribute('tp-carousel-campaign-data', 'data-settings', wp_json_encode($carousel_args));

        $tp_section_title_show = $settings['tp_section_title_show'];
        $tp_sub_title = $settings['tp_sub_title'];
        $tp_title = $settings['tp_title'];
        $tp_btn_button_show = $settings['tp_btn_button_show'];
        $tp_btn_text = $settings['tp_btn_text'];
        $tp_title2 = $settings['tp_title2'];
        $tp_title3 = $settings['tp_title3'];

        $od_tutor_course_title_content_bg_img = $settings['od_tutor_course_title_content_bg_img'];
        $od_tutor_course_title_content_bg_img2 = $settings['od_tutor_course_title_content_bg_img2'];


        ?>

        <?php if ( $settings['od_design_style']  == 'layout-2' ): 


              // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme theme-2');
                }
            }



        ?>

             <!-- course-area-start -->
      <div class="it-course-area it-course-style-3 it-course-bg p-relative grey-bg pt-120 pb-120" style="background-image:url(<?php echo esc_url($od_tutor_course_title_content_bg_img['url'], 'odcore');?>);">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="it-course-title-wrap mb-60">
               <div class="row align-items-end">
                  <div class="col-xl-7 col-lg-7 col-md-12">
                     <div class="it-course-title-box">
                        <span class="it-section-subtitle-4">
                           <img src="<?php echo esc_url($od_tutor_course_title_content_bg_img2['url'], 'odcore');?>" alt="">
                           <?php echo esc_html($tp_sub_title, 'odcore');?>
                        </span>
                        <h4 class="it-section-title-3"> <?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                  </div>
                  <div class="col-xl-5 col-lg-5 col-md-12">
                     <div class="it-course-button text-start text-lg-end pt-25">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <?php echo $settings['tp_btn_text']; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
                    <?php
                        global $post, $authordata;
                        while ($query->have_posts()) : $query->the_post(); 
                        $course_id         = $post->ID;
                        $review_count = tutor_utils()->get_course_review_count($course_id);
                        $course_duration   = get_tutor_course_duration_context( $course_id, true );
                        $terms = get_the_terms(get_the_ID(), 'course-category');
                        $profile_url = tutor_utils()->profile_url($authordata->ID);
                        $course_rating = tutor_utils()->get_course_rating();
                        $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                        $tutor_course_duration = get_tutor_course_duration_context(get_the_ID());
                        $course_students = tutor_utils()->count_enrolled_users_by_course();
                        $product_id = tutor_utils()->get_course_product_id();
                        $product    = wc_get_product( $product_id );
                    ?>

               <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                  <div class="it-course-item">
                     <div class="it-course-thumb mb-20 p-relative">
                        <a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                        <div class="it-course-thumb-text">
                                <?php foreach ($terms as $term) : ?>
                                <span>
                                    <a href="<?php echo get_term_link($term->slug, 'course-category'); ?>"><?php echo $term->name; ?></a>
                                </span>
                                <?php endforeach; ?>
                        </div>
                     </div>
                     <div class="it-course-content"> 
                            <?php
                                $course_rating = tutor_utils()->get_course_rating();
                                tutor_utils()->star_rating_generator_course( $course_rating->rating_avg );
                            ?>
                           <span>(<?php echo apply_filters('tutor_course_rating_count', $course_rating->rating_count) ;?>)</span>
                        </div>
                        <h4 class="it-course-title pb-5"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                        <div class="it-course-info pb-15 mb-25 d-flex justify-content-between">
                           <span><i class="fa-light fa-file-invoice"></i><?php print esc_html__('lessons', 'odcore'); ?> <?php echo $tutor_lesson_count; ?></span>
                           <span><i class="fa-sharp fa-regular fa-clock"></i><?php echo $course_duration; ?></span>
                           <span><i class="fa-light fa-user"></i><?php echo esc_html($course_students, 'odcore');?></span>
                        </div>
                        <div class="it-course-author pb-15">
                           <?php echo get_avatar(get_the_author_meta('ID'), 50) ?>
                           <span><?php echo esc_html__('By', 'odcore');?> <i><?php echo get_the_author_meta('display_name', get_the_author_meta('ID')); ?></i></span>
                        </div>
                        <div class="it-course-price-box d-flex justify-content-between">
                               <?php
                                        $course_id = get_the_ID();
                                        $default_price = apply_filters('tutor-loop-default-price', __('Free', 'micourse'));
                                        $price_html = '<span> ' . $default_price . '</span>';
                                        if (tutor_utils()->is_course_purchasable()) {

                                            $product_id = tutor_utils()->get_course_product_id($course_id);
                                            $product = wc_get_product($product_id);

                                            if ($product) {
                                                $price_html = '<span> ' . $product->get_price_html() . ' </span>';
                                            }
                                        }
                                        echo $price_html;
                                    ?>
                           <a href="<?php the_permalink();?>"><i class="fa-light fa-cart-shopping"></i><?php echo esc_html__('View Details', 'odcore');?></a>
                        </div>
                     </div>
                  </div>
                <?php endwhile; wp_reset_query(); ?>
               </div>
            </div>
         </div>
      </div>

        <?php elseif ($settings['od_design_style'] === 'layout-3'):

               // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square theme');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square theme');
                }
            }


        ?>

          <!-- course-area-start -->
      <div class="it-course-area it-course-style-3 it-course-style-4 it-course-bg p-relative pt-120 pb-90">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="it-course-title-wrap mb-60">
               <div class="row align-items-end">
                  <div class="col-xl-7 col-lg-7 col-md-8">
                     <div class="it-course-title-box">
                        <span class="it-section-subtitle-5 purple-2">
                           <img src="<?php echo esc_url($od_tutor_course_title_content_bg_img2['url'], 'odcore');?>" alt="">
                           <?php echo esc_html($tp_sub_title, 'odcore');?>
                        </span>
                        <h4 class="it-section-title-3"><?php echo tp_kses($tp_title, 'odcore');?></h4>
                     </div>
                  </div>
                  <div class="col-xl-5 col-lg-5 col-md-4">
                     <div class="it-course-button text-start text-md-end pt-25">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <span>
                            <?php echo $settings['tp_btn_text']; ?>
                           </span>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
                <?php
                    global $post, $authordata;
                    while ($query->have_posts()) : $query->the_post();
                    $course_id         = $post->ID;
                    $course_duration   = get_tutor_course_duration_context( $course_id, true );
                    $terms = get_the_terms(get_the_ID(), 'course-category');
                    $profile_url = tutor_utils()->profile_url($authordata->ID);
                    $course_rating = tutor_utils()->get_course_rating();
                    $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                    $tutor_course_duration = get_tutor_course_duration_context(get_the_ID());
                    $course_students = tutor_utils()->count_enrolled_users_by_course();
                    $product_id = tutor_utils()->get_course_product_id();
                    $product    = wc_get_product( $product_id );
                ?>
               <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="ed-course-2-item">
                     <div class="it-course-thumb p-relative">
                        <a href="course-details.html"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                        <div class="it-course-thumb-text"> 
                            <?php foreach ($terms as $term) : ?>
                           <span>
                                <a href="<?php echo get_term_link($term->slug, 'course-category'); ?>"><?php echo $term->name; ?></a>
                           </span>
                            <?php endforeach; ?>
                        </div>
                     </div>
                     <div class="it-course-content">
                        <div class="d-flex align-items-center justify-content-between mb-5">
                           <div class="it-course-rating">
                             <?php
                                $course_rating = tutor_utils()->get_course_rating();
                                tutor_utils()->star_rating_generator_course( $course_rating->rating_avg );
                            ?>
                               <span>(<?php echo apply_filters('tutor_course_rating_count', $course_rating->rating_count) ;?>)</span>
                           </div>
                           <div class="it-course-price-box d-flex justify-content-between">
                              
                               <?php
                                     $course_id = get_the_ID();
                                     $default_price = apply_filters('tutor-loop-default-price', __('Free', 'micourse'));
                                     $price_html = '<span> ' . $default_price . '</span>';
                                     if (tutor_utils()->is_course_purchasable()) {

                                         $product_id = tutor_utils()->get_course_product_id($course_id);
                                         $product = wc_get_product($product_id);

                                         if ($product) {
                                             $price_html = '<span> ' . $product->get_price_html() . ' </span>';
                                         }
                                     }
                                     echo $price_html;
                                 ?>
                           </div>
                        </div>
                        <h4 class="it-course-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                        <div class="it-course-author pb-20">
                           <?php echo get_avatar(get_the_author_meta('ID'), 50) ?>
                           <span><?php echo esc_html__('By' ,'odcore');?> <i><?php echo get_the_author_meta('display_name', get_the_author_meta('ID')); ?></i></span>
                        </div>
                        <div class="it-course-info pb-15 mb-10 d-flex justify-content-between">
                           <span><i class="fa-light fa-file-invoice"></i><?php echo $tutor_lesson_count; ?> <?php print esc_html__('lessons', 'odcore'); ?></span>
                           <span><i class="fa-sharp fa-regular fa-clock"></i><?php echo $course_duration; ?></span>
                           <span><i class="fa-light fa-user"></i><?php echo esc_html($course_students, 'odcore');?></span>
                        </div>                       
                     </div>
                  </div>
               </div>
                <?php endwhile; wp_reset_query(); ?>



            </div>
         </div>
      </div>
      <!-- course-area-end -->


        <?php elseif ($settings['od_design_style'] === 'layout-4'): 



               // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-square orange');
                }
            }


        ?>
            <!-- course-area-start -->
      <div class="it-course-area ed-course-bg ed-course-style-3 p-relative pt-120 pb-90">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="ed-course-title-wrap mb-65">
               <div class="row align-items-center">
                  <div class="col-xl-6">
                     <div class="it-course-title-box">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        </h4>
                     </div>
                  </div>
                  <div class="col-xl-6">
                     <div class="ed-course-button text-lg-end">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <?php echo $settings['tp_btn_text']; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
                    <?php
                        global $post, $authordata;
                        while ($query->have_posts()) : $query->the_post();
                        $course_id         = $post->ID;
                        $course_duration   = get_tutor_course_duration_context( $course_id, true );
                        $terms = get_the_terms(get_the_ID(), 'course-category');
                        $profile_url = tutor_utils()->profile_url($authordata->ID);
                        $course_rating = tutor_utils()->get_course_rating();
                        $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                        $tutor_course_duration = get_tutor_course_duration_context(get_the_ID());
                        $course_students = tutor_utils()->count_enrolled_users_by_course();
                        $product_id = tutor_utils()->get_course_product_id();
                        $product    = wc_get_product( $product_id );
                    ?>



               <div class="col-xl-4 col-lg-6 col-md-6 mb-30 wow itfadeUp" data-wow-duration=".9s"
               data-wow-delay=".3s">
                  <div class="it-course-item ed-course-style-2">
                     <div class="it-course-thumb mb-25 p-relative">
                        <a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                        <div class="it-course-thumb-text">
                           <span>
                                <?php foreach ($terms as $term) : ?>
                                    <a href="<?php echo get_term_link($term->slug, 'course-category'); ?>"><?php echo $term->name; ?></a>
                                <?php endforeach; ?>
                               
                           </span>
                        </div>
                     </div>
                     <div class="it-course-content p-relative">
                        <div class="it-course-rating mb-10 d-flex align-items-center justify-content-between">
                           <div>
                            <span class="star_show">
                                 <?php
                                        $course_rating = tutor_utils()->get_course_rating();
                                        tutor_utils()->star_rating_generator_course( $course_rating->rating_avg );
                                    ?>
                            </span>
                              <span><?php apply_filters('tutor_course_rating_count', $course_rating->rating_count) ;?></span>
                           </div>
                           <div class="it-course-price-box">
                              
                               <?php
                                     $course_id = get_the_ID();
                                     $default_price = apply_filters('tutor-loop-default-price', __('Free', 'micourse'));
                                     $price_html = '<span> ' . $default_price . '</span>';
                                     if (tutor_utils()->is_course_purchasable()) {

                                         $product_id = tutor_utils()->get_course_product_id($course_id);
                                         $product = wc_get_product($product_id);

                                         if ($product) {
                                             $price_html = '<span> ' . $product->get_price_html() . ' </span>';
                                         }
                                     }
                                     echo $price_html;
                                 ?>
                           </div>
                        </div>
                        <h4 class="it-course-title pb-15"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                        <div class="it-course-info pb-15 mb-30 d-flex justify-content-between">
                           <span><i class="fa-light fa-file-invoice"></i><?php echo $tutor_lesson_count; ?> <?php print esc_html__('lessons', 'odcore'); ?></span>
                           <span><i class="fa-sharp fa-regular fa-clock"></i><?php echo $course_duration; ?></span>
                           <span><i class="fa-light fa-user"></i><?php echo esc_html($course_students, 'odcore');?></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                           <div class="it-course-author">
                              <?php echo get_avatar(get_the_author_meta('ID'), 50) ?> 
                              <span><?php echo get_the_author_meta('display_name', get_the_author_meta('ID')); ?></span>
                           </div>
                           <div class="ed-course-price-box">
                              <a class="ed-course-btn" href="<?php the_permalink();?>"><?php echo esc_html__('Enroll', 'odcore');?>
                                 <span>
                                    <svg width="21" height="8" viewBox="0 0 21 8" fill="none"
                                       xmlns="http://www.w3.org/2000/svg">
                                       <path
                                          d="M20.3536 4.35355C20.5488 4.15829 20.5488 3.84171 20.3536 3.64645L17.1716 0.464466C16.9763 0.269204 16.6597 0.269204 16.4645 0.464466C16.2692 0.659728 16.2692 0.976311 16.4645 1.17157L19.2929 4L16.4645 6.82843C16.2692 7.02369 16.2692 7.34027 16.4645 7.53553C16.6597 7.7308 16.9763 7.7308 17.1716 7.53553L20.3536 4.35355ZM0 4.5H20V3.5H0V4.5Z"
                                          fill="currentcolor" />
                                    </svg>
                                 </span>
                              </a>
                           </div>
                        </div>
                        <div class="ed-course-shape">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/course/ed-item-shape.png" alt="">
                        </div>
                     </div>
                  </div>
               </div>
                <?php endwhile; wp_reset_query(); ?>


            </div>
         </div>
      </div>
      <!-- course-area-end -->

        <?php else:


              // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'ed-btn-theme');
                }
            }



        ?>

            <!-- course-area-start -->
      <div class="it-course-area ed-course-bg ed-course-style-3 p-relative pt-120 pb-90" style="background-image:url(<?php echo esc_url($od_tutor_course_title_content_bg_img['url'], 'odcore');?>)">
         <div class="container">
            <?php if(!empty($tp_section_title_show)):?>
            <div class="ed-course-title-wrap mb-65">
               <div class="row align-items-center">
                  <div class="col-xl-8 col-lg-8 col-md-7">
                     <div class="it-course-title-boxmb-70">
                        <span class="ed-section-subtitle"><?php echo esc_html($tp_sub_title, 'odcore');?></span>
                        <h4 class="ed-section-title"><?php echo tp_kses($tp_title, 'odcore');?>
                        <?php if(!empty($tp_title2)):?>
                           <span class="p-relative ed-title-shape  z-index"><?php echo tp_kses($tp_title2, 'odcore');?>
                              <svg width="168" height="65" viewBox="0 0 168 65" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path
                                    d="M73.3791 8.52241C78.4861 6.03398 82.5735 4.26476 88.8944 3.31494C94.2074 2.51659 99.6315 2.08052 104.982 1.95274C120.428 1.5839 135.136 4.94481 146.513 9.7789C158.639 14.931 166.74 22.7171 166.094 31.8511C165.316 42.8363 151.375 52.0035 133.539 57.1364C110.286 63.8284 81.7383 64.1305 58.5896 61.1289C37.5299 58.3982 11.6525 51.9446 3.59702 40.1836C-3.42072 29.9382 12.0777 18.2085 27.5463 11.6691C40.3658 6.24978 55.7075 2.97602 70.8049 4.09034C81.9407 4.91227 93.2195 6.91079 102.467 10.0494C112.882 13.5844 120.151 18.7016 127.875 23.7722"
                                    stroke="#704FE6" stroke-width="3" stroke-linecap="round" />
                              </svg>

                           </span>
                       <?php endif;?>
                           <?php echo tp_kses($tp_title3, 'odcore');?>
                        </h4>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 col-md-5">
                     <div class="ed-course-button text-md-end">
                       <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>>
                            <?php echo $settings['tp_btn_text']; ?>
                           <i>
                              <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                    stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10"
                                    stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                           </i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
        <?php endif;?>
            <div class="row">
                    <?php
                        global $post, $authordata;
                        while ($query->have_posts()) : $query->the_post();

                        $course_id         = $post->ID;
                        $review_count = tutor_utils()->get_course_review_count($course_id);
                        $course_duration   = get_tutor_course_duration_context( $course_id, true );
                        $terms = get_the_terms(get_the_ID(), 'course-category');
                        $profile_url = tutor_utils()->profile_url($authordata->ID);
                        $course_rating = tutor_utils()->get_course_rating();
                        $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                        $tutor_course_duration = get_tutor_course_duration_context(get_the_ID());
                        $course_students = tutor_utils()->count_enrolled_users_by_course();
                        $product_id = tutor_utils()->get_course_product_id();
                        $product    = wc_get_product( $product_id );
                    ?>

               <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
                  <div class="it-course-item ed-course-style-2">
                     <div class="it-course-thumb mb-25 p-relative">
                        <a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                        <div class="it-course-thumb-text">
                            <?php foreach ($terms as $term) : ?>
                                <span>
                                    <a href="<?php echo get_term_link($term->slug, 'course-category'); ?>"><?php echo $term->name; ?></a>
                                </span>
                            <?php endforeach; ?>
                        </div>
                     </div>
                     <div class="it-course-content p-relative">
                        <div class="it-course-rating mb-10 d-flex align-items-center justify-content-between">
                           <div>

                            <span class="star_show">
                                 <?php
                                $course_rating = tutor_utils()->get_course_rating();
                                tutor_utils()->star_rating_generator_course( $course_rating->rating_avg );
                            ?>
                            </span>

                                                  
                              <span>(<?php echo apply_filters('tutor_course_rating_count', $course_rating->rating_count) ;?>)</span>
                           </div>
                           <div class="it-course-price-box">
                               <?php
                                        $course_id = get_the_ID();
                                        $default_price = apply_filters('tutor-loop-default-price', __('Free', 'odcore'));
                                        $price_html = '<span> ' . $default_price . '</span>';
                                        if (tutor_utils()->is_course_purchasable()) {

                                            $product_id = tutor_utils()->get_course_product_id($course_id);
                                            $product = wc_get_product($product_id);

                                            if ($product) {
                                                $price_html = '<span> ' . $product->get_price_html() . ' </span>';
                                            }
                                        }
                                        echo $price_html;
                                    ?>
                           </div>


                        </div>
                        <h4 class="it-course-title pb-15"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                        <div class="it-course-info pb-15 mb-30 d-flex justify-content-between">
                           <span><i class="fa-light fa-file-invoice"></i><?php print esc_html__('lessons', 'odcore'); ?> <?php echo $tutor_lesson_count; ?></span>
                           <span><i class="fa-sharp fa-regular fa-clock"></i><?php echo $course_duration; ?></span>
                           <span><i class="fa-light fa-user"></i><?php echo esc_html($course_students, 'odcore');?></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                           <div class="it-course-author">
                              <?php echo get_avatar(get_the_author_meta('ID'), 50) ?> <span><?php echo get_the_author_meta('display_name', get_the_author_meta('ID')); ?></span>
                           </div>
                           <div class="ed-course-price-box">
                              <a class="ed-course-btn" href="<?php the_permalink();?>"><?php echo esc_html__('Enroll', 'odcore');?>
                                 <span>
                                    <svg width="21" height="8" viewBox="0 0 21 8" fill="none"
                                       xmlns="http://www.w3.org/2000/svg">
                                       <path
                                          d="M20.3536 4.35355C20.5488 4.15829 20.5488 3.84171 20.3536 3.64645L17.1716 0.464466C16.9763 0.269204 16.6597 0.269204 16.4645 0.464466C16.2692 0.659728 16.2692 0.976311 16.4645 1.17157L19.2929 4L16.4645 6.82843C16.2692 7.02369 16.2692 7.34027 16.4645 7.53553C16.6597 7.7308 16.9763 7.7308 17.1716 7.53553L20.3536 4.35355ZM0 4.5H20V3.5H0V4.5Z"
                                          fill="currentcolor" />
                                    </svg>
                                 </span>
                              </a>
                           </div>
                        </div>
                        <div class="ed-course-shape">
                           <img src="<?php echo get_template_directory_uri();?>/assets/img/course/ed-item-shape.png" alt="">
                        </div>
                     </div>
                  </div>
               </div>
                <?php endwhile; wp_reset_query(); ?>

            </div>
         </div>
      </div>
      <!-- course-area-end -->

    

    	<?php endif; ?>

       <?php
	}

}

$widgets_manager->register( new TP_Tutor_Course() );