<?php 
/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  tvcore
 */
get_header(); 


?>


 <!-- teacher-details-area-start -->
      <div class="it-teacher-details-area pt-120 pb-120">
         <div class="container">
            <div class="it-teacher-details-wrap">
               <div class="row">


               <?php 
                      if( have_posts() ):
                      while( have_posts() ): the_post();
                          $instructor_designation = function_exists('get_field') ? get_field('instructor_designation') : '';
                          $facebook = function_exists('get_field') ? get_field('facebook') : '';
                          $twitter = function_exists('get_field') ? get_field('twitter') : '';
                          $skype = function_exists('get_field') ? get_field('skype') : '';
                          $linkedin = function_exists('get_field') ? get_field('linkedin') : '';
                          $phone = function_exists('get_field') ? get_field('phone') : '';
                          $address = function_exists('get_field') ? get_field('address') : '';
                          $address_url = function_exists('get_field') ? get_field('address_url') : '';
                          $email = function_exists('get_field') ? get_field('email') : '';
                          $button_text = function_exists('get_field') ? get_field('button_text') : '';
                          $button_url = function_exists('get_field') ? get_field('button_url') : '';
                          $skill_title = function_exists('get_field') ? get_field('skill_title') : '';
                          $skill_name = function_exists('get_field') ? get_field('skill_name') : '';
                  ?> 
                  <div class="col-xl-3 col-lg-3">
                     <div class="it-teacher-details-left">
                        <div class="it-teacher-details-left-thumb">
                           <img src="<?php the_post_thumbnail_url();?>" alt="">
                        </div>
                        <div class="it-teacher-details-left-social text-center">
                        <?php if(!empty($facebook)):?>
                           <a href="<?php echo esc_url($facebook, 'tvcore');?>"><i class="fab fa-facebook-f"></i></a>
                        <?php endif;?>
                        <?php if(!empty($twitter)):?>
                           <a href="<?php echo esc_url($twitter, 'tvcore');?>"><i class="fab fa-twitter"></i></a>
                        <?php endif;?>
                        <?php if(!empty($skype)):?>
                           <a href="<?php echo esc_url($skype, 'tvcore');?>"><i class="fab fa-skype"></i></a>
                        <?php endif;?>
                        <?php if(!empty($linkedin)):?>
                           <a href="<?php echo esc_url($linkedin, 'tvcore');?>"><i class="fab fa-linkedin-in"></i></a>
                        <?php endif;?>
                        </div>
                        <div class="it-teacher-details-left-info">
                           <ul>
                              <li>
                                 <i class="fa-light fa-phone-volume"></i>
                                 <a href="tel:<?php echo esc_attr($phone, 'tvcore');?>"><?php echo esc_html($phone, 'tvcore');?></a>
                              </li>
                              <li>
                                 <i class="fa-light fa-location-dot"></i>
                                 <a href="<?php echo esc_url($address_url, 'tvcore');?>" target="_blank"><?php echo esc_html($address, 'tvcore');?></a>
                              </li>
                              <li>
                                 <i class="fa-light fa-envelope"></i>
                                 <a href="mailto:<?php echo esc_attr($email, 'tvcore');?>"><?php echo esc_html($email, 'tvcore');?></a>
                              </li>
                           </ul>
                        </div>
                        <div class="it-teacher-details-left-btn">
                           <a class="ed-btn-theme" href="<?php echo esc_url($button_url, 'tvcore');?>">
                              <span>
                                 <?php echo esc_html($button_text, 'tvcore');?>
                                 <i>
                                    <svg width="17" height="14" viewBox="0 0 17 14" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11 1.24023L16 7.24023L11 13.2402" stroke="currentcolor" stroke-width="1.5"
                                       stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M1 7.24023H16" stroke="currentcolor" stroke-width="1.5"
                                       stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                                 </svg>
                                 </i>
                              </span>
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9">
                     <div class="it-teacher-details-right">
                        <div class="it-teacher-details-right-title-box">
                           <h4><?php the_title();?></h4>
                           <span><?php echo esc_html($instructor_designation, 'tvcore');?></span>
                           <?php the_content();?>
                        </div>
                        <style type="text/css">
                           

                        </style>
                      
                        <div class="it-progress-bar-wrap inner-style">
                           <h4><?php echo esc_html($skill_title,  'tvcore');?></h4>
                           <?php foreach($skill_name as $single_item):?>
                           <div class="it-progress-bar-item">
                              <label><?php echo esc_html($single_item['single_skill_name'], 'tvcore');?></label>
                              <div class="it-progress-bar">
                                 <div class="progress">
                                       
                                    <div class="progress-bar wow slideInLeft" data-wow-delay=".1s"
                                       data-wow-duration="2s" role="progressbar" data-width="<?php echo esc_attr($single_item['skill_percentage_number'], 'tvcore');?>%" aria-valuenow="<?php echo esc_attr($single_item['skill_percentage_number'], 'tvcore');?>"
                                       aria-valuemin="0" aria-valuemax="100"
                                       style="width: <?php echo esc_attr($single_item['skill_percentage_number'], 'tvcore');?>%; background-color:<?php echo esc_attr($single_item['skill_bar_color'], 'tvcore');?>; visibility: visible; animation-duration: 2s; animation-delay: 0.1s; animation-name: slideInLeft;">
                                       <span ><?php echo esc_html($single_item['skill_percentage_number'], 'tvcore');?>%</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        <?php endforeach;?>

                        </div>
                     </div>
                  </div>

                  <?php 
                      endwhile; wp_reset_query();
                     endif; 
                  ?>
               </div>
            </div>
         </div>
      </div>
      <!-- teacher-details-area-end -->


       <!-- team-area-start -->
      <div class="ed-team-area grey-bg-5 p-relative inner-style fix z-index pt-110 pb-120">
         <div class="container">
            <div class="it-team-title-wrap mb-40">
               <div class="row align-items-center justify-content-center">
                  <div class="col-xl-6">
                     <div class="it-team-title-box text-center">
                        <?php



                    $sub_title = function_exists('get_field') ? get_field('sub_title') : '';
                    $title = function_exists('get_field') ? get_field('title') : ''; 




                        ?>
                        <span class="ed-section-subtitle"><?php echo esc_html($sub_title, 'tvcore');?></span>
                        <h4 class="ed-section-title"><?php echo esc_html($title, 'tvcore');?>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
            <div class="ed-team-wrapper">
               <div class="swiper-container ed-team-active">
                  <div class="swiper-wrapper">


               <?php
                  $args = array(
                    'post_type'      => 'team',
                    'posts_per_page' => -1,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                );

                // Create a new instance of WP_Query
                $query = new WP_Query($args);
                if( $query->have_posts() ):
                while( $query->have_posts() ): $query->the_post();
                  
             
               ?>
                     <div class="swiper-slide">
                        <div class="ed-team-item">
                           <div class="ed-team-thumb fix">
                              <img src="<?php the_post_thumbnail_url();?>" alt="">
                           </div>
                           <div class="ed-team-content p-relative">
                              <div class="ed-team-social-box p-relative">
                                 <button>
                                    <i class="fa-light fa-share-nodes"></i>
                                 </button>
                                 <div class="ed-team-social-wrap">
                                       <?php if(!empty($facebook)):?>
                                          <a href="<?php echo esc_url($facebook, 'tvcore');?>"><i class="fab fa-facebook-f"></i></a>
                                       <?php endif;?>
                                       <?php if(!empty($twitter)):?>
                                          <a href="<?php echo esc_url($twitter, 'tvcore');?>"><i class="fab fa-twitter"></i></a>
                                       <?php endif;?>
                                       <?php if(!empty($skype)):?>
                                          <a href="<?php echo esc_url($skype, 'tvcore');?>"><i class="fab fa-skype"></i></a>
                                       <?php endif;?>
                                       <?php if(!empty($linkedin)):?>
                                          <a href="<?php echo esc_url($linkedin, 'tvcore');?>"><i class="fab fa-linkedin-in"></i></a>
                                       <?php endif;?>
                                 </div>
                              </div>
                              <div class="ed-team-author-box">
                                 <h4 class="ed-team-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                 <span><?php echo esc_html($instructor_designation, 'tvcore');?></span>
                              </div>
                           </div>
                        </div>
                     </div>

                  <?php 
                      endwhile; wp_reset_query();
                     endif; 
                  ?>
                  </div>
                  <div class="ed-team-arrow-box mt-65 text-center">
                     <button class="slider-prev">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M9.57031 5.92969L3.50031 11.9997L9.57031 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                           <path d="M20.5 12H3.67" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                         </svg>
                     </button>
                     <button class="slider-next">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.4297 5.92969L20.4997 11.9997L14.4297 18.0697" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                           <path d="M3.5 12H20.33" stroke="currentcolor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
                         </svg>
                     </button>          
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- team-area-end -->




<?php get_footer();  ?>