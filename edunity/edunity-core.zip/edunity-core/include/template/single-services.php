<?php 
/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  tvcore
 */
get_header(); 

$post_column = is_active_sidebar( 'service-sidebar' ) ? 9 : 10;
$post_column_center = is_active_sidebar( 'service-sidebar' ) ? '' : 'justify-content-center';

?>
  
      <!-- service details area start -->
      <div class="it-service-details__area pt-120 pb-100">
         <div class="container">

        <?php if( have_posts() ) : while( have_posts() ) : the_post();
          $thumbnail = function_exists( 'get_field' ) ? get_field( 'thumbnail' ) : NULL;
          $video_url = function_exists( 'get_field' ) ? get_field( 'video_url' ) : NULL;
          $extra_description = function_exists( 'get_field' ) ? get_field( 'extra_description' ) : NULL;
          ?>
            <div class="row">
               <div class="col-xl-<?php echo esc_attr($post_column);?> col-lg-<?php echo esc_attr($post_column);?>">
                <div class="service_details_wrapp ml-40 ">
                <?php the_content();?>
               <?php if(!empty($thumbnail['url'])):?>

               <div class="it-sv-details-middle-thumb p-relative mb-30">
                  <img src="<?php echo esc_url($thumbnail['url']);?>" alt="">
                  <a class="popup-video it-pulse" href="<?php echo esc_url($video_url);?>"><i class="fa-sharp fa-solid fa-play"></i></a>
               </div>
                <?php endif;?>
                    <?php echo tp_kses($extra_description);?>  
                </div>         
               </div>
               <?php if ( is_active_sidebar('service-sidebar') ): ?> 
               <div class="col-xl-3 col-lg-3 mb-50">
                  <div class="it-sv-details-sidebar">

                          <?php dynamic_sidebar( 'service-sidebar' ); ?>

                 </div>
               </div>
             <?php endif;?>
            
            </div>
         </div>
        <?php 
            endwhile; wp_reset_query();
            endif; 
        ?>

      </div>
      <!-- service details area end -->



<?php get_footer();  ?>