<?php get_header();
    global $post;


      $lesson = function_exists('get_field') ? get_field('lesson') : '';
      $time = function_exists('get_field') ? get_field('time') : '';
      $location = function_exists('get_field') ? get_field('location') : '';
      $date = function_exists('get_field') ? get_field('date') : '';
      $event_fee = function_exists('get_field') ? get_field('event_fee') : '';
      $button = function_exists('get_field') ? get_field('button') : '';
      $button_url = function_exists('get_field') ? get_field('button_url') : '';

?>

<div class="it-event-details-area pt-120 pb-120">
         <div class="container">
            <div class="row">
               <div class="col-xl-9 col-lg-8">
                  <div class="it-evn-details-wrap">
                     <div class="it-evn-details-thumb mb-35">
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                     </div>
                     <h4 class="it-evn-details-title"><?php the_title();?></h4>
                     <div class="postbox__meta">
                        <?php if(!empty($lesson)):?>
                        <span><i class="fa-light fa-file-invoice"></i><?php echo esc_html__('Lesson', 'tvcore');?> <?php echo esc_html($lesson, 'tvcore');?></span>
                    <?php endif;?>
                    <?php if(!empty($time)):?>
                        <span><i class="fa-light fa-clock"></i><?php echo esc_html($time, 'tvcore');?></span>
                    <?php endif;?>
                    <?php if(!empty($location)):?>
                        <span><i class="fa-light fa-location-dot"></i><?php echo esc_html($location, 'tvcore');?></span>
                    <?php endif;?>
                     </div>
                    <?php the_content();?>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-4">
                  <div class="it-evn-sidebar-box it-course-sidebar-box">
                     <div class="it-evn-sidebar-thumb mb-30">
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                     </div>
                     <div class="it-evn-sidebar-list mb-30">
                        <ul>
                        <?php if(!empty($date)):?>
                           <li><span><?php echo esc_html('Date', 'tvcore');?></span> <span><?php echo esc_html($date, 'tvcore');?></span></li>
                        <?php endif;?>
                        <?php if(!empty($location)):?>
                           <li><span><?php echo esc_html('Venue', 'tvcore');?></span> <span><?php echo esc_html($location, 'tvcore');?></span></li>
                        <?php endif;?>
                        <?php if(!empty($time)):?>
                           <li><span><?php echo esc_html('Time', 'tvcore');?></span> <span><?php echo esc_html($time, 'tvcore');?></span></li>
                       <?php endif;?>
                        <?php if(!empty($event_fee)):?>
                           <li><span><?php echo esc_html('Event Fee', 'tvcore');?></span> <span class="rate"><?php echo esc_html($event_fee, 'tvcore');?></span></li>
                       <?php endif;?>
                        </ul>
                     </div>

                     <a class="ed-btn-square radius purple-4 w-100 text-center mb-20" href="<?php echo esc_url($button_url, 'tvcore');?>"> 
                        <span>
                          <?php echo esc_html($button, 'tvcore');?>
                        </span>
                     </a>
                  </div>
               </div>
            </div>

         </div>
      </div>





<?php get_footer();